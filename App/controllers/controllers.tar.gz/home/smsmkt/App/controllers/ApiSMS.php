<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiSMS AS ApiSMSDao;
use \App\models\CampaignBuscaCarrier AS CampaignBuscaCarrierDao;
include_once "/home/smsmkt/public/PHPMailer/PHPMailerAutoload.php";

class ApiSMS{

  public function crearToken($fecha, $user, $password){
    $fecha1 = md5($fecha);
    $fecha2 = md5($fecha1);
    $username = md5("$user-$password");
    return md5("$username-$fecha2");
  }

  public function SubmitJson(){
    $input = json_decode(file_get_contents("php://input"), 1);
    MasterDom::validateIp($input['acceso']['user']);
    MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));

    $input['acceso']['fecha'] = date('Y-m-d H:i:s');
    $input['acceso']['token'] = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $input['acceso']['token']);

    if( $vacio == 0 && $valido == 0 ){

      $campaign_id = $input['card']['campaign'];
      $customer_id = $input['card']['customer'];
      $carrier_id = $input['card']['carrier'];
      $destination = $input['card']['destination'];
      $source = $input['card']['source'];
      $contenido = $input['card']['text'];
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, $destination);//verificacion de limites de envio

      echo $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier_id, $destination, $source, $contenido);
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function SubmitMultiJson(){
    $input = json_decode(file_get_contents("php://input"), 1);
    MasterDom::validateIp($input['acceso']['user']);
    MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));

    $input['acceso']['fecha'] = date('Y-m-d H:i:s');
    $input['acceso']['token'] = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $input['acceso']['token']);

    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['card']['campaign'];
      $customer_id = $input['card']['customer'];
      $carrier_id = $input['card']['carrier'];
      $destinations = $input['card']['destination'];
      $source = $input['card']['source'];
      $contenido = $input['card']['text'];
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, $destinations);//verificacion de limites de envio

      $success = array();
      foreach ($destinations as $key => $destination) {
        $response =  $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier_id, $destination, $source, $contenido);
        $response = json_decode($response);
        array_push($success,$response->success);
      }
      echo json_encode(array('success'=>$success));
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function SubmitMultiCarrierJson(){
    $input = json_decode(file_get_contents("php://input"), 1);
    MasterDom::validateIp($input['acceso']['user']);
    MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));
    MasterDom::validarCarrierMsisdn($input['card']['destination'] ,$input['card']['carrier']);

    $input['acceso']['fecha'] = date('Y-m-d H:i:s');
    $input['acceso']['token'] = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $input['acceso']['token']);

    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['card']['campaign'];
      $customer_id = $input['card']['customer'];
      $carrier = $input['card']['carrier'];
      $destinations = $input['card']['destination'];
      $source = $input['card']['source'];
      $contenido = $input['card']['text'];
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, $destinations);//verificacion de limites de envio

      $success = array();
      foreach ($destinations as $key => $destination) {
        $response = $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier[$key], $destination, $source, $contenido);
        $response = json_decode($response);
        array_push($success,$response->success);
      }
      echo json_encode(array('success'=>$success));
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function submitGet(){
    $input = array();
    $input['destination'] = MasterDom::getData('destination');
    $input['source'] = MasterDom::getData('source');
    $input['text'] = MasterDom::getData('text');
    $input['customer'] = MasterDom::getData('customer');
    $input['carrier'] = MasterDom::getData('carrier');
    $input['campaign'] = MasterDom::getData('campaign');
    $input['user'] = MasterDom::getData('user');
    $input['password'] = MasterDom::getData('password');

    MasterDom::validatePermission($input['user'], $input['customer'], MasterDom::getData('url'));
    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarUsuario($input['user'], $input['password']);

    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['campaign'];
      $customer_id = $input['customer'];
      $carrier_id = $input['carrier'];
      $destination = $input['destination'];
      $source = $input['source'];
      $contenido = $input['text'];
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, $destination);//verificacion de limites de envio
      echo $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier_id, $destination, $source, $contenido);
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function submitMultiGet(){
    $input = array();
    $input['destination'] = MasterDom::getData('destination');
    $input['source'] = MasterDom::getData('source');
    $input['text'] = MasterDom::getData('text');
    $input['customer'] = MasterDom::getData('customer');
    $input['carrier'] = MasterDom::getData('carrier');
    $input['campaign'] = MasterDom::getData('campaign');
    $input['user'] = MasterDom::getData('user');
    $input['password'] = MasterDom::getData('password');
    MasterDom::validatePermission($input['user'], $input['customer'], MasterDom::getData('url'));
    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarUsuario($input['user'], $input['password']);

    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['campaign'];
      $customer_id = $input['customer'];
      $carrier_id = $input['carrier'];
      $destinations = $input['destination'];
      $source = $input['source'];
      $contenido = $input['text'];
      $success = array();
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, explode(',',$destinations));//verificacion de limites de envio

      foreach(explode(',',$destinations) as $key => $destination) {
        $response = $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier_id, $destination, $source, $contenido);
        $response = json_decode($response);
        array_push($success,$response->success);
      }
      echo json_encode(array('success'=>$success));
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function submitMultiCarrierGet(){
    $input = array();
    $input['destination'] = MasterDom::getData('destination');
    $input['source'] = MasterDom::getData('source');
    $input['text'] = MasterDom::getData('text');
    $input['customer'] = MasterDom::getData('customer');
    $input['carrier'] = MasterDom::getData('carrier');
    $input['campaign'] = MasterDom::getData('campaign');
    $input['user'] = MasterDom::getData('user');
    $input['password'] = MasterDom::getData('password');

    MasterDom::validatePermission($input['user'], $input['customer'], MasterDom::getData('url'));
    MasterDom::validarCarrierMsisdn($input['destination'] ,$input['carrier']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarUsuario($input['user'], $input['password']);

    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['campaign'];
      $customer_id = $input['customer'];
      $carrier = explode(',',$input['carrier']);
      $destinations = $input['destination'];
      $source = $input['source'];
      $contenido = $input['text'];
      $campaign_id = $this->verificarCampaign($campaign_id, $customer_id);
      $this->verificarLimitesEnviosSMS($campaign_id, explode(',',$destinations));//verificacion de limites de envio
      
      $success = array();
      foreach (explode(',',$destinations) as $key => $destination) {
        $response = $this->agregarRegistroMsisdn($campaign_id,$customer_id, $carrier[$key], $destination, $source, $contenido);
        $response = json_decode($response);
        array_push($success,$response->success);
      }
      echo json_encode(array('success'=>$success));
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function moDetail(){
    $input = json_decode(file_get_contents("php://input"), 1);
    MasterDom::validateIp($input['acceso']['user']);
    MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));
    $input['acceso']['fecha'] = date('Y-m-d H:i:s');
    $input['acceso']['token'] = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarUsuario($input['acceso']['user'], $input['acceso']['password']);
    
    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['card']['campaign'];
      $carrier = $input['card']['carrier'];
      $from = $input['card']['from'];
      $to = $input['card']['to'];
      $text = $input['card']['text'];
      $mo = ApiSMSDao::getMOByDetail($input);
      if($mo!=null){
        echo json_encode(array('success'=>$mo));
      }else{
        echo json_encode(array('Error'=>"Sin MO's"));
      }
      
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  public function mo(){
    $input = json_decode(file_get_contents("php://input"), 1);
    MasterDom::validateIp($input['acceso']['user']);
    MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));
    $input['acceso']['fecha'] = date('Y-m-d H:i:s');
    $input['acceso']['token'] = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);

    $vacio = MasterDom::isArrayEmpty($input);
    $valido = MasterDom::validarUsuario($input['acceso']['user'], $input['acceso']['password']);
    
    if( $vacio == 0 && $valido == 0 ){
      $campaign_id = $input['card']['campaign'];
      $carrier = $input['card']['carrier'];
      $from = $input['card']['from'];
      $to = $input['card']['to'];
      $text = $input['card']['text'];
      $mo = ApiSMSDao::getMO($input);
      if($mo!=null){
        echo json_encode(array('success'=>$mo));
      }else{
        echo json_encode(array('Error'=>"Sin MO's"));
      }
    }else{
      $error = MasterDom::alertsService($vacio);
      if($error == ''){
        echo json_encode(MasterDom::alertsService($valido));
      }else{
        echo json_encode($error);
      }
    }
  }

  /*FUNCION QUE RECIBE DATOS PARA ENVIAR UN MENSAJE SMS DESDE LA PLATAFORMA*/
  public function agregarRegistroMsisdn($campaign_id,$customer_id, $carrier_id, $destination,$source,$contenido){
      $esJsonCampaign = CampaignBuscaCarrierDao::getCampaignApiWeb($campaign_id);
      $carrier_id = ($carrier == 'carrier')? 0 : $carrier_id;

      if(count($esJsonCampaign) > 0){
        $shortCodes = CampaignBuscaCarrierDao::getCarrierCustomerGroup($customer_id); //se obtienen las marcaciones del custoimer
        $marcacion = $this->buscarMarcacion($source, $shortCodes);
        if(is_array($marcacion)){
          $carriers = CampaignBuscaCarrierDao::getCarrierCustomer($customer_id, $marcacion['short_code_id']);
          $carrierShortCode = $this->buscarCarrierConectionId($carrier_id, $carriers);
          if(is_array($carrierShortCode) && $carrier_id != 0){
            /****************************************/

            $msisdn = CampaignBuscaCarrierDao::getMsisdnCatalogoMsisdn($destination);
            if(is_array($msisdn)){
              $msisdnId = $msisdn['msisdn_id'];
              if($carrier_id != $msisdn['carrier_id']){
                CampaignBuscaCarrierDao::updateMsisdnCarrier($msisdnId,$carrier_id);
              }
            }else{
              $msisdnId = CampaignBuscaCarrierDao::insertaMsisdn(substr($destination, -12), $carrierShortCode['carrier_id']);
            }

            if($carrier_id == 1){
              $msisdnWhiteList = CampaignBuscaCarrierDao::getMsisdnWhiteList($msisdnId, $carrier_id);
              if($msisdnWhiteList != ''){
                $statusWhiteList = $msisdnWhiteList['status'];
              }else{
                CampaignBuscaCarrierDao::insertMsisdnWhiteList( $msisdnId, $carrier_id, 1);
                $statusWhiteList = 1;
              }
            }

            $registro = CampaignBuscaCarrierDao::insertSmsCampaign($campaign_id, date('Y-m-d G:i:s'), $msisdnId, $carrierShortCode['carrier_connection_short_code_id'], 4,4, $contenido);
            return json_encode(array('success' => $registro));
            /****************************************/
          }else{
              $msisdn = CampaignBuscaCarrierDao::getMsisdnCatalogoMsisdn($destination);
              if(is_array($msisdn)){
                $msisdnId = $msisdn['msisdn_id'];
                if($carrier_id != $msisdn['carrier_id']){
                  CampaignBuscaCarrierDao::updateMsisdnCarrier($msisdnId,$carrier_id);
                }
              }else{
                $msisdnId = CampaignBuscaCarrierDao::insertaMsisdn(substr($destination, -12), $carrier_id);
              }

              if($carrier_id == 1){
                $msisdnWhiteList = CampaignBuscaCarrierDao::getMsisdnWhiteList($msisdnId, $carrier_id);
                if($msisdnWhiteList != ''){
                  $statusWhiteList = $msisdnWhiteList['status'];
                }else{
                  CampaignBuscaCarrierDao::insertMsisdnWhiteList( $msisdnId, $carrier_id, 1);
                  $statusWhiteList = 1;
                }
              }

              $registro = CampaignBuscaCarrierDao::insertSmsCampaign($campaign_id, date('Y-m-d G:i:s'), $msisdnId, -1, 10,4, $contenido);
              return json_encode(array('success' => $registro));
          }
        }else{
          return json_encode(MasterDom::alertsService($marcacion));
        }
      }else{
        return json_encode(MasterDom::alertsService(-10));
      }
  }

  public function verificarLimitesEnviosSMS($campaign_id, $destinations){
    $user_id = ApiSMSDao::getCampaignUser($campaign_id)['user_id']; 
    $customer_id = ApiSMSDao::getCampaignCustomer($campaign_id)['customer_id']; 

    if($user_id != '' && $customer_id != ''){

      /*TOTALES QUE PUEDE ENVIAR EL CUSTOMER*/
      $customer_day = (Object) CampaignBuscaCarrierDao::getTotalesCustomerDia($customer_id);
      $customer_month = (Object) CampaignBuscaCarrierDao::getTotalesCustomerMes($customer_id);
      /*TOTALES QUE PUEDE ENVIAR EL USUARIO*/
      $user_day = (Object) CampaignBuscaCarrierDao::getTotalesUserDia($user_id);
      $user_month = (Object) CampaignBuscaCarrierDao::getTotalesUserMes($user_id);

      if($customer_month->resta_mes > 0 ){
        if($customer_day->resta_dia > 0){
          /*VALIDACION CORRECTA*/
          if(count($destinations) <= $user_day->resta_dia){
            if(count($destinations) <= $customer_day->resta_dia){

            }else{
              echo json_encode(MasterDom::alertsService(-15,"porque trata de enviar: ".count($destinations)." y el customer solo puedes enviar: $customer_day->resta_dia"));
              exit;
            }
            
          }else{
            echo json_encode(MasterDom::alertsService(-15,"porque trata de enviar: ".count($destinations)." y el usuario solo puede enviar: $user_day->resta_dia"));
            exit;
          }

        }else{echo json_encode(MasterDom::alertsService(-14));exit;}
      }else{echo json_encode(MasterDom::alertsService(-13));exit;}
    }
  }

  public function verificarCampaign($campaign_id, $customer_id){
    if($campaign_id == ''){
      $campaign = ApiSMSDao::getCampaignByCustomerId($customer_id);
      if(!empty($campaign)){
        return $campaign['campaign_id'];
      }else{
        echo json_encode(array('Error' => 'El customer no cuenta con ninguna campaña'));
        exit;
      }
    }else{
      return $campaign_id;
    }
  }

  /*FUNCION QUE COMPARA LA MARCACION DE LA BASE DE DATOS DEL USUARIO CON LA MARCACION RECIBIDA*/
  public function buscarMarcacion($source, $shortCodes){
    foreach ($shortCodes as $key => $value) {
      if($value['short_code'] == $source){
        return $value;
      }
    }
    return -8;
  }

  /*FUNCION QUE BUSCA EL CARRIER ID DE LA BASE DE DATOS CON EL CARRIER RECIBIDO*/
  public function buscarCarrierConectionId($carrier, $carriers){
    foreach ($carriers as $key => $value) {
      if($value['carrier_connection_short_code_id'] == $carrier){
        return $value;
      }
    }
    return -9;
  }

}














