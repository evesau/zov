<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiUrl AS ApiUrlDao;

class ApiRcs{

  private $_contenedor;

    public function index(){
	
	echo "++ENTRA++\n";
	$clienteId = "1051983085880-i4a54imvajtjsihh5rbhl3unokijvv39.apps.googleusercontent.com";
	$redirect = "http://smppvier.amovil.mx:8080/ApiRcs/endpoint";
	$scope = "https://www.googleapis.com/auth/rcsbusinessmessaging";
	$dato = urlencode("https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=$clienteId&redirect_uri=$redirect&scope=$scope");
	//$data = file_get_contents($dato);
	//echo "--$data--\n";

	$parametros = "state=state_parameter_passthrough_value&access_type=offline&include_granted_scopes=true&response_type=code&client_id=$clienteId&redirect_uri=".urlencode($redirect)."&scope=".urlencode($scope);
	echo "/////$parametros////\n";
	$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,"https://accounts.google.com/o/oauth2/v2/auth");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$parametros);

// in real life you should use something like:
// curl_setopt($ch, CURLOPT_POSTFIELDS, 
//          http_build_query(array('postvar1' => 'value1')));

// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$server_output = curl_exec ($ch);

curl_close ($ch);

echo "--$server_output--\n";	

	$w = stream_get_wrappers();
echo 'openssl: ',  extension_loaded  ('openssl') ? 'yes':'no', "\n";
echo 'http wrapper: ', in_array('http', $w) ? 'yes':'no', "\n";
echo 'https wrapper: ', in_array('https', $w) ? 'yes':'no', "\n";
echo 'wrappers: ', var_export($w);
    }

    public function endpoint(){

	$p = print_r($_POST,1);
	$a = file_get_contents("php://input");
	$s = print_r($_SERVER, 1);
	mail('tecnico@airmovil.com','RCS ENDPOINT', "Server: $s\nPOST: $p\nInput: $a");
    }

    public function scope(){

        $p = print_r($_POST,1);
        $a = file_get_contents("php://input");
        mail('tecnico@airmovil.com','RCS SCOPE', $a);
    }
}
