<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Campania as CampaniaDao;
use \App\controllers\Contenedor;

class Campania
{

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader=<<<html
<!-- DataTables CSS -->
    <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
<script src="/js/jquery.dataTables.min.js"></script>
<script src="/js/dataTables.bootstrap.min.js"></script>
<script src="/js/bootbox.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
// var table = $('<div id="muestra-client"></div>').DataTable({
//                 "order": [[4, 'desc']]          
//             });

    var table = $('#muestra-cupones').DataTable({
        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing": "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
    });

    $("#checkAll").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });

    $(document).on("click", "#delete", function(e) {
            bootbox.confirm("&iquest;Borrar&aacute;s las campa&ntilde;a(s) seleccionada(s)?", function(result) {
                if (result) 
                    $( "#delete_form" ).submit();
            });
    });
} );
</script>
html;

        $row = CampaniaDao::getAllCampaign($id_custom);
        $html = '';
        foreach($row AS $key=>$value){
        $html.=<<<html
            <tr>
                <td><input type="checkbox" name="borrar[]" value="{$value['campaign_id']}"/></td>
                <td>{$value['campaign_id']}</td>
                <td>{$value['name']}</td>
                <td>{$value['delivery_date']}</td>
html;
        $fecha = date("Y-m-d H:i:s");
        if ($fecha >= $value['delivery_date'] || $value['campaign_status_id'] == 4) {
            $html.=<<<html
                <td class="text-center"> Sin acciones </td>
html;
        } else {
            $html.=<<<html
                <td class="text-center"><a href="/campania/edit/{$value['campaign_id']}" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
html;
        }
        $html.=<<<html
            </tr>
html;

        }

        $botonDelete =<<<html
<button id="delete" type="button" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></button>
html;

        $customer = MasterDom::getData('customer_id');

        $customer_id = MasterDom::getSession('customer_id');

        if ($customer_id == 1) {
            View::set('botonDelete',$botonDelete);
        }

        View::set('id_client',$id);
        View::set('table',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
  	    View::render("campania");
    
    }

    public function add(){
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">

<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

// <script>
// $(document).ready(function() {
//     $("#add").validate({
//             rules: {
//                 nombre_campania: {
//                     required: true
//                 },
//                 datetimepicker:{
//                     required:true
//                 }
//             messages:
//             }
//     });
// });
// </script>

<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
    <script>    
        $(document).ready(function() {
            jQuery('#datetimepicker').datetimepicker();

            $("#add").validate(
                {
                    rules: {
                        nombre_campania: {
                            required: true,
                            maxlength: 60,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania: {
                            required: "Escriba un nombre de campa&ntilde;a, minimo de 3 caracteres y maximo de 60"
                        },
                        datetimepicker: {
                            required: "Ingrese fecha y hora de lanzamiento"
                        }
                    }
                });

            setInterval(function(){ 
                $.get( "/campania/getTime", function( data ) {
                        $( "#fecha_sistema" ).html( data );
                });
            }, 1000);

            $(".seleccion").on("change",function(){
                var id = $(this).attr("valor");

                $("fieldset").attr("disabled",true);
                $(".existente_valida_dato_"+id).attr("disabled",false);


            });
        }); 
    </script>
html;
        
        $shortCodeHtml = '';
        foreach(CampaniaDao::getShortCode() AS $k=>$value){
            $ids = CampaniaDao::getCarrierCustomer($id_custom, $value['short_code_id']); 
            if(empty($ids))
                continue;
                $disabled = ($k == 0) ? '' : 'disabled';
                $check = ($k == 0) ? 'checked="checked"' : '';
                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Marcacion :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <label class="action">
                                    <input class="seleccion" value="_dato_{$k}" name="iCheck" $check type="radio" valor="{$k}"> {$value['short_code']}
                                </label>
                                <input type="hidden" name="short_code_id" value="{$value['short_code_id']}"/>
                            </div>
                        <fieldset class="field_select existente_valida_dato_{$k} " $disabled >
html;
            foreach($ids AS $val){
                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3">&nbsp;&nbsp; Carrier:</label>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <div class="checkbox">
                                    <label><input type="checkbox" class"carrier" name="carrier_connection_short_code_id[]" value="{$val['carrier_connection_short_code_id']}" checked="checked">{$val['name']}</label>
                                </div>
                            </div>
                        </div>
html;
            }
            $shortCodeHtml.=<<<html
                        </fieldset>
                        </div>
html;
        }

        
        View::set('shortCodeHtml',$shortCodeHtml);
        View::set('customer_id',$id_custom);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("addcampania");    
    }



    public function getTime(){
    $fecha = date("Y-m-d H:i:s");
    echo '<b> La fecha del sistema actual es: '.$fecha.'</b>';
    exit;
    }



    public function add_campania(){
        // echo "comienza la función\n";        
        if (empty($_POST)) {}
        else { $delivery  = $_POST['datetimepicker'];}

        $delivery_date = $this->formatoFecha($delivery);

        $campanias = new \stdClass();
        $campanias->_name = MasterDom::getData('nombre_campania');
        $campanias->_module_id = 4;
        $campanias->_delivery_date = $delivery_date;
        $campanias->_campaing_status_id = 1;
        
        $addCamp = CampaniaDao::insert($campanias);
        $id_custom = MasterDom::getSession('customer_id');

        $datos = new \stdClass();
        $datos->_customer_id = $id_custom;
        $datos->_campaign_id = $addCamp;
        
        $addCC = CampaniaDao::insertCC($datos);

        $addCU = CampaniaDao::insertCampaignUser(MasterDom::getSession('id_user'),$addCamp);

        $ccsc = MasterDom::getDataAll('carrier_connection_short_code_id');
            
        foreach ($ccsc as $key => $value) {
            $registro = new \stdClass();
            $registro->_campaign_id = $addCamp;
            $registro->_carrier_connection_short_code_id = $value;
            $registro->_short_code_id = MasterDom::getData('short_code_id');

            $idCcss = CampaniaDao::insertCcsc($registro);
            if(empty($idCcss))
                return $this->alertas('error_general');

            $idCcss = CampaniaDao::insertCampaignCarrierShortCode($registro);
            if(empty($idCcss))
                return $this->alertas('error_general');
        }

        if (empty($addCamp) && empty($addCC) ) {
            return $this->alertas('error_general');
            header('location:/campania/add');
        } else {
            $registro = $this->registroUsuario("Agrego Campania {$addCamp}");
            CampaniaDao::registroUsuario($registro);
            return $this->alertas('success_add');
            header('location:/campania');
        }

    }


    public function edit($id){
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');
        $id = (int)$id;
        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">

<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

// <script>
// $(document).ready(function() {
//     $("#add").validate({
//             rules: {
//                 nombre_campania: {
//                     required: true
//                 },
//                 datetimepicker:{
//                     required:true
//                 }
//             messages:{
//             }
//     });
// });
// </script>

<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
    <script>    
        $(document).ready(function() {
            jQuery('#datetimepicker').datetimepicker();

            $("#add").validate(
                {
                    rules: {
                        nombre_campania: {
                            required: true,
                            maxlength: 60,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania: {
                            required: "Escriba un nombre de campa&ntilde;a, minimo de 3 caracteres y maximo de 60"
                        },
                        datetimepicker: {
                            required: "Ingrese fecha y hora de lanzamiento"
                        }
                    }
                });

            setInterval(function(){ 
                $.get( "/campania/getTime", function( data ) {
                        $( "#fecha_sistema" ).html( data );
                });
            }, 1000);
        }); 
    </script>
html;
        $row = CampaniaDao::getById($id);
        $status = "";
        foreach (CampaniaDao::getCampaignStatus() as $key => $value) {
            $select = ($value['campaign_status_id'] == $row['campaign_status_id']) ? "select" : "";
            $status .=<<<html
                <option {$select} value="{$value['campaign_status_id']}">{$value['name']}</option> 
html;
        }

        $fechas = date_format($row['delivery_date'], 'mm/dd/yyyy HH:mm');
        //print_r($fechas);

        View::set('status',$status);
        View::set('nombre_campania',$row['name']);
        View::set('fecha',$row['delivery_date']);
        View::set('campaign_id',$row['campaign_id']);
    
        View::set('customer_id',$id_custom);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("editcampania");    
    }

    public function edit_campania(){
        // echo "comienza la función\n";
         if (empty($_POST)) {}
        else {
            $delivery  = $_POST['datetimepicker'];
            // print_r($delivery);
        }

        $delivery_date = $this->formatoFecha($delivery);

        $campanias = new \stdClass();
        $campanias->_name = MasterDom::getData('nombre_campania');
        $campanias->_delivery_date = $delivery_date;
        $campanias->_campaign_id = MasterDom::getData('campania');
        $campanias->_status = (MasterDom::getData('status')!="")? MasterDom::getData('status'): 1;
        $sms_campania = new \stdClass();
        $sms_campania->_campaign_id = MasterDom::getData('campania');
        $sms_campania->_delivery_date = $delivery_date;
        $sms_campania->_sms_campaign_estatus_id = (MasterDom::getData('status')==4) ? 12 : 'sms_campaign_estatus_id';
        $addCamp = CampaniaDao::update($campanias);
        $editSMSC = CampaniaDao::updateSMSC($sms_campania);


        if (empty($addCamp) && empty($editSMSC)) {
             return $this->alertas('error_general');
        } else {
            $registro = $this->registroUsuario("Actualizo Campania {$campanias->_campaign_id}");
            CampaniaDao::registroUsuario($registro);
            return $this->alertas('success_edit');
        }

    }


     public function delete_campania($id){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(CampaniaDao::delete($id) === false)
                {return $this->alertas('error_borrar');}
            else
                {$registro = $this->registroUsuario("Elimino Campania {$id}");
                                CampaniaDao::registroUsuario($registro);}
        }

        return $this->alertas('success_delete');
    }


    function formatoFecha($fecha_){
      
    list($m,$d,$y) = explode("/",$fecha_);
    list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

    $hora = '';
    $hora .= $tiempo.' '.$ampm;

    $time = strtotime($hora);
    $cadena = date("H:i", $time);
    //echo $cadena; 

    $timestamp = mktime(0,0,0,$m,$d,$y);
    $date = date("Y-m-d",$timestamp);
    //echo $date;

    return $date.' '.$cadena;

    }



    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifico con éxito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/campania');
        View::set('class', $class);
        View::set('titulo','campa&ntilde;a');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

}
