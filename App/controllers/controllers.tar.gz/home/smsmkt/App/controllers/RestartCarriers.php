<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;

class RestartCarriers
{

    public function restartCarrier($accion){
	
        try{
            if ($accion == 1) {
                $json['card']['reconnect'] = 'true';
                $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
                mail("tecnico@airmovil.com", "Reinicio existoso de los carrier SMSMKT", "Estatus: ".print_r($reinicio,1));
            }
        }catch(Exception $e){
            mail("tecnico@airmovil.com", "Reinicio fallido de los carrier SMSMKT", "Estatus: ".print_r($reinicio,1));
        }

    }

}
