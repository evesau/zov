<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiDoppler AS ApiDopplerDao;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ApiDoppler_bk{

    /*
        ::::::::::::::::NOTA:::::::::::::::
        se ha cambiado el nombre de la funcion servicio por servicio1
        se ha cambiado el nombre de la funcion updateCampaigns por updateCampaigns1
    */


    private $_contenedor;
    private $_host_doppler = 'https://restapi.fromdoppler.com/accounts/';
    private $_api_key='2B55B4D51DA0C1F6CF721687D4E8BF7F';
    private $_usuario_doppler = 'jorge.manon%40airmovil.com';
    private $_url_peticion;

    function __construct(){
        $this->_url_peticion = $this->_host_doppler.''.$this->_usuario_doppler;
        if($_GET['url'] != 'ApiDoppler/servicio' || $_GET['url'] != 'ApiDoppler/updateCampaigns'){
            $this->_contenedor = new Contenedor;
            View::set('header',$this->_contenedor->header());
            View::set('footer',$this->_contenedor->footer());
        }
    }

    public function index(){
        $extraHeader=<<<html
        <!-- DataTables CSS -->
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script>
            $(document).ready(function(){
                $("#muestra-cupones").tablesorter();
                var oTable = $('#muestra-cupones').DataTable({
                    "columnDefs": [{
                        "orderable": false,
                        "targets": 0
                    }],
                     "order": false
                });

                // Remove accented character from search input as well
                $('#muestra-cupones input[type=search]').keyup( function () {
                    var table = $('#example').DataTable();
                    table.search(
                        jQuery.fn.DataTable.ext.type.search.html(this.value)
                    ).draw();
                });
            });
        </script>
html;
        $tabla = '';
        $status_traductor = array('draft' => 'Borrador', 'shipped' => 'Enviado', 'shipping' => 'Enviando');
            foreach (ApiDopplerDao::getCampaigns() as $key => $value) {
                $value = (Object) $value;
                if($value->status != 'draft'){
                    $fecha_envio = ($value->send_date != '')? $value->send_date : 'Envío Pendiente';
                    $tabla .=<<<html
                    <tr>
                        <td><input type="checkbox" name="campaign_id[]" value="{$value->doppler_campaign_id}" /></td>
                        <td>{$value->doppler_campaign_id}</td>
                        <td>{$fecha_envio}</td>
                        <td>{$value->nombre}</td>
                        <td>{$value->email_sender}</td>
                        <td>{$value->subject}</td>
                        <td>{$status_traductor[$value->status]}</td>
                        <td>{$value->uniqueOpens}</td>
                        <td>{$value->totalUnopened}</td>
                        <td>{$value->totalHardBounces}</td>
                        <td>{$value->totalSoftBounces}</td>
                        <td>{$value->successFullDeliveries}</td>
                        <td>{$value->totalRecipients}</td>
                    </tr>
html;
                }
            }

        //print_r($detalle_envio = $this->getReporteCampaign('9606688'));

        View::set('tabla', $tabla);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_all");
    }

    public function showDetalle(){
        $extraFooter =<<<html
        <script>
            $(document).ready(function(){
                $("#btnCrear").click(function(){
                    $.ajax({
                        url: '/ApiDoppler/crearGrupo',
                        type: 'POST',
                        data: $('#campaigns').serialize(),
                        success: function(data){
                            $('#response_group_add').html(data);   
                            setTimeout(function(){
                              $('#response_group_add').html("");
                            }, 2000);                           
                        }
                    });
                });                 
            });
        </script>
html;
        $status_traductor = array('opened' => 'Abierto', 'notOpened' => 'Sin Abrir');
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $entregados = 0;
        $totales = 0;

        $campaign_div = '';
        $campaigns = MasterDom::getDataAll('campaign_id');
        foreach ($campaigns as $llave => $id) {
            $campaign_div .= '<input type="hidden" name="campaign_id[]" value="'.$id.'"/>';
            $reporte = (Object) ApiDopplerDao::getCampaignById($id);
            $nombreCampaign .= '<h5><span>'.$reporte->nombre.'</span></h5>';
            $totales += intval($reporte->totalRecipients);
            $abiertos += intval($reporte->uniqueOpens);
            $no_abiertos += intval($reporte->totalUnopened);
            $rechazados_hard += intval($reporte->totalHardBounces);
            $rechazados_soft += intval($reporte->totalSoftBounces);
            $entregados += intval($reporte->successFullDeliveries);
        }

        $abiertos_p = round($abiertos*(100/$totales),2);
        $no_abiertos_p = round($no_abiertos*(100/$totales),2);
        $abiertos_p = round($abiertos*(100/$totales),2);
        $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
        $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
        $entregados_p = round($entregados*(100/$totales),2);   

        $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;

        View::set('tabla', $tabla);
        View::set('campaign_div', $campaign_div);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show");
    }

    public function showGroups(){
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $totales = 0;
        $campaign_div = '';
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroups();
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);       
                $nombreCampaign = '<label>'.$value['nombre_campaign'].'</label><br>';
                $totales = intval($reporte->totalRecipients);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);
            }else{
                $reporte = (Object) ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<label>'.$value['nombre_campaign'].'</label><br>';
                $totales += intval($reporte->totalRecipients);
                $abiertos += intval($reporte->uniqueOpens);
                $no_abiertos += intval($reporte->totalUnopened);
                $rechazados_hard += intval($reporte->totalHardBounces);
                $rechazados_soft += intval($reporte->totalSoftBounces);
                $entregados += intval($reporte->successFullDeliveries);
            }    

            if($grupos[$key+1]['doppler_group_id'] != $aux){
                
                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $entregados_p = round($entregados*(100/$totales),2);   


                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td><h5><span > {$value['nombre']} </span></h5></td>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100%</span></h5>
                        </td>
                        <td>
                            <a href="/ApiDoppler/showGroup/{$value['doppler_group_id']}"><span class="btn btn-primary"><i class="fa fa-eye"></i></span></a>
                        </td>
                    </tr>
html;
            }

        }     

        View::set('tabla', $tabla);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show_groups");
    }

    public function showGroup($doppler_group_id){
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $entregados = 0;
        $totales = 0;
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroup($doppler_group_id);
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);               
                $nombreCampaign = '<h5><span>'.$value['nombre_campaign'].'</span></h5>';
                $totales = intval($reporte->totalRecipients);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);

                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $entregados_p = round($entregados*(100/$totales),2);   


                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;


            }else{
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign = '<h5><span>'.$value['nombre_campaign'].'</span></h5>';
                $totales_campaign = intval($reporte->totalRecipients);
                $totales += $totales_campaign;
                $abiertos_campaign = intval($reporte->uniqueOpens);
                $abiertos += $abiertos_campaign;
                $no_abiertos_campaign = intval($reporte->totalUnopened);
                $no_abiertos += $no_abiertos_campaign;
                $rechazados_hard_campaign = intval($reporte->totalHardBounces);
                $rechazados_hard += $rechazados_hard_campaign;
                $rechazados_soft_campaign = intval($reporte->totalSoftBounces);
                $rechazados_soft += $rechazados_soft_campaign;
                $entregados_campaign = intval($reporte->successFullDeliveries);
                $entregados += $entregados_campaign;
        
                $abiertos_p = round($abiertos_campaign*(100/$totales_campaign),2);
                $no_abiertos_p = round($no_abiertos_campaign*(100/$totales_campaign),2);
                $abiertos_p = round($abiertos_campaign*(100/$totales_campaign),2);
                $rechazados_hard_p = round($rechazados_hard_campaign*(100/$totales_campaign),2);
                $rechazados_soft_p = round($rechazados_soft_campaign*(100/$totales_campaign),2);
                $entregados_p = round($entregados_campaign*(100/$totales_campaign),2);      

                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;
            }    

            if( (count($grupos)-1) == $key ){
                $doppler_grupo_nombre = $value['nombre'];
                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $entregados_p = round($entregados*(100/$totales),2);

                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td><h5><span>TOTALES</span></h5></td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;
            }

        }     

        View::set('tabla', $tabla);
        View::set('doppler_grupo_nombre', $doppler_grupo_nombre);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show_group");
    }

    public function crearGrupo(){
        $grupo = new \stdClass();
        $grupo->_group_id = ApiDopplerDao::getGroupId()['id'];
        $grupo->_name =  MasterDom::getData('name');
        foreach (MasterDom::getDataAll('campaign_id') as $key => $value) {
            $grupo->_campaign_id = $value;
            $id = ApiDopplerDao::insertGroup($grupo);
            if($id >0){
                echo "<h2><span class='label label-primary'>La campaña $grupo->_campaign_id fue agregada correctamente al grupo $grupo->_name</span></h2>";
            }else{
                echo "<h2><span class='label label-warning'>La campaña $grupo->_campaign_id no pudo ser agregada correctamente al grupo $grupo->_name</span></h2>";
            }
        }
    }

    public static function crearExcel(){
        $encabezado = array('GRUPO','CAMPAÑAS','ABIERTOS','NO ABIERTOS','RECHAZADOS HARD','RECHAZADOS SOFT','ENTREGADOS','TOTALES');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Taurus Silver")
        ->setLastModifiedBy("Taurus Silver")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de grupos")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");

        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        /***********************************************************************************/
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
    $entregados = 0;
        $totales = 0;
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroups();
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                //$reporte = $this->getReporteCampaign($value['doppler_campaign_id']);
                $reporte = (Object) ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<'.$value['nombre_campaign'].'>';
                $totales = intval($reporte->totalRecipients);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);
            }else{
                //$reporte = $this->getReporteCampaign($value['doppler_campaign_id']);
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<'.$value['nombre_campaign'].'>';
                $totales += intval($reporte->totalRecipients);
                $abiertos += intval($reporte->uniqueOpens);
                $no_abiertos += intval($reporte->totalUnopened);
                $rechazados_hard += intval($reporte->totalHardBounces);
                $rechazados_soft += intval($reporte->totalSoftBounces);
        $entregados += intval($reporte->successFullDeliveries);
            }    

            if($grupos[$key+1]['doppler_group_id'] != $aux){
                
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A'.$fila, $value['nombre'])
                ->setCellValue('B'.$fila, $nombreCampaign)
                ->setCellValue('C'.$fila, $abiertos)
                ->setCellValue('D'.$fila, $no_abiertos)
                ->setCellValue('E'.$fila, $rechazados_hard)
                ->setCellValue('F'.$fila, $rechazados_soft)
                ->setCellValue('G'.$fila, $entregados)
        ->setCellValue('H'.$fila, $totales);

                $fila++;
            }

        }
        /************************************************************************************************
        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            
        }

        /************************************************************************************************/


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Reporte de Grupos.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }
/*
    funciones para no consumir las peticiones de Doppler
*/
    public function servicio(){}
    public function updateCampaigns(){}

    public function servicio1(){
        $response_campanias = json_decode(file_get_contents($this->_url_peticion."/campaigns?page=1&per_page=10&api_key=$this->_api_key")); 
        $texto = '';
        $datos = new \stdClass();
        $datos->campaign_id = 1;
        $marcacion = '27268';

        $contenido = "Mensaje de prueba de Correo";
        $contenido = urlencode($contenido);
        foreach ($response_campanias->items as $key => $value) {
            $response_suscriptor = json_decode(file_get_contents($this->_url_peticion.'/campaigns/'.$value->campaignId.'/deliveries?page=1&per_page=10&api_key='.$this->_api_key));
            $existe = count(ApiDopplerDao::getCampaignIdExist($value->campaignId));
            $suscriptor = new \stdClass();
            $suscriptor->campaignId = $value->campaignId;

            foreach ($response_suscriptor->items as $llave => $valor) {
                $suscriptor->suscriptorEmail = $valor->subscriberEmail;
                $suscriptor->deliveryStatus = $valor->deliveryStatus;
                if($existe==0){
                    $id = ApiDopplerDao::insert($suscriptor);
                    echo 'Insertado::::::::  ID: '.$id.'<br>';

                    if($suscriptor->deliveryStatus == 'opened'){
                        $suscriptorEmail = str_replace('@','%40',$valor->subscriberEmail);
                        echo 'Email::::::'.$suscriptorEmail.'<br>';
                        $response = json_decode(file_get_contents($this->_url_peticion.'/subscribers/'.$suscriptorEmail.'?api_key='.$this->_api_key)); 
                        foreach ($response->fields as $key => $value) {            
                            if($value->name == 'phone'){
                                $telefono = $value->value;
                            }
                        }
                        echo 'TELEFONO: '.$telefono.'<br>';
                        $carrier = file_get_contents('http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn='.$telefono);
                        echo 'CARRIER TEXTO: '.$carrier.'<br>';
                        switch(strtolower($carrier)){
                            case 'telcel':
                                $carrier = 1;
                                break;
                            case 'movistar':
                                $carrier = 2;
                                break;
                            case 'att':
                                $carrier = 3;
                                break;
                            default:
                                $carrier = -1;
                                break;
                        }
                        $datos->carrier_id = $carrier;
                        $carrier_array = ApiDopplerDao::getCarrierConectionShortCodeId($datos);
                        $carrier = $carrier_array['carrier_connection_short_code_id'];

                        echo 'CARRIER CONNECTION SHORT CODE ID:::::::: '.$carrier.'<br>';
                        $envio = file_get_contents("http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=$contenido&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id);
                        echo 'ENVIO::::::'.$envio.'<br>';
                        $texto .= "Respuesta: ".$telefono."<::::::>".$carrier.'<br>ENVIO::::::'.$envio."<br>http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=MT_DOPPLER_SMS&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id."***************************************************************************";
                    }
                }elseif ($existe>0){
                    $suscriber = ApiDopplerDao::getById($suscriptor);
                    echo $suscriptor->deliveryStatus.'<<<<<>>>>>'.$suscriber['delivery_status'].'<br>';
                    if($suscriptor->deliveryStatus != $suscriber['delivery_status']){
                        $suscriptorEmail = str_replace('@','%40',$valor->subscriberEmail);
                        echo 'Email::::::'.$suscriptorEmail.'<br>';
                        $response = json_decode(file_get_contents($this->_url_peticion.'/subscribers/'.$suscriptorEmail.'?api_key=2B55B4D51DA0C1F6CF721687D4E8BF7F')); 
                        foreach ($response->fields as $key => $value) {            
                            if($value->name == 'phone'){
                                $telefono = $value->value;
                            }
                        }
                        echo 'TELEFONO: '.$telefono.'<br>';
                        $carrier = file_get_contents('http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn='.$telefono);
                        echo 'CARRIER TEXTO: '.$carrier.'<br>';
                        switch(strtolower($carrier)){
                            case 'telcel':
                                $carrier = 1;
                                break;
                            case 'movistar':
                                $carrier = 2;
                                break;
                            case 'att':
                                $carrier = 3;
                                break;
                            default:
                                $carrier = -1;
                                break;
                        }
                        $datos->carrier_id = $carrier;
                        $carrier_array = ApiDopplerDao::getCarrierConectionShortCodeId($datos);
                        $carrier = $carrier_array['carrier_connection_short_code_id'];

                        echo 'CARRIER CONNECTION SHORT CODE ID:::::::: '.$carrier.'<br>';
                        $envio = file_get_contents("http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=$contenido&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id);
                        echo 'ENVIO::::::'.$envio.'<br>';

                        $texto .= "Respuesta: ".$telefono."<::::::>".$carrier.'<br>ENVIO::::::'.$envio."<br>http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=MT_DOPPLER_SMS&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id."***************************************************************************";
                        ApiDopplerDao::update($suscriptor);
                    }
                }   
            }
        }

        echo $texto;
        mail("jorge.manon@airmovil.com,juan.medina@airmovil.com","checador de campañas Doppler","Se ha terminado de actualizar los estados de envio de las campañas:    ".$texto);
    }

    public function updateCampaigns1(){
        $response = $this->getCampaigns();
        foreach($response->items as $key => $value) {
                    if($value->status != 'draft'){
                        $detalle_envio = $this->getReporteCampaign($value->campaignId);
                        $campaign->_campaignId = $value->campaignId;
                        $fecha = substr($value->scheduledDate,0,10).' '.substr($value->scheduledDate,11,-5);
                        $campaign->_fecha_envio = $fecha;
                        $campaign->_name = $value->name;
                        $campaign->_fromEmail = $value->fromEmail;
                        $campaign->_subject = $value->subject;
                        $campaign->_status = $value->status;

                        if(count($detalle_envio) != 0){
                                echo 'La campaña no tiene detalle de envio...<br>';
                                $campaign->_uniqueOpens = $detalle_envio->uniqueOpens;
                                $campaign->_totalUnopened = $detalle_envio->totalUnopened;
                                $campaign->_totalHardBounces = $detalle_envio->totalHardBounces;
                                $campaign->_totalSoftBounces = $detalle_envio->totalSoftBounces;
                                $campaign->_totalRecipients = $detalle_envio->totalRecipients;
                                $campaign->_successFullDeliveries = $detalle_envio->successFullDeliveries;
                        }else{
                                $campaign->_uniqueOpens = 0;
                                $campaign->_totalUnopened = 0;
                                $campaign->_totalHardBounces = 0;
                                $campaign->_totalSoftBounces = 0;
                                $campaign->_totalRecipients = 0;
                                $campaign->_successFullDeliveries = 0;
                        }
                        if( count(ApiDopplerDao::getCampaign($value->campaignId)) == 0){
                            ApiDopplerDao::insertCampaign($campaign);
                            echo 'Se ha insertado correctamente..<br>';
                            print_r($campaign);
                            echo '<br>';
                        }else{
                            ApiDopplerDao::updateCampaign($campaign);
                            echo 'Se ha actualizado correctamente..<br>';
                            print_r($campaign);
                            echo '<br>';
                        }
                    }
        }
        mail("jorge.manon@airmovil.com,juan.medina@airmovil.com","Actualizador de Capañas","Se ha actualizado la base de datos de las camp?s::::::: ");
    }

    public function getReporteCampaign($campaign_id){
        return json_decode(file_get_contents("$this->_url_peticion/campaigns/$campaign_id/results-summary?api_key=$this->_api_key"));
    }

    public function getCampaigns(){
        return json_decode(file_get_contents($this->_url_peticion."/campaigns?page=1&per_page=10&api_key=$this->_api_key")); 
    }

    public function getCampaign($campaignId){
        return json_decode(file_get_contents($this->_url_peticion.'/campaigns/'.$campaignId.'/deliveries?page=1&per_page=10&api_key='.$this->_api_key));
    }
}







