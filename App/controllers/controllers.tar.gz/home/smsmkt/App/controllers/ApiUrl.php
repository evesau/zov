<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiUrl AS ApiUrlDao;

class ApiUrl{

  private $_contenedor;

    private function generateUrl($length = 4) {
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$charactersLength = strlen($characters);
    	$randomString = '';
    	for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[mt_rand(0, $charactersLength - 1)];
    	}
    	return $randomString;
    }

    public function registroHit(){

	$code = MasterDom::getData('code');
	if($code == ''){
	    echo 0;
	    exit();
	}
	
	$data = ApiUrlDao::getById($code);
	if(count($data) < 1){
	    echo 0;
	    exit();
	}

	$url = (MasterDom::getData('uri') == '') ? '' : MasterDom::getData('uri');
	$id = $data['url_general_id'];

	$data = new \stdClass();
	$data->_id = $id;
	$data->_url = $url;
	$insert = ApiUrlDao::insertSeguimiento($data);
	if($insert >= 1){
	    echo 1;
	    exit();
	}else{
	    echo 0;
	    exit();
	}
    }

    public function mensajesPost(){

	$mensaje = MasterDom::getDataAll('mensaje');
	$inicio = MasterDom::getData('inicio');
	$fin = MasterDom::getData('fin');

	if($mensaje == '' OR $inicio == '' OR $fin == ''){
	    echo "Algun parametro vacio";
	    exit();
   	}

	echo "INICIA PROCESO...\n";
	$array = ApiUrlDao::preparaEnvio($inicio, $fin);	
	//print_r($array);
	//echo "++FIN++";
	exit();
	exit();

	foreach($array AS $key=>$value){
		$pwd = 'hl%D3"60F;)W';
                $pwd = urlencode($pwd);
                ########################
                $msisdn = $value['msisdn'];
                /* se agrego para prueba de api web  */
                $urlRedirect = $value['url_redirect'];
                $idUnico = ApiUrl::generateStatic($msisdn,$urlRedirect);
                /*if ($idUnico==0 || $idUnico=="") {
                    mail('tecnico@airmovil.com','id vacio',"Mail id vacio..$msisdn");
                    continue;
                }*/
                //$bIdUnico = DinamicwebDao::getByidUnico($msisdn,$idUnico);
		$idUnico = $value['identificador'];
                $carrier = strtoupper($value['carrier']);
		echo "++msisdn: $msisdn<br />";
		echo "++mensaje $mensaje<br />";
		echo "++carrier: $carrier<br />";

		$envio = '';
		$envio = urlencode($mensaje." http://arv.mx/$idUnico");
	
                ################
                if (!empty($value) || $msisdn != "" || $envio != "" || $carrier != "") {
                    usleep(125000);
                    $llamada = "https://ws.gtp.bz/api/http_bulk/http.php?user=jose.moreno@airmovil.com&pass=$pwd&api_id=1131611826&ani=$msisdn&msj=$envio&carr=$carrier";
                    echo $llamada."<br>";
                    //para llamar api de tecnophone
                    $response = @file_get_contents("https://ws.gtp.bz/api/http_bulk/http.php?user=jose.moreno@airmovil.com&pass=$pwd&api_id=1131611826&ani=$msisdn&msj=$envio&carr=$carrier");
                    #print_r($response."<br>");
                    if (preg_match("/Enviado/",$response)) {
                        $numeros_validos++;
                        $mensajeEnviados[] = $response;
			$data = new \stdClass();
			$data->_id = $value['url_general_id'];
			$data->_estatus = 1;
			ApiUrlDao::update($data);
			echo "++OK++<br />";
                    }else{
			print_r($response);
                        $numeros_invalidos++;
                        $mensajeNoenviados[] = $response;
			$data = new \stdClass();
                        $data->_id = $value['url_general_id'];
                        $data->_estatus = 0;
                        ApiUrlDao::update($data);
			echo "++ERROR++<br />";
                    }

		}
	}
	
    }


    public function enviaUrlredirect(){
    	$code = MasterDom::getData('code');
    	if ($code == '') {
    		echo 0;
    		exit();
    	}

    	$data = ApiUrlDao::getById($code);
    	if (count($data) < 1) {
    		echo 0;
    		exit();
    	}

    	$id = $data['url_general_id'];

    	$urlRedirect = ApiUrlDao::buscaUrlredirect($id);

    	if ($urlRedirect != '') {
    		$url = $urlRedirect['url_redirect'];
    		echo $url;
    		exit();
    	}
    	else{
    		echo 0;
    		exit();
    	}


    }

    public function recursiva($intento = 1, $data){
	if($intento > 5){
	    //mail('tecnico@airmovil.com','CLUB PREMIER', "No se pude generar URL unica {$data->_msisdn}");
	    return false;
	}
	$data->_identificador = $this->generateUrl();
	$id = ApiUrlDao::insert($data);
	if($id === false){
	    return $this->recursiva($intento + 1, $data);
	}

	return $data->_identificador;
    }

    public function generate($msisdn,$urlRedirect,$carrier){
	$url = $this->generateUrl();
	if($msisdn == '')
	    return false;
	$data = new \stdClass();
	$data->_msisdn = $msisdn;
	$data->_identificador = $this->generateUrl();
	$data->_url_redirect = $urlRedirect;
	$data->_carrier = $carrier;
	$data->_customer = 1;

	$identificador = $this->recursiva(0, $data);
	if($identificador == false)
	    return false;

	return $identificador;
    }

    public static function generateStatic($msisdn,$urlRedirect,$carrier){
	if($msisdn == '')
	    return false;

	$api = new ApiUrl();
	return $api->generate($msisdn,$urlRedirect,$carrier);
    }
}
