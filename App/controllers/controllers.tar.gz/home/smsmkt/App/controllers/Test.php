<?php
namespace App\controller;

include '/usr/local/bin/vendor/autoload.php';;

class Test{

    public static function inicio(){
echo "777777777INICIO777777\n";
$objReader = \PHPExcel_IOFactory::createReader('Excel2007');
$objReader->setReadDataOnly(true);
echo "8888888888FIN8888888\n";
    }
}
?>
