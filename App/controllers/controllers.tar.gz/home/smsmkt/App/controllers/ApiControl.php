<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiControl AS ApiControlDao;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ApiControl{

    private $_contenedor;
    function __construct(){
         $this->_contenedor = new Contenedor;
         View::set('header',$this->_contenedor->header());
         View::set('footer',$this->_contenedor->footer());
    }

    public function UserAll(){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){
                $('#tabla_campaign').DataTable({
                "language": {
                  "emptyTable": "No hay datos disponibles",
                  "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                  "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                  "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                  "lengthMenu": "Mostrar _MENU_ registros",
                  "zeroRecords":  "No se encontraron resultados",
                  "search": "Buscar:",
                  "processing": "Procesando...",
                  "paginate" : {
                      "next": "Siguiente",
                      "previous" : "Anterior"
                  }
                }
              });


                $("#delete").click(function(){
                    var num_ids = $("input[type=checkbox]:checked").length;
                    if(num_ids > 0){
                        alertify.confirm("¿Desea eliminar los usuarios selecciandos?",
                          function(){
                            $("#all").submit();
                          });
                    }else{
                        alertify.alert('Se debe seleccionar al menos un usuario');
                    }
                });
            });
        </script>
html;
        $status = array('Oculto','Visible','Eliminado');

        $tabla = '';
        foreach (ApiControlDao::getUserAll(MasterDom::getSession('customer_id')) as $key => $value) {
            if( ($key%2) == 0){
                $colorTr = 'style="background-color: #e3e4e5;"';
            }else{
                $colorTr = '';
            }

            $tabla .=<<<html
            <tr $colorTr>
                <td><input type="checkbox" name="ids[]" value="{$value['user_id']}"></td>
                <td>{$value['customer_id']}</td>
                <td>{$value['user']}</td>
                <td>
html;
            
            foreach (ApiControlDao::getIpByUser($value['user_id']) as $keyIp => $valueIp) {
                $tabla .=<<<html
                <div><label>{$valueIp['ip']}</label></div>
html;
            }


            $tabla .=<<<html
                </td>
                <td>
html;
            $apis = ApiControlDao::getApiByUserId($value['user_id']);
            foreach ($apis as $keyApi => $valueApi) {
                if(preg_match('/mail|MAIL|Mail/',$valueApi['nombre'])){
                    $color = "#8ec9e5";
                }elseif(preg_match('/push|PUSH|Push/',$valueApi['nombre'])){
                    $color = "#75ea81";
                }elseif(preg_match('/sms|SMS|Sms/',$valueApi['nombre'])){
                    $color = "#e5b077";
                }
                $tabla .=<<<html
                <label style="background-color: $color; border-radius:5px; border:20px;">{$valueApi['nombre']}</label>
                <!-- <div style="background-color: #8ec9e5; border-radius:10px; margin:5px; justify-content: center;width: auto;"> -->
html;
            }

            $tabla .=<<<html
                </td>
                <td>{$status[$value['status']]}</td>
                <td>
                    <a href="/ApiControl/UserEdit/{$value['user_id']}"><span class="btn btn-primary btn-circle fa fa-pencil"></span></a>
                </td>
            </tr>
html;
        }

        View::set('tabla', $tabla);       
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_user_all");
    }

    public function UserAdd(){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){

                /********************INICIO DE LA FUNCION DEL EVENTO DE APIS CHANGE*********************/
                $("#btnAsignar").click(function(){
                    var api_id = $("#apis option:selected").val();
                    if(api_id>0){
                        var nombre = $("#apis option:selected").text();
                        var html = '<div class="col-md-4 col-sm-4 col-xs-4" style="background-color: gray; border-radius:10px; margin:5px; justify-content: center;width: auto;" id="contendor_'+api_id+'"><i class="fa fa-times-circle-o cerrar col-md-1 col-sm-1 col-xs-1" id="cerrar_'+api_id+'" nombre="'+nombre+'" api_id="'+api_id+'" style="font-size: 18px; margin-top:3px; margin-left:5px; color:#C9302C;"></i><input type="hidden" name="api_id[]" value="'+api_id+'" ><div class="col-md-11 col-sm-11 col-xs-11" style="justify-content: center;margin-top:10px;"><label class="control-label col-md-8 col-sm-8 col-xs-8" style="text-align: center;color:#000000;" >'+nombre+'</label></div></div>';
                        $("#contendor_apis").append(html);
                        $("#apis option:selected").remove();
                    }
                });
                /********************FIN DE LA FUNCION DEL EVENTO DE APIS CHANGE*********************/

                /********************INICIO DE LA FUNCION DEL EVENTO PARA CIERRE DE APIS*********************/
                $(document).on("click",".cerrar",function(){
                    var id = $(this).attr('api_id');
                    var nombre = $(this).attr('nombre');
                    $("#contendor_"+id).remove();
                    $("#apis").append('<option value="'+id+'">'+nombre+'</option>');
                });
                /********************FIN DE LA FUNCION DEL EVENTO PARA CIERRE DE APIS*********************/

                /********************INICIO VALIDATE DE ENTRADAS*********************/
                $("#add").validate({
                    rules:{
                        user:{
                            required: true
                        },
                        password:{
                            required: true
                        }
                    },
                    messages:{
                        user:{
                            required: "Este campo es requerido"
                        },
                        password:{
                            required: "Este campo es requerido"
                        }
                    }
                });
                /********************FIN VALIDATE DE ENTRADAS*********************/

            });
        </script>
html;

        $sApis = '';
        foreach (ApiControlDao::getApisAll() as $key => $value) {
            $sApis .=<<<html
            <option value="{$value['api_id']}">{$value['nombre']}</option>
html;
        }

        View::set('sApis', $sApis);        
        View::set('customer_id', MasterDom::getSession('customer_id'));        
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_user_add");
    }

    public function userInsert(){
        $usuario = new \stdClass();
        $usuario->_user = MasterDom::getDataAll('user');
        $usuario->_customer = MasterDom::getDataAll('customer');
        $usuario->_password = MD5(MasterDom::getDataAll('password'));
        $usuario->_status = MasterDom::getDataAll('status');
        $ips = MasterDom::getDataAll('ips');
        $ips = str_replace('\r\n','', $ips);
        $ips = str_replace('\n','', $ips);
        $ips = str_replace('\r','', $ips);       
        $ips = str_replace(' ','', $ips);       

        $apis = MasterDom::getDataAll('api_id');
        $usuario_id = ApiControlDao::insertUser($usuario);
        if($usuario_id > 0){

            $errores = array();

            foreach ($apis as $key => $value) {
                $error = ApiControlDao::insertUserApi($usuario_id, $value);
                array_push($errores, array('API',$error));
            }

            foreach (explode(',',$ips) as $key => $value) {
                if(preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\z/', $value)){
                    $error = ApiControlDao::insertIp($usuario_id, $value);
                    array_push($errores, array("IP",$error));
                }else{
                    array_push($errores, array("IP",-1));
                }
            }

            $mensaje = '';
            foreach ($errores as $key => $value) {
                $valor = $value[1];
                $nombre = $value[0];

                if($valor >= 0){
                    $alert = "success";
                    $message = "Operacion exitosa al asignar la $nombre al usuario $usuario->_user";
                }else{
                    $alert = "danger";
                    $message = "Ha ocurrido un problema al asignar la $nombre al usuario $usuario->_user";
                }
                $mensaje .=<<<html
                <div class="alert alert-$alert alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <strong>Información: </strong>  {$message}
                </div>
html;
            }
            View::set('regreso','/ApiControl/UserAll');
            View::set('titulo','Usuario');
            View::set('class','success');
            View::set('mensaje','Detalle: '.$mensaje);
            View::render("mensaje");
        }//fin del if usuario_id > 0
    }

    public function UserEdit($user_id){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){

                /********************INICIO DE LA FUNCION DEL EVENTO DE APIS CHANGE*********************/
                $("#btnAsignar").click(function(){
                    var api_id = $("#apis option:selected").val();
                    if(api_id>0){
                        var nombre = $("#apis option:selected").text();
                        var html = '<div class="col-md-4 col-sm-4 col-xs-4" style="background-color: gray; border-radius:10px; margin:5px; justify-content: center;width: auto;" id="contendor_'+api_id+'"><i class="fa fa-times-circle-o cerrar col-md-1 col-sm-1 col-xs-1" id="cerrar_'+api_id+'" nombre="'+nombre+'" api_id="'+api_id+'" style="font-size: 18px; margin-top:3px; margin-left:5px; color:#C9302C;"></i><input type="hidden" name="api_id[]" value="'+api_id+'" ><div class="col-md-11 col-sm-11 col-xs-11" style="justify-content: center;margin-top:10px;"><label class="control-label col-md-8 col-sm-8 col-xs-8" style="text-align: center;color:#000000;" >'+nombre+'</label></div></div>';
                        $("#contendor_apis").append(html);
                        $("#apis option:selected").remove();
                    }
                });
                /********************FIN DE LA FUNCION DEL EVENTO DE APIS CHANGE*********************/

                /********************INICIO DE LA FUNCION DEL EVENTO PARA CIERRE DE APIS*********************/
                $(document).on("click",".cerrar",function(){
                    var id = $(this).attr('api_id');
                    var nombre = $(this).attr('nombre');
                    $("#contendor_"+id).remove();
                    $("#apis").append('<option value="'+id+'">'+nombre+'</option>');
                });
                /********************FIN DE LA FUNCION DEL EVENTO PARA CIERRE DE APIS*********************/
                /********************INICIO VALIDATE DE ENTRADAS*********************/
                $("#edit").validate({
                    rules:{
                        user:{
                            required: true
                        },
                        password:{
                            required: true
                        }
                    },
                    messages:{
                        user:{
                            required: "Este campo es requerido"
                        },
                        password:{
                            required: "Este campo es requerido"
                        }
                    }
                });
                /********************FIN VALIDATE DE ENTRADAS*********************/
                /********************INICIO VALIDATE DE ENTRADAS*********************/
                $("#add").validate({
                    rules:{
                        user:{
                            required: true
                        },
                        password:{
                            required: true
                        }
                    },
                    messages:{
                        user:{
                            required: "Este campo es requerido"
                        },
                        password:{
                            required: "Este campo es requerido"
                        }
                    }
                });
                /********************FIN VALIDATE DE ENTRADAS*********************/

            });
        </script>
html;
        $usuario = ApiControlDao::getUserById($user_id);
        $sApis = '';
        $apisAsignadas = '';
        $apisUsuario = ApiControlDao::getApiByUserId($user_id);
        foreach (ApiControlDao::getApisAll() as $key => $value) {
            $existente = false;
            foreach ($apisUsuario as $keyApi => $valueApi) {
                if($value['api_id'] == $valueApi['api_id']){
                    $existente = true;
                    break;
                }
            }
            if($existente){
                $apisAsignadas .=<<<html
                <div class="col-md-4 col-sm-4 col-xs-4" style="background-color: gray; border-radius:10px; margin:5px; justify-content: center;width: auto;" id="contendor_{$value['api_id']}">
                    <i class="fa fa-times-circle-o cerrar col-md-1 col-sm-1 col-xs-1" id="cerrar_{$value['api_id']}" nombre="{$value['nombre']}" api_id="{$value['api_id']}" style="font-size: 18px; margin-top:3px; margin-left:5px; color:#C9302C;"></i>
                    <input type="hidden" name="api_id[]" value="{$value['api_id']}" >
                    <div class="col-md-11 col-sm-11 col-xs-11" style="justify-content: center;margin-top:10px;">
                        <label class="control-label col-md-8 col-sm-8 col-xs-8" style="text-align: center;color:#000000;" >{$value['nombre']}</label>
                    </div>
                </div>
html;

            }else{
                $sApis .=<<<html
                <option value="{$value['api_id']}">{$value['nombre']}</option>
html;
            }
            
        }

        $ips = '';
        foreach (ApiControlDao::getUserIp($user_id) as $key => $value) {
            $ips .= $value['ip'].',';
        }

        $sStatus = '';
        foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
            $selected = ($usuario['status'] == $key)? 'selected' : '';
            $sStatus .=<<<html
            <option value="{$key}" {$selected}>{$value}</option>
html;
        }

        View::set('usuario', $usuario);
        View::set('sStatus', $sStatus);
        View::set('sApis', $sApis);
        View::set('ips', $ips);
        View::set('apisAsignadas', $apisAsignadas);        
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_user_edit");
    }


    public function userUpdate(){
        $usuario = new \stdClass();
        $usuario->_user_id = MasterDom::getDataAll('user_id');
        $usuario->_user = MasterDom::getDataAll('user');
        $usuario->_customer = MasterDom::getDataAll('customer');
        $usuario->_password = MasterDom::getDataAll('password_reset');
        $usuario->_status = MasterDom::getDataAll('status');
        $apis = MasterDom::getDataAll('api_id');
        $apisUsuario = ApiControlDao::getApiByUserId($usuario->_user_id);

        $ips = MasterDom::getDataAll('ips');
        $ips = str_replace('\r\n','', $ips);
        $ips = str_replace('\n','', $ips);
        $ips = str_replace('\r','', $ips);       
        $ips = str_replace(' ','', $ips);    
        $errores = array();

        ApiControlDao::deleteUserIp($usuario->_user_id);

        foreach (explode(',',$ips) as $key => $value) {
            //echo $value.'::::::::::::::::'.preg_match('^[\d]{1,3}[.][\d]{1,3}[.][\d]{1,3}[.][\d]{1,3}$', $value).'<br>';

            if(preg_match("/^[\d]{1,3}[.][\d]{1,3}[.][\d]{1,3}[.][\d]{1,3}$/", $value)){
                //echo "------Entro---------";
                $error = ApiControlDao::insertIp($usuario->_user_id, $value);
                array_push($errores, array($error => "Asignacion de IP ".$value));
            }else{
                //echo "------No Entro---------";
                array_push($errores, array(-1 => "Asignacion de IP"));
            }
        }

        
        $id = ApiControlDao::updateUser($usuario);
        array_push($errores, array($id => 'Actualizacion de Usuario'));
        if($usuario->_password != ''){
            $id = ApiControlDao::updateUserPassword($usuario->_user_id);
            array_push($errores, array($id => 'Actualizacion de Password'));
        }
        ApiControlDao::deleteApisByUser($usuario->_user_id);
        foreach ($apis as $key => $value) {
            $id = ApiControlDao::insertUserApi($usuario->_user_id, $value);
            array_push($errores, array($id => 'Insercion de Api'));
        }

        $mensaje = '';
        foreach ($errores as $key => $value) {
            $value = $value[0];
            if($key >= 0){
                $alert = "success";
                $message = "Sucess $value";
            }else{
                $alert = "danger";
                $message = "Ha ocurrido un problema en $value";
            }
            $mensaje .=<<<html
            <div class="alert alert-$alert alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                <strong>Detalle : </strong>  {$message}
            </div>
html;
        }
        View::set('regreso','/ApiControl/UserAll');
        View::set('titulo','Usuario');
        View::set('class','success');
        View::set('mensaje','Detalle: '.$mensaje);
        View::render("mensaje");
    }

    public function userDelete(){
        $ids = array();
        foreach (MasterDom::getDataAll('ids') as $key => $value) {
            $id = ApiControlDao::deleteUser($value);
            $ids[$id] = 'Eliminación de Usuario';
        }

        $mensaje = '';
        foreach ($ids as $key => $value) {
            if($key >= 0){
                $alert = "success";
                $message = "Sucess $value";
            }else{
                $alert = "danger";
                $message = "Ha ocurrido un problema en $value";
            }
            $mensaje .=<<<html
            <div class="alert alert-$alert alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                <strong>Detalle : </strong>  {$message}
            </div>
html;
        }
        View::set('regreso','/ApiControl/UserAll');
        View::set('titulo','Usuario');
        View::set('class','success');
        View::set('mensaje','Detalle: '.$mensaje);
        View::render("mensaje");
    }

    public function ApiAll(){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){
                $('#tabla_campaign').DataTable({
                "language": {
                  "emptyTable": "No hay datos disponibles",
                  "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                  "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                  "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                  "lengthMenu": "Mostrar _MENU_ registros",
                  "zeroRecords":  "No se encontraron resultados",
                  "search": "Buscar:",
                  "processing": "Procesando...",
                  "paginate" : {
                      "next": "Siguiente",
                      "previous" : "Anterior"
                  }
                }
              });


                $("#delete").click(function(){
                    var num_ids = $("input[type=checkbox]:checked").length;
                    if(num_ids > 0){
                        alertify.confirm("¿Desea eliminar las apis selecciandas?",
                          function(){
                            $("#all").submit();
                          });
                    }else{
                        alertify.alert('Se debe seleccionar al menos una api');
                    }
                });
            });
        </script>
html;
        $status = array('Oculto','Visible','Eliminado');

        $tabla = '';
        foreach (ApiControlDao::getApiAll() as $key => $value) {
            $tabla .=<<<html
            <tr>
                <td><input type="checkbox" name="ids[]" value="{$value['api_id']}"></td>
                <td>{$value['nombre']}</td>
                <td>{$value['url']}</td>
                <td>{$status[$value['status']]}</td>
                <td>
                    <a href="/ApiControl/ApiEdit/{$value['api_id']}"><span class="btn btn-primary btn-circle fa fa-pencil"></span></a>
                </td>
            </tr>
html;
        }

        View::set('tabla', $tabla);       
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_api_all");
    }

    public function ApiAdd(){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){
                /********************INICIO VALIDATE DE ENTRADAS*********************/
                $("#add").validate({
                    rules:{
                        nombre:{
                            required: true
                        },
                        api_url:{
                            required: true
                        }
                    },
                    messages:{
                        nombre:{
                            required: "Este campo es requerido"
                        },
                        api_url:{
                            required: "Este campo es requerido"
                        }
                    }
                });
                /********************FIN VALIDATE DE ENTRADAS*********************/

            });
        </script>
html;
    
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_api_add");
    }

    public function apiInsert(){
        $api = new \stdClass();
        $api->_nombre = MasterDom::getData('nombre');
        $api->_url = MasterDom::getData('api_url');
        $api->_status = MasterDom::getData('status');
        $api_id = ApiControlDao::insertApi($api);
            
        if($api_id >= 0){
            $alert = "success";
            $message = "Se ha insertado correctamente la API $api_id";
        }else{
            $alert = "danger";
            $message = "Ha ocurrido un problema ";
        }
        $mensaje .=<<<html
            <div class="alert alert-$alert alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                <strong>Error: </strong>  {$message}
            </div>
html;

        View::set('regreso','/ApiControl/ApiAll');
        View::set('titulo','Api');
        View::set('class','success');
        View::set('mensaje','Detalle: '.$mensaje);
        View::render("mensaje");
    }

    public function ApiEdit($api_id){
      $extraHeader =<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){
                /********************INICIO VALIDATE DE ENTRADAS*********************/
                $("#edit").validate({
                    rules:{
                        nombre:{
                            required: true
                        },
                        api_url:{
                            required: true
                        }
                    },
                    messages:{
                        nombre:{
                            required: "Este campo es requerido"
                        },
                        api_url:{
                            required: "Este campo es requerido"
                        }
                    }
                });
                /********************FIN VALIDATE DE ENTRADAS*********************/

            });
        </script>
html;
        $api = ApiControlDao::getApiById($api_id);
        $sStatus = '';
        foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
            $selected = ($api['status'] == $key)? 'selected' : '';
            $sStatus .=<<<html
            <option value="{$key}" {$selected}>{$value}</option>
html;
        }

        View::set('api', $api);
        View::set('sStatus', $sStatus);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_control_api_edit");
    }


    public function apiUpdate(){
        $api = new \stdClass();
        $api->_api_id = MasterDom::getData('api_id');
        $api->_nombre = MasterDom::getData('nombre');
        $api->_url = MasterDom::getData('api_url');
        $api->_status = MasterDom::getData('status');
        $id = ApiControlDao::updateApi($api);
            
        if($id >= 0){
            $alert = "success";
            $message = "Sucess $id";
        }else{
            $alert = "danger";
            $message = "Ha ocurrido un problema $id";
        }
        $mensaje .=<<<html
        <div class="alert alert-$alert alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <strong>Detalle : </strong>  {$message}
        </div>
html;
        View::set('regreso','/ApiControl/ApiAll');
        View::set('titulo','Api');
        View::set('class','success');
        View::set('mensaje','Detalle: '.$mensaje);
        View::render("mensaje");
    }

    public function apiDelete(){
        $ids = array();
        foreach (MasterDom::getDataAll('ids') as $key => $value) {
            $id = ApiControlDao::deleteApi($value);
            $ids[$id] = 'Eliminación de Api';
        }

        $mensaje = '';
        foreach ($ids as $key => $value) {
            if($key >= 0){
                $alert = "success";
                $message = "Sucess $value";
            }else{
                $alert = "danger";
                $message = "Ha ocurrido un problema en $value";
            }
            $mensaje .=<<<html
            <div class="alert alert-$alert alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                <strong>Detalle : </strong>  {$message}
            </div>
html;
        }
        View::set('regreso','/ApiControl/ApiAll');
        View::set('titulo','Api');
        View::set('class','success');
        View::set('mensaje','Detalle: '.$mensaje);
        View::render("mensaje");
    }
}







