<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
//use \App\models\ApiDoppler AS ApiDopplerDao;

class WebHookFacebook {
  private $token = 'EAAF0t4uRx6QBAAjfEOSUOxOmOjXMPe407SAqEZCOlILXo3amVyNj8GLrQIqUh8tfnrzbprbQh9b3uQtqyXfMbKnneZCoiuvJt1uZCk3KZAffcWLSEMF0rZBKP4P5UNxizsBvNxSuGdHn04xQHQiVnjq4xfBQ30asiDh1fTetGQkg7PPwVWxGxGqemT8MFYtMZD';
  private $url = "https://graph.facebook.com/v2.6/me/messages?access_token=";

  public function index(){
    /*******************/
    $challenge = $_REQUEST['hub_challenge'];
    $verify_token = $_REQUEST['hub_verify_token'];
    if ($verify_token === 'token_jorge') {
      echo $challenge;
    }
    /*******************/
    $input = json_decode(file_get_contents('php://input'), true);

    $sender = $input['entry'][0]['messaging'][0]['sender']['id'];
    $mensaje = $input['entry'][0]['messaging'][0]['message']['text'];
    $postback = $input['entry'][0]['messaging'][0]['postback']['payload'];

    if($mensaje == 'Inicio' || $mensaje == 'inicio' || $mensaje == 'INICIO' || $postback == -1){
      $this->sendMessageTipoContrato($sender);
      exit;
    }

    if(!empty($postback)){
      $postback = explode(',',$postback);
      switch ($postback[0]) {
        case 1:
          $this->sendMessageTipoPropiedad($sender,$postback[0], $postback[1]);
          break;
        case 2:
          $this->getMessageZonas($sender,$postback[0], $postback[1], $postback[2]);
          break;
        case 3:
          $this->getMessagePropiedades($sender,$postback[0], $postback[1], $postback[2], $postback[3], $postback[4], $postback[5]);
          break;
      }
    }
  }

  public function sendMessageText($sender, $mensaje){
    $jsonData = '{
        "recipient":{
            "id":"'.$sender.'"
        }, 
        "message":{
            "text": "'.$mensaje.'"
        }
    }';

    if(!empty($sender) && !empty($mensaje)){
      $this->execCurl($this->url.$this->token, $jsonData);
    }
  }

  public function sendMessageTipoContrato($sender){
    $jsonData ='{
      "recipient":{
        "id":"'.$sender.'"
      },
      "message":{
        "attachment":{
          "type":"template",
          "payload":{
            "template_type":"button",
            "text":"¡Hola! ¿En que puedo ayudarte hoy, qué buscas?:",
            "buttons":[{
                "type":"postback",
                "payload":"1,1",
                "title":"Renta"
            },{
                "type":"postback",
                "payload":"1,2",
                "title":"Venta"
            }]
          }
        }
      }
    }';

    $this->execCurl($this->url.$this->token, $jsonData);
  }

  public function sendMessageTipoPropiedad($sender, $opcion,$tipo_contrato){
    $jsonData ='{
      "recipient":{
        "id":"'.$sender.'"
      },
      "message":{
        "attachment":{
          "type":"template",
          "payload":{
            "template_type":"button",
            "text":"Seleccina una el tipo de propiedad",
            "buttons":[{
               "type":"postback",
               "payload":"2,'.$tipo_contrato.',1",
               "title":"Oficina"
             },
             {
               "type":"postback",
               "payload":"2,'.$tipo_contrato.',2",
               "title":"Casa"
             },
             {
               "type":"postback",
               "payload":"2,'.$tipo_contrato.',3",
               "title":"Departamento"
             }]
          }
        }
      }
    }';

    $this->execCurl($this->url.$this->token, $jsonData);
    $this->sendOpciones($sender, $opcion -1, $contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado, $propiedades->numero_propiedades);
  }

  public function getMessageZonas($sender, $opcion,$contrato_id, $tipo_inmueble_id){
    $zonas = $this->getZonasAPI($contrato_id, $tipo_inmueble_id);
    $opciones = '';
    foreach ($zonas->zonas as $key => $value) {
         /***********************/         
         $opciones .='{
            "content_type":"text",
            "title":"'.$value->localidad.'",
            "payload":"3,'.$contrato_id.','.$tipo_inmueble_id.','.$value->id_localidad.',1,3",
            "image_url":"http://5piso.com/img/inmuebles/principal_589_0_5acfef8056f87.JPG"
          },';
        /***********************/
    }//fin del for

    $this->respuestaRapida($sender, "Delegaciones:", $opciones);
    $this->sendOpciones($sender, $opcion, $contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado, $propiedades->numero_propiedades);
  }

  public function getMessagePropiedades($sender, $opcion,$contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado){
      $propiedades = $this->getPropiedadesAPI($contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado);
      $buttons = '';
      $contador = 0;
      foreach ($propiedades->propiedades as $key => $value) {
        $this->sendPantillaSencilla($sender,$value->id_inmueble, $value->foto, $value->titulo);
      }
      $this->sendOpciones($sender, $opcion, $contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado, $propiedades->numero_propiedades);
  }

  public function sendOpciones($sender, $opcion, $contrato_id, $tipo_inmueble_id, $id_localidad, $inicio, $paginado, $numero_propiedades){
      if( $numero_propiedades > ($inicio + $paginado) ){
         $inicio += $paginado; 
         $jsonData ='{
           "recipient":{
             "id":"'.$sender.'"
           },
           "message":{
             "attachment":{
               "type":"template",
               "payload":{
                 "template_type":"button",
                 "text":"Opciones",
                 "buttons":[{
                     "type":"postback",
                     "title":"Inicio",
                     "payload":"-1"
                 },{
                     "type":"postback",
                     "title":"Mas Propiedades",
                     "payload":"'.$opcion.','.$contrato_id.','.$tipo_inmueble_id.','.$id_localidad.','.$inicio.','.$paginado.'"
                 },{
                     "type":"postback",
                     "title":"Regresar",
                     "payload":"'.($opcion-1).','.$contrato_id.','.$tipo_inmueble_id.','.$id_localidad.','.$inicio.','.$paginado.'"
                 }]
               }
             }
           }
         }';
      }else{
         $jsonData ='{
           "recipient":{
             "id":"'.$sender.'"
           },
           "message":{
             "attachment":{
               "type":"template",
               "payload":{
                 "template_type":"button",
                 "text":"Opciones",
                 "buttons":[{
                     "type":"postback",
                     "title":"Inicio",
                     "payload":"-1"
                 },{
                     "type":"postback",
                     "title":"Regresar",
                     "payload":"'.($opcion-1).','.$contrato_id.','.$tipo_inmueble_id.','.$id_localidad.','.$inicio.','.$paginado.'"
                 }]
               }
             }
           }
         }';
      }

      $this->execCurl($this->url.$this->token, $jsonData);

  }

  public function sendPantillaSencilla($sender, $id_inmueble, $foto, $titulo){
      $json_imagen.='{
        "recipient":{
          "id":"'.$sender.'"
        },
        "message":{
              "attachment":{
                "type":"image", 
                "payload":{
                  "url":"http://5piso.com/img/inmuebles/'.$foto.'", 
                  "is_reusable":false
                }
              }
            }
      }';

      $json_botones.='{
        "recipient":{
          "id":"'.$sender.'"
        },
        "message":{
          "attachment":{
            "type":"template",
            "payload":{
              "template_type":"button",
              "text":"'.utf8_decode($titulo).'",
              "buttons":[{
               "type":"web_url",
               "url":"http://5piso.com/InteriorPropiedadTest/index/departamento-en-venta-'.$id_inmueble.'",
               "title":"Ver Detalles"
             },{
               "type":"phone_number",
               "title":"Llamar",
               "payload":"525551865113"
             },{
                "type": "element_share",
                "share_contents": {
                  "attachment": {
                    "type": "template",
                    "payload": {
                      "template_type": "generic",
                      "elements": [
                        {
                          "title": "'.$titulo.'",
                          "subtitle": "Inmueble",
                          "image_url": "http://5piso.com/img/inmuebles/'.$foto.'",
                          "default_action": {
                            "type": "web_url",
                            "url": "http://5piso.com/InteriorPropiedadTest/index/departamento-en-venta-'.$id_inmueble.'",
                          },
                          "buttons": [
                            {
                              "type": "web_url",
                              "url": "http://5piso.com/InteriorPropiedadTest/index/departamento-en-venta-'.$id_inmueble.'",
                              "title": "Ver Detalles del Inmueble"
                            }
                          ]
                        }
                      ]
                    }
                  }
                }
              }]
            }
          }
        }
      }';
      $this->execCurl($this->url.$this->token, $json_imagen);
      $this->execCurl($this->url.$this->token, $json_botones);
  }

  public function respuestaRapida($sender, $mensaje, $opciones){
    $jsonData ='{
      "recipient":{
        "id":"'.$sender.'"
      },
      "message":{
        "text": "'.$mensaje.'",
        "quick_replies":['.$opciones.']
      }
    }';

    $this->execCurl($this->url.$this->token, $jsonData);
  }

  public function getZonasAPI($contrato_id, $tipo_inmueble_id){
    $jsonData = '{
      "id_tipo_contrato": '.$contrato_id.',
      "id_tipo_inmueble": '.$tipo_inmueble_id.'
    }';
    return $this->execCurl("http://5piso.com/Api/getZonas", $jsonData);
  }

  public function getPropiedadesAPI($id_tipo_contrato, $id_tipo_inmueble, $id_localidad, $inicio, $paginado){
    $jsonData = '{
      "id_tipo_contrato":'.$id_tipo_contrato.',
      "id_tipo_inmueble":'.$id_tipo_inmueble.',
      "id_localidad":'.$id_localidad.',      
      "inicio":'.$inicio.',
      "cantidad_paginado":'.$paginado.'
    }';
    return $this->execCurl("http://5piso.com/Api/getPropiedades", $jsonData);
  }

  public function execCurl($url,$jsonData){
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => $jsonData,
      CURLOPT_HTTPHEADER => array("content-type: application/json"),
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    //mail('jorge.manon@airmovil.com','BOT_FACEBOOK','Ejecucion de Curl JsonData: '.json_encode($jsonData));
    return json_decode($response);
  }

}



















