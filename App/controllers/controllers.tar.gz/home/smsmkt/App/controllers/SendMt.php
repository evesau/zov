<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\SendMt as SendMtDao;
use \App\controllers\Contenedor;


class SendMt{

   public function sendGet(){
      $usuario = MasterDom::getData('usuario');
      $password = MasterDom::getData('pwd');
      $telefono = MasterDom::getData('msisdn');
      $mensaje = MasterDom::getData('msj');
      $carrier = MasterDom::getData('carrier');
      $source = MasterDom::getData('source');

      if($usuario == '' || $password == '' || $telefono == '' || $mensaje == '' || $carrier == '' || $source == '' ){
         echo "Algun paramentro recibido es incorrecto";
         exit;
      }

      $smsCampaignStatusId = 10;
      $delivery = date('Y-m-d H:i:s');  
      $usuario = SendMtDao::getCustomerByUser($usuario, $password);
      $msisdn_datos = SendMtDao::getMsisdnByMsisdn($telefono);

      if(count($usuario) > 0){
         $conexion = SendMtDao::getCarrierConnectionShortCode($usuario['customer_id'],$usuario['api_web_id'], $source);
         $campaign_id = $conexion['campaign_id'];
         $carrier_connection_short_code_id = $conexion['carrier_connection_short_code_id'];
         $modulesId = $conexion['modules_id'];
         
         if(empty($carrier_connection_short_code_id)){
            echo 'La campaña recibida no pertenece al customer del usuario';
            exit;
         }

         if(!preg_match("/^[0-9]{2}[0-9]{10}$/",$telefono)){
            echo "El MSISDN recibido es incorrecto";
            exit;
         }

         if(!empty($msisdn_datos['msisdn_id'])){
            $msisdnId = $msisdn_datos['msisdn_id'];         
            $carrier = $msisdn_datos['carrier_id'];
         }else{
            $msisdnId = SendMtDao::insertaMsisdn($telefono, $carrier_id);
         }

         if($this->verificarLimitesEnvios($conexion['customer_id'], $conexion['user_id'])){
            if(strlen($mensaje) <= 160){
               $id_mensaje = SendMtDao::insertSmsCampaign($campaign_id, $delivery, $msisdnId, $carrier_connection_short_code_id, $smsCampaignStatusId, $modulesId, $mensaje);
            }else{
               echo "El mensaje cuenta con mas caracteres de los permitidos";
               exit;
            }
            
         }else{
            echo 'Error general';
         }
         echo 'El mensaje ha sido encolado con el id : '.$id_mensaje;
      }else{
         echo 'El usuario o contraseña son incorrectas';
      }
   }

   public function verificarLimitesEnvios($customer, $usuario){
      $totales_customer_mes = SendMtDao::getTotalesCustomerMes($customer);
      $totales_customer_dia = SendMtDao::getTotalesCustomerDia($customer);

      $totales_user_mes = SendMtDao::getTotalesUserMes($usuario);
      $totales_user_dia = SendMtDao::getTotalesUserDia($usuario);

      if($totales_customer_mes['resta_mes'] > 0 && $totales_customer_dia['resta_dia'] > 0){
         if($totales_user_mes['resta_mes'] > 0 && $totales_user_dia['resta_dia'] > 0){
            return true;
         }else{
            echo "El Usuario ya no cuenta con envios disponibles";
            exit;
         }
      }else{
         echo "El Customer ya no cuenta con envios disponibles";
         exit;
      }

      return false;
   }

}
