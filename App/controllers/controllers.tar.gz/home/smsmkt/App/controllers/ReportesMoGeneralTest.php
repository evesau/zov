<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//include '/usr/local/bin/vendor/autoload.php';

use \Core\View;
use \Core\MasterDom;
use \App\models\Reportesmogeneral as ReportesDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ReportesMoGeneralTest{

    private $_contenedor;

    function __construct(){
        if($_GET['url'] != 'Reportesmogeneral/datosJsonMOGeneral' ){
            $this->_contenedor = new Contenedor;
            View::set('header',$this->_contenedor->header());
            View::set('footer',$this->_contenedor->footer());
        }
    }

    public function obtenerLimite($registros, $inicio, $limite){
        $seleccion = array();
        for($i = $inicio; $i<count($registros); $i ++) {
            $registro = json_encode($registros[$i]);
            if($registro != NULL){
                array_push($seleccion, json_decode(utf8_encode($registro)));
            }
            
            if($i == ($inicio + $limite)){
                break;
            }
        }

        //mail('jorge.manon@airmovil.com','Query Reportes', 'Seleccion: '.json_encode($seleccion));
        return $seleccion; 
    }

    public function mogeneral(){
        MasterDom::verificaUsuario();
        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

        <!-- DataTable Principal MO -->
        <script>

            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#fecha_inicio').datetimepicker({
                        format: 'YYYY-MM-DD',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#fecha_fin').datetimepicker({
                        format: 'YYYY-MM-DD',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });



                $("#fecha_inicio").on("dp.change", function (e) {
                    $('#fecha_fin').data("DateTimePicker").minDate(e.date);
                });
                $("#fecha_fin").on("dp.change", function (e) {
                    $('#fecha_inicio').data("DateTimePicker").maxDate(e.date);
                });

                $('#fecha_inicio').val('');
                $('#fecha_fin').val('');

                /*se forza el click del boton para inicializar la tabla de los MO's*/
                $("#btnAplicar").click();


            });

            function actualizarDataTableMO(){
                $("#reporte_mo").dataTable().fnDestroy();
            }

            $("#btnAplicar").click(function(){
                $("#reporte_mo").dataTable().fnDestroy();
                muestraInfoMO();
            });

            $("#btnExcel").click(function(){
                //$("#reporte_mo_general").attr('target','_blank'); //forzar a abrir en una nueva pestaña la petición
                //$("#reporte_mo_general").attr('method','POST');//se cambia el atributo del metodo de envio del formulario
                $("#reporte_mo_general").attr("action","/Reportesmogeneral/generarExcelMOGeneral");
                $("#reporte_mo_general").submit();

            });

            function muestraInfoMO(){
                //alert($("#in").val());
                $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/ReportesMoGeneralTest/datosJsonMOGeneral',
                                        "Type":'POST',
                                        "data": {
                                            fecha_inicio: $("#fecha_inicio").val(),
                                            fecha_fin: $("#fecha_fin").val(),
                                            source: $("#source").val(),
                                            destination: $("#destination").val(),
                                            keyword: $("#keyword").val(),
                                            in: $("#in").val()
                                        }
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $shortcode = ReportesDao::getShortCodeByCustomer($id_custom);

        $short_codes = '';
        foreach ($shortcode as $key => $value) {
            $short_codes .= "'".$value['SHORT_CODE']."'";
            if($key != count($shortcode)-1){
                $short_codes .= ',';
            }
        }

        $row = ReportesDao::getAllCampaignMO($id_custom, $short_codes);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name']." -- ".$value['short_code']."</option>";
            //$select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('in',$short_codes);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reporte_mo_general_test");
    }

    /**
     * Jorge 24/Octubre/2017
     * Metodo que genera los datos JSON dependiendo de los datos enviados desde el formulario de la vista
     * reporte_mo_general, esta funcion alimenta la tabla de reporte_mo
     */
    public function datosJsonMOGeneral(){
        //header("Content-type: application/json; charset=utf-8");
        $start = MasterDom::getData('start');
        $length = MasterDom::getData('length');
        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
        $in = MasterDom::getData('in');
        $fecha_inicial = MasterDom::getData("fecha_inicio");
        $fecha_fin = MasterDom::getData("fecha_fin");
        $source = MasterDom::getData("source");
        $destination = MasterDom::getData("destination");
        $status = MasterDom::getData("status");
        $keyword = MasterDom::getData("keyword");

        $limit_fecha = '';
        $limit_fecha .= ($fecha_inicial != '')? " AND sms.entry_time >= '".$fecha_inicial." 00:00:00'" : '';
        $limit_fecha .= ($fecha_fin != '')? " AND sms.entry_time <= '".$fecha_fin." 23:59:59'" : ''; 
        $limit_fecha .= ($in != '')? ' AND sms.destination IN('.$in.')' : ''; 

        $limit_fecha .= ($source != '')? " AND sms.source = '".$source."'" : '';
        $limit_fecha .= ($destination != '')? " AND sms.destination = '".$destination."'" : '';
        $limit_fecha .= ($keyword != '')? " AND sms.content = '".$keyword."'" : '';

        $consulta = new \stdClass();
        $consulta->where = $limit_fecha;
        $registros = ReportesDao::reportMOGeneral($consulta);
        $recordsTotalFiltered = count($registros);        
        $consulta->limit = (!empty($start) && !empty($length))? " LIMIT $start, $length" : ' LIMIT 0, 20';

        /*se sacan el intervalo de valores del conjunto de registros*/
        $registros = $this->obtenerLimite($registros, $start, $length);

        echo json_encode(array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$registros));
        exit;
    }

    /**
     * Jorge 24/Octubre/2017
     * Metodo que genera el archivo Excel y lo descarga automaticamente, esta funcion recibe los paramentros
     * desde el formulario reporte_mo_general de la vista reporte_mo_general, el cual envia los datos a esta funcion
     * en una nueva pestaña del navegador
     */
    public function generarExcelMOGeneral(){
        $fecha_inicial = MasterDom::getData("fecha_inicio");
        $fecha_fin = MasterDom::getData("fecha_fin");
        $source = MasterDom::getData("source");
        $destination = MasterDom::getData("destination");
        $status = MasterDom::getData("status");
        $keyword = MasterDom::getData("keyword");
        $in = MasterDom::getData("in");


        //mail('jorge.manon@airmovil.com', 'Query datos', 'Fecha Inicial: '.$fecha_inicial.'<br>Fecha Final: '.$fecha_fin);

        $limit_fecha = '';
        $limit_fecha .= ($fecha_inicial != '')? " AND sms.entry_time >= '".$fecha_inicial." 00:00:00'" : '';
        $limit_fecha .= ($fecha_fin != '')? " AND sms.entry_time <= '".$fecha_fin." 23:59:59'" : ''; 
        $limit_fecha .= ($in != '')? ' AND sms.destination IN('.$in.')' : ''; 

        $limit_fecha .= ($source != '')? " AND sms.source LIKE '%".$source."%'" : '';
        $limit_fecha .= ($destination != '')? " AND sms.destination LIKE '%".$destination."%'" : '';
        $limit_fecha .= ($status != '')? " AND sms.status LIKE '%".$status."%'" : '';
        
        $limit_fecha .= ($keyword != '')? " AND (sk.keyword = '".$keyword."' OR "." sms.content = '".$keyword."')"  : '';
        
        $consulta = new \stdClass();
        $consulta->where = $limit_fecha;
        $consulta->limit = (!empty($start) && !empty($length))? " LIMIT $start, $length" : '';
        /**/
        Reportesmogeneral::crearExcel(ReportesDao::reportMOGeneral($consulta));
    }

    public function datosJsonMO(){
        header("Content-type: application/json; charset=utf-8");
        $start = MasterDom::getData('start');
        $length = MasterDom::getData('length');
        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
        $id_custom = MasterDom::getSession('customer_id');
        $id_campania = $_GET['id_camp'];
        
        if(empty($id_campania)){
            $recordsTotalFiltered = count(ReportesDao::reportMOTotal($id_custom));
            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCopTotal($id_custom ,$start, $length));
            print_r(json_encode($prueba));
            exit;

            //echo json_encode($prueba);
        } elseif(!empty($id_campania)){
            $recordsTotalFiltered = count(ReportesDao::reportMO($id_custom, $id_campania));
            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCop($id_custom, $id_campania, $start, $length));
            print_r(json_encode($prueba));
            exit;
            //echo json_encode($prueba);
        }
    }

    public static function crearExcel($mensajes){
        $encabezado = array('FECHA','SOURCE','DESTINATION','CONTENT','ESTATUSSMS');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }


}














