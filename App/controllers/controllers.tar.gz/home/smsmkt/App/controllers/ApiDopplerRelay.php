<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
include_once "/home/smsmkt/public/PHPMailer/PHPMailerAutoload.php";

class ApiDopplerRelay{

		private $_contenedor;
		private $_host_doppler = 'https://restapi.fromdoppler.com/accounts/';
		private $_api_key='2B55B4D51DA0C1F6CF721687D4E8BF7F';
    	private $_usuario_doppler = 'jorge.manon%40airmovil.com';
    	private $_url_peticion;
	
	function __construct(){
        $this->_url_peticion = $this->_host_doppler.$this->_usuario_doppler;
        if($_GET['url'] != 'ApiDopplerRelay/test'){
            $this->_contenedor = new Contenedor;
            View::set('header',$this->_contenedor->header());
            View::set('footer',$this->_contenedor->footer());
        }
    }

	public function index(){
		//$this->vaciarList(1149662);
		$this->importarSuscriptores();
/*
		$listaClientes = array();
		foreach($this->getLists()->items AS $keyList => $valueList){
			foreach($this->getSuscriberById($valueList->listId)->items AS $keySuscriptor => $valueSuscriptor){
				//echo 'Email: '.$valueSuscriptor->email.'<br>';
				if($listaClientes[$valueSuscriptor->email] == ''){
					//array_push($listaClientes, $valueSuscriptor);
					$listaClientes[$valueSuscriptor->email] = $valueSuscriptor;
				}
			}
		}


		foreach($listaClientes AS $keyClientes => $valueClientes){
			$this->asignarSuscriptorList(1149662, array('email' => $valueClientes->email, 'fields' => $valueClientes->fields));
		}
*/
		View::set('tabla', $tabla);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_suscriber");
	}
	
	public function asignarSuscriptorList($list_id){
		$data_string = json_encode($suscriptor);
		$url = "$this->_url_peticion/lists/$list_id/subscribers?api_key=$this->_api_key";
        $ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json;charset=UTF-8','Content-Length: ' . strlen($data_string)));
		$result = curl_exec($ch);
		if($result == false){
		    echo 'Curl error: ' . curl_error($ch).'<br><br>';
		}else{
		    echo 'Operación completada sin errores<br><br>';
		}
	}

	public function vaciarList($list_id){
		
		$suscriptores = $this->getListById($list_id);

		foreach ($suscriptores->items as $key => $value) {
			$email = str_replace('@','%40',$value->email);
			$url = "$this->_url_peticion/lists/$list_id/subscribers/$email?api_key=2B55B4D51DA0C1F6CF721687D4E8BF7F";
			$data_string = json_encode(array('email' => $email));
	        $ch = curl_init($url);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json;charset=UTF-8','Content-Length: ' . strlen($data_string)));
			$result = curl_exec($ch);			
		}
	}

	public function importarSuscriptores(){
		$url = "https://restapi.fromdoppler.com/accounts/jorge.manon%40airmovil.com/lists/1149662/subscribers/import-csv?api_key=2B55B4D51DA0C1F6CF721687D4E8BF7F";

		$data_string = json_encode("jorgeitch@hotmail.com,Jorge,Manon,7471406668,25/11/17,26/11/17,Masculino,23/04/93
juan.medina@airmovil.com,Juan ,Medina,5510123937,26/11/17,27/11/17,Masculino,15/06/90
cesar.rivera@airmovil.com,Cesar,Cortes,5551865113,27/11/17,28/11/17,Masculino,21/02/95
jaime.ramirez@airmovil.com,Jaime,Ramirez,5543904792,28/11/17,29/11/17,Masculino,05/07/87");


        $ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/csv','Accept: application/json'));
		$result = curl_exec($ch);
		if($result == false){
		    echo 'Curl error: ' . curl_error($ch).'<br><br>';
		}else{
		    echo 'Operación completada sin errores<br><br>';
		}
		print_r($result);
		echo '<br>';
	}

	public function sendMail(){
        	$username = getenv('jorge.manon@airmovil.com');
	        $password = getenv('Airmovil1');
        	$host = 'smtp.dopplerrelay.com';
	        $port = 587;
        	$fromEmail = 'santander@airmovil.com';
	        $fromName = 'Santander';
     
        	$to1Email = 'juan.medina@airmovil.com';
	        $to1Name = 'Juan';
        
	        $to2Email = 'jaime.ramirez@airmovil.com';
        	$to2Name = 'Jaime Ramirez';

	        $to3Email = 'jorge.manon@airmovil.com';
        	$to3Name = 'Jorge Mañon';

        	$subject = 'Test desde Doppler Relay';
	        $text = "Hola Mundo";
        	$html = "<html><label>Hola Mundo</label></html>";
	        $mail = new \PHPMailer;
	        //$mail->IsSMTP();
	        $mail->Host = $host;
	        $mail->Port = $port;
	        $mail->SMTPAuth = true;
        	$mail->AuthType ='LOGIN';
	        $mail->Username = $username;
	        $mail->Password = $password;
        	$mail->SMTPSecure = 'ssl';
	        $mail->From = $fromEmail;
        	$mail->FromName = $fromName;
	        $mail->AddAddress($to1Email, $to1Name);
	        $mail->AddAddress($to2Email, $to2Name);
	        $mail->AddAddress($to3Email, $to3Name);
	        $mail->IsHTML(true);
	        $mail->Subject = $subject;
	        $mail->Body = $html;
	        $mail->AltBody = $text;
	        
	        if(!$mail->Send()) {
	            echo 'Message could not be sent.';
	            echo 'Mailer Error: ' . $mail->ErrorInfo;
        	    exit;
	        }
	        echo 'Message has been sent';
	}


	public function getReporteCampaign($campaign_id){
	        return json_decode(file_get_contents("$this->_url_peticion/campaigns/$campaign_id/results-summary?api_key=$this->_api_key"));
    	}

	public function getCampaigns(){
        	return json_decode(file_get_contents($this->_url_peticion."/campaigns?page=1&per_page=10&api_key=$this->_api_key"));
    	}

	public function getCampaign($campaignId){
        	return json_decode(file_get_contents($this->_url_peticion.'/campaigns/'.$campaignId.'/deliveries?page=1&per_page=10&api_key='.$this->_api_key));
    	}
	
	public function getSuscriberById($listId){
		//return json_decode(file_get_contents($this->_url_peticion."/lists/".$listId."/subscribers?page=1&per_page=10&api_key=".$this->_apikey));
		return json_decode(file_get_contents($this->_url_peticion."/lists/".$listId."/subscribers?page=1&per_page=10&api_key=".$this->_api_key));
	}

	public function getFieldsById($email){
		$email = str_replace('@','%40',$email);
		return json_decode(file_get_contents($this->_url_peticion."/subscribers/".$email."?api_key=".$this->_api_key));
	
	}
	
	public function getLists(){
		return json_decode(file_get_contents($this->_url_peticion."/lists?page=1&per_page=10&api_key=$this->_api_key"));
	}

	public function getListById($list_id){
		return json_decode(file_get_contents("$this->_url_peticion/lists/$list_id/subscribers?page=1&per_page=10&api_key=$this->_api_key"));
	}
}







