<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Control as ControlDao;
use \App\controllers\Contenedor;

class Control{

	function __construct() {
		$this->_contenedor = new Contenedor;
		View::set('header',$this->_contenedor->header());
		View::set('footer',$this->_contenedor->footer());
    }

	public function index(){

		$table_truncate = array(0 =>"campaing", 1 =>"campaign_api_web", 2 =>"campaign_carrier_short_code",3=>"campaign_customer",4=>"campaign_user",4=>"carrier_connection_short_code_campaign",6=>"customer_service",7=>"msisdn",8=>"service",9=>"service_keyword",10=>"msisdn_white_list",11=>"sms",12=>"sms_campaign",13=>"user_control_mt");

		//option //customer_control_mt


		$tables = ControlDao::getAll();
		$truncate = ControlDao::truncate();
		echo "<pre>";
		print_r($truncate);
		echo "</pre>";


		View::render("control");
	}
}
?>