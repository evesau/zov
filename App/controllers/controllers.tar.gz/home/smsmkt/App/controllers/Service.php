<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

use \Core\View;
use \Core\MasterDom;
use \App\models\Service as serviceDao;
use \App\controllers\Contenedor;

class Service {

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

    MasterDom::verificaUsuario();
  	View::render("service");
    
    }


        public function seleccionar(){

      MasterDom::verificaUsuario();
      $id_custom = MasterDom::getSession('customer_id');

      $extraHeader=<<<html
<!-- DataTables CSS -->
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

      $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>

    <script>    
        $(document).ready(function() {

            $(".seleccion_campania").on("change", function () {
              valor = $(this).val();
                if(valor == "no"){
                  $('#nombre_campania').removeAttr("disabled");
                }else
                  $('#nombre_campania').attr('disabled', 'disabled');
            });


            $("#add").validate({
                    rules: {
                        nombre_campania: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania: {
                            required: "Este campo es obligatorio"
                        }
                    }
            });

        });
    </script>
html;

$si = '';
$no = '';

  $html=<<<html
  <div class="x_panel">
    <div class="x_content">
      <form id="add" action="/Service/serviceCampania" enctype="multipart/form-data" method="POST">
        <div class="form-group">
            <label class="control-label">¿Para crear el servicio seleccionar&aacute;s una campaña existente? : </label>
            <div class="radio">
                <label class="action">
                  <input value=si class="seleccion_campania" name="campania_e" checked="checked" type="radio"> Si 
                </label>
                <label class="action">
                  <input value=no class="seleccion_campania" name="campania_e" type="radio"> No
                </label>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label">Campaña: </label>
              <div class="">
                <input type="text" class="form-control" placeholder="Nombre de la campaña" name="nombre_campania" id="nombre_campania" disabled>
              </div>
        </div>

        <div class="form-group">
            <div class="col-md-12 col-sm-9 col-xs-12">
                <button type="submit" class="btn btn-success pull-right">Siguiente</button>
            </div>
        </div>
      </form>
    </div>
  </div>
html;

  View::set('contenido',$html);
  View::set('header',$this->_contenedor->header($extraHeader));
  View::set('footer',$this->_contenedor->footer($extraFooter));
  View::render("service_seleccionar");
    }

    public function serviceCampania(){

      $check = MasterDom::getData('campania_e');
        if(empty($check))
          return MasterDom::alertas('error_general'); 

      if (MasterDom::getData('campania_e') == "si") {
        header('location: /service/add');
      }elseif(MasterDom::getData('campania_e') == "no") {
        $this->seleccionaMarcacionExistente();
      }
    }

    public function seleccionaMarcacionExistente(){

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $nombreCampania = MasterDom::getData('nombre_campania');
        
        $shortCode = serviceDao::getCarrierCustomerGroup($customer);

        $shortCodeHtml = '';
        foreach($shortCode AS $k=>$value){
            $ids = serviceDao::getCarrierCustomer($customer, $value['short_code_id']);
            if(empty($ids))
                continue;

                $disabled = ($k == 0) ? '' : 'disabled';
                $check = ($k == 0) ? 'checked="checked"' : '';

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Marcacion :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <label class="action">
                                    <input class="seleccion" value="_dato_{$k}" name="iCheck" $check type="radio"> {$value['short_code']}
                                </label>
                            </div>
                        </div>
                        <fieldset class="existente_valida_dato_{$k}" $disabled>
html;
            foreach($ids AS $val){

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;carrier :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <div class="checkbox">
                                    <label><input type="checkbox" class"carrier" name="carrier_connection_short_code_id[]" value="{$val['carrier_connection_short_code_id']}" checked="checked">{$val['name']}</label>
                                </div>
                            </div>
                        </div>
html;
            }
            $shortCodeHtml.=<<<html
                        </fieldset>
                        <br />
html;
        }


  $html=<<<html
  <div class="x_panel">
    <div class="x_title">
      <h2>Configuracion de Marcacion</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
          <li><a class="close-link"><i class="fa fa-close"></i></a></li>
        </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <p>En esta pantalla podra seleccionar la marcacion por la cual va a salir el mensaje, puedes seleccionar los carriers para el envio.</p>
      <div class="ln_solid"></div>
      <form id="add" action="/Service/addServiceCampania" method="POST">

        $shortCodeHtml

        <div class="ln_solid"></div>

        <div class="form-group">
          <div class="col-md-12 col-sm-9 col-xs-12">
            <a href="#" class="btn btn-success pull-right">Siguiente</a>
          </div>
        </div>
        <input type="hidden" value="$nombreCampania" name='nombre_campania'/>
        <input type="hidden" value="$customer" name='customer_id'/>
      </form>
    </div>
  </div>
html;



        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {
             $(".seleccion").on("change", function () {
                valor = $(this).val();
                $("fieldset[class*='existente_valida']").attr('disabled', 'disabled');
                $('.existente_valida'+ valor).removeAttr("disabled");
            });

            $('.btn-success').on("click",function() {
                var pivote = $(".seleccion:checked").val();
                var buscar = $(".existente_valida" + pivote + " input:checked")
                if(buscar.length == 0){
                    bootbox.alert("Error: debes seleccionar por lo menos un carrier!");
                }else
                    $( "#add" ).submit();
            }); 

        });
    </script>
html;

  View::set('contenido',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("service_seleccionar");
    }

        public function addServiceCampania(){
          //print_r($_POST);
        // echo "comienza la función\n";

        $carrierConnectionArray = MasterDom::getDataAll('carrier_connection_short_code_id');

        $carrierIds = '';
        foreach($carrierConnectionArray AS $value){
            $carrierIds .= "$value,";
        }

        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = serviceDao::findCarriersP($carrierIds);
        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

             
        //$buscaCarrier = function ($valor) use($carrierIdsArray){
            foreach($carrierIdsArray AS $value){ 
                if($value['carrier_id'] == $carrierIdsArray){
                    $carrierConnectionId = $value['carrier_connection_id'];
                    $carrierId = $value['carrier_id'];
                    $shortCodeId = $value['short_code_id'];
                    $carrierConnectionShortCodeId = $value['carrier_connection_short_code_id'];
                    $shortCode = $value['short_code'];
                    break;
                }
            }          
            //return $retorno; 
        //};

        $carrierId = $value['carrier_id'];
        $shortCodeId = $value['short_code_id'];
        $carrierConnectionShortCodeId = $value['carrier_connection_short_code_id'];

        $serviceCampania = new \stdClass();
        $serviceCampania->_name = MasterDom::getData('nombre_campania');
        $serviceCampania->_module_id = 4;
        $serviceCampania->_delivery_date = "00:00:00";
        $serviceCampania->_campaing_status_id = 1;
        // echo "\ncontroller\n

        // exit;
        $addCamp = serviceDao::insertCS($serviceCampania);
        // echo "addCamp: $addCamp";

         $id_custom = MasterDom::getSession('customer_id');

             $datos = new \stdClass();
             $datos->_customer_id = $id_custom;
             $datos->_campaign_id = $addCamp;
             // echo "datos: ";

             $addCC = serviceDao::insertCC($datos);

                   $dateccsc = new \stdClass();
                   $dateccsc->_campaign_id = $addCamp;
                   $dateccsc->_carrier_id = $carrierId;
                   $dateccsc->_short_code_id = $shortCodeId;
             
                  $addCCSC = serviceDao::insertaCCSC($dateccsc);

                         $dateccscc = new \stdClass();
                         $dateccscc->_campaign_id = $addCamp;
                         $dateccscc->_carrier_connection_short_code_id = $carrierConnectionShortCodeId;

                         $dateCCSCC = serviceDao::insertaCCSCC($dateccscc);

        //exit;

        if (empty($addCamp) && empty($addCC) && empty($addCCSC) && empty($addCCSCC)) {
              return $this->alertas('error_general');
        } else {
            return $this->alerta('success_add');
            $registro = $this->registroUsuario("Agrego service {$addCamp}");
            serviceDao::registroUsuario($registro);
        }

    }

    private function alerta($caso = 'error_general'){
            $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'La campa&ntilde;a se cre&oacute; exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
              
          View::set('regreso','/service/add');
          View::set('class', $class);
          View::set('titulo','Campa&ntilde;a');
          View::set('mensaje', $mensaje);
          View::render("mensaje");
        }

    /***********************************************************************************************************/

    public function add() {
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    campania: {
                        required: true
                    },

                    short_code: {
                        required: true
                    },

                    title: {
                        required: true
                    },
                    
                    description: {
                        required: true
                    },

                    handler: {
                        required: true
                    },

                    configuration: {
                        required: true
                    }
                },
                messages: {
                    campania: {
                        required: "Este campo es obligatorio"
                    },

                    short_code: {
                        required: "Este campo es obligatorio"
                    },

                    title: {
                        required: "Este campo es obligatorio"
                    },

                    description: {
                        required: "Este campo es obligatorio"
                    },
                    
                    handler: {
                        required: "Este campo es obligatorio"
                    },

                    configuration: {
                        required: "Este campo es obligatorio"
                    }
                }
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#campania").change(function() {
                    var form_data = {
                        campania: $("#campania").val()
                    };
                    $.ajax({
                            type: "POST",
                            url: "/Service/showShortCode",
                            data: form_data,
                            success: function(response)
                            {
                                console.debug(response);
                                $("#short_code").html(response).fadeIn();
                            }
                    });
                });

                $("#handler").change(function(){
                    if( $("#handler").val() == 'url'){
                        console.debug('url');
                        $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                        $("#configuration").get(0).type = 'url';
                    }
                    if( $("#handler").val() == 'staticText'){
                        console.debug('staticText');
                        $("#configuration").get(0).placeholder = 'Ingresa el texto';
                        $("#configuration").get(0).type = 'text';
                    }
                });
        
            });
        </script>

html;
        $id_custom = MasterDom::getSession('customer_id');

        $campania_option = '';
        $campania = serviceDao::getCampaign($id_custom);
        foreach ($campania as $key => $value) {
            $campania_option .= '<option value='.$value['campaign_id'].'>'.$value['name'].'</option>';
        }
        
        View::set('campania_option',$campania_option);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("service_add");
    
    }

    public function showShortCode(){
        $id_campania = MasterDom::getData('campania');
        //echo $id_campania;

        $option_short_code = '';
        $short_code = serviceDao::getShortCode($id_campania);
        //print_r($short_code);
        foreach ($short_code as $key => $value) {
            $option_short_code .= '<option value='.$value['short_code_id'].'>'.$value['short_code'].'</option>';
        }
 
        echo $option_short_code;
    }

    public function add_service(){

        MasterDom::verificaUsuario();
        if (empty($_POST)){ header('location:/Service/');}

        $campania   = MasterDom::getData('campania');
        $short_code = MasterDom::getData('short_code');
        $title      = MasterDom::getData('title');
        $description= MasterDom::getData('description');
        $handler    = MasterDom::getData('handler');
        $configuration = MasterDom::getData('configuration');
        $keywords   = explode("\n", MasterDom::getData('keywords'));

        $service = new \stdClass();
        $service->_campania = $campania;
        $service->_short_code = $short_code;
        $service->_title = $title;
        $service->_description = $description;
        $service->_handler = $handler;
        $service->_configuration = $configuration;
        $service->_status = 1;
        $priority = 0;
        if ($id_service = serviceDao::insert($service)){

            $id_customer_service = serviceDao::insertCustomerService(MasterDom::getSession('customer_id'), $id_service);
            
            foreach ($keywords as $key => $value) {
                $priority = $priority +1;
                if ($value != '') {
                    if (!serviceDao::insertKeywords(trim($value),$id_service,$priority++)){
                        header('location:/Service/add');
                    }
                }   
            }
            $registro = $this->registroUsuario("Agrego service:{$id_service}");
            serviceDao::registroUsuario($registro);            

            return $this->alertas('success_add');
        } else {
            return $this->alertas('error_general');
        }
    }
/*********************************************************************************************************/
    public function edit(){

        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;
        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

    <script>
        $("#form").validate({
            rules: {
                campania: {
                    required: true
                },

                short_code: {
                    required: true
                },

                title: {
                    required: true
                },

                description: {
                    required: true
                },
                
                handler: {
                    required: true
                },

                configuration: {
                    required: true
                }
            },
            messages: {

                    campania: {
                        required: "Este campo es obligatorio"
                    },

                    short_code: {
                        required: "Este campo es obligatorio"
                    },

                    title: {
                        required: "Este campo es obligatorio"
                    },

                    description: {
                        required: "Este campo es obligatorio"
                    },
                    
                    handler: {
                        required: "Este campo es obligatorio"
                    },

                    configuration: {
                        required: "Este campo es obligatorio"
                    }
                }
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {

            $("#servicio").change(function(){
                console.debug()
                var form = {
                    service: $("#servicio").val()
                };

                $.ajax({
                    type: "POST",
                    url: "/Service/getDataService",
                    dataType: 'json',
                    data: form,
                    async: false,
                    success: function(data){
                        console.debug(data);
                        $('#id_service').val(data._service_id);
                        $('#campania').val(data._campaign_id);
                        $('#short_code_id').val(data._short_code_id);
                        $('#short_code').val(data._short_code);
                        $('#title').val(data._title);
                        $('#description').val(data._description);
                        $('#handler').val(data._handler);
                        $('#configuration').val(data._configuration);
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "/Service/getKeywords",
                    dataType: 'json',
                    data: form,
                    async: false,
                    success: function(data){
                        console.debug(data);
                        $('#keywords').val(data);
                    }
                });

            });

            $("#handler").change(function(){
                if( $("#handler").val() == 'url'){
                    console.debug('url');
                    $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                    $("#configuration").get(0).type = 'url';
                }
                if( $("#handler").val() == 'staticText'){
                    console.debug('staticText');
                    $("#configuration").get(0).placeholder = 'Ingresa el texto';
                    $("#configuration").get(0).type = 'text';
                }
            });
        });
    </script>
html;
        
        $service_option = '';
        $service = serviceDao::getService($id_custom);
        foreach ($service as $key => $value) {
            $service_option .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        $campania_option = '';
        $campania = serviceDao::getCampaign($id_custom);
        foreach ($campania as $key => $value) {
            $campania_option .= '<option value='.$value['campaign_id'].'>'.$value['name'].'</option>';
        }

        View::set('campania_option',$campania_option);
        View::set('service_option',$service_option);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("service_edit");
    }

    public function getDataService(){
        $id_service = MasterDom::getData('service');
        $info = serviceDao::getServiceContent($id_service);
        //print_r($info);

        $service = new \stdClass();
        $service->_service_id = $info['service_id'];
        $service->_campaign_id = $info['campaign_id'];
        $service->_short_code_id = $info['short_code_id'];
        $service->_short_code = $info['short_code'];
        $service->_title = $info['title'];
        $service->_description = $info['description'];
        $service->_handler = $info['handler'];
        $service->_configuration = $info['configuration'];

        //print_r($service); 

        $json = json_encode($service);
        echo $json;
    }


    public function getKeywords(){
        $id_service = MasterDom::getData('service');
        $keyword = serviceDao::getServiceKeyword($id_service);
        
        $keywords = '';
        foreach ($keyword as $key => $value) {
            if ($value['keyword'] != '')
                $keywords .= $value['keyword']."\n";
        }

        $keywords = trim($keywords,"\n");

        $json = json_encode($keywords);
        echo $json;
    }

    public function edit_service(){

        MasterDom::verificaUsuario();
        if (empty($_POST)){ header('location:/Service/');}

        $service_id =MasterDom::getData('id_service');
        $campania   = MasterDom::getData('campania');
        $short_code = MasterDom::getData('short_code');
        $short_code_id = MasterDom::getData('short_code_id');
        $title      = MasterDom::getData('title');
        $description= MasterDom::getData('description');
        $handler    = MasterDom::getData('handler');
        $configuration = MasterDom::getData('configuration');
        $keywords   = explode("\n", MasterDom::getData('keywords'));

        $service = new \stdClass();
        $service->_service_id = $service_id;
        $service->_campania = $campania;
        $service->_short_code_id = $short_code_id;
        $service->_title = $title;
        $service->_description = $description;
        $service->_handler = $handler;
        $service->_configuration = $configuration;
        $service->_status = 1;


        /*Antes de insertar las keywords hay que borrar los resgistros pasados*/
        serviceDao::delete($service_id);

        /*Se hace la actualización de datos*/
        serviceDao::update($service);

        $priority = 0;           
            foreach ($keywords as $key => $value) {
                $priority = $priority +1;
                if ($value != '') {
                    if (!serviceDao::insertKeywords($value,$service_id,$priority)){
                        header('location:/Service/add');
                    }
                }   
            }

            $registro = $this->registroUsuario("Actualizo service {$service_id}");
            serviceDao::registroUsuario($registro);            

            return $this->alertas('success_edit'); //exito
    }

/********************************************************************************************************/
    public function delete(){
        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;
        $extraFooter =<<<html
        <!--jQuery validate -->
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script>
            $("#form").validate({
                rules: {
                    servicio: {
                        required: true
                    }
                },
                messages: {
                    servicio: "Este campo es requerido"
                }
            });
        </script>
html;
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $service_option = '';
        $service = serviceDao::getService($id_custom);
        foreach ($service as $key => $value) {
            $service_option .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('service_option',$service_option);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("service_delete");
    }

    public function delete_service(){
        MasterDom::verificaUsuario();
        if (empty($_POST)) header('location:/Service/seleccionar');

        $id_service = MasterDom::getData('servicio');
        //echo $id_service;exit;
        
        serviceDao::deleteService($id_service);
        $registro = $this->registroUsuario("Elimino service {$id_service}");
        serviceDao::registroUsuario($registro);

        return $this->alertas('success_delete'); //exito

    }

    /***************************************************************************************************/
    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'El servicio se cre&oacute; exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borr&oacute; con &eacute;xito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modific&oacute; con &eacute;xito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurri&oacute; algo inesperado.';

        View::set('regreso','/menu');
        View::set('class', $class);
        View::set('titulo','Servicio');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

}
