<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Campaign as CampaignDao;
use \App\controllers\TestGraphs;

class TestGraphs
{

private $_contenedor;

    function __construct() { 
    $this->_contenedor = new Contenedor;
    View::set('header',$this->_contenedor->header());
    View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

      //View::set('contenido',$html);
      $prueba =<<<html

      <form id="form" class="form-horizontal form-label-left" >
            <div class="form-group">
              <label class="col-sm-3 control-label">Escribe un n&uacute;mero: </label>
              <div class="col-sm-9">
                <div class="input-group">
                  <input type="text" class="form-control" name="number" id="number">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Escribe tu mensaje: </label>
              <div class="col-sm-9">
                <div class="input-group">
                  <textarea type="text" class="resizable_textarea form-control" maxlength="160" id="texto"></textarea>
                </div>
              </div>
            </div>
              <div class="form-group">
                <div class="col-md-12 col-sm-9 col-xs-12">
                  <button type="button" class="btn btn-success pull-right">Enviar</button>
              </div>
            </div>
        </form>
html;

      @file_put_contents('log.txt', print_r($prueba,1), FILE_APPEND);
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());
      View::set('prueba',$prueba);
      View::render("testgraphs");
    }

    /*@file_put_contents('log.txt', print_r($data,1), FILE_APPEND);*/

  /*  public function seleccionar(){

      MasterDom::verificaUsuario();
      $id_custom = MasterDom::getSession('customer_id');

      $extraHeader=<<<html
<!-- DataTables CSS -->
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

      $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>

    <script>    
        $(document).ready(function() {

            $(".seleccion_campania").on("change", function () {
              valor = $(this).val();
                if(valor == "no"){
                  $('#nombre_campania').removeAttr("disabled");
                }else
                  $('#nombre_campania').attr('disabled', 'disabled');
            });


            $("#add").validate({
                    rules: {
                        nombre_campania: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania: {
                            required: "Este campo es obligatorio"
                        }
                    }
            });

        });
    </script>
html;

$si = '';
$no = '';

  $html=<<<html
  <div class="x_panel">
    <div class="x_content">
      <form id="add" action="/TestGraphs/serviceCampania" enctype="multipart/form-data" method="POST">
        <div class="form-group">
            <label class="control-label">¿Para crear el servicio seleccionar&aacute;s una campaña existente? : </label>
            <div class="radio">
                <label class="action">
                  <input value=si class="seleccion_campania" name="campania_e" checked="checked" type="radio"> Si 
                </label>
                <label class="action">
                  <input value=no class="seleccion_campania" name="campania_e" type="radio"> No
                </label>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label">Campaña: </label>
              <div class="">
                <input type="text" class="form-control" placeholder="Nombre de la campaña" name="nombre_campania" id="nombre_campania" disabled>
              </div>
        </div>

        <div class="form-group">
            <div class="col-md-12 col-sm-9 col-xs-12">
                <button type="submit" class="btn btn-success pull-right">Siguiente</button>
            </div>
        </div>
      </form>
    </div>
  </div>
html;

  View::set('contenido',$html);
  View::set('header',$this->_contenedor->header($extraHeader));
  View::set('footer',$this->_contenedor->footer($extraFooter));
  View::render("testgraphs");
    }

    public function serviceCampania(){

      $check = MasterDom::getData('campania_e');
        if(empty($check))
          return MasterDom::alertas('error_general'); 

      if (MasterDom::getData('campania_e') == "si") {
        header('location: /service/add');
      }elseif(MasterDom::getData('campania_e') == "no") {
        //header('location: /TestGraphs/seleccionaMarcacionExistente');
        $this->seleccionaMarcacionExistente();
      }
    }

    public function seleccionaMarcacionExistente(){

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $nombreCampania = MasterDom::getData('nombre_campania');
        
        $shortCode = CampaignDao::getCarrierCustomerGroup($customer);

        $shortCodeHtml = '';
        foreach($shortCode AS $k=>$value){
            $ids = CampaignDao::getCarrierCustomer($customer, $value['short_code_id']);
            if(empty($ids))
                continue;

                $disabled = ($k == 0) ? '' : 'disabled';
                $check = ($k == 0) ? 'checked="checked"' : '';

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Marcacion :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <label class="action">
                                    <input class="seleccion" value="_dato_{$k}" name="iCheck" $check type="radio"> {$value['short_code']}
                                </label>
                            </div>
                        </div>
                        <fieldset class="existente_valida_dato_{$k}" $disabled>
html;
            foreach($ids AS $val){

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;carrier :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <div class="checkbox">
                                    <label><input type="checkbox" class"carrier" name="carrier_connection_short_code_id[]" value="{$val['carrier_connection_short_code_id']}" checked="checked">{$val['name']}</label>
                                </div>
                            </div>
                        </div>
html;
            }
            $shortCodeHtml.=<<<html
                        </fieldset>
                        <br />
html;
        }


  $html=<<<html
  <div class="x_panel">
    <div class="x_title">
      <h2>Configuracion de Marcacion</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
          <li><a class="close-link"><i class="fa fa-close"></i></a></li>
        </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <p>En esta pantalla podra seleccionar la marcacion por la cual va a salir el mensaje, puedes seleccionar los carriers para el envio.</p>
      <div class="ln_solid"></div>
      <form id="add" action="/TestGraphs/addServiceCampania" method="POST">

        $shortCodeHtml

        <div class="ln_solid"></div>

        <div class="form-group">
          <div class="col-md-12 col-sm-9 col-xs-12">
            <a href="#" class="btn btn-success pull-right">Siguiente</a>
          </div>
        </div>
        <input type="hidden" value="$nombreCampania" name='nombre_campania'/>
        <input type="hidden" value="$customer" name='customer_id'/>
      </form>
    </div>
  </div>
html;



        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {
             $(".seleccion").on("change", function () {
                valor = $(this).val();
                $("fieldset[class*='existente_valida']").attr('disabled', 'disabled');
                $('.existente_valida'+ valor).removeAttr("disabled");
            });

            $('.btn-success').on("click",function() {
                var pivote = $(".seleccion:checked").val();
                var buscar = $(".existente_valida" + pivote + " input:checked")
                if(buscar.length == 0){
                    bootbox.alert("Error: debes seleccionar por lo menos un carrier!");
                }else
                    $( "#add" ).submit();
            }); 

        });
    </script>
html;

  View::set('contenido',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("testgraphs");
    }

        public function addServiceCampania(){
          //print_r($_POST);
        // echo "comienza la función\n";

        $carrierConnectionArray = MasterDom::getDataAll('carrier_connection_short_code_id');

        $carrierIds = '';
        foreach($carrierConnectionArray AS $value){
            $carrierIds .= "$value,";
        }

        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = CampaignDao::findCarriersP($carrierIds);
        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

             
        //$buscaCarrier = function ($valor) use($carrierIdsArray){
            foreach($carrierIdsArray AS $value){ 
                if($value['carrier_id'] == $carrierIdsArray){
                    $carrierConnectionId = $value['carrier_connection_id'];
                    $carrierId = $value['carrier_id'];
                    $shortCodeId = $value['short_code_id'];
                    $carrierConnectionShortCodeId = $value['carrier_connection_short_code_id'];
                    $shortCode = $value['short_code'];
                    break;
                }
            }          
            //return $retorno; 
        //};

        $carrierId = $value['carrier_id'];
        $shortCodeId = $value['short_code_id'];
        $carrierConnectionShortCodeId = $value['carrier_connection_short_code_id'];

        $serviceCampania = new \stdClass();
        $serviceCampania->_name = MasterDom::getData('nombre_campania');
        $serviceCampania->_module_id = 4;
        $serviceCampania->_delivery_date = "00:00:00";
        $serviceCampania->_campaing_status_id = 1;
        // echo "\ncontroller\n

        // exit;
        $addCamp = CampaignDao::insertCS($serviceCampania);
        // echo "addCamp: $addCamp";

         $id_custom = MasterDom::getSession('customer_id');

             $datos = new \stdClass();
             $datos->_customer_id = $id_custom;
             $datos->_campaign_id = $addCamp;
             // echo "datos: ";

             $addCC = CampaignDao::insertCC($datos);

                   $dateccsc = new \stdClass();
                   $dateccsc->_campaign_id = $addCamp;
                   $dateccsc->_carrier_id = $carrierId;
                   $dateccsc->_short_code_id = $shortCodeId;
             
                  $addCCSC = CampaignDao::insertaCCSC($dateccsc);

                         $dateccscc = new \stdClass();
                         $dateccscc->_campaign_id = $addCamp;
                         $dateccscc->_carrier_connection_short_code_id = $carrierConnectionShortCodeId;

                         $dateCCSCC = CampaignDao::insertaCCSCC($dateccscc);

        //exit;

        if (empty($addCamp) && empty($addCC) && empty($addCCSC) && empty($addCCSCC)) {
              return $this->alertas('error_general');
        } else {
            return $this->alerta('success_add');
        }

    } */

}