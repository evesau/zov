<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Blacklist as BlacklistDao;
use \App\controllers\Contenedor;
use \App\PHPExcel\ProcesoExcel;

class Blacklist{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){
        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link href="/css/jquery.tag-editor.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;
        $extraFooter = <<<html
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script src="/js/jquery.caret.min.js"></script>
<script src="/js/jquery.tag-editor.js"></script>

<script>
$(document).ready(function(){
}); 

    function findBlacklist(){

        $(document).ready(function(){
            
            var inputNum  = $('#number').val();
            var inputCarrier = $('input:radio[name=carrier]:checked').val();
            data = {"num" : '52'+inputNum, "carrier" : inputCarrier},
            $('#successMessage').hide();

            $.ajax(
            {
               type: "POST",
               url: "/Blacklist/consult_one",
               data: data,
               async:false,    
               success: function(data)
               {
                    if(data == 'true'){
                        $('#successMessage').show();
                        $('#successMessage').html("<br><br><p class='text-danger'>No Blacklist...!");
                    }
                    else{
                        $('#successMessage').show();
                        var table = "<table class='table table-hover'>";
                        $.each(data, function (ind, elem) { 
                            table += "<tr align='center'><td >" + elem + "</td><td>Blacklist</td></tr>";
                        });
                        table += "</table>"
                        $('#successMessage').html(table);
                    }
               },

                error: function(xhr, textStatus, errorThrown){
                console.debug("no success");
                    return false;
               }
            });

        });
    }

/*************************************************************************************/

    jQuery.validator.addMethod("isBlacklist",function(value,element)
    {
         inputElem_0  = $('#add_one input[name=number_add]').val();
         inputElem_1 = $('#add_one input:radio[name=carrier_add]:checked').val();
        data = {"num" : '52'+inputElem_0, "carrier" : inputElem_1},
            eReport = '';
            console.debug(data);

         val = 0;

        $.ajax(
        {
           type: "POST",
           url: "/Blacklist/consult_one",
           //dataType: "json",
           data: data,
           async:false,    
           success: function(data)
           {
                if(data == 'true'){
            //        $('#successMessage').show();
                    console.debug("ok success true");
                    val = 1;              
                }
                else{
                    console.debug("ok success false");
            //        $('#successMessage').hide();
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
            console.debug(textStatus + xhr);
            console.debug("no success");
                return false;
           }
        });
        
        console.debug("final script: " + val);
        return this.optional(element) || 0 != val;
    }, jQuery.validator.format("This is blacklist"));


    $("#consult_one").validate({
            rules: {
                number: {
                    required: true,
                    digits: true,
                    maxlength: 10,
                    minlength: 10,
                    Blacklist: true
                }
            },
            messages: {
                number: {
                    required: "Ingresa un número telefónico",
                    digits: "Ingresa sólo dígitos",
                    maxlength: "El número debe ser menor a 10 dígitos",
                    minlength: "El número debe ser de 10 dígitos" 
                }
            }
    });

    $("#add_one").validate({
        rules: {
            number_add: {
                required: true,
                digits: true,
                maxlength: 10,
                minlength: 10,
                isBlacklist: true
            }
        },
        messages: {
            number_add: {
                required: "Ingresa un número telefónico",
                digits: "Ingresa sólo dígitos",
                maxlength: "El número debe ser menor a 10 dígitos",
                minlength: "El número debe ser de 10 dígitos"
            }
        },

        submitHandler: function(form){
            var inputElem_2  = $('#add_one input[name=number_add]').val();
            var inputElem_3 = $('#add_one input:radio[name=carrier_add]:checked').val();
            var Form_data = {"num" : inputElem_2, "carrier" : inputElem_3};

            var myJsonString = JSON.stringify(Form_data);
            console.debug(myJsonString);

            $.ajax({
                    type:"POST",
                    url: "/Blacklist/addNumber",
                    data: myJsonString,
                    dataType:"json",
                    success: function(data){
                        alert("todo fue un éxito...!");
                    },
                    error: function(data){
                        alert("algo salio mal...");
                        //console.debug("algo salio mal...");
                    }
                }
            )

        }

    });

    $("#blacklist_xls").validate({
        rules: {
            excel: {
                required: true,
                extension: "xls"
                
            }
        },
        messages: {
            excel: {
                required: "Debes subir un archivo",
                extension: "La extensión del archivo debe ser .xls"
            }
        }
    });

</script>

<!----- Script Columna 2 -------->
<script>

    $(document).ready(function(){

        $('input[name=numbers]').tagEditor({
            initialTags: ['5521069135','5524178952','2235684110']
        });
    });

</script>

<script>

function blacklist(){

    $(document).ready(function(){
        
        var inputNum  = $('#tags_1').val();
        var inputCarrier = $('input:radio[name=carrier_multi]:checked').val();
        data = {"nums" : inputNum, "carrier" : 
        inputCarrier},
        $('#message').hide();

        $.ajax(
        {
           type: "POST",
           url: "/Blacklist/consult_multi",
           //dataType: "json",
           data: data,
           async:false,    
           success: function(data)
           {
                if(data == ''){
                    $('#message').show();
                    $('#message').html("<br><br><p class='text-danger'>No Blacklist...!");
                }
                else{
                    $('#message').show();
                    var table = "<table class='table table-hover'>";
                    $.each(data, function (ind, elem) { 
                        table += "<tr align='center'><td >" + elem + "</td><td>Blacklist</td></tr>";
                    });
                    table += "</table>"
                    $('#message').html(table);
                }
           },

            error: function(xhr, textStatus, errorThrown){
            console.debug("no success");
                return false;
           }
        });

    });
}

</script>
html;


$tercer_columna = <<<html
        <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_520">
                <div class="x_title">
                  <h2>Agrega Números a Blacklist</h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <p class="text-primary" align="right">El archivo debe tener extensión .xls (Excel)</p>
                  <form action="/Blacklist/upload"  enctype="multipart/form-data" method="POST" id='blacklist_xls'>
                    <br>
                    <input align="center" type="file" name="excel" id="excel">
                    <div class="row" align="center">
                      <div class="col-sm-12">
                        <label class="radio-inline"><input type="radio" name="carrier" value="telcel" checked="checked">Telcel</label>
                        <label class="radio-inline"><input type="radio" name="carrier" value="movistar">Movistar</label>
                        <label class="radio-inline"><input type="radio" name="carrier" value="att">AT&T</label>
                      </div>
                    </div>
                        <br><br>  
                    <input align="center" type="submit" id="btnEnviar" class="btn btn-primary pull-right"  >
                  </form>
                  <br><br><br>
                </div>
              </div>
            </div>


    <!-- segundo renglon tercer columna -->
        <div class="row">
            <!--div class="col-md-4 col-sm-4 col-xs-12"></div>
            <div class="col-md-4 col-sm-4 col-xs-12"></div-->
            
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2> Agregar un número</h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form id="add_one" class="form-horizontal form-label-left" >
                    <div class="form-group">
                      <label class="col-sm-3 control-label">Escribe un número: </label>

                      <div class="col-sm-9">
                        <div class="input-group">
                          <input type="text" class="form-control" name="number_add" id="number_add">
                            <span class="input-group-btn">
                              <button type="submit" class="btn btn-primary">Añadir</button>
                            </span>
                        </div>
                      </div>
                    </div>

                    <div class="row" align="center">
                      <div class="col-sm-9">
                        <label class="radio-inline"><input type="radio" name="carrier_add" value="telcel" checked="checked">Telcel</label>
                        <label class="radio-inline"><input type="radio" name="carrier_add" value="movistar">Movistar</label>
                        <label class="radio-inline"><input type="radio" name="carrier_add" value="att">AT&T</label>
                      </div>
                    </div>

                    <br>
                    <div class="divider-dashed"></div>
                  </form>
                </div>
              </div>
            </div>

          </div>
html;

        $tamanio_div_airmovil =<<<html
                <div class="col-md-4 col-sm-4 col-xs-12">
html;

        $tamanio_div_normal =<<<html
                <div class="col-md-6 col-sm-6 col-xs-12">
html;

        
        if (MasterDom::getSession('customer_id') == 1) {
            View::set('tamanio_div',$tamanio_div_airmovil);
            View::set('tercer_columna',$tercer_columna);
        } else {
            View::set('tamanio_div',$tamanio_div_normal);
        }

        MasterDom::verificaUsuario();
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("blacklist");
    }

    public function consult_one(){

        if(!empty($_POST)){
            $blacklist = new \stdClass();
            $blacklist->_num = MasterDom::getData('num');
            $blacklist->_carrier = MasterDom::getData('carrier');

            if ($blacklist->_carrier == 'telcel') {
                $row = BlacklistDao::getByCarrierTelcel($blacklist->_num);
            } elseif ($blacklist->_carrier == 'movistar') {
                $row = BlacklistDao::getByCarrierMovistar($blacklist->_num);
            } elseif ($blacklist->_carrier == 'att') {
                $row = BlacklistDao::getByCarrierAtt($blacklist->_num);
            } else{
                exit;
            }

            if(empty($row)) {
                echo 'true';
               //no hay registros en la bd
            } else{
                echo 'false';
                //sí hay registros en la bd
            }
        }else
            echo "error";
    }

    public function consult_multi(){
        
        if (empty($_POST)) 
            echo "error";
        
        $blacklist = new \stdClass();
        $blacklist->_num = MasterDom::getDataAll('nums');
        $blacklist->_carrier = MasterDom::getData('carrier');

        $blacklist_ok = array();

        $numeros = explode(',', $blacklist->_num);

        if ($blacklist->_carrier == 'telcel') {
            foreach ($numeros as $key => $val) {
                $val = "52{$val}";
                $row = BlacklistDao::getByCarrierTelcel($val);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
                    //$blacklist_ok[] = $val;
            }   
        } elseif ($blacklist->_carrier == 'movistar') {
            foreach ($numeros as $key => $val) {
                $val = "52{$val}";
                $row = BlacklistDao::getByCarrierMovistar($val);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
                    //$blacklist_ok[] = $val;
            }
        } elseif ($blacklist->_carrier == 'att') {
            foreach ($numeros as $key => $val) {
                $val = "52{$val}";
                $row = BlacklistDao::getByCarrierAtt($val);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
                    //$blacklist_ok[] = $val;
            }
        } else{
            exit;
        }
        //print_r(blacklist_ok);

        header('Content-Type: application/json');
        $json = json_encode($blacklist_ok);
        echo $json;
    }

    public function upload(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return $this->alertas('error_general');

        MasterDom::verificaUsuario();
        $carrier = MasterDom::getData('carrier');
        $custom = MasterDom::getSession('customer_id');

        $move = MasterDom::moverDirectorio($_FILES['excel'], $custom, 'blacklst');
        //print_r($move);
        $contenido = MasterDom::procesoExcel('getColumna',$move['nombre'],'A');
        $list = json_decode($contenido);

        foreach ($list as $key => $value) {
            foreach ($value as $k => $val) {
               if ($carrier == 'telcel') {
                    BlacklistDao::insert($val);
                    $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                    BlacklistDao::registroUsuario($registro);
               } elseif ($carrier == 'movistar') {
                    BlacklistDao::insertMovistar($val);
                    $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                    BlacklistDao::registroUsuario($registro);
               }elseif ($carrier == 'att') {
                   BlacklistDao::insertAtt($val);
                   $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                   BlacklistDao::registroUsuario($registro);
               } else {
                   return $this->alertas('error_general');
               }
               
            }
        }

        $table = "<table class='table table-hover' ><tr><td> Números insertados: </td><td>".count($list)."</td></tr>";
        
        View::set('name_file',$_FILES['excel']['name']);
        View::set('table',$table);
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
        View::render("add_blacklist");

        MasterDom::procesoExcel('borrarArchivo',$move['nombre']);

    }

    public function addNumber(){

        $arrResult = array();
        $contenido = json_decode(file_get_contents("php://input"),true);
        //print_r($contenido);

        if ($contenido['carrier'] == 'telcel') {
            $insert = BlacklistDao::insert( $contenido['num']);
            $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
            BlacklistDao::registroUsuario($registro);
        } elseif ($contenido['carrier'] == 'movistar') {
            $insert = BlacklistDao::insertMovistar( $contenido['num']);
            $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
            BlacklistDao::registroUsuario($registro);
        }elseif ($contenido['carrier'] == 'att') {
           $insert = BlacklistDao::insertAtt( $contenido['num']);
           $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
           BlacklistDao::registroUsuario($registro);
        } else {
           return $this->alertas('error_general');
        }

        if(!$insert){
            $arrResult['respuesta'] = 'error';
        } else{
            array_push($arrResult,array( 'respuesta' => 'succes'));
        }

        header("Content-Type: application/json");
        echo json_encode($arrResult);
        return;

    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Success.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'error_producto')
            $mensaje = 'Ocurrio un error al insertar los productos.';
        else
            $mensaje = 'Ocurrio algo inesperado.';

        View::set('regreso','/menu');
        View::set('class', $class);
        View::set('titulo','Carrier');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    public function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }


}