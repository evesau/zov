<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\User as UserDao;
use \App\controllers\Contenedor;

class Doppler{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){
        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/custom.min.css" rel="stylesheet">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

        <script type="text/javascript">
          $(document).ready(function(){

            var myWidth = 0, myHeight = 0;
            if( typeof( window.innerWidth ) == 'number' ) {
              //No-IE
              myWidth = window.innerWidth;
              myHeight = window.innerHeight;
            } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
              //IE 6+
              myWidth = document.documentElement.clientWidth;
              myHeight = document.documentElement.clientHeight;
            } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
              //IE 4 compatible
              myWidth = document.body.clientWidth;
              myHeight = document.body.clientHeight;
            }

            // sandbox="allow-forms"
            $("#contenedor").html('<iframe height="'+myHeight+'" class="col-md-12 col-sm-12 col-xs-12 col-lg-12" src="https://app2.fromdoppler.com/Campaigns/Draft" scrolling="auto" frameborder="1" ><p>Este navegador no soporta IFrames.</p></iframe>');

          });
        </script>
html;

        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("doppler");
    }

}
