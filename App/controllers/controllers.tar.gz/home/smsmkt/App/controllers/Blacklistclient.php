<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Blacklistclient as BlacklistclientDao;
use \App\controllers\Contenedor;
use \App\PHPExcel\ProcesoExcel;

class Blacklistclient{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){
        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link href="/css/jquery.tag-editor.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">

html;
        $extraFooter = <<<html
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script src="/js/jquery.caret.min.js"></script>
<script src="/js/jquery.tag-editor.js"></script>

<script>

    function findBlacklist(){

        $(document).ready(function(){
            
            var inputNum  = $('#number').val();
            var inputCarrier = $('input:radio[name=carrier]:checked').val();
            data = {"num" : '52'+inputNum, "carrier" : inputCarrier},
            $('#successMessage').hide();

            $.ajax(
            {
               type: "POST",
               url: "/Blacklistclient/consult_one",
               data: data,
               async:false,    
               success: function(data)
               {
                    if(data == 'true'){
                        $('#successMessage').show();
                        $('#successMessage').html("<br><br><p class='text-danger'>No Blacklist...!");
                    }
                    else{
                        $('#successMessage').show();
                        var table = "<table class='table table-hover'>";
                        $.each(data, function (ind, elem) { 
                            table += "<tr align='center'><td >" + elem + "</td><td>Blacklist</td></tr>";
                        });
                        table += "</table>"
                        $('#successMessage').html(table);
                    }
               },

                error: function(xhr, textStatus, errorThrown){
                console.debug("no success");
                    return false;
               }
            });

        });
    }

/*************************************************************************************/

    jQuery.validator.addMethod("isBlacklist",function(value,element)
    {
         inputElem_0  = $('#add_one input[name=number_add]').val();
         inputElem_1 = $('#add_one input:radio[name=carrier_add]:checked').val();
        data = {"num" : '52'+inputElem_0, "carrier" : inputElem_1},
            eReport = '';
            console.debug(data);

         val = 0;

        $.ajax(
        {
           type: "POST",
           url: "/Blacklistclient/consult_one",
           //dataType: "json",
           data: data,
           async:false,    
           success: function(data)
           {
                if(data == 'true'){
            //        $('#successMessage').show();
                    console.debug("ok success true");
                    val = 1;              
                }
                else{
                    console.debug("ok success false");
            //        $('#successMessage').hide();
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
            console.debug(textStatus + xhr);
            console.debug("no success");
                return false;
           }
        });
        
        console.debug("final script: " + val);
        return this.optional(element) || 0 != val;
    }, jQuery.validator.format("This is blacklist"));


    $("#consult_one").validate({
            rules: {
                number: {
                    required: true,
                    digits: true,
                    maxlength: 10,
                    minlength: 10,
                    Blacklist: true
                }
            },
            messages: {
                number: {
                    required: "Ingresa un número telefónico",
                    digits: "Ingresa sólo dígitos",
                    maxlength: "El número debe ser menor a 10 dígitos",
                    minlength: "El número debe ser de 10 dígitos" 
                }
            }
    });

    $("#add_one").validate({
        rules: {
            number_add: {
                required: true,
                digits: true,
                maxlength: 10,
                minlength: 10,
                isBlacklist: true
            }
        },
        messages: {
            number_add: {
                required: "Ingresa un número telefónico",
                digits: "Ingresa sólo dígitos",
                maxlength: "El número debe ser a 10 dígitos",
                minlength: "El número debe ser de 10 dígitos"
            }
        },

        submitHandler: function(form){
            var inputElem_2  = $('#add_one input[name=number_add]').val();
            var inputElem_3 = $('#add_one input:radio[name=carrier_add]:checked').val();
            var Form_data = {"num" : inputElem_2, "carrier" : inputElem_3};

            var myJsonString = JSON.stringify(Form_data);
            console.debug(myJsonString);

            $.ajax({
                    type:"POST",
                    url: "/Blacklistclient/addNumber",
                    data: myJsonString,
                    dataType:"json",
                    success: function(data){
                        alert("El número se agrego con éxito...!");
                        $("#addBlackone").hide();
                    error: function(data){
                        alert("algo salio mal...");
                        //console.debug("algo salio mal...");
                        $("#addBlackone").hide();
                    }
                }
            )

        }

    });

    $("#blacklist_xls").validate({
        rules: {
            excel: {
                required: true,
                extension: "xls|xlsx"
                
            }
        },
        messages: {
            excel: {
                required: "Debes subir un archivo",
                extension: "La extensión del archivo debe ser .xls ó .xslx"
            }
        }
    });

</script>

<!----- Script Columna 2 -------->
<script>

    $(document).ready(function(){

        $('input[name=numbers]').tagEditor({
            initialTags: ['5521069135','5524178952','2235684110']
        });

        $("#addBlackone").hide();
        $("#deleteBlack").hide();

        $("#btnAddBlack").click( function() {
            $("#addBlackone").show();
        } );

        $("#btnEnviar").click( function(){
            $("#blacklist_xls").validate({
                rules: {
                    excel: {
                        required: true,
                        extension: "xls|xlsx"
                        
                    }
                },
                messages: {
                    excel: {
                        required: "Debes subir un archivo",
                        extension: "La extensión del archivo debe ser .xls ó .xslx"
                    }
                }
            });
        });

        $("#btnDeleteBlack").click( function(){
            $("#deleteBlack").show();
        } );


        $("#deleteOne").click(function(){

            $("#deleteBlackForm").validate({
                rules: {
                    number_delete: {
                        required: true,
                        maxlength: 10,
                        minlength: 10,
                        digits: true
                        
                    }
                },
                messages: {
                    number_delete: {
                        required: "Debes ingresar un n&uacute;mero",
                        maxlength: "Deben ser 10 digitos",
                        minlength: "Deben ser 10 digitos",
                        digits: "Ingresa s&oacute;lo d&iacute;gitos"
                    }
                }
            });

            var msisdn = $("#number_delete").val();
            if(msisdn.length > 0){
                $("#deleteBlack").submit();
            }
        });


        $("#agregarOne").click(function(){

            $("#agregarOneForm").validate({
                rules: {
                    number_add: {
                        required: true,
                        maxlength: 10,
                        minlength: 10,
                        digits: true
                        
                    }
                },
                messages: {
                    number_add: {
                        required: "Debes ingresar un n&uacute;mero",
                        maxlength: "Deben ser 10 digitos",
                        minlength: "Deben ser 10 digitos",
                        digits: "Ingresa s&oacute;lo d&iacute;gitos"
                    }
                }
            });

        });


    });

</script>

<script>

function blacklist(){

    $(document).ready(function(){
        
        var inputNum  = $('#tags_1').val();
        var inputCarrier = $('input:radio[name=carrier_multi]:checked').val();
        data = {"nums" : inputNum, "carrier" : inputCarrier},
        $('#message').hide();

        $.ajax(
        {
           type: "POST",
           url: "/Blacklistclient/consult_multi",
           //dataType: "json",
           data: data,
           async:false,    
           success: function(data)
           {
                if(data == ''){
                    $('#message').show();
                    $('#message').html("<br><br><p class='text-danger'>No Blacklist...!");
                }
                else{
                    $('#message').show();
                    var table = "<table class='table table-hover'>";
                    $.each(data, function (ind, elem) { 
                        table += "<tr align='center'><td >" + elem + "</td><td>Blacklist</td></tr>";
                    });
                    table += "</table>"
                    $('#message').html(table);
                }
           },

            error: function(xhr, textStatus, errorThrown){
            console.debug("no success");
                return false;
           }
        });

    });
}

</script>
html;


$tercer_columna = <<<html
        <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="x_panel tile fixed_height_520">
                <div class="x_title" style="height: auto; right: auto;">
                    <h2>Agregar N&uacute;meros a Blacklist</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-primary" align="right">El archivo debe tener extensión .xls (Excel)</p>
                    <form action="/Blacklistclient/upload"  enctype="multipart/form-data" method="POST" id='blacklist_xls'>
                        <br>
                        <input class="form-control" style="height: auto; right: auto;" type="file" name="excel" id="excel" >
                        <div class="row" align="center">
                            <div class="col-sm-12">
                                <label class="radio-inline"><input type="radio" name="carrier" value="telcel" checked="checked">Telcel</label>
                                <label class="radio-inline"><input type="radio" name="carrier" value="movistar">Movistar</label>
                                <label class="radio-inline"><input type="radio" name="carrier" value="att">AT&T</label>
                            </div>
                        </div>
                        <br><br><br>
                        <!--<input  ></input>-->
                        <button align="center" type="submit" id="btnEnviar" class="btn btn-success pull-right" >Agregar lista a Blacklist <i class="fa fa-list-alt"></i></button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="x_panel tile fixed_height_520">
                <div class="x_title" style="height: auto; right: auto;">
                    <h2>Click en el bot&oacute;n Agregar N&uacute;meros a Blacklist o Eliminar </h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <button type="button" id="btnAddBlack" class="col-md-4 col-sm-4 col-xs-12 btn btn-success pull-left" >Agregar n&uacute;mero <i class="fa fa-plus-square"></i></button>
                    <button type="button" id="btnDeleteBlack" class="col-md-4 col-sm-4 col-xs-12 btn btn-danger pull-right" >Eliminar n&uacute;mero <i class="fa fa-trash"></i></button>
                </div>
            </div>
        </div>


    <!-- segundo renglon tercer columna -->
        <div class="col-md-12 col-sm-12 col-xs-12" id=addBlackone>
            <div class="x_panel tile fixed_height_240">
                <div class="x_title">
                    <h2> Agregar un n&uacute;mero</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form id="agregarOneForm" class="form-horizontal form-label-left" action="/Blacklistclient/addOne" method="post" >
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Escribe un n&uacute;mero: </label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="number_add" id="number_add">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" id="agregarOne">A&ntilde;adir</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row" align="center">
                            <div class="col-sm-9">
                                <label class="radio-inline"><input type="radio" name="carrier_add" value="telcel" checked="checked">Telcel</label>
                                <label class="radio-inline"><input type="radio" name="carrier_add" value="movistar">Movistar</label>
                                <label class="radio-inline"><input type="radio" name="carrier_add" value="att">AT&T</label>
                            </div>
                        </div>
                        <!--<br><div class="divider-dashed"></div>-->
                    </form>
                </div>
            </div>
        </div>

        <!-- segundo renglon tercer columna -->
        <div class="col-md-12 col-sm-12 col-xs-12" id=deleteBlack>
            <div class="x_panel tile fixed_height_240">
                <div class="x_title">
                    <h2> Eliminar n&uacute;mero de blacklist</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form id="deleteBlackForm" class="form-horizontal form-label-left" action="/Blacklistclient/deleteBlacklist"  method="post" >
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Escribe un n&uacute;mero: </label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="number_delete" id="number_delete" required>
                                    <span class="input-group-btn">
                                        <button class="btn btn-danger" id="deleteOne">Eliminar</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
html;

        $tamanio_div_airmovil =<<<html
                <div class="col-md-4 col-sm-4 col-xs-12">
html;

        /*$tamanio_div_normal =<<<html
                <div class="col-md-6 col-sm-6 col-xs-12">
html;*/

        
        MasterDom::verificaUsuario();

        View::set('tamanio_div',$tamanio_div_airmovil);
        View::set('tercer_columna',$tercer_columna);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("blacklistclient");
    }

    public function addOne(){
        if (!empty($_POST)) {
            $msisdn = "52".MasterDom::getData('number_add');
            $carrier = MasterDom::getData('carrier_add');
            $customer_id = MasterDom::getSession('customer_id');
            $insert = false;
            if ($carrier == 'telcel') {
                $idB = BlacklistclientDao::getByCarrierTelcel($msisdn,$customer_id);
                if (empty($idB)) {
                    $id = BlacklistclientDao::insertTelcel(substr($msisdn,-10),$customer_id);
                }

                if (!empty($id) || !empty($idB)) {
                    $insert = true;
                } else {
                    $insert = false;
                }
                
            } elseif ($carrier == 'movistar') {
                $idB = BlacklistclientDao::getByCarrierMovistar($msisdn,$customer_id);
                if (empty($idB)) {
                    $id = BlacklistclientDao::insertMovistar(substr($msisdn,-10),$customer_id);
                }
                
                if (!empty($id) || !empty($idB)) {
                    $insert = true;
                } else {
                    $insert = false;
                }

            } elseif ($carrier == 'att') {
                $idB = BlacklistclientDao::getByCarrierAtt($blacklist,$customer_id);
                if (empty($idB)) {
                    $id = BlacklistclientDao::insertAtt(substr($msisdn,-10),$customer_id);
                }
                
                if (!empty($id) || !empty($idB)) {
                    $insert = true;
                } else {
                    $insert = false;
                }

            }

            if ($insert) {
                $this->alertas('success_add');
            } else {
                $this->alertas('error_add');
            }

        } else {
            header("Location: /blacklistclient");
        }
    }

    public function deleteBlacklist(){
        if (!empty($_POST)) {
            $msisdn = "52".MasterDom::getData('number_delete');
            $customer_id = MasterDom::getSession('customer_id');
            // buscamos en todas las black list client
            $blT = BlacklistclientDao::getByCarrierTelcel($msisdn,$customer_id);
            $blM = BlacklistclientDao::getByCarrierMovistar($msisdn,$customer_id);
            $blAt = BlacklistclientDao::getByCarrierAtt($msisdn,$customer_id);

            
            $deleteF = false;
            if (!empty($blT[0]['blacklist_telcel_client_id'])) {
                BlacklistclientDao::deleteBlacklistTelcel($blT[0]['blacklist_telcel_client_id']);
                $deleteF = true;
            }

            if (!empty($blM[0]['blacklist_movistar_client_id'])) {
                BlacklistclientDao::deleteBlacklistMovistar($blM[0]['blacklist_movistar_client_id']);
                $deleteF = true;
            }

            if (!empty($blAt[0]['blacklist_att_client_id'])) {
                BlacklistclientDao::deleteBlacklistAtt($blAt[0]['blacklist_att_client_id']);
                $deleteF = true;
            }

            if ($deleteF) {
                $this->alertas('succes_delete');
            } else {
                if (empty($blT) && empty($blM) && empty($blAt)) {
                    $this->alertas('erro_emptymsisdn');
                } else {
                    $this->alertas('error_general');
                }
            }

        } else {
            header("Location: /blacklistclient");
        }
    }

    public function consult_one(){

        if(!empty($_POST)){
            $blacklist = new \stdClass();
            $blacklist->_num = MasterDom::getData('num');
            $blacklist->_carrier = MasterDom::getData('carrier');
            $customer_id = MasterDom::getSession('customer_id');

            if ($blacklist->_carrier == 'telcel') {
                $row = BlacklistclientDao::getByCarrierTelcel($blacklist->_num, $customer_id);
            } elseif ($blacklist->_carrier == 'movistar') {
                $row = BlacklistclientDao::getByCarrierMovistar($blacklist->_num, $customer_id);
            } elseif ($blacklist->_carrier == 'att') {
                $row = BlacklistclientDao::getByCarrierAtt($blacklist->_num, $customer_id);
            } else{
                exit;
            }

            if(empty($row)) {
                echo 'true';
               //no hay registros en la bd
            } else{
                echo 'false';
                //sí hay registros en la bd
            }
        }else
            echo "error";
    }

    public function consult_multi(){
        
        if (empty($_POST)) 
            echo "error";
        
        $blacklist = new \stdClass();
        $blacklist->_num = MasterDom::getDataAll('nums');
        $blacklist->_carrier = MasterDom::getData('carrier');

        $blacklist_ok = array();
        $customer_id = MasterDom::getSession('customer_id');
        $numeros = explode(',', $blacklist->_num);

        if ($blacklist->_carrier == 'telcel') {
            foreach ($numeros as $key => $val) {
                $val = "52".$val;
                $row = BlacklistclientDao::getByCarrierTelcel($val,$customer_id);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
            }   
        } elseif ($blacklist->_carrier == 'movistar') {
            foreach ($numeros as $key => $val) {
                $val = "52".$val;
                $row = BlacklistclientDao::getByCarrierMovistar($val,$customer_id);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
            }
        } elseif ($blacklist->_carrier == 'att') {
            foreach ($numeros as $key => $val) {
                $val = "52".$val;
                $row = BlacklistclientDao::getByCarrierAtt($val,$customer_id);
                if(!empty($row))
                    array_push($blacklist_ok, $val);
            }
        } else{
            exit;
        }

        header('Content-Type: application/json');
        $json = json_encode($blacklist_ok);        
        echo $json;

    }

    public function upload(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return $this->alertas('error_general');

        MasterDom::verificaUsuario();
        $carrier = MasterDom::getData('carrier');
        $custom = MasterDom::getSession('customer_id');

        $move = MasterDom::moverDirectorio($_FILES['excel'], $custom, 'blacklst');
        //print_r($move);
        $contenido = MasterDom::procesoExcel('getColumna',$move['nombre'],'A');
        $list = json_decode($contenido);

        foreach ($list as $key => $value) {
            foreach ($value as $k => $val) {
               if ($carrier == 'telcel') {
                    $blT = BlacklistclientDao::getBlacklistTelcel($val,$custom);
                    if (empty($blT)) {
                        BlacklistclientDao::insertTelcel($val,$custom);
                        $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                        BlacklistclientDao::registroUsuario($registro);
                    }                    
               } elseif ($carrier == 'movistar') {
                    $blM = BlacklistclientDao::getBlacklistMovistar($val,$custom);
                    if (empty($blM)) {
                        BlacklistclientDao::insertMovistar($val,$custom);
                        $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                        BlacklistclientDao::registroUsuario($registro);
                    }                    
               }elseif ($carrier == 'att') {
                    $blAt = BlacklistclientDao::getBlacklistAtt($val,$custom);
                    if (empty($blAt)) {
                        BlacklistclientDao::insertAtt($val,$custom);
                        $registro = $this->registroUsuario("Agrego numero {$val} a blacklist {$carrier}");
                        BlacklistclientDao::registroUsuario($registro);
                    }
               } else {
                   return $this->alertas('error_general');
               }
               
            }
        }

        $table = "<table class='table table-hover' ><tr><td> Números insertados: </td><td>".count($list)."</td></tr>";
        
        View::set('name_file',$_FILES['excel']['name']);
        View::set('table',$table);
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
        View::render("add_blacklist");

        MasterDom::procesoExcel('borrarArchivo',$move['nombre']);

    }

    public function addNumber(){

        $arrResult = array();
        $contenido = json_decode(file_get_contents("php://input"),true);
        $customer_id = MasterDom::getSession('customer_id');

        if ($contenido['carrier'] == 'telcel') {
            /*$blT = BlacklistclientDao::getBlacklistTelcel($val,$custom);
            if (empty($blT)) {*/
                $insert = BlacklistclientDao::insertTelcel( $contenido['num'] , $customer_id);
                $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
                BlacklistclientDao::registroUsuario($registro);
            /*}*/
        } elseif ($contenido['carrier'] == 'movistar') {
            /*$blM = BlacklistclientDao::getBlacklistMovistar($val,$custom);
            if (empty($blM)) {*/
                $insert = BlacklistclientDao::insertMovistar( $contenido['num'], $customer_id);
                $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
                BlacklistclientDao::registroUsuario($registro);
            /*}*/
        }elseif ($contenido['carrier'] == 'att') {
            /*$blAt = BlacklistclientDao::getBlacklistAtt($val,$custom);
            if (empty($blAt)) {*/
                $insert = BlacklistclientDao::insertAtt( $contenido['num'], $customer_id);
                $registro = $this->registroUsuario("Agrego numero {$contenido['num']} a blacklist {$contenido['carrier']}");
                BlacklistclientDao::registroUsuario($registro);
            /*}*/
        } else {
           return $this->alertas('error_general');
        }

        if(!$insert){
            $arrResult['respuesta'] = 'error';
        } else{
            array_push($arrResult,array( 'respuesta' => 'succes'));
        }

        header("Content-Type: application/json");
        echo json_encode($arrResult);
        return;

    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se agrego correctamente';
            $class = 'success';
        }elseif($caso == 'error_general'){
            $mensaje = 'Lo sentimos ocurrio un error.';
        }
        elseif($caso == 'error_add'){
            $mensaje = 'Ocurrio un error al agregar';
        }
        elseif($caso == 'succes_delete'){
            $mensaje = 'Se elimin&oacute; correctamente';
            $class = 'success';
        }
        elseif ($caso == 'erro_emptymsisdn') {
            $mensaje = 'N&uacute;mero no encontrado en Blacklist';
            $class = 'success';
        }
        else{
            $mensaje = 'Ocurrio algo inesperado.';
        }

        View::set('regreso','/blacklistclient');
        View::set('class', $class);
        View::set('titulo','Blacklist Client');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    public function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

    public function reporteBlack(){
        header("Content-type: application/json; charset=utf-8");
        if (!empty($_GET)){
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
            $customer_id = MasterDom::getSession('customer_id');

            $registros = BlacklistclientDao::getBlacklistTotal($customer_id);
            $prueba = array("draw"=>$draw, "recordsTotal"=>count($registros), "recordsFiltered"=>count($registros),"data"=>$this->obtenerLimite($registros, $start, $length));
            echo json_encode($prueba);
        }
    }

    public function obtenerLimite($registros, $inicio, $limite){
        $seleccion = array();
        for($i = $inicio; $i<count($registros); $i ++) {
            array_push($seleccion, $registros[$i]);
            if($i == ($inicio + $limite)){
                break;
            }
        }
        return $seleccion;
    }


}