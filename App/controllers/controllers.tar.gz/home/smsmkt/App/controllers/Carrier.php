<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Carrier as CarrierDao;
use \App\controllers\Contenedor;

class Carrier
{

private $_contenedor;

    function __construct() { 

	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {

	$extraHeader=<<<html
<!-- DataTables CSS -->
	<link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

	$extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>	
	$(document).ready(function() {

	     var table = $('#muestra-cupones').DataTable({
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                            "lengthMenu": "Mostrar _MENU_ entradas",
                            "search": "Buscar:",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });

    	    $("#checkAll").change(function () {
    		$("input:checkbox").prop('checked', $(this).prop("checked"));
    	    });

    	    $(document).on("click", "#delete", function(e) {
            	bootbox.confirm("&iquest;Desactivaras los carriers seleccionados?", function(result) {
		    if (result) 
		        $( "#delete_form" ).submit();
            	});
            });
	} );
</script>
html;


	View::set('header',$this->_contenedor->header($extraHeader));

	$json['card']['status'] = 'true';
	$statusJava = MasterDom::curlPostJava('config/StatusCarrierJson/', $json);
	$buscaCarrier = function($carrier) use ($statusJava){
			$retorno;
			foreach($statusJava['status'] AS $value){
			    if($value['id'] == $carrier)
				$retorno = $value;
			}	
		    return $retorno;
		};

	$row = CarrierDao::getAll();
	$html = '';
	foreach($row AS $key=>$value){

	    $id = MasterDom::setParamSecure($value['carrier_connection_short_code_id']);
	    $carrier = $buscaCarrier($value['carrier_connection_short_code_id']);
	    $statusCarrier = ($carrier['bound'] == 'true') ? '<a href="#/adjust" class="btn btn-success"><i class="fa fa-circle"></i> Online</a>' : '<a href="#/adjust" class="btn btn-default"><i class="fa fa-circle-o"></i> Offline</a><br /><i class="fa fa-times-circle text-danger"></i> '.$carrier['lastError'].'</a>';
	
	    $estatus = ($value['status'] == 1) ? 'Enabled' : 'Disabled';
	    $html.=<<<html
		<tr>
		    <td><input type="checkbox" name="borrar[]" value="{$value['carrier_connection_id']}"/></td>
		    <td>{$value['carrier_name']}</td>
		    <td>{$value['system_id']}</td>
		    <td>{$value['mode']}</td>
		    <td>$estatus</td>
		    <td>$statusCarrier</td>
		    <td class="center"><a href="/carrier/edit/$id" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
		</tr>
html;
	}	

	View::set('table',$html);
	View::set('footer',$this->_contenedor->footer($extraFooter));
	View::render("carrierall");
    }

    private function jqueryShortCode(){
        $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script>    
        $(document).ready(function() {
             var table = $('#muestra-cupones').DataTable({
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 eçntradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "search": "Buscar:",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        } );

        jQuery.validator.addMethod("ExisteUsuario",function(value,element)
            {

                data = {"nombre" : value},
                eReport = '';
                var nombre_hidden = $("#nombre_hidden").val();

                var val = 0;

                $.ajax(
                {
                   type: "POST",
                   url: "/carrier/validaNombreShortCode",
                   dataType: "json",
                   data: data,
                   async:false,    
                   success: function(data){
                        if(data == true)
                           val = 1;
                   },
                   error: function(xhr, textStatus, errorThrown){
                        val = 0;
                   }
                });

                if(nombre_hidden == value)
                    val = 1;
                
                return this.optional(element) || 0 != val;
            }, jQuery.validator.format("Ya existe"));

	    $("#add").validate(
                {
                    rules: {
                        nombre: {
                            required: true,
                            digits: true
                        }
                    },
                    messages: {
                        nombre: {
                            required: "Este campo es obligatorio",
                            digits: "Ingresa sólo números"
                        }
                    }
        });
</script>
html;
        return array('header'=>$extraHeader, 'footer'=>$extraFooter);
    }

    private function jqueryCompany(){
	$extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

	$extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script>    
        $(document).ready(function() {
             var table = $('#muestra-cupones').DataTable({
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 eçntradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "search": "Buscar:",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        });

        jQuery.validator.addMethod("ExisteUsuario",function(value,element)
            {

                data = {"nombre" : value},
                eReport = '';
                var nombre_hidden = $("#nombre_hidden").val();

                var val = 0;

                $.ajax(
                {
                   type: "POST",
                   url: "/carrier/validaNombreCompany",
                   dataType: "json",
                   data: data,
                   async:false,    
                   success: function(data){
                        if(data == true)
                           val = 1;
                   },
                   error: function(xhr, textStatus, errorThrown){
                        val = 0;
                   }
                });

                if(nombre_hidden == value)
                    val = 1;
                
                return this.optional(element) || 0 != val;
            }, jQuery.validator.format("Ya existe este nombre"));

	    $("#add").validate(
                {
                    rules: {
                        nombre: {
                            required: true,
                            maxlength: 60,
                            minlength: 3,
                            ExisteUsuario: true
                        }
                    },
                    messages: {
                        nombre: {
                            required: "Este campo es obligatorio",
                            maxlength: "Es permitido sólo un máximo de 60 caracteres",
                            minlength: "No puedes escribir menos de 3 caracteres",
                            ExisteUsuario: "Este usuario ya existe"
                        }
                    }
        });
</script>
html;
	return array('header'=>$extraHeader, 'footer'=>$extraFooter);
    }

    public function indexCompany() {

        $row = CarrierDao::getAllCompany();
        $html = '';
        foreach($row AS $key=>$value){

            $id = MasterDom::setParamSecure($value['carrier_id']);
            $html.=<<<html
                <tr>
                    <td>{$value['name']}</td>
                    <td class="center"><a href="/carrier/editCompany/$id" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
                </tr>
html;
        }

	$jquery = $this->jqueryCompany();
        View::set('table',$html);
	   View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
        View::render("carrier_company_all");
    }

    public function showShortCode($json = false){

	$data = CarrierDao::getShortCodeAll();
	$array = array();
	foreach($data AS $value)
	    array_push($array, array('id'=>$value['short_code_id'], 'value'=>$value['short_code']));
	
	if($json === false){
	    header("Content-type: application/json; charset=utf-8");
            echo json_encode($array);
	}else
            return $array;
    }

    public function showCarrier($json = false){

        $data = CarrierDao::getCarrierAll();
        $array = array();
        foreach($data AS $value)
            array_push($array, array('id'=>$value['carrier_id'], 'value'=>$value['name']));

	if($json === false){
	    header("Content-type: application/json; charset=utf-8");
            echo json_encode($array);
	}else 
	    return $array;
    }

    private function setJquery(){
	$extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script>
        $(document).ready(function(){

            jQuery.validator.addMethod("ExisteUsuario",function(value,element)
            {

                data = {"nombre" : value},
                eReport = '';
		var nombre_hidden = $("#nombre_hidden").val();

                var val = 0;

                $.ajax(
                {
                   type: "POST",
                   url: "/carrier/validaNombre",
                   dataType: "json",
                   data: data,
                   async:false,    
                   success: function(data){
                        if(data == true)
                           val = 1;
                   },
                   error: function(xhr, textStatus, errorThrown){
                        val = 0;
                   }
                });

		if(nombre_hidden == value)
		    val = 1;
                
                return this.optional(element) || 0 != val;
            }, jQuery.validator.format("Ya existe este nombre"));

	      $("#add").validate(
                {
                    rules: {
                        nombre: {
                            required: true,
                            maxlength: 60,
                            minlength: 3,
			                ExisteUsuario: true	    
                        },

                        host: {
                            required: true,
                            maxlength: 50,
                            minlength: 3
                        },

                        puerto: {
                            required: true,
			                number: true
                        },
                        
                        system_id: {
                            required: true,
                            maxlength: 20,
                            minlength: 3
                        },

                        password: {
			                required: true,
                            maxlength: 20,
                            minlength: 3
                        },

            			source_ton: {
                            required: true,
                            number: true
                        },

            			source_npi: {
                            required: true,
                            number: true
                        },

            			destination_ton: {
                            required: true,
                            number: true
                        },

            			destination_npi: {
                            required: true,
                            number: true
                        },

            			addr_ton: {
                            required: true,
                            number: true
                        },

            			addr_npi: {
                            required: true,
                            number: true
                        },

            			tps_submit_one: {
                            required: true,
                            number: true
                        },

            			tps_submit_multi: {
                            required: true,
                            number: true
                        },

            			submit_multi_size: {
                            required: true,
                            number: true
                        },

            			country_code: {
                            required: true,
                            number: true
                        }
                    },
                    messages: {
                        nombre: {
                            required: "Este campo es obligatorio",
                            maxlength: "Es permitido sólo un máximo de 60 caracteres",
                            minlength: "No puedes escribir menos de 3 caracteres",
                            ExisteUsuario: "Este usuario ya existe"
                        },

                        host: {
                            required: "Este campo es obligatorio",
                            maxlength: "Es permitido sólo un máximo de 50 caracteres",
                            minlength: "No puedes escribir menos de 3 caracteres"
                        },

                        puerto: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },
                        
                        system_id: {
                            required: "Este campo es obligatorio",
                            maxlength: "Es permitido sólo un máximo de 20 caracteres",
                            minlength: "No puedes escribir menos de 3 caracteres"
                        },

                        password: {
                            required: "Este campo es obligatorio",
                            maxlength: "Es permitido sólo un máximo de 20 caracteres",
                            minlength: "No puedes escribir menos de 2 caracteres"
                        },

                        source_ton: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        source_npi: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        destination_ton: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        destination_npi: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        addr_ton: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        addr_npi: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        tps_submit_one: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        tps_submit_multi: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        submit_multi_size: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        },

                        country_code: {
                            required: "Este campo es obligatorio",
                            number: "Ingresa sólo números"
                        }

                    }
                }
            );
        });
        </script>
html;

	return array('header'=>$extraHeader, 'footer'=>$extraFooter);
    }

    public function add(){

	$obtieneSelect = function($metodo){
            $show = $this->$metodo(true);
            $html = '';
            foreach($show AS $value){
            	$html.=<<<html
        	<option value="{$value['id']}">{$value['value']}</option>
html;
            }

	    return $html;
	};

	$carrier = $obtieneSelect('showCarrier');
	$shortCode = $obtieneSelect('showShortCode');

	$jquery = $this->setJquery();
        View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
	View::set('carrier', $carrier);
	View::set('shortCode', $shortCode);
        View::render("carrier_add");
    }

    public function edit($id){
	$id = MasterDom::getParamSecure($id);
	if(empty($id) OR ($id == 0))
	    return MasterDom::alertas('error_general');

	$data = CarrierDao::getById($id);
	if(empty($data) OR (count($data) < 1))
	    return MasterDom::alertas('error_general');

	$carrier = new \stdClass();
	$carrier->_nombre  = $data['carrier_name'];
        $carrier->_host  = $data['host'];
        $carrier->_puerto = $data['port'];
        $carrier->_system_id = $data['system_id'];
        $carrier->_password = $data['password'];
        $carrier->_system_type  = ($data['system_type'] == 'nulo') ? '' : $data['system_type'];
        $carrier->_source_ton = $data['source_ton'];
        $carrier->_source_npi = $data['source_npi'];
        $carrier->_destination_ton = $data['destination_ton'];
        $carrier->_destination_npi = $data['destination_npi'];
        $carrier->_addr_ton = $data['addr_ton'];
        $carrier->_addr_npi = $data['addr_npi'];
        $carrier->_supports_wap_push = ($data['supports_wap_push'] == 1 ) ? 'checked="checked"' :'' ;
        $carrier->_mode = $data['mode'];
        $carrier->_status = ($data['status'] == 1) ? 'checked="checked"' :'' ;
        $carrier->_tps_submit_one = $data['tps_submit_one'];
        $carrier->_tps_submit_multi = $data['tps_submit_multi'];
        $carrier->_submit_multi_size = $data['submit_multi_size'];
        $carrier->_white_list = ($data['white_list'] == 'enable') ? 'checked="checked"' :'' ;
        $carrier->_white_list_user = $data['white_list_user'];
        $carrier->_white_list_pwd = $data['white_list_pwd'];
        $carrier->_country_code = $data['country_code'];
        $carrier->_carrier = $data['carrier_id'];
        $carrier->_shortCode = $data['short_code_id'];
	$carrier->_id = $data['carrier_connection_short_code_id'];
	$carrier->_carrier_connection_id = $data['carrier_connection_id'];

	$obtieneSelect = function($metodo, $valor){
            $show = $this->$metodo(true);
            $html = '';
            foreach($show AS $value){
		$selected = ($value['id'] == $valor) ? 'selected="selected"' : '';
                $html.=<<<html
                <option value="{$value['id']}" $selected >{$value['value']}</option>
html;
            }

            return $html;
        };

        $carrierShow = $obtieneSelect('showCarrier', $carrier->_carrier);
        $shortCodeShow = $obtieneSelect('showShortCode', $carrier->_shortCode);

	$showMode = '';
	foreach(array('TRX','RX','TX') AS $value){
	    $selected = ($value == $carrier->_mode) ? 'selected="selected"' : '';
	    $showMode.=<<<html
                <option value="$value" $selected >$value</option>
html;
	}

	$jquery = $this->setJquery();
	View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
	View::set('carrier', $carrier);
        View::set('shortCodeShow', $shortCodeShow);
	View::set('carrierShow', $carrierShow);
	View::set('modeShow', $showMode);
        View::render("carrier_edit");
    }

    private function getObjCarrier($edit = false){

	$carrier = new \stdClass();

	if($edit){
	    $carrier->_id = MasterDom::getData('id');
            $carrier->_carrier_connection_id = MasterDom::getData('carrier_connection_id');

	    if(empty($carrier->_id) OR empty($carrier->_carrier_connection_id))
		return MasterDom::alertas('error_general');
	}

        $carrier->_nombre  = MasterDom::getData('nombre');
        $carrier->_host  = MasterDom::getData('host');
        $carrier->_puerto = MasterDom::getData('puerto');
        $carrier->_system_id = MasterDom::getData('system_id');
        $carrier->_password = MasterDom::getData('password');
        $carrier->_system_type  = MasterDom::getData('system_type');
        $carrier->_source_ton = MasterDom::getData('source_ton');
        $carrier->_source_npi = MasterDom::getData('source_npi');
        $carrier->_destination_ton = MasterDom::getData('destination_ton');
        $carrier->_destination_npi = MasterDom::getData('destination_npi');
        $carrier->_addr_ton = MasterDom::getData('addr_ton');
        $carrier->_addr_npi = MasterDom::getData('addr_npi');
        $carrier->_supports_wap_push = MasterDom::getData('supports_wap_push');
        $carrier->_mode = MasterDom::getData('mode');
        $carrier->_status = MasterDom::getData('status');
        $carrier->_tps_submit_one = MasterDom::getData('tps_submit_one');
        $carrier->_tps_submit_multi = MasterDom::getData('tps_submit_multi');
        $carrier->_submit_multi_size = MasterDom::getData('submit_multi_size');
        $carrier->_white_list = MasterDom::getData('white_list');
        $carrier->_white_list_user = MasterDom::getData('white_list_user');
        $carrier->_white_list_pwd = MasterDom::getData('white_list_pwd');
        $carrier->_country_code = MasterDom::getData('country_code');
        $carrier->_carrier = MasterDom::getData('carrier');
        $carrier->_shortCode = MasterDom::getData('short_code');

        if(empty($carrier->_nombre) || empty($carrier->_host) || empty($carrier->_puerto) || empty($carrier->_system_id)
                || empty($carrier->_password) || ($carrier->_source_ton == '') || ($carrier->_source_npi == '') || ($carrier->_destination_ton == '')
                || ($carrier->_destination_npi == '') || ($carrier->_addr_ton == '') || ($carrier->_addr_npi == '') || empty($carrier->_mode)
                || ($carrier->_tps_submit_one == '') || ($carrier->_tps_submit_multi == '') || ($carrier->_submit_multi_size == '')
                || empty($carrier->_carrier) || empty($carrier->_shortCode)){
            return MasterDom::alertas('error_general');
	}

        $carrier->_status = ($carrier->_status == 'on') ? 1 : 0;
        $carrier->_supports_wap_push = ($carrier->_supports_wap_push == 'on') ? 1 : 0;
        $carrier->_white_list = ($carrier->_white_list == 'on') ? 'enable' : 'disable';

	return $carrier;
    }

    public function addCompany(){

	if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

	$nombre = MasterDom::getData('nombre');
	if(empty($nombre))
	    return MasterDom::alertas('error_general');

	if(!CarrierDao::insertCompany($nombre))
	    return MasterDom::alertas('error_general');

    $registro = $this->registroUsuario("Agrego company {$nombre}");
    CarrierDao::registroUsuario($registro);
	return MasterDom::alertas('success_add');	
    }

    public function editCompany($id){

	$id = MasterDom::getParamSecure($id);
        if(empty($id) OR ($id == 0))
            return MasterDom::alertas('error_general');

        $data = CarrierDao::getIdCompany($id);
        if(empty($data) OR (count($data) < 1))
            return MasterDom::alertas('error_general');

	$jquery = $this->jqueryCompany();
	$carrier = new \stdClass();
	$carrier->_nombre = $data['name'];
	$carrier->_id = $data['carrier_id'];
	View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
	View::set('carrier', $carrier);
        View::render("carrier_company_edit");
    }

    public function editCompanyPost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
	$id = MasterDom::getData('id');
        if(empty($nombre) OR empty($id))
            return MasterDom::alertas('error_general');

        if(CarrierDao::updateCompany($id, $nombre) === false)
            return MasterDom::alertas('error_general');

        $registro = $this->registroUsuario("Actualizo company ".$id.":{$nombre}");
        CarrierDao::registroUsuario($registro);
        return MasterDom::alertas('success_add');
    }

    public function indexShortCode() {

        $row = CarrierDao::getAllShortCode();
        $html = '';
        foreach($row AS $key=>$value){

            $id = MasterDom::setParamSecure($value['short_code_id']);
            $html.=<<<html
                <tr>
                    <td>{$value['short_code']}</td>
                    <td class="center"><a href="/carrier/editShortCode/$id" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
                </tr>
html;
        }

        $jquery = $this->jqueryShortCode();
        View::set('table',$html);
        View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
        View::render("carrier_short_code_all");
    }

    public function addShortCode(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
        if(empty($nombre))
            return MasterDom::alertas('error_general');

        if(!CarrierDao::insertShortCode($nombre))
            return MasterDom::alertas('error_general');

        $registro = $this->registroUsuario("Agrego shortCode {$nombre}");
        CarrierDao::registroUsuario($registro);
        return MasterDom::alertas('success_add');
        
    }

    public function editShortCode($id){

        $id = MasterDom::getParamSecure($id);
        if(empty($id) OR ($id == 0))
            return MasterDom::alertas('error_general');

        $data = CarrierDao::getIdShortCode($id);
        if(empty($data) OR (count($data) < 1))
            return MasterDom::alertas('error_general');

        $jquery = $this->jqueryShortCode();
        $carrier = new \stdClass();
        $carrier->_nombre = $data['short_code'];
        $carrier->_id = $data['short_code_id'];
        View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
        View::set('carrier', $carrier);
        View::render("carrier_short_code_edit");
    }

    public function editShortCodePost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
        $id = MasterDom::getData('id');
        if(empty($nombre) OR empty($id))
            return MasterDom::alertas('error_general');

        if(CarrierDao::updateShortCode($id, $nombre) === false)
            return MasterDom::alertas('error_general');

        $registro = $this->registroUsuario("Actualizo shortCode {$nombre} id: {$id}");
        CarrierDao::registroUsuario($registro);
        return MasterDom::alertas('success_add');
         
    }

    public function addCarrier(){

	if(!$_POST OR !MasterDom::whiteListeIp())
	    return MasterDom::alertas('error_general');

        $carrier = $this->getObjCarrier();

      	$idCarrier = CarrierDao::insert($carrier); 
	if(!$idCarrier OR empty($idCarrier) OR ($idCarrier < 1)){
	    return MasterDom::alertas('error_general');
	}

	$connection = CarrierDao::insertCarrierShortCode($idCarrier, $carrier->_shortCode, $carrier->_carrier);
	if(!$connection OR empty($connection) OR ($connection < 1)){
            return MasterDom::alertas('error_general');
        }

        if (!empty($idCarrier)) {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Agrego carrier {$idCarrier}");
            CarrierDao::registroUsuario($registro);
            /***************************************************************/
        }
	
	try{
	    $json['card']['reconnect'] = 'true';
	    $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
	    return MasterDom::alertas('success_add');
	}catch(Exception $e){
	    return MasterDom::alertas('error_carrier');
	}

    }

    public function editCarrier(){
	
	if(!$_POST OR !MasterDom::whiteListeIp()){
            return MasterDom::alertas('error_general');
	}

        $carrier = $this->getObjCarrier(true);
	if(CarrierDao::update($carrier) === false){
	    return MasterDom::alertas('error_general');
	}

	if(CarrierDao::updateRelation($carrier->_id, $carrier->_shortCode, $carrier->_carrier) === false){
	    return MasterDom::alertas('error_general');
	}

    if (!empty($carrier->_id)) {
        /**************************** Registro *************************/
        $registro = $this->registroUsuario("Actualizo carrier {$carrier->_carrier_connection_id}");
        CarrierDao::registroUsuario($registro);
        /***************************************************************/
    }

	try{
            $json['card']['reconnect'] = 'true';
            $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
            return MasterDom::alertas('success_add');
        }catch(Exception $e){
            return MasterDom::alertas('error_carrier');
        }

    }

    public function delete(){

	if(!$_POST OR !MasterDom::whiteListeIp())
	    return MasterDom::alertas('error_general');

	$row = MasterDom::getDataAll('borrar');
	if(count($row) < 1 OR empty($row))
	    return MasterDom::alertas('error_general');

	foreach($row AS $value){
	    $id = (int)$value;
	    if($value == '')
		continue;
	    $registro = $this->registroUsuario("Elimino carrier {$id}");
        CarrierDao::registroUsuario($registro);
        CarrierDao::delete($id);
	}
    

	try{
            $json['card']['reconnect'] = 'true';
            $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
            return MasterDom::alertas('success_add');
        }catch(Exception $e){
            return MasterDom::alertas('error_carrier');
        }

    }

    public function validaNombre (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByName(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

	return;
    }

    public function validaNombreCompany (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByNameCompany(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

        return;
    }

    public function validaNombreShortCode (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByNameShortCode(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

        return;
    }

    public function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }
}
