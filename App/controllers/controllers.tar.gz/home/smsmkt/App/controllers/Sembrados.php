<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

error_reporting(E_ALL);

use \Core\View;
use \Core\MasterDom;
use \App\models\Sembrados as SembradosDao;
use \App\models\Menu as MenuDao;
use \App\controllers\Contenedor;

class Sembrados {

private $_contenedor;

    function __construct() { 
		$this->_contenedor = new Contenedor;
		View::set('header',$this->_contenedor->header());
		View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {
    	$id_customer = MasterDom::getSession('customer_id');
        /*********************Total MT Messages***************************/
        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;
		$extraFooter =<<<html
			<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

			<!--jQuery validate -->
			<script src="/js/magicsuggest-min.js"></script>
			<script src="/js/validate/jquery.validate.js"></script>
			<script src="/js/jquery.dataTables.min.js"></script>
			<script src="/js/dataTables.bootstrap.min.js"></script>
			<script src="/js/jquery.tablesorter.js"></script>
			 <script src="/js/bootbox.min.js"></script>

			<script>
				$(document).ready(function(){

					$("#datatable-checkbox").tab$eesalesorter();
					var oTable = $('#datatable-checkbox').DataTable({
						"columnDefs": [{
							"orderable": false,
							"targets": 0
						}],
						"order": false
					});

					// Remove accented character from search input as well
					$('#datatable-checkbox input[type=search]').keyup( function () {
						var table = $('#example').DataTable();
						table.search(
							jQuery.fn.DataTable.ext.type.search.html(this.value)
						).draw();
					});

					jQuery('#identificador').keyup(function() {
						var str = jQuery('#identificador').val();
						var spart = str.split(" ");
						for ( var i = 0; i < spart.length; i++ ){
							var j = spart[i].charAt(0).toUpperCase();
							spart[i] = j + spart[i].substr(1);
						}
						jQuery('#identificador').val(spart.join(" "));
					});

					$("#form-add-msisdn1").validate({
			            rules:{
			              telefono:{
			                required: true,
			                maxlength: 10,
			                minlength: 10,
			                digits: true
			              },
			              identificador:{
			                required: true
			              }
			            },
			            messages:{
			              telefono:{
			                required: "Este campo es requerido",
			                maxlength: "Este campo debe tener 10 digitos",
			                minlength: "Este campo debe tener 10 digitos",
			                digits: "Este campo es de valores numericos"
			              },
			              identificador:{
			                required: "Este campo es requerido",
			                minlength: "Este campo debe tener 5 digitos minimos"
			              }
			            }
			        });//fin del jquery validate

					$("#checkAll").change(function () {
                		$("input:checkbox").prop('checked', $(this).prop("checked"));
            		});

			        $(document).on("click", "#delete", function(e) {
                    	bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                        	if (result) 
                            	$( "#servicios" ).submit();
                    	});
            		});

				});

				/*$(document).on('click','#add-msisdn',function(e) {
					var data = $("#form-add-msisdn").serialize();
					$.ajax({
						data: data,
						type: "post",
						url: "/Sembrados/add",
						success: function(data){

							if(data == "1"){
								$('#result').html('<div class="alert alert-danger alert-dismissible"> El n&uacute;mero ya ha sido registrado</div>');

								setTimeout(function(){
								 	$('#result').html("");
								}, 3000);
							}

							if(data == "2"){
								$('#result').html('<div class="alert alert-success alert-dismissible"> Se ha agregado el numero telefonico</div>');
								$('#telefono').val('');
								$('#identificador').val('');
								setTimeout(function(){
								 	$('#result').html("");
								}, 3000);
							}

							if(data == "3"){
								$('#result').html('<div class="alert alert-info alert-dismissible"> Se ha agregado el numero telefonico</div>');
								$('#telefono').val('');
								$('#identificador').val('');
								setTimeout(function(){
								 	$('#result').html("");
								}, 3000);
							}

							if(data == "4"){
								$('#result').html('<div class="alert alert-warning alert-dismissible"> Ingresa datos</div>');
								$('#result').delay(3000).fadeOut();
							}


						}
					});

					$.ajax({
						url: "/Sembrados/getTabla",
						success: function(data1){
							$('#tabla-consulta').html(data1);
						}
					});
	
				});*/

			</script>

html;
		$id_custom = MasterDom::getSession('customer_id');

		if(!empty(MasterDom::getDataAll('msisdnId'))){
			$extraFooter .=<<<html
			<script>
				$(document).ready(function(){
					/*$(".collapse-link-1").click();
					$( "#addMsisdn" ).click(function() {
						$(".collapse-link-1" ).click();
						$("#telefono").focus();
					});*/
				});
			</script>
html;
			
			$msisdnSearch = SembradosDao::getMsisdnById(MasterDom::getDataAll('msisdnId'));
			$numero = $msisdnSearch['msisdn_log'];
			$msisdn = substr($numero, -10);

			View::set('msisdnId',$msisdnSearch['msisdn_sembrados_id']);
			View::set('accion','editMsisdn');
			View::set('msisdn',$msisdn);
			View::set('identificador',$msisdnSearch['identificador']);
			View::set('titulo_add_edit', 'Editar el n&uacute;mero ');
			View::set('btn_add_edit','Editar');
			View::set('btn_alert','btn-info');
			View::set('display','display: none;');
			$btnAdd = <<<html
			<a href="/Sembrados/" class="fa fa-plus btn btn-success btn-sm" style="padding-top:7px; padding-bottom: 7px;"> Agregar</a>
html;

			View::set('btnAdd',$btnAdd);
		}else{
			$extraFooter .=<<<html
			<script>
				$(document).ready(function(){
					$(".collapse-link-1").click();
					$( "#addMsisdn" ).click(function() {
						$(".collapse-link-1" ).click();
						$("#telefono").focus();
					});
				});
			</script>
html;
			View::set('titulo_add_edit', 'Agregar un numero telefonico de pruebas');
			View::set('btn_add_edit','Agregar');
			View::set('btn_alert','btn-success');
			View::set('accion','addMsisdn');
		}



		$tabla = "";
		$i = 0;
		foreach (SembradosDao::getMsisdnSembrados($id_custom) as $key => $value) {
			$nombreCarrier = (strlen($value['nombre_carrier']) > 1) ? $value['nombre_carrier'] : "Sin Carrier";
			$i++;
			$status = ($value['estatus'] == 1 ) ? "Activo" : "Inactivo";
			$tabla .=<<<html
				<tr>
					<td><input type="checkbox" name="checkAll[]" id="checkAll" value="{$value['msisdn_sembrados_id']}"/></td>
					<td>{$i}</td>
					<td>{$value['identificador']}</td>
					<td>{$value['msisdn_log']}</td>
					<td>{$nombreCarrier}</td>
					<td style="text-align: center; ">
						<a href="/Sembrados&msisdnId={$value['msisdn_sembrados_id']}" class="btn btn-info fa fa-edit"> Editar</a>
					</td>
				</tr>
html;
		}

		View::set('tabla',$tabla);
		View::set('header',$this->_contenedor->header($extraHeader));
		View::set('footer',$this->_contenedor->footer($extraFooter));
		View::render("sembrados_inicio");
	}

	public function addMsisdn(){
		$numero 		= "52" . MasterDom::getData('telefono');
		$identificador 	= MasterDom::getDataAll('identificador');
		$id_customer 	= MasterDom::getSession('customer_id');


		$buscarMsisdn = SembradosDao::getMsisdn($numero);

		// Consulta para buscar msisdn de la BD 
		foreach ($buscarMsisdn as $key => $value) {
			$id = $value['msisdn_id'];
		}

		// Preparando datos para enviar a sembrado
		$msisdnSembrado = new \stdClass();
		$msisdnSembrado->_msisdn_id = $id;
		$msisdnSembrado->_msisdn_log = $numero;
		$msisdnSembrado->_identificador = $identificador;
		$msisdnSembrado->_estatus = 1;
		$msisdnSembrado->_customer_id = $id_customer;

		$texto = "";
		// Buscar en msisdn
		if(!empty($buscarMsisdn)>0){

			$n = MasterDom::getDataAll('telefono');
			$i = MasterDom::getDataAll('identificador');

			if(!empty($n) AND !empty($i)){
				$buscarMsisdnSembrados = SembradosDao::getAnMsisdnSembrado($numero);
				if($buscarMsisdnSembrados){
					$class = "info";
					$texto = "El numero {$n}, ya se encuentra registrado en la lista de numeros sembrados."; 
				}else{
					$class = "success";
					$idSembrado = SembradosDao::insertMsisdnSembradoNuevo($msisdnSembrado);
					$texto = "El numero {$n} ha sido insertado a la lista de n&uacute;meros sembrados.";
				}
			}else{
				$class = "danger";
				$texto = "Ha ocurrido un error.";
			}

		}else{
			
			$x = MasterDom::getDataAll('telefono');
			$y = MasterDom::getDataAll('identificador');

			if(!empty($x) AND !empty($y)){
				// Envio de peticion para buscar el carrier del numero telefonico que ingresara a msisdn
				$num = MasterDom::getData('telefono');
				$type_carrier = file_get_contents("http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn=$num");
				if($type_carrier == "NO CARRIER"){
					$idCarrier = 0; // Si el carrier no es encontrado, '0' para despues procesar lo en la BD
				}else{
					// Consultar cual es el id del carrier
					$busquedaIdCarrier = SembradosDao::getCarrier(strtolower($type_carrier));
					$idCarrier = $busquedaIdCarrier['carrier_id'];
				}

				$msisdn = new \StdClass();
				$msisdn->_msisdn = $numero;
				$msisdn->_carrier_id = $idCarrier;
				$idMsisdn = SembradosDao::insertMsisdnNuevo($msisdn);
				// ID de nuevo registro dentro de msisdn
				$msisdnSembrado->_msisdn_id = $idMsisdn;
				// Insertar nuevo registro dentro de sembrados
				$idSembrado = SembradosDao::insertMsisdnSembradoNuevo($msisdnSembrado);
				// Insertar numero de telcel a whitelist
				$parametros = new \stdClass();
				$parametros->_customer_id = $id_customer;
				$parametros->_msisdn_id = $idMsisdn;
				$datosWhiteList = SembradosDao::getDatosParaWhiteList($parametros);
				foreach ($datosWhiteList as $key => $value) {
					// Insertar en la tabla de white list si el numero es telcel
					if($value['carrier_id'] == 1){
						$whitelist = new \stdClass();
						$whitelist->_msisdn_id = $value['msisdn_id'];
						$whitelist->_carrier_connection_id = $value['carrier_connection_id'];
						$insertWhiteList = SembradosDao::insertWhiteList($whitelist);
					}
				}
				$class = "success";
				$texto = "Se ha insertado el n&uacute;mero {$numero}, a la lista de numeros sembrados."; // Se
			}else{
				$class = "danger";
				$texto = "Ha ocurrido un error";
			}

		}


		View::set('class',$class);
		View::set('regreso','/Sembrados/');
		View::set('titulo', '');
		View::set('mensaje', $texto);
		View::render("mensaje");
	}

	public function getModificarMsisdn(){
		if($id>0){
			View::set('class','success');
			View::set('mensaje','SE HA INSERTADO CORRECTAMENTE');
		}else{
			View::set('class','danger');
			View::set('mensaje','AL PARECER HA OCURRIDO UN PROBLEMA');
		}
		
		View::set('regreso','');
		View::set('header',$this->_contenedor->header());
		View::set('footer',$this->_contenedor->footer());
		View::render("alerta");
	}

	public function editMsisdn(){
		$data = new \stdClass();
		$data->_msisdn_sembrados_id = MasterDom::getDataAll('msisdn_sembrado_id');
		$data->_msisdn_log = MasterDom::getDataAll('telefono');
		$data->_identificador = MasterDom::getDataAll('identificador');

		$id = SembradosDao::updateMsisdnById($data);

		if($id>0){
			$class = "success";
			$texto = "Se ha modificado";
		}else{
			$class = "warning";
			$texto = "Al parecer existe un problema";
		}

		View::set('class',$class);
		View::set('regreso','/Sembrados/');
		View::set('titulo', '');
		View::set('mensaje', $texto);
		View::render("mensaje");
	}

	public static function add(){
		$numero 		= "52" . MasterDom::getData('telefono');
		$identificador 	= MasterDom::getDataAll('identificador');
		$id_customer 	= MasterDom::getSession('customer_id');

		$buscarMsisdn = SembradosDao::getMsisdn($numero);

		// Consulta para buscar msisdn de la BD 
		foreach ($buscarMsisdn as $key => $value) {
			$id = $value['msisdn_id'];
		}

		// Preparando datos para enviar a sembrado
		$msisdnSembrado = new \stdClass();
		$msisdnSembrado->_msisdn_id = $id;
		$msisdnSembrado->_msisdn_log = $numero;
		$msisdnSembrado->_identificador = $identificador;
		$msisdnSembrado->_estatus = 1;
		$msisdnSembrado->_customer_id = $id_customer;

		// Buscar en msisdn
		if(!empty($buscarMsisdn)>0){

			$n = MasterDom::getDataAll('telefono');
			$i = MasterDom::getDataAll('identificador');

			if(!empty($n) AND !empty($i)){
				$buscarMsisdnSembrados = SembradosDao::getAnMsisdnSembrado($numero);
				if($buscarMsisdnSembrados){
					echo "1";
				}else{
					$idSembrado = SembradosDao::insertMsisdnSembradoNuevo($msisdnSembrado);
					echo "2";
				}
			}else{
				echo "4";
			}

		}else{
			
			$x = MasterDom::getDataAll('telefono');
			$y = MasterDom::getDataAll('identificador');

			if(!empty($x) AND !empty($y)){
				// Envio de peticion para buscar el carrier del numero telefonico que ingresara a msisdn
				$num = MasterDom::getData('telefono');
				$type_carrier = file_get_contents("http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn=$num");

				if($type_carrier == "NO CARRIER"){
					// Si el carrier no es encontrado, '0' para despues procesar lo en la BD
	 				$idCarrier = 0;
				}else{
					// Consultar cual es el id del carrier
					$busquedaIdCarrier = SembradosDao::getCarrier(strtolower($type_carrier));
					$idCarrier = $busquedaIdCarrier['carrier_id'];
				}

				$msisdn = new \StdClass();
				$msisdn->_msisdn = $numero;
				$msisdn->_carrier_id = $idCarrier;
				$idMsisdn = SembradosDao::insertMsisdnNuevo($msisdn);


				// ID de nuevo registro dentro de msisdn
				$msisdnSembrado->_msisdn_id = $idMsisdn;
				// Insertar nuevo registro dentro de sembrados
				
				$idSembrado = SembradosDao::insertMsisdnSembradoNuevo($msisdnSembrado);

				// Insertar numero de telcel a whitelist

				$parametros = new \stdClass();
				$parametros->_customer_id = $id_customer;
				$parametros->_msisdn_id = $idMsisdn;
				$datosWhiteList = SembradosDao::getDatosParaWhiteList($parametros);

				foreach ($datosWhiteList as $key => $value) {
					// Insertar en la tabla de white list si el numero es telcel
					if($value['carrier_id'] == 1){
						$whitelist = new \stdClass();
						$whitelist->_msisdn_id = $value['msisdn_id'];
						$whitelist->_carrier_connection_id = $value['carrier_connection_id'];
						$insertWhiteList = SembradosDao::insertWhiteList($whitelist);
					}
				}

				echo "3";
			}else{
				echo "4";
			}

		}
	}

	public function getTabla(){
		$id_custom = MasterDom::getSession('customer_id');
		$tabla = "";
		$i = 0;
		foreach (SembradosDao::getMsisdnSembrados($id_custom) as $key => $value) {
			$i++;
			$status = ($value['estatus'] == 1 ) ? "Activo" : "Inactivo";
			$tabla .=<<<html
				<tr>
					<td><input type="checkbox" name="checkAll[]" id="checkAll" value="{$value['msisdn_sembrados_id']}"/></td>
					<td>{$i}</td>
					<td>{$value['identificador']}</td>
					<td>{$value['msisdn_log']}</td>
					<td>{$value['name']}</td>
				</tr>
html;
		}

		echo $tabla;
	}

	public static function delete(){
		$ids = MasterDom::getDataAll('checkAll');
		if(!empty($ids)){

			foreach ($ids as $key => $value) {
				$delete = SembradosDao::delete($value);
				if($delete>0){
					$class = 'success';
					$mensaje = 'Se ha eliminado correctamente';
				}else{
					$class = 'danger';
					$mensaje = 'No se ha eliminado los registros';
				}
			}
			
			View::set('class',$class);
			View::set('regreso','/Sembrados');
			View::set('titulo', ', eliminaci&oacute;n de n&uacute;meros sembrados');
			View::set('mensaje', $mensaje);
			View::render("mensaje");
		}else{
			$class = 'warning';

			View::set('class',$class);
			View::set('regreso','/Sembrados');
			View::set('titulo', 'Mensaje de error');
			View::set('mensaje', 'Lo sentimos al parecer no seleccionaste ningun registro para eliminar, intenta nuevamente');
			View::render("mensaje");
		}
		
	}


}