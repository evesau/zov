<?php
//phpinfo();
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;

mail('esau.espinoza@airmovil.com','soap server SmsSkyWs',file_get_contents('php://input'));
/*
** Client Wsdl
** Esaú
*/
class SmsSkyWs
{
	public function index()
	{
		
	}

	public function sendSms($params)
	{
		mail("esau.espinoza@airmovil.com", 'sendSms', file_get_contents("php://input"). "params: " . print_r($params,1).file_get_contents("php://output"));

	header("Content-Type: application/xml; charset=utf-8");
$response =<<<html
	<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.sky.com/SkySmsHeader" xmlns:ns2="http://www.sky.com/SkySmsChangePassword">
	   <SOAP-ENV:Body>
	      <ns2:SendSmsResponse>
	         <ns2:headerResponse>
	            <ns1:codeError>0x001</ns1:codeError>
	            <ns1:messageError>error</ns1:messageError>
	         </ns2:headerResponse>
	         <ns2:idMessage>1001</ns2:idMessage>
	         <ns2:success>Message queded</ns2:success>
	         <ns2:code>001</ns2:code>
	         <ns2:description>Mensaje preparado para envio</ns2:description>
	         <ns2:operator>telcel</ns2:operator>
	      </ns2:SendSmsResponse>
	   </SOAP-ENV:Body>
	</SOAP-ENV:Envelope>
html;

		
		echo $response;
		exit;
	}
	 
	public function changePasswordSms($params)
	{
		mail("esau.espinoza@airmovil.com", 'changePasswordSms', file_get_contents("php://input"). "params: " . print_r($params,1).file_get_contents("php://output"));



	header("Content-Type: application/xml; charset=utf-8");
$response =<<<html
	<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.sky.com/SkySmsHeader" xmlns:ns2="http://www.sky.com/SkySmsChangePassword">
	   <SOAP-ENV:Body>
	      <ns2:ChangePasswordSmsResponse>
	         <ns2:headerResponse>
	            <ns1:codeError>0x001</ns1:codeError>
	            <ns1:messageError>error</ns1:messageError>
	         </ns2:headerResponse>
	         <ns2:code>1001</ns2:code>
	         <ns2:description>no fount error</ns2:description>
	      </ns2:ChangePasswordSmsResponse>
	   </SOAP-ENV:Body>
	</SOAP-ENV:Envelope>
html;
		
		echo $response;
		exit;
	}

}


$server = new \SoapServer("https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl");
$server->AddFunction('sendSms');
$server->AddFunction('changePasswordSms');
$server->handle();
print_r($server);
