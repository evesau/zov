<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\FiltroCaracteresEspeciales as FiltroCaracteresEspecialesDao;
use \App\controllers\FiltroCaracteresEspeciales;

class FiltroCaracteresEspeciales{

	private $_contenedor;

	    function __construct()
	    { 
			$this->_contenedor = new Contenedor;
	    }

	    public function index() { //Función principal

			if(!empty($_POST['url'])){ //Comprobamos si el parámetro enviado por POST no está vacío

						$url = $_POST['url'];

						if(filter_var($url, FILTER_VALIDATE_URL)){
							
							$arrContextOptions=array(
							    "ssl"=>array(
							        "verify_peer"=>false,
							        "verify_peer_name"=>false,
							    ),
							); 

							$url = file_get_contents($url, false, stream_context_create($arrContextOptions));

							//$search_CaracteresEspeciales = "La url es valida";

							$search_CaracteresEspeciales = $this->revisaCaracteresEspeciales($url);//Función para revisar si hay caracteres especiales en el contenido de la URL

						} elseif(!filter_var($url, FILTER_VALIDATE_URL)) {
							
							$search_CaracteresEspeciales = $this->revisaCaracteresEspeciales($url);// No es url, pero hay una mala palabra

						} else {
							
							$search_CaracteresEspeciales = $search_CaracteresEspeciales->Mensaje = array("message" => FALSE);//.No hay caracteres especiales en el parámetro enviado

						}

			} else{

				$search_CaracteresEspeciales = $search_CaracteresEspeciales->Mensaje = array("message" => FALSE);//."2do if"; //Parámetro enviado por POST está vacío
			}
			
		header('Content-Type: application/json; charset=utf-8');
		$json = json_encode($search_CaracteresEspeciales);
		echo $json;

		}

		public function revisaCaracteresEspeciales($search_CaracteresEspeciales){//Funcion detectora de caracteres especiales

					$caracterEspecial = array('À','Á','Â','Ã','Ä','Å','Æ','Ç','È','É','Ê','Ë','Ì','Í','Î','Ï','Ñ','Ò','Ó','Ô','Õ','Ö','Ø','Ù','Ú','Û','Ü','ß','à','á','â','ã','ä','å','æ','ç','è','é','ê','ë','ì','í','î','ï','ñ','ò','ó','ô','õ','ö','÷','ø','ù','ú','û','ü','ÿ','₫','á','é','í','ó','ú','à','è','ì','ò','ù','â','ê','î','ô','û','ã','õ','ç','â','ã','å','ä','æ','ë','ï','ð','õ','ö','ø','ü','ý','ÿ','ñ','/[^a-z0-9\-&lt;&gt;]/','/[\-]+/','/&lt;{^&gt;*&gt;/');//Array que contiene los caracteres Especiales a detectar

					foreach ($caracterEspecial as $caracteresEspeciales) {
					 
						if(preg_match("/$caracteresEspeciales/i",$search_CaracteresEspeciales)){/*Usamos expresiones regulares
																		  		  				para comprobar ss en el texto existe algun insurto.
																		  		 				Tambièn usamos los datos insertados en la base de datos.
																	      		  				Tambien se usa el modificador i para que no diferencie entre mayuscula y minuscula*/

							return $search_CaracteresEspeciales = array("message" => TRUE);//."Hay caracteres especiales";//Si se ejecuta el if() y detecta al menos una mala palabra almacenada en la BD, devuelve TRUE
							exit;
						}

					}

			return $search_CaracteresEspeciales = array("message" => FALSE);//."ninguna mala palabra";//Si no se detecta ningun caracter especial devuelve FALSE
		}//Fin de la funcion

		public function intento(){
			View::render('test_CaracteresEspeciales');
		}

		public function prueba_url(){
			View::render('test_url');
		}
}