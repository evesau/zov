<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

error_reporting(E_ALL);

use \Core\View;
use \Core\MasterDom;
use \App\models\Badword as badwordDao;
use \App\controllers\Contenedor;

class BadwordTest {

private $_contenedor;

    function __construct() { 
    $this->_contenedor = new Contenedor;
    View::set('header',$this->_contenedor->header());
    View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

    MasterDom::verificaUsuario();

    $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

    $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    campania: {
                        required: true
                    },

                    short_code: {
                        required: true
                    },

                    title: {
                        required: true
                    },
                    
                    handler: {
                        required: true
                    },

                    configuration: {
                        required: true
                    }
                }
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#campania").change(function() {
                    var form_data = {
                        campania: $("#campania").val()
                    };
                    $.ajax({
                            type: "POST",
                            url: "/Service/showShortCode",
                            data: form_data,
                            success: function(response)
                            {
                                console.debug(response);
                                $("#short_code").html(response).fadeIn();
                            }
                    });
                });

                $("#handler").change(function(){
                    if( $("#handler").val() == 'url'){
                        console.debug('url');
                        $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                        $("#configuration").get(0).type = 'url';
                    }
                    if( $("#handler").val() == 'staticText'){
                        console.debug('staticText');
                        $("#configuration").get(0).placeholder = 'Ingresa el texto';
                        $("#configuration").get(0).type = 'text';
                    }
                });
        
            });
        </script>

html;

     $data_allTable = '<tr>';
        $bad = badwordDao::getAll();
        foreach ($bad as $key => $value) {
            $data_allTable .= "<td>".$value['word']."</td>
                                <td>".$value['bad_words_id']."</td>";
        }

        $data_allTable .= "</tr>";

    View::set('table',$data_allTable);
    View::set('header',$this->_contenedor->header($extraHeader));
    View::set('footer',$this->_contenedor->footer($extraFooter));
    View::render("badword_all");

    
    }

    public function add() {
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    word: {
                        required: true
                    }
                },
                messages: {
                    word: {
                        required: "Escriba una palabra"
                    }
                }
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#campania").change(function() {
                    var form_data = {
                        campania: $("#campania").val()
                    };
                    $.ajax({
                            type: "POST",
                            url: "/Service/showShortCode",
                            data: form_data,
                            success: function(response)
                            {
                                console.debug(response);
                                $("#short_code").html(response).fadeIn();
                            }
                    });
                });

                $("#handler").change(function(){
                    if( $("#handler").val() == 'url'){
                        console.debug('url');
                        $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                        $("#configuration").get(0).type = 'url';
                    }
                    if( $("#handler").val() == 'staticText'){
                        console.debug('staticText');
                        $("#configuration").get(0).placeholder = 'Ingresa el texto';
                        $("#configuration").get(0).type = 'text';
                    }
                });
        
            });
        </script>

html;
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("badword_add");
    
    }


    public function add_word(){

        MasterDom::verificaUsuario();
        if (empty($_POST)){ header('location:/badword/add/');}

        $word = MasterDom::procesoAcentos('word');
        // $words = MasterDom::procesoAcentos($word);

        $datos = new \stdClass();
        $datos->_word = $word;
        $datos->_customer_id = MasterDom::getSession('customer_id');

        $istWord = badwordDao::insert($datos);

        if (empty($istWord)){
            header('location:/badword/add');
        } else {
            $registro = $this->registroUsuario("Agrego badword {$istWord}");
            badwordDao::registroUsuario($registro);
            header('location:/badword/mostrar');
        }
    }

    public function delete(){
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    word: {
                        required: true
                    }
                },
                messages: {
                    word: {
                        required: "Elige una palabra"
                    }
                }
            });
        </script>
html;

        $id_custom = MasterDom::getSession('customer_id');

        $word_option = '';
        // $service = badwordDao::getService($id_custom);
        $words = badwordDao::getAllByCustomer(MasterDom::getSession('customer_id'));
        foreach ($words as $key => $value) {
            $word_option .= "<option value=".$value['bad_words_id'].">".$value['word']."</option>";
        }

        View::set('word_option',$word_option);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("badword_delete");
    }

    public function delete_badword(){
        MasterDom::verificaUsuario();
        if (empty($_POST)) header('location:/badword/mostrar');

        $id_badword = MasterDom::getData('word');
        // echo $id_badword;exit;
        if (empty($id_badword)) {
            echo "id vacio";
        } else{
            badwordDao::delete($id_badword);
            $registro = $this->registroUsuario("Elimino badword {$id_badword}");
            badwordDao::registroUsuario($registro);    
        }
        header('location:/badword/mostrar/'); //exito

    }

    public function mostrar(){

        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;
        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

    <script>
        $("#form").validate({
            rules: {
                campania: {
                    required: true
                },

                short_code: {
                    required: true
                },

                title: {
                    required: true
                },
                
                handler: {
                    required: true
                },

                configuration: {
                    required: true
                }
            }
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {

            $("#servicio").change(function(){
                console.debug()
                var form = {
                    service: $("#servicio").val()
                };

                $.ajax({
                    type: "POST",
                    url: "/Service/getDataService",
                    dataType: 'json',
                    data: form,
                    async: false,
                    success: function(data){
                        console.debug(data);
                        $('#id_service').val(data._service_id);
                        $('#campania').val(data._campaign_id);
                        $('#short_code').val(data._short_code);
                        $('#short_code_id').val(data._short_code_id);
                        $('#title').val(data._title);
                        $('#description').val(data._description);
                        $('#handler').val(data._handler);
                        $('#configuration').val(data._configuration);
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "/Service/getKeywords",
                    dataType: 'json',
                    data: form,
                    async: false,
                    success: function(data){
                        console.debug(data);
                        $('#keywords').val(data);
                    }
                })
            });


            $("#campania").change(function() {
                var form_data = {
                    campania: $("#campania").val()
                };
                $.ajax({
                        type: "POST",
                        url: "/Service/showShortCode",
                        data: form_data,
                        success: function(response){
                            console.debug(response);
                            $("#short_code").html(response).fadeIn();
                        }
                });
            });

            $("#handler").change(function(){
                if( $("#handler").val() == 'url'){
                    console.debug('url');
                    $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                    $("#configuration").get(0).type = 'url';
                }
                if( $("#handler").val() == 'staticText'){
                    console.debug('staticText');
                    $("#configuration").get(0).placeholder = 'Ingresa el texto';
                    $("#configuration").get(0).type = 'text';
                }
            });
        });
    </script>

    <!-- DataTables JavaScript -->
<script src="/js/jquery.dataTables.min.js"></script>
<script src="/js/dataTables.bootstrap.min.js"></script>
<script src="/js/bootbox.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

    var table = $('#muestra-cupones').DataTable({
        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing": "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
    });

    $("#checkAll").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });

    $(document).on("click", "#delete", function(e) {
            bootbox.confirm("&iquest;Borrar&aacute;s los bad words seleccionados?", function(result) {
                if (result) 
                    $( "#delete_form" ).submit();
            });
    });
} );
</script>
html;


        $data_allTable = '';
        $bad = badwordDao::getAllByCustomer(MasterDom::getSession('customer_id'));
        foreach ($bad as $key => $value) {
            $data_allTable .= " <tr>
                                    <td><input type='checkbox' name='borrar[]' value='{$value['bad_words_id']}'/></td>
                                    <td>{$value['word']}</td>
                                </tr>";
        }

        View::set('table',$data_allTable);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("badword_all");
    }

        public function delete_badwordList(){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(badwordDao::delete($id) === false)
                {return $this->alertas('error_borrar');}
            else
                {$registro = $this->registroUsuario("Elimino badword {$id}");
                                badwordDao::registroUsuario($registro);}
        }

        return $this->alertas('success_delete');

        // header('location:/badword/mostrar/'); //exito

    }


     private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con éxito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/badword/mostrar');
        View::set('class', $class);
        View::set('titulo','badword');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }


}