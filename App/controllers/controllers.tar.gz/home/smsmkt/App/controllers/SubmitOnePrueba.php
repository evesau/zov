<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
//use \App\controllers\Contenedor;


class SubmitOnePrueba
{

//private $_contenedor;

    /*function __construct() {
      
	//$this->_contenedor = new Contenedor;
	//View::set('header',$this->_contenedor->header());
	//View::set('footer',$this->_contenedor->footer());
    }*/



    public function index() {

    }



    public function envioPruebaCampaign(){
        if (empty($_POST)) {
            MasterDom::alertas('error_general');
        }else{

            $campaign = "Prueba_".MasterDom::getData('campania');
            $mensaje = MasterDom::getData('mensaje');
            $carrierConnection = MasterDom::getData('carrierConnection');
            $carrierConnectionPost = $carrierConnection;
            $carrierConnection = unserialize(base64_decode($carrierConnection));
            //print_r($carrierConnection);

            $carrierIds = '';
                foreach($carrierConnection AS $value){
                    $carrierIds .= "$value,";
                }

            $carrierIds = rtrim($carrierIds, ",");
            $carrierIdsArray = CampaignDao::findCarriers($carrierIds);
            //print_r($carrierIdsArray);
            //echo "<br> Campaign: $campaign <br>";
            //echo "<br> Mensaje: $mensaje <br>";
            //print_r(MasterDom::getSession('customer_id'));
            $sembrados = CampaignDao::getSembrados(MasterDom::getSession('customer_id'));
            /*echo "---------->";
            print_r($sembrados);*/
            $fecha = date('Y-m-d G:m:s');
            $campaign_id = CampaignDao::insertaCampaniaIni($campaign,4,$fecha,3);
            if ($campaign_id > 0) {
                CampaignDao::insertaCampaniaCustomer(MasterDom::getSession('customer_id'),$campaign_id);
                CampaignDao::insertCampaignUser(MasterDom::getSession('id_user'),$campaign_id);
                foreach ($carrierIdsArray as $key => $value) {
                    CampaignDao::insertaCampaniaCarrierShortCode($campaign_id,$value['carrier_id'],$value['short_code_id']);
                    CampaignDao::insertaCarrierConnectionShortCodeCampaign($campaign_id,$value['carrier_connection_short_code_id']);
                }
                
            }else{
                MasterDom::alertas('error_general');
            }

            $msisdnPrueba = array();
            //echo "---------->>";           
            foreach ($sembrados as $key => $value) {
                
                foreach ($carrierIdsArray as $k => $val) {
                    
                    if ($value['name'] == "telcel" && $val['name'] == "telcel") {
                        array_push($msisdnPrueba,array( 'campaign_id'=>$campaign_id,
                                                        'msisdn_id'=>$value['msisdn_id'],
                                                        'content'=>$mensaje,
                                                        'carrier_connection_short_code_id'=>$val['carrier_connection_short_code_id']
                                                    )
                                );
                    }elseif ($value['name'] == "movistar" && $val['name'] == "movistar") {
                        array_push($msisdnPrueba,array( 'campaign_id'=>$campaign_id,
                                                        'msisdn_id'=>$value['msisdn_id'],
                                                        'content'=>$mensaje,
                                                        'carrier_connection_short_code_id'=>$val['carrier_connection_short_code_id']
                                                    )
                                );
                    }elseif ($value['name'] == "att" && $val['name'] == "att") {
                        array_push($msisdnPrueba,array( 'campaign_id'=>$campaign_id,
                                                        'msisdn_id'=>$value['msisdn_id'],
                                                        'content'=>$mensaje,
                                                        'carrier_connection_short_code_id'=>$val['carrier_connection_short_code_id']
                                                    )
                                );
                    } else {
                        array_push($msisdnPrueba,array( 'campaign_id'=>$campaign_id,
                                                        'msisdn_id'=>$value['msisdn_id'],
                                                        'content'=>$mensaje,
                                                        'carrier_connection_short_code_id'=>$val['carrier_connection_short_code_id']
                                                    )
                                );
                    }

                }

            }

            //print_r($msisdnPrueba);
            $insertados = false;
            foreach ($msisdnPrueba as $key => $value) {
                $sms_campaign_id = CampaignDao::insertSmsCampaign(
                                    $value['campaign_id'],
                                    $fecha,
                                    $value['msisdn_id'],
                                    $value['carrier_connection_short_code_id'],
                                    4,
                                    4,
                                    $value['content']);
                if ($sms_campaign_id > 0) {
                    $insertados = true;
                }else{
                    MasterDom::alertas('error_general');
                }
            }

            $html =<<<html
            <div>
                <h2>Prueba enviada!</h2>
            </div>
html;

            $html .=<<<html
            <div class="x_content">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Msisdn</th>
                            <th>Carrier</th>
                            <th>Identificador</th>
                            <th>Campa&ntilde;a</th>
                            <th>Mensaje</th>
                        </tr>
                    </thead>
                    <tbody>
html;

            foreach ($sembrados as $key => $value) {
                $html .=<<<html
                        <tr>
                            <td>{$value['msisdn_log']}</td>
                            <td>{$value['name']}</td>
                            <td>{$value['identificador']}</td>
                            <td>{$campaign}</td>
                            <td>{$mensaje}</td>
                        </tr>
html;
            }

            $html .=<<<html
                    </tbody>
                </table>
            </div>
html;
            
            if ($insertados) {
                echo $html;
            }

            /*
                    */

        }

        View::render("submit_one_add");
    }


}
