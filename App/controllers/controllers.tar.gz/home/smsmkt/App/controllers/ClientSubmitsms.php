<?php
//phpinfo();
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
/*
** Client Wsdl
** Esaú
*/
class ClientSubmitsms
{

	public function index()
	{
		try {
			/*echo "Hola";
			exit;*/

			ini_set("soap.wsdl_cache_enabled","0");

			$uri = "https://smsmkt.amovil.mx/wsdl/SubmitSms.wsdl";
			
			$uriServidor = "https://smsmkt.amovil.mx/wsdl/serverEsau.php";

			$clienteSOAP = new \SoapClient($uri, array(	'trace' => 1,
														'exceptions' => 1,
														'connection_timeout' => 2000,
														'ssl_method' => SOAP_SSL_METHOD_TLS)
											);

			$parametros = array(1=>2.1,2=>3.1);

			$location = array('location' => $uriServidor);

			print_r($clienteSOAP->__soapCall('sumar',$parametros,$location));

			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			/*print $this->_clienteSoap->__getLastRequestHeaders() . "\n";print $this->_clienteSoap->__getLastRequest() . "\n";print $this->_clienteSoap->__getLastResponse();*/
			//echo "--->";
			print_r($var);


		} catch (\SoapFault $e) {
			print_r($e);
		}
	}

}