<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//include '/usr/local/bin/vendor/autoload.php';

use \Core\View;
use \Core\MasterDom;
use \App\models\AdminReporte as AdminReporteDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class AdminReporte{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){

        $extraHeader=<<<html
    <!-- DataTables CSS -->
    <link href="../css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DateTimePicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

html;

        $extraFooter=<<<html
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <script>
    $(document).ready(function() {

        var anio = (new Date).getFullYear();

        $('#datetimepicker').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
        $('#datetimepicker1').datetimepicker({
                format: 'DD/MM/YYYY',
                minDate: "01/01/" + anio,
                //maxDate: moment(),
                daysOfWeekDisabled: [0, 6]
        });

        $("#datetimepicker").on("dp.change", function (e) {
                $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
        });
        $("#datetimepicker1").on("dp.change", function (e) {
                $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
        });

            var table = $('#reportes_admin').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "bLengthChange": false,
                        "searching": false,
                        "ordering": false,
                        "iDisplayLength": 20,
                        "ajax": {
                            "url": '/AdminReporte/datosJsonReporteTotal',
                            "dataType":'json'
                        },
                        "columns": [
                            { "data": "name_campaign" },
                            { "data": "modulo" },
                            { "data": "delivery_date" },
                            { "data": "name" },
                            { "data": "short_code" },
                            { "data": "total_mensajes" }
                        ],
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing": "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });
        });

        function actualizarDataTableSearch(){

            $("#reportes_admin").dataTable().fnDestroy();
            cambioCampaniaSearch();
        }

        function cambioCampaniaSearch(){

            var table2 = $('#reportes_admin').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "bLengthChange": false,
                        "searching": false,
                        "ordering": false,
                        "iDisplayLength": 20,
                        "ajax": {
                                    "url": '/AdminReporte/searchDate',
                                    "dataType":'json',
                                    "data": {
                                        fecha_ini: $("input:text[name=datetimepicker]").val(),
                                        fecha_fin: $("input:text[name=datetimepicker1]").val(),
                                        status: $("select[name=status]").val(),
                                        direction: $("select[name=direction]").val(),
                                        shortcode: $("select[name=shortcode]").val(),
                                        campania: $("select[name=campania]").val()
                                    }
                                },
                        "columns": [
                            { "data": "name_campaign" },
                            { "data": "modulo" },
                            { "data": "delivery_date" },
                            { "data": "name" },
                            { "data": "short_code" },
                            { "data": "total_mensajes" }
                        ],
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing":     "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });
        }

    </script>
html;
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');
        $id_user = MasterDom::getSession('id_user');

        $total_telcel = AdminReporteDao:: getTotalTelcel($id_custom);
        $total_movistar = AdminReporteDao:: getTotalMovistar($id_custom);
        $total_att = AdminReporteDao:: getTotalATT($id_custom);

        $tt=count($total_telcel);
        $tm=count($total_movistar);
        $tatt=count($total_att);

        $sCampaigns = '';
        $sShortCode = '';
        foreach (AdminReporteDao::getAllCampaign() as $key => $value) {
           $sCampaigns .=<<<html
           <option value="{$value['name_campaign']}">{$value['name_campaign']}</option>
html;
            $sShortCode .=<<<html
            <option value="{$value['short_code']}">{$value['short_code']}</option>
html;
        }

        $sStatus = '';
        foreach (AdminReporteDao::getCampaignStatus() as $key => $value) {
            $sStatus .=<<<html
            <option value="{$value['name']}">{$value['name']}</option>
html;
        }

        View::set('telcel',$tt);
        View::set('movi',$tm);
        View::set('att',$tatt);
        View::set('sCampaigns',$sCampaigns);
        View::set('sShortCode',$sShortCode);
        View::set('sStatus',$sStatus);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportesadmin");
    }

    public function datosJsonReporteTotal(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
        $row = AdminReporteDao::getTotalMessages();

        if(empty($row)){
            $recordsTotal = 0;
        }else{
            $recordsTotal = count(AdminReporteDao::getTotalMessages());
        }

            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotal, "recordsFiltered"=>$recordsTotal,"data"=>AdminReporteDao::getTotalMessagesCop($start, $length));
            echo json_encode($prueba);
    }

    public function searchDate(){

        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $status = MasterDom::getData('status');
            $campania = MasterDom::getData('campania');
            $direction = MasterDom::getData('direction');
            $shortcode = MasterDom::getData('shortcode');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);

            if(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearch($id_custom, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCop($id_custom, $start, $length, $fecha_ini, $fecha_fin));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampania($id_custom, $campania, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaCop($id_custom, $campania, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) &&empty($campania) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchShortcode($id_custom, $shortcode, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchShortcodeCop($id_custom, $shortcode, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($status) && empty($campania) &&empty($shortcode) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchStatus($id_custom, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchStatusCop($id_custom, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($direction) && empty($campania) &&empty($shortcode) && empty($status)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchDirection($id_custom, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchDirectionCop($id_custom, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaShortCode($id_custom, $campania, $shortcode, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeCop($id_custom, $campania, $shortcode, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($status) && empty($shortcode) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaStatus($id_custom, $campania, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaStatusCop($id_custom, $campania, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($direction) && empty($status) && empty($shortcode)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaDirection($id_custom, $campania, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaDirectionCop($id_custom, $campania, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) && !empty($status) && empty($campania) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchShortcodeStatus($id_custom, $shortcode, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchShortcodeStatusCop($id_custom, $shortcode, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) && !empty($direction) && empty($campania) && empty($status)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchShortcodeDirection($id_custom, $shortcode, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchShortcodeDirectionCop($id_custom, $shortcode, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeStatus($id_custom, $campania, $shortcode, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeStatusCop($id_custom, $campania, $shortcode, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($direction) && empty($status)) {

                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeDirection($id_custom, $campania, $shortcode, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeDirectionCop($id_custom, $campania, $shortcode, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeStatusDirection($id_custom, $campania, $shortcode, $status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchCampaniaShortCodeStatusDirectionCop($id_custom, $campania, $shortcode, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchStatusDirection($id_custom, $status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchStatusDirectionCop($id_custom, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && !empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(AdminReporteDao::getTotalMessagesSearchShorCodeStatusDirection($id_custom, $shortcode ,$status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalMessagesSearchShortCodeStatusDirectionCop($id_custom, $shortcode, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }

        }

    }

    public function mt(){
        MasterDom::verificaUsuario();

    $extraHeader=<<<html
    <!-- jQuery -->
    <!-- DataTables CSS -->
    <link href="/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DateTimePicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

    <!-- DataTable Reporte MT Principal -->
    <script>

        $(document).ready(function() {

            var anio = (new Date).getFullYear();

            $('#datetimepicker').datetimepicker({
                        format: 'YYYY-MM-DD',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
            $('#datetimepicker1').datetimepicker({
                    format: 'YYYY-MM-DD',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker").on("dp.change", function (e) {
                    $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker1").on("dp.change", function (e) {
                    $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
            });

            $('#datetimepicker2').datetimepicker({
                    format: 'YYYY-MM-DD',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
            $('#datetimepicker3').datetimepicker({
                    format: 'YYYY-MM-DD',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker2").on("dp.change", function (e) {
                    $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker3").on("dp.change", function (e) {
                    $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
            });

            $('#datetimepicker4').datetimepicker({
                    format: 'YYYY-MM-DD',
                    minDate: "01/01/" + anio,
                    maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
            $('#datetimepicker5').datetimepicker({
                    format: 'YYYY-MM-DD',
                    minDate: "01/01/" + anio,
                    maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker4").on("dp.change", function (e) {
                    $('#datetimepicker5').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker5").on("dp.change", function (e) {
                    $('#datetimepicker4').data("DateTimePicker").maxDate(e.date);
            });

             var table = $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonMT',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                "lengthMenu": "Mostrar _MENU_ registros",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        });

        function actualizarDataTable(){

            $("#reporte_mt").dataTable().fnDestroy();
            cambioCampania();
        }

        function cambioCampania(){

            var table2 = $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getData',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

    </script>
    <!-- Fin DataTable Reporte MT Principal -->

    <!-- DataTable Reporte MT por campaña y fecha -->
    <script>
        function muestraCalendario(){
            $('#calendario').show();
            $('#shorcode').hide();
            $("input:text[name=muestra1]").val("ok");
            $("input:text[name=muestra2]").val("cambio");
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shorcode').hide();
            $("input:text[name=muestra2]").val("ok");
            $("input:text[name=muestra1]").val("cambio");
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shorcode').show();
            $("input:text[name=muestra2]").val("cambio");
            $("input:text[name=muestra1]").val("cambio");
        }

        function actualizarDataTableCampaniaFecha(){
            $("#reporte_mt").dataTable().fnDestroy();
            muestraInfo()
        }

        function muestraInfo(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateMT',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

        <!-- Fin DataTable Reporte MT por campaña y fecha -->

        <!-- DataTable Reporte MT por fecha -->
        <script>

        function actualizarDataTableFecha(){
            $("#reporte_mt").dataTable().fnDestroy();
            muestraInfoDetalle()
        }

        function muestraInfoDetalle(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateMTFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

        <!-- Fin DataTable Reporte MT por fecha -->

        <!-- DataTable Search Report MT -->
        <script>

        function actualizarDataTableSearchReportMT(){

            $("#reporte_mt").dataTable().fnDestroy();
            var muestra1 = $("input:text[name=muestra1]").val();
            var muestra2 = $("input:text[name=muestra2]").val();
            //var c = $("input:text[name=fechas]").val();
            if(muestra1 == "ok"){
                cambioDataTableSearchReportMTFechas()
            } else if(muestra2 == "ok"){
                cambioDataTableSearchReportMTFechasAll()
            } else {
                cambioDataTableSearchReportMT()
            }

        }

        function cambioDataTableSearchReportMT(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/searchDateReportMT',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker4]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker5]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val(),
                                                 id_camp: $("#id_campania option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        function cambioDataTableSearchReportMTFechas(){
            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/searchDateReportMTCamFechas',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val(),
                                                 id_camp: $("#id_campania_1 option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }


        function cambioDataTableSearchReportMTFechasAll(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/searchDateReportMTFechas',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val()
                                                 //id_camp: $("#id_campania_1 option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Search Report MT -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#mtdetalle").validate({
                    rules: {
                        campania: {
                            required: true
                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;
        $id_custom = MasterDom::getSession('customer_id');
        $row = AdminReporteDao::getAllCampaign($id_custom);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name_campaign']." -- ".$value['short_code']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mt_admin");
    }

    public function datosJsonMT(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $search = MasterDom::getData('search');

        $value = MasterDom::getData('value');

        $row = AdminReporteDao::getAllCampaign();
        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        $recordsTotalFiltered = count(AdminReporteDao::reportMT($result));

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCop($result, $start, $length));

        echo json_encode($prueba);
    }

    public function searchDateReportMT(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);


            if (empty($id_campania)) {

                $row = AdminReporteDao::getAllCampaign($id_custom);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }

                if(empty($result)){
                    $result = 0;
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMT($result, $destination));

                    $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::getTotalSearchReporteMTCop($result, $destination, $start, $length));

                    echo json_encode($prueba);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierTotal($result, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCopCarrier($result, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopEstatusTotal($result, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTEstatus($result, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceTotal($result, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSource($result, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceEstatusTotal($result, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceEstatus($result, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierEstatusTotal($result, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierEstatus($result, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceTotal($result, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSource($result, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotal($result, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceEstatus($result, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationEstatusTotal($result, $destination, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationEstatus($result, $destination, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceTotal($result, $destination, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSource($result, $destination, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotal($result, $destination, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceEstatus($result, $destination, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierTotal($result, $destination, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrier($result, $destination, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotal($result, $destination, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierEstatus($result, $destination, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotal($result, $destination, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierSource($result, $destination, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopAllTotal($result, $destination, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTAll($result, $destination, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios sobre la campania actual
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(AdminReporteDao::reportMT($id_custom, $result));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCop($id_custom, $result, $start, $length));

                    echo json_encode($resultado);
                }



            }else/*if (!empty($id_campania))*/ {

                if(!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination

                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMT($id_campania, $destination));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCop($id_campania, $destination, $start, $length));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierTotal($id_campania, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCopCarrier($id_campania, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopEstatusTotal($id_campania, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTEstatus($id_campania, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceTotal($id_campania, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSource($id_campania, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceEstatusTotal($id_campania, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceEstatus($id_campania, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierEstatusTotal($id_campania, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierEstatus($id_campania, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceTotal($id_campania, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSource($id_campania, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotal($id_campania, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceEstatus($id_campania, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationEstatusTotal($id_campania, $destination, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationEstatus($id_campania, $destination, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceTotal($id_campania, $destination, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSource($id_campania, $destination, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotal($id_campania, $destination, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceEstatus($id_campania, $destination, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierTotal($id_campania, $destination, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrier($id_campania, $destination, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotal($id_campania, $destination, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierEstatus($id_campania, $destination, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotal($id_campania, $destination, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierSource($id_campania, $destination, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus

                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopAllTotal($id_campania, $destination, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTAll($id_campania, $destination, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(AdminReporteDao::reportMT($id_custom, $id_campania));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCop($id_custom, $id_campania, $start, $length));

                    echo json_encode($resultado);
                }

            }
        }

    }

    public function searchDateReportMTCamFechas(){

        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);


            if (empty($id_campania)) {

                $row = AdminReporteDao::getAllCampaign($id_custom);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }

                if(empty($result)){
                    $result = 0;
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCFechas($result, $destination, $fecha_ini, $fecha_fin));

                    $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::getTotalSearchReporteMTCopCFechas($result, $destination, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($prueba);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierTotalCFechas($result, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCopCarrierCFechas($result, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopEstatusTotalCFechas($result, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTEstatusCFechas($result, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceTotalCFechas($result, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceCFechas($result, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceEstatusTotalCFechas($result, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceEstatusCFechas($result, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierEstatusTotalCFechas($result, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierEstatusCFechas($result, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceTotalCFechas($result, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceCFechas($result, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotalCFechas($result, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceEstatusCFechas($result, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationEstatusTotalCFechas($result, $destination, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationEstatusCFechas($result, $destination, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceTotalCFechas($result, $destination, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceCFechas($result, $destination, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotalCFechas($result, $destination, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceEstatusCFechas($result, $destination, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierTotalCFechas($result, $destination, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierCFechas($result, $destination, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotalCFechas($result, $destination, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierEstatusCFechas($result, $destination, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotalCFechas($result, $destination, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierSourceCFechas($result, $destination, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopAllTotalCFechas($result, $destination, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTAllCFechas($result, $destination, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios sobre la campania actual
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(AdminReporteDao::reportMTCFechas($id_custom, $result, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCopCFechas($id_custom, $result, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }



            }else/*if (!empty($id_campania))*/ {

                if(!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination

                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCFechas($id_campania, $destination, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCopCFechas($id_campania, $destination, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierTotalCFechas($id_campania, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCopCarrierCFechas($id_campania, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopEstatusTotalCFechas($id_campania, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTEstatusCFechas($id_campania, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceTotalCFechas($id_campania, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceCFechas($id_campania, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopSourceEstatusTotalCFechas($id_campania, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTSourceEstatusCFechas($id_campania, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierEstatusTotalCFechas($id_campania, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierEstatusCFechas($id_campania, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceTotalCFechas($id_campania, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceCFechas($id_campania, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotalCFechas($id_campania, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTCarrierSourceEstatusCFechas($id_campania, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationEstatusTotalCFechas($id_campania, $destination, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationEstatusCFechas($id_campania, $destination, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceTotalCFechas($id_campania, $destination, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceCFechas($id_campania, $destination, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotalCFechas($id_campania, $destination, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationSourceEstatusCFechas($id_campania, $destination, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierTotalCFechas($id_campania, $destination, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierCFechas($id_campania, $destination, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotalCFechas($id_campania, $destination, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierEstatusCFechas($id_campania, $destination, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotalCFechas($id_campania, $destination, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTDestinationCarrierSourceCFechas($id_campania, $destination, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus

                    $recordsTotalFiltered = count(AdminReporteDao::getTotalSearchReporteMTCopAllTotalCFechas($id_campania, $destination, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::getTotalSearchReporteMTAllCFechas($id_campania, $destination, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(AdminReporteDao::reportMTCFechas($id_custom, $id_campania, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCopCFechas($id_custom, $id_campania, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }

            }
        }

    }


    public function reporte_mt(){
        # Reporte Excel
        //print_r($_GET);
        //exit;
        $cam1 = MasterDom::getData('muestra1');
        $cam2 = MasterDom::getData('muestra2');


        if ($cam1 == "cambiar" && $cam2 == "cambiar") {
            $id_campania = MasterDom::getData("reporte");
            $id_customer = MasterDom::getSession('customer_id');
            $destination = MasterDom::getData('destination');
            $carrier = MasterDom::getData('carrier');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');



            /*echo "<br>id:$id_campania<br>";
            echo "<br>destination:$destination<br>";
            echo "<br>carrier:$carrier<br>";
            echo "<br>source:$source<br>";
            echo "<br>estatus:$estatus<br>";
            echo "<br>customer:$id_customer<br>";

            exit;*/

            if (empty($id_campania)){
                /*$mensajes = AdminReporteDao::reportMT($id_customer, $result);
                $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                AdminReporteDao::registroUsuario($registro);*/
                $row = AdminReporteDao::getAllCampaign($id_customer);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }
                if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos los parametros vacios
                    $mensajes = AdminReporteDao::reportMTE($id_customer, $result);
                    //print_r($mensajes);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTEEstatus($id_customer, $result, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source excel campania actual
                    $mensajes = AdminReporteDao::reportMTESource($id_customer, $result, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTESourceEstatus($id_customer, $result, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier excel campania actual
                    $mensajes = AdminReporteDao::reportMTECarrier($id_customer, $result, $carrier);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTECarrierEstatus($id_customer, $result, $carrier, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source excel campania actual
                    $mensajes = AdminReporteDao::reportMTECarrierSource($id_customer, $result, $carrier, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTECarrierSourceEstatus($id_customer, $result, $carrier, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestination($id_customer, $result, $destination);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationEstatus($id_customer, $result, $destination, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationSource($id_customer, $result, $destination, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationSourceEstatus($id_customer, $result, $destination, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationCarrier($id_customer, $result, $destination, $carrier);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationCarrierEstatus($id_customer, $result, $destination, $carrier, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source excel campania actual
                    $mensajes = AdminReporteDao::reportMTEDestinationCarrierSource($id_customer, $result, $destination, $carrier, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Todos los campos/excel campania actual
                    $mensajes = AdminReporteDao::reportMTEAllSources($id_customer, $result, $destination, $carrier, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    AdminReporteDao::registroUsuario($registro);
                }

            }else{

                    /*$mensajes = AdminReporteDao::reportMTE($id_customer, $id_campania);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                    AdminReporteDao::registroUsuario($registro);*/
                    if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos los parametros vacios
                        $mensajes = AdminReporteDao::reportMTE($id_customer, $id_campania);
                        //print_r($mensajes);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTEEstatus($id_customer, $id_campania, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source excel campania actual
                        $mensajes = AdminReporteDao::reportMTESource($id_customer, $id_campania, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTESourceEstatus($id_customer, $id_campania, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier excel campania actual
                        $mensajes = AdminReporteDao::reportMTECarrier($id_customer, $id_campania, $carrier);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTECarrierEstatus($id_customer, $id_campania, $carrier, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source excel campania actual
                        $mensajes = AdminReporteDao::reportMTECarrierSource($id_customer, $id_campania, $carrier, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTECarrierSourceEstatus($id_customer, $id_campania, $carrier, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestination($id_customer, $id_campania, $destination);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationEstatus($id_customer, $id_campania, $destination, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationSource($id_customer, $id_campania, $destination, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationSourceEstatus($id_customer, $id_campania, $destination, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationCarrier($id_customer, $id_campania, $destination, $carrier);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationCarrierEstatus($id_customer, $id_campania, $destination, $carrier, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source excel campania actual
                        $mensajes = AdminReporteDao::reportMTEDestinationCarrierSource($id_customer, $id_campania, $destination, $carrier, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Todos los campos/excel campania actual
                        $mensajes = AdminReporteDao::reportMTEAllSources($id_customer, $id_campania, $destination, $carrier, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        AdminReporteDao::registroUsuario($registro);
                    }

                }
                //print_r($mensajes);
                $this->crearExcel($mensajes);
                exit;
        } // fin de if cambiar
        elseif ($cam1 == "ok") { // enviar a otra funcion de reportes campania y fechas
            self::reporte_mtDetalle();
        }
        elseif ($cam2 == "ok") { // envia a otra funcion de solo reportes por fechas
            self::reporte_mtDetalleFechas();
        }else{ // se sale de la funcion
            exit;
        }
       
    }


    public function mo(){
        MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

        <!-- DataTable Principal MO -->
        <script>

            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker1').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
                });

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });


                 var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonMO',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

            });

            function actualizarDataTableMO(){

                $("#reporte_mo").dataTable().fnDestroy();
                cambioCampaniaMO();
            }

            function cambioCampaniaMO(){

                var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonMO',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            }

        </script>
        <!-- Fin DataTable Principal MO -->
        <!-- DataTable Reporte MO por campaña y fecha -->
        <script>

        function muestraCalendario(){
            $('#calendario').show();
            $('#shorcode').hide();
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shorcode').hide();
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shorcode').show();
        }

        function actualizarDataTableCampaniaFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoMO()
        }

        function muestraInfoMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateMO',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>
        <!-- Fin DataTable Reporte MO por campaña y fecha -->

        <!-- DataTable Reporte MO por fecha -->
        <script>

        function actualizarDataTableFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoDetalleMO()
        }


        function muestraInfoDetalleMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateMOFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });


        }

        </script>

    <!-- Fin DataTable Reporte MO por fecha -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#modetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

            });
    });
    </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $row = AdminReporteDao::getAllCampaignMO($id_custom);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name']." -- ".$value['short_code']."</option>";
            //$select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mo");
    }

    public function datosJsonMO(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_custom = MasterDom::getSession('customer_id');
        /*$row = AdminReporteDao::getAllCampaignMO($id_custom);

        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }*/
        $id_campania = $_GET['id_camp'];
        
        if(empty($id_campania)){

            $recordsTotalFiltered = count(AdminReporteDao::reportMOTotal());

            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMOCopTotal($start, $length));
            print_r(json_encode($prueba));
            exit;

            //echo json_encode($prueba);
        } elseif(!empty($id_campania)){
            $recordsTotalFiltered = count(AdminReporteDao::reportMO($id_campania));
        
            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMOCop($id_campania, $start, $length));
        
            print_r(json_encode($prueba));
            exit;
            //echo json_encode($prueba);
        }
    }


    public function reporte_mo(){

        # Reporte Excel

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('reporte');
        $datos->_id_customer = MasterDom::getSession('customer_id');

        $row = AdminReporteDao::getAllCampaignMO($datos->_id_customer);
        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        if ($datos->_id_campaign == 0){
            $mensajes = AdminReporteDao::reportMO($datos->_id_customer, $result);
            $registro = $this->registroUsuario("Descargo reporte mo campania {$result}");
            AdminReporteDao::registroUsuario($registro);
        }else{
                $mensajes = AdminReporteDao::reportMOExcel($datos->_id_campaign,$datos->_id_customer);
                $registro = $this->registroUsuario("Descargo reporte mo campania {$datos->_id_campaign}");
                AdminReporteDao::registroUsuario($registro);
        }

        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_moDetalle(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker1');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = AdminReporteDao::reportMOExcelDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle campania {$datos->_id_campaign}");
        AdminReporteDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


        public function reporte_moDetalleFechas(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = AdminReporteDao::reportMOExcelDetalleFechaCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle por fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
        AdminReporteDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function getData(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('id_camp');

        $row = AdminReporteDao::getAllCampaign();

        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if($id_campania !=0){

            $recordsTotalFiltered = count(AdminReporteDao::getData($id_campania));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCop($id_campania, $start, $length));
            echo json_encode($mensajes);

        }else{

            $recordsTotalFiltered = count(AdminReporteDao::reportMT($result));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMTCop($result, $start, $length));
            echo json_encode($mensajes);

        }

    }

    public function getDataMO(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('reporte');
        $row = AdminReporteDao::getAllCampaignMO();

        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        if (!empty($id_campania)) {

            $recordsTotalFiltered = count(AdminReporteDao::reportMO($id_campania));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMOCop($id_campania, $start, $length));
            print_r(json_encode($mensajes));
            exit();
            //echo json_encode($mensajes);

        }/*else{

            $recordsTotalFiltered = count(AdminReporteDao::reportMO($id_custom, $result));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportMOCop($id_custom, $result, $start, $length));
            echo json_encode($mensajes);

        }*/

    }


    public function services(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

         <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker1').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
                });

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });


                var table = $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonService',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

            });

            function actualizarDataTableService(){

                $("#reporte_servicio").dataTable().fnDestroy();
                cambioCampaniaService();
            }

            function cambioCampaniaService(){

                var table = $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataServicesMO',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            }


        </script>

         <!-- Fin DataTable Reporte Principal Services -->

        <!-- DataTable Reporte Services por campaña y fecha -->

        <script>

        function muestraCalendario(){
            $('#calendario').show();
            $('#shortcode').hide();
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shortcode').hide();
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shortcode').show();
        }

        function actualizarDataTableCampaniaFechaServices(){

            $("#reporte_servicio").dataTable().fnDestroy();
            muestraInfoCampFechaServices()
        }


        function muestraInfoCampFechaServices(){

            $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateService',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

        }

        </script>

        <!-- Fin DataTable Reporte Services por campaña y fecha -->

        <!-- DataTable Reporte Services por fecha -->

        <script>

        function actualizarDataTableFechaServices(){

            $("#reporte_servicio").dataTable().fnDestroy();
            muestraInfoFechaServices()
        }


        function muestraInfoFechaServices(){

            $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataDateServiceFecha',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

        }

        </script>

    <!-- Fin DataTable Reporte Services por fecha -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $row = AdminReporteDao::getAllServiceMO($id_custom);

        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("services");
    }

    public function datosJsonService(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_custom = MasterDom::getSession('customer_id');

        $recordsTotalFiltered =AdminReporteDao::reportService($id);

        if(empty($recordsTotalFiltered)){
            $recordsTotalFiltered = 0;
        }else{
            $recordsTotalFiltered = count($recordsTotalFiltered);
        }

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::reportServiceCop($id, $start, $length));

        echo json_encode($prueba);
    }

    public function reporte_servicio(){

        # Reporte Excel


        if (MasterDom::getData('reporte') == 0){
            $mensajes = AdminReporteDao::reportService();
            $registro = $this->registroUsuario("Descargo reporte services");
            AdminReporteDao::registroUsuario($registro);
        }   else {

                $datos = new \stdClass();

                $datos->_id_service = MasterDom::getData('reporte');
                $datos->_id_customer = MasterDom::getSession('customer_id');

                // print_r($datos);

                $mensajes = AdminReporteDao::reportServiceExcel($datos);
                $registro = $this->registroUsuario("Descargo reporte service {$datos->_id_service}");
                AdminReporteDao::registroUsuario($registro);
            }
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>".substr($value['destination'], 0, 10)."</td>
                        <td>".substr($value['direction'], 0, 10)."</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_serviceDetalleFechas(){

        # Reporte Excel


       $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);


        $datos = new \stdClass();

        // $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

                // print_r($datos);

                $mensajes = AdminReporteDao::reportServiceExcelDetalleFechasCount($datos);
                $registro = $this->registroUsuario("Descargo reporte service fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
                AdminReporteDao::registroUsuario($registro);

        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');


        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>".substr($value['destination'], 0, 10)."</td>
                        <td>".substr($value['direction'], 0, 10)."</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_mtDetalle(){
      // print_r($_POST);
      // exit;


        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker');

        //$fecha_inicio = $this->formatoFecha($inicio);
        //$fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $inicio;
        $datos->_fecha_fin = $fin;

        $mensajes = AdminReporteDao::reportMTDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle {$datos->_id_campaign}");
        AdminReporteDao::registroUsuario($registro);
        //print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Enviados.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>CARRIER</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['FECHA']}</td>
                        <td>".$value['CARRIER']."</td>
                        <td>".substr($value['DESTINATION'], 0, 10)."</td>
                        <td>{$value['SHORTCODE']}</td>
                        <td>{$value['CONTENT']}</td>
                        <td>{$value['ESTATUSSMS']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


        public function reporte_mtDetalleFechas(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        // $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = AdminReporteDao::reportMTDetalleFechaCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mt fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
        AdminReporteDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Enviados.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>CARRIER</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['FECHA']}</td>
                        <td>".$value['CARRIER']."</td>
                        <td>".substr($value['DESTINATION'], 0, 10)."</td>
                        <td>{$value['SHORTCODE']}</td>
                        <td>{$value['CONTENT']}</td>
                        <td>{$value['ESTATUSSMS']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_serviceDetalle(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker1');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);


        $datos = new \stdClass();

        $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        // print_r($datos);

        $mensajes = AdminReporteDao::reportServiceExcelDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte service detalle {$datos}");
        AdminReporteDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios_Detalle.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function getDataServicesMO(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('id_camp');
        $id_custom = MasterDom::getSession('customer_id');

        $mensajes = AdminReporteDao::getDataService($id_campania, $id_custom);

        $recordsTotalFiltered = count(AdminReporteDao::getDataService($id_campania, $id_custom));
        $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::getDataServiceCop($id_campania, $id_custom, $start, $length));
        echo json_encode($mensajes);

    }


    public function getDataDateMO(){

        # Funcion que actulaiza los campos del reporte MO por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $id = MasterDom::getData('campania');
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_campaign = $id;
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(AdminReporteDao::reportMOExcelDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::reportMOExcelDetalle($consulta,$start,$length));
            echo json_encode($mensajes);

        }
    }


    public function getDataDateMOFecha(){

        # Funcion que actualiza los campos del reporte MO por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(AdminReporteDao::reportMOExcelDetalleFechaCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMOExcelDetalleFecha($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }


    public function getDataDateMT(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {
            header("Content-type: application/json; charset=utf-8");
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$fecha_inicio = $this->formatoFecha($inicio);
            //$fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_campaign = MasterDom::getData('campania');
            $consulta->_fecha_ini = MasterDom::getData('fecha_ini');
            $consulta->_fecha_fin = MasterDom::getData('fecha_fin');
            $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>AdminReporteDao::reportMTDetalle($consulta,$start,$length));
            echo json_encode($mensajes);
        }
    }


        public function getDataDateMTFecha(){

        # Funcion que actualiza los campos del reporte Mt por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFecha($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }

####################################### BUSQUEDA POR FECHAS Y PARAMETROS MT ###################################

        public function searchDateReportMTFechas(){

        # Funcion que busca los campos del reporte Mt por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');

            $fin = MasterDom::getData('fecha_fin');

            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;
            //print_r($consulta);
            $destination = MasterDom::getData('destination');
            $carrier = MasterDom::getData('carrier');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');

            if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCount($consulta));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFecha($consulta, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountEstatus($consulta, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaEstatus($consulta, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountSource($consulta, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaSource($consulta, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountSourceEstatus($consulta, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaSourceEstatus($consulta, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountCarrier($consulta, $carrier));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaCarrier($consulta, $carrier, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountCarrierEstatus($consulta, $carrier, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaCarrierEstatus($consulta, $carrier, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountCarrierSource($consulta, $carrier, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaCarrierSource($consulta, $carrier, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountCarrierSourceEstatus($consulta, $carrier, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaCarrierSourceEstatus($consulta, $carrier, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestination($consulta, $destination));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestination($consulta, $destination, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationEstatus($consulta, $destination, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationEstatus($consulta, $destination, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationSource($consulta, $destination, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationSource($consulta, $destination, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationSourceEstatus($consulta, $destination, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationSourceEstatus($consulta, $destination, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationCarrier($consulta, $destination, $carrier));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationCarrier($consulta, $destination, $carrier, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationCarrierEstatus($consulta, $destination, $carrier, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationCarrierEstatus($consulta, $destination, $carrier, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountDestinationCarrierSource($consulta, $destination, $carrier, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaDestinationCarrierSource($consulta, $destination, $carrier, $source, $start, $length));

                echo json_encode($mensajes);
            }
            else { # Destination & Carrier & Source & Estatus All
                $recordsTotalFiltered = count(AdminReporteDao::reportMTDetalleFechaCountAllSources($consulta, $destination, $carrier, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportMTDetalleFechaAllSources($consulta, $destination, $carrier, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }

        }
    }

####################################### FIN BUSQUEDA POR FECHAS Y PARAMETROS MT ###############################


        public function getDataDateService(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $id = MasterDom::getData('campania');
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_service = $id;
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(AdminReporteDao::reportServiceExcelDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportServiceExcelDetalle($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }


        public function getDataDateServiceFecha(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(AdminReporteDao::reportServiceExcelDetalleFechasCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = AdminReporteDao::reportServiceExcelDetalleFechas($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }

    public function smspush(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

         <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker2').datetimepicker({
                        format: 'YYYY-MM-DD',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'YYYY-MM-DD',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });

             var table = $("#reporte_smspush").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonPush',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "titulo" },
                                { "data": "mensaje" },
                                { "data": "tipo_mensaje" },
                                { "data": "delivery_date" },
                                { "data": "total" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            });
        </script>

        <!-- DataTable Reporte Campanias por fecha -->
        <script>

        function actualizarDataTablePush(){
            $("#reporte_smspush").dataTable().fnDestroy();
            muestraInfoPush();
        }


        function muestraInfoPush(){
            $("#reporte_smspush").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                "url": '/AdminReporte/datosJsonPush',
                                "dataType":'json',
                                "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                fecha_fin: $("input:text[name=datetimepicker3]").val()}
                            },
                            "columns": [
                                { "data": "titulo" },
                                { "data": "mensaje" },
                                { "data": "tipo_mensaje" },
                                { "data": "delivery_date" },
                                { "data": "total" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Reporte Campanias por fecha -->

    <script src="/js/magicsuggest-min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script> -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("smspush");
    }

    /*push*/
    public function datosJsonPush(){
        header("Content-type: application/json; charset=utf-8");
        $start = MasterDom::getData('start');
        $length = MasterDom::getData('length');
        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
        $inicio = MasterDom::getData('fecha_ini');
        $fin = MasterDom::getData('fecha_fin');

        $where = '';
        if($inicio!='' || $fin!=''){
            $where = ' WHERE ';
            $where .= ($inicio!='')? ' delivery_date >= \''.$inicio.'\'' : '';
            $where .= ($inicio!='' && $fin!='')? ' AND ' : '';
            $where .= ($fin!='')? ' delivery_date <= \''.$fin.'\'' : ''; 
        }

        $sms_push = AdminReporteDao::getSmsPush($start, $length, $where);

        foreach ($sms_push as $key => $value) {
            if($sms_push[$key]['tipo_mensaje']==1){
                $sms_push[$key]['tipo_mensaje'] = "General";
            }elseif($sms_push[$key]['tipo_mensaje']==2){
                $sms_push[$key]['tipo_mensaje'] = "Deposito";
            }elseif($sms_push[$key]['tipo_mensaje']==3){
                $sms_push[$key]['tipo_mensaje'] = "Transaccion";
            }
        }

        if (empty($sms_push)) {
            $recordsTotalFiltered = 0;
        } else{
            $recordsTotalFiltered = count($sms_push);
        }

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>$sms_push);
        echo json_encode($prueba);
    }


    public function campaniasall(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });

             var table = $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/datosJsonCampania',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            });
        </script>

        <!-- DataTable Reporte Campanias por fecha -->
        <script>

        function actualizarDataTableFechaCampanias(){

            $("#reporte_campania").dataTable().fnDestroy();
            muestraInfoDetalleCampania()
        }


        function muestraInfoDetalleCampania(){

            $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/AdminReporte/getDataCampaniasFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Reporte Campanias por fecha -->

    <script src="/js/magicsuggest-min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script> -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("campaniasall");
    }

    public function datosJsonCampania(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        if (empty(AdminReporteDao::getAllCampaniaByCustomer())) {

            $recordsTotalFiltered = 0;
        } else{
            $recordsTotalFiltered = count(AdminReporteDao::getAllCampaniaByCustomer());
        }

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::getAllCampaniaByCustomerCop($start, $length));
        
        echo json_encode($prueba);
    }


    public function getDataCampaniasFecha(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');

            //$fecha_inicio = $this->formatoFechaReporte($inicio);
            //$fecha_fin = $this->formatoFechaFinReporte($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $inicio;
            $consulta->_fecha_fin = $fin;

            if (empty(AdminReporteDao::getAllCampaniaByCustomerFechas($consulta))) {
                $recordsTotalFiltered = 0;
            }else {
                $recordsTotalFiltered = count(AdminReporteDao::getAllCampaniaByCustomerFechas($consulta));
            }

            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>AdminReporteDao::getAllCampaniaByCustomerFechasCop($consulta, $start, $length));
                echo json_encode($mensajes);
        }
    }


        public function reporte_campaniasFecha(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        if(empty(AdminReporteDao::getAllCampaniaByCustomerFechas($datos))){
            $mensajes = AdminReporteDao::getAllCampaniaByCustomer($datos->_id_customer = MasterDom::getSession('customer_id'));
            $registro = $this->registroUsuario("Descargo reporte campanias {$datos->_id_customer}");
            AdminReporteDao::registroUsuario($registro);
        }else{
            $mensajes = AdminReporteDao::getAllCampaniaByCustomerFechas($datos);
            $registro = $this->registroUsuario("Descargo reporte campanias detalle {$datos}");
            AdminReporteDao::registroUsuario($registro);
        }

        //print_r($mensajes);
        //exit();

        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Campanias_Detalle.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
        header('Cache-Control: max-age=1');
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>CAMPA&Ntilde;A</th>
                     <th bgcolor = '#AAB7B8'>FECHA DE CREACI&Oacute;N</th>
                     <th bgcolor = '#AAB7B8'>FECHA DE ENV&Iacute;O</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['campania']}</td>
                        <td>".$value['created']."</td>
                        <td>{$value['delivery_date']}</td>
                        <td>{$value['estatus']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }

    public function formatoFecha($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia;//.' '.'00:00:00';
        // return $fecha.' '.'00:00:00';
    }
      public function formatoFechaFin($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia;//.' '.'23:59:59';
        // return $fecha.' '.'00:00:00';
    }

    public function formatoFechaReporte($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia.' '.'00:00:00';
        // return $fecha.' '.'00:00:00';
    }

    public function formatoFechaFinReporte($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia.' '.'23:59:59';
        // return $fecha.' '.'00:00:00';
    }


    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

    public static function crearExcel($mensajes){
        $encabezado = array('FECHA','CARRIER','DESTINATION','SHORTCODE','CONTENT','ESTATUSSMS');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }

}
