<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Listaclient as ListaclientDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Listaclient {

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader=<<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
        <!-- DataTables JavaScript -->
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {

            var table = $('#muestra-client').DataTable({
                "language": {
                                    "emptyTable": "No hay datos disponibles",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                    "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                    "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                    "lengthMenu": "Mostrar _MENU_ registros",
                                    "zeroRecords":  "No se encontraron resultados",
                                    "search": "Buscar:",
                                    "processing": "Procesando...",
                                    "paginate" : {
                                        "next": "Siguiente",
                                        "previous" : "Anterior"
                                    }
                                }
            });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                    bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                        if (result) 
                            $( "#delete_form" ).submit();
                    });
            });
        } );
        </script>
html;

    $datos = ListaclientDao::getAll();
    $html = "";
    foreach ($datos as $key => $value) {
        
        if ($value['estatus'] == 1) {
            $estatus = "Activo";
        } elseif ($value['estatus'] == 0) {
            $estatus = "Inactivo";
        }

        $html.= <<<html
        <tr>
            <td><input type="checkbox" name="borrar[]" value="{$value['client_list_id']}"/></td>
            <td>{$value['key_santander']}</td>
            <td>{$value['msisdn']}</td>
            <td>{$value['mail']}</td>
            <td>{$value['so_device']}</td>
            <td>{$value['token_device']}</td>
            <td>{$estatus}</td>
            <td>
                <table id="muestra-accion">
                    <thead>
                        <tr>
                            <th>Editar</th>
                            <th>Ver reporte</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>
                        <a href="/listaclient/edit/
html;
        $html.= 
                                            MasterDom::setParamSecure($value['client_list_id'])
;
        $html.= <<<html
                                            " type="button" class="btn btn-primary btn-circle center-block" title="Editar"><i class="fa fa-pencil-square-o"></i></a>
                        
                        </td>
                        <td>
                        <a href="/reporteclient/
html;
$html.= 
                                            MasterDom::setParamSecure($value['msisdn'])
;
        $html.= <<<html
                                             " type="button" class="btn btn-warning btn-circle center-block" title="Ver detalle"><i class="fa fa-file-text-o" aria-hidden="true"></i></a>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
html;
    }

    View::set('table',$html);
    View::set('header',$this->_contenedor->header($extraHeader));
    View::set('footer',$this->_contenedor->footer($extraFooter));
  	View::render("listaclient");    
    }


    public function generarExcel($client_id){
        $row = ClientDao::getMsisdnBusca($client_id);
        $mensajes = array();

        foreach ($row as $key => $value) {
            switch($value['carrier_id']){
                case 1: 
                    $value['carrier_id'] = 'Telcel';
                    break;
                case 2:
                    $value['carrier_id'] = 'Movistar';
                    break;
                case 3:
                    $value['carrier_id'] = 'ATT';
                    break;
                default:
                    $value['carrier_id'] = 'Sin Carrier';
            }

            array_push($mensajes, array(0=>$value['msisdn'], 1=> $value['carrier_id']));
        }

        Client::crearExcel($mensajes);

    }

    public static function crearExcel($mensajes){
        $encabezado = array('MSISDN','CARRIER');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }

    public function add(){
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');
        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#add").validate({
            rules: {
                key_santander: {
                    required: true
                },
                msisdn: {
                    required:true,
                    maxlength: 10,
                    minlength: 10
                },
                mail: {
                    required:true
                },
                so_device: {
                    required:true
                },
                token_device: {
                    required:true
                },
                estatus: {
                    required:true
                }
            },
            messages: {
                key_santander: "Este campo es obligatorio",

                msisdn: {
                    required: "Este campo es obligatorio",
                    maxlength: "Solo se permite 10 digitos",
                    minlength: "Solo se permite 10 digitos"
                },

                mail: "Este campo es obligatorio",

                so_device: "Eliga una opcion",

                token_device: "Este campo es obligatorio",

                estatus: "Eliga una opcion"
            }
    });
});
</script>
html;
        $so_device = "<option value='' >Seleccione Tipo Dispositivo</option>";
        foreach (array('ANDROID' => 'ANDROID', 'IOS' => 'IOS') as $key => $value) {
            $so_device .= "<option value=\"$key\" >$value</option>";
        }

        $estatus = "<option value='' >Seleccione Estatus</option>";
        foreach (array(0 =>'Inactivo',1=>'Activo') as $key => $value) {
            $estatus .= "<option value=\"$key\" >$value</option>";
        }
        View::set('so_device',$so_device);
        View::set('estatus',$estatus);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("client_list_add");
    }

    public function add_client(){

        $client = new \stdClass();
        $client->_key_santander =       MasterDom::getData('key_santander');
        $client->_msisdn =              "52".MasterDom::getData('msisdn');
        $client->_mail =                MasterDom::getData('mail');
        $client->_so_device =           MasterDom::getData('so_device');
        $client->_token_device =        MasterDom::getData('token_device');
        $client->_estatus =             MasterDom::getData('estatus');

        // Buscamos y si encontramos mandamos a edit
        $client_list_id = ListaclientDao::buscaKey(MasterDom::getData('key_santander'));

        if (!empty($client_list_id)) {
            $clien_existe =$client_list_id[0]['client_list_id'];
        }
        

        if ( $clien_existe != "") {
/*
            $html =<<<html
<div class="alert alert-warning alert-dismissible fade in" role="alert" style="color: black;">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
    <strong>Key Santander ya Existe!</strong>
    Se redirigir&aacute; a editarlo en 5 segundos..
</div>
html;

            View::set('key_santander_existe',$html);
            View::render("client_list_add");

            sleep(5);*/

            header("Location:/listaclient/edit/".MasterDom::setParamSecure($client_list_id[0]['client_list_id']));

        }else{

            $addClient = ListaclientDao::insert($client);

            if ($addClient == '')
            return $this->alertas('error general');

            if ($addClient > 0) {
                /**************************** Registro *************************/
                $registro = $this->registroUsuario("Agrego client_list: {$addClient}");
                ListaclientDao::registroUsuario($registro);
                /***************************************************************/
                return $this->alertas('success_add');
            }
            
             

        }
        
            
    }

    public function edit($id){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#edit").validate({
            rules: {
                key_santander: {
                    required: true
                },
                msisdn: {
                    required:true
                },
                mail: {
                    required:true
                },
                so_device: {
                    required:true
                },
                token_device: {
                    required:true
                },
                estatus: {
                    required:true
                }
            },
            messages: {
                key_santander: "Este campo es obligatorio",

                msisdn: "Este campo es obligatorio",

                mail: "Este campo es obligatorio",

                so_device: "Eliga una opcion",

                token_device: "Este campo es obligatorio",

                estatus: "Eliga una opcion"
            }
    });
});
</script>
html;

        $id_list = MasterDom::getParamSecure($id);
        
        $client = ListaclientDao::getById($id_list);
        $dataClient = (object)$client;

        $tipo = array(  'ANDROID'   => 'ANDROID',
                        'IOS'       => 'IOS');

        $so_device = "";
        foreach ($tipo as $key => $value) {

            if (strtoupper($dataClient->so_device) == $value) {
                $so_device .= "<option value=\"$key\" selected=\"selected\">$value</option>";
            }elseif (strtoupper($dataClient->so_device) == $value) {
                $so_device .= "<option value=\"$key\" selected=\"selected\">{$value}</option>";
            }else{
                $so_device .= "<option value=\"$key\" >$value</option>";
            }

        }

        $status = array(1 => 'Activo',
                        0 => 'Inactivo');
        $estatus = "";
        foreach ($status as $key => $value) {

            if (strtoupper($dataClient->estatus) == $key) {
                $estatus .= "<option value=\"$key\" selected=\"selected\">$value</option>";
            }elseif (strtoupper($dataClient->estatus) == $key) {
                $estatus .= "<option value=\"$key\" selected=\"selected\">{$value}</option>";
            }else{
                $estatus .= "<option value=\"$key\" >$value</option>";
            }
            
        }
        

        View::set('Cliente',$dataClient);
        View::set('so_device',$so_device);
        View::set('estatus',$estatus);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("client_list_edit");
    }

    public function edit_client(){
        MasterDom::verificaUsuario();

        $client = new \stdClass();
        $client->_key_santander =   MasterDom::getData('key_santander');
        $client->_msisdn =          "52".MasterDom::getData('msisdn');
        $client->_mail =            MasterDom::getData('mail');
        $client->_so_device =       MasterDom::getData('so_device');
        $client->_token_device =     MasterDom::getData('token_device');
        $client->_estatus =          MasterDom::getData('estatus');
        $client->_client_list_id =   MasterDom::getData('client_list_id');

        $editclient = ListaclientDao::update($client);

        if ($editclient === FALSE) 
            return $this->alertas('error_general');

        if ($editclient != "") {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Edito lista client id:{$editclient}");
            ListaclientDao::registroUsuario($registro);
            /***************************************************************/
        }

         return $this->alertas('success_edit');

        
        
    }

    public function delete($id){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(ClientDao::delete($id) === false)
                return $this->alertas('error_borrar');

            if ($id != "") {
                /**************************** Registro *************************/
                $registro = $this->registroUsuario("Elimino client {$id}");
                ClientDao::registroUsuario($registro);
                /***************************************************************/
            }

        }

        return $this->alertas('success_delete');
        
    }


    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borr&oacute; con exito las bases seleccionadas.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con &eacute;xito.';
            $class = 'success';
        }elseif($caso == 'success_process') {
            $mensaje = 'Proceso finalizado correctamente';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/listaclient');
        View::set('class', $class);
        View::set('titulo','Agenda general');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    public function seleccionaCliente($id_cliente){

     $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {

            $('.btn-success').on("click",function() {
                var file = $("input[name$='file']").val();
                if(file != ""){
                    var respuesta = confirm('Desea importar a la agenda');
                    if (respuesta){
                        $( "#add" ).submit();
                    }
                }else{
                    alert('Seleccione una plantilla');
                }
            });
        });
    </script>
html;

    $customer = MasterDom::getSession('customer_id');
    if(empty($customer))
        return MasterDom::alertas('error_general');

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Importar Contactos</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                <div class="x_content">
                    <!--p>Seleccione la opción deseada para definir los Contacto que se utilizaran en la realizaci&oacute;n del env&iacute;o.</p-->
                    <div class="ln_solid"></div>
                        <form id="add" action="/listaclient/seleccionaClientePost" enctype="multipart/form-data" method="POST">
                            <div class="form-group">
                                <div class="radio">
                                    <br >
                                    <input type="file" accept=".xls,.xlsx,.txt,.csv" name="file"/>
                                    <p class="help-block">Importar un archivo excel, te recomendamos usar la siguiente plantilla, los formatos validos son .xls, .xlsx</p>
                                    <p class="help-block"><a href='/plantillas/Plantilla_Agenda.xlsx'><i class="fa fa-file-excel-o"></i> Descarga plantilla</a></p>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                                <input type="hidden" name='id_cliente' value="$id_cliente">
                            <div class="form-group">
                                <div class="col-md-12 col-sm-9 col-xs-12">
                                    <a href="#" class="btn btn-success pull-right">Siguiente</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
html;

    View::set('contenido',$html);
    View::set('footer',$this->_contenedor->footer($extraFooter));
    View::render("base_add");
    }

    public function seleccionaClientePost(){
        $id_cliente = MasterDom::getData('id_cliente');
        $file = $_FILES['file'];
        
        if(empty($file))
            return MasterDom::alertas('error_general');
            
        $filename = $file['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);

        if(strtolower($ext) ==  'xls' || strtolower($ext) == 'xlsx' || strtolower($ext) == 'csv' || strtolower($ext) == 'zip' || strtolower($ext) == 'txt')
            return $this->functionExcel($file, $ext, $id_cliente);
        else
            return MasterDom::alertas('error_general');
    }

    private function functionExcel($file, $ext, $id_cliente){

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $ext = strtolower($ext);
        $archivo = MasterDom::moverDirectorio($file, $customer, 'book');
    
        if($archivo === false)
            return MasterDom::alertas('error_general');

        if($ext ==  'xls' || $ext == 'xlsx'){   

            $excel = MasterDom::procesoExcel('getFilas', $archivo['nombre']);
            $excelArray = json_decode($excel, 1);

            //print_r($excelArray);

            if(empty($excelArray))
                return MasterDom::alertas('personal','/listaclient/seleccionaClientePost', 'Error', 'Se cancel&oacute; el proceso, el documento est&aacute; vac&iacute;o.');

            foreach($excelArray AS $key=>$value){
                if($value != '')
                    $array[$key] = $value;
            }
            $file_name = $archivo['nombre'];
        }

        elseif($ext == 'csv'){
            $arch = MasterDom::$_target.$archivo['nombre'];
            $acum = 1;
            if (($fichero = fopen($arch, "r")) !== FALSE) {
                while (($datos = fgetcsv($fichero)) !== FALSE) {
                    if($acum == 1){
                        $array = $datos;
                        //print_r($array);
                        break;
                    }
                 $acum += 1;
                }
              fclose($fichero);
              $file_name = $archivo['nombre'];
            }else{
                return MasterDom::alertas('error_general');
            }
        }else{
            return MasterDom::alertas('personal','/listaclient/', 'Error', 'Lo sentimos, ocurri&oacute; un error, el formato del archivo no es v&aacute;lido.');
        }


       

    $keysanta = '';
    $celular = '';
    $correo = '';
    $os_device = '';
    $token_device = '';
    //print_r($array);
        foreach($array AS $key=>$value){
            $select = '';
        
            if ($key == "A"){
                $select = 'selected="selected"';
                $keysanta.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{

                $keysanta.=<<<html
                    <option value="$key" $select >$value</option>
html;

            }

            if ($key == "B"){
                $select = 'selected="selected"';
                $celular.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{

                $celular.=<<<html
                    <option value="$key" $select >$value</option>
html;

            }

            if($key == "C"){
                        $select = 'selected="selected"';
                        $correo.=<<<html
                            <option value="$key" $select >$value</option>
html;
            } else{

                $correo.=<<<html
                    <option value="$key" $select >$value</option>
html;

            }

            if($key == "D"){
                        $select = 'selected="selected"';
                        $os_device.=<<<html
                            <option value="$key" $select >$value</option>
html;
            }else{

                $os_device.=<<<html
                    <option value="$key" $select >$value</option>
html;

            }

            if($key == "E"){
                        $select = 'selected="selected"';
                        $token_device.=<<<html
                            <option value="$key" $select >$value</option>
html;
            }else{

                $token_device.=<<<html
                    <option value="$key" $select >$value</option>
html;

            }

        }

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Selecci&oacute;n  de columnas para importar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla deber&aacute; seleccionar la columna del excel que contiene los datos de los clientes...</p>
                    <div class="ln_solid"></div>
                    <form action="/listaclient/guardaDatos" enctype="multipart/form-data" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione Columna que contiene "Key Santander" : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_key_santander">
                                    $keysanta
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al n&uacute;mero de celular :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_numero">
                                    $celular
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al correo :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_mail">
                                    $correo
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al tipo de dispositivo :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_so_device">
                                    $os_device
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al token del dispositivo :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_token_device">
                                    $token_device
                                </select>
                            </div>
                        </div>

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="ext" value="$ext" />
                        <input type="hidden" name="nombre_archivo" value="{$file_name}" />
                        <input type="hidden" name="customer_id" value="$customer" />
                        <input type='hidden' name='id_cliente' value="$id_cliente" />
                      </form>
                  </div>
                </div>
html;

        View::set('contenido',$html);
        View::render("submit_one_add");
    
    }

    public function guardaDatos(){
        $nombreArchivo = MasterDom::getData('nombre_archivo');
        $msisdnArray = json_decode(MasterDom::procesoExcel('completeArray', $nombreArchivo, true),1);

        $total_registros= count($msisdnArray) -1;
        $numeros_validos = 0;
        $numeros_invalidos = 0;

        //print_r($msisdnArray);
        //echo "-->\n";

        foreach ($msisdnArray as $key => $value) {
            if ($key == 1) {
                continue;
            }

            $dataList = new \stdClass;
            $dataList->_key_santander = $value['A'];
            $dataList->_msisdn = "52".$value['B'];
            $dataList->_mail = $value['C'];
            $dataList->_os_device = $value['D'];
            $dataList->_token_device = $value['E'];
            $dataList->_estatus = 1;

            //print_r($dataList);

            // Buscamos si el key de santander no existe para poder insertarlo
            //$client_list_id = ListaclientDao::buscaKey($dataList->_key_santander);
            /*
            if (empty(ListaclientDao::buscaKey($dataList->_key_santander))) {
                $new_client_list_id = ListaclientDao::insertClients($dataList);            
                if ($new_client_list_id > 0) {
                    $numeros_validos++;
                }else{
                    $numeros_invalidos ++;
                }
            }else{
                $numeros_invalidos ++;
            }*/
            $new_client_list_id = ListaclientDao::insertClients($dataList);            
            if (!empty($new_client_list_id)) {
                $numeros_validos++;
            }else{
                $numeros_invalidos++;
            }
        

        }
        //exit;
        if ($numeros_validos > 0) {
            $botonFinalizar =<<<html
        <input type="submit" class="btn btn-success pull-right" value="Finalizar Proceso">
html;

        }else{
            $botonFinalizar =<<<html
        <a type="button" class="btn btn-danger pull-right" value="Salir" href="/listaclient" >Salir</a>
html;
        }
        


        $html=<<<html
            <form action="/listaclient/mensaje" method="POST">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripcion</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Total de Contactos :</td>
                          <td>$total_registros</td>
                        </tr>
                        <tr>
                          <td>Contactos con mismo key actualizados correctamente :</td>
                          <td>$numeros_validos</td>
                        </tr>
                        <tr>
                          <td>Contactos key ya existente :</td>
                          <td>$numeros_invalidos</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                          $botonFinalizar
                          </div>
                    </div>
                </div>
              </div>
        </form>
html;

        View::set('contenido',$html);
        View::render("detalle_client");
    }

    public function mensaje(){
        
        return $this->alertas('success_process');
    }

    function registroUsuario($accion){

        $id_usuario = $_SESSION['id_user'];
        $nickname = $_SESSION['usuario'];
        $customer = $_SESSION['name_customer'];
        $script = explode("/",$_SERVER["REQUEST_URI"]);
        $ip = $_SERVER['REMOTE_ADDR'];
        $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

        $registro = new \stdClass;
        $registro->_id_usuario = $id_usuario;
        $registro->_nickname = $nickname;
        $registro->_customer = $customer;
        $registro->_script = $script[1];
        $registro->_ip = $ip;
        $registro->_modulo = $modulo;
        $registro->_accion = $accion;
          
        return $registro;

    }

}