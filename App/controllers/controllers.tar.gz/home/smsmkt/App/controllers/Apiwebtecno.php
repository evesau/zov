<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Dinamicweb as DinamicwebDao;
use \App\controllers\Contenedor;
use \App\controllers\ApiUrl;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Apiwebtecno {

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index(){   
        header("Location: menu");
    }


    public function generarExcel($client_id){
        $row = ClientDao::getMsisdnBusca($client_id);
        $mensajes = array();

        foreach ($row as $key => $value) {
            switch($value['carrier_id']){
                case 1: 
                    $value['carrier_id'] = 'Telcel';
                    break;
                case 2:
                    $value['carrier_id'] = 'Movistar';
                    break;
                case 3:
                    $value['carrier_id'] = 'ATT';
                    break;
                default:
                    $value['carrier_id'] = 'Sin Carrier';
            }

            array_push($mensajes, array(0=>$value['msisdn'], 1=> $value['carrier_id']));
        }

        Client::crearExcel($mensajes);

    }

    public static function crearExcel($mensajes){
        $encabezado = array('MSISDN','CARRIER');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }

    public function add(){
        header("Location: menu");
    }

    public function add_client(){
        header("Location: menu");
    }

    public function edit($id){
        header("Location: menu");
    }

    public function edit_client(){
        header("Location: menu");
    }

    public function delete($id){
        header("Location: menu");
    }


    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borr&oacute; con exito las bases seleccionadas.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con &eacute;xito.';
            $class = 'success';
        }elseif($caso == 'success_process') {
            $mensaje = 'Proceso finalizado correctamente';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/apiwebtecno/seleccionaCliente');
        View::set('class', $class);
        View::set('titulo','Dinamic web');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    public function seleccionaCliente($id_cliente){

     $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {

            $('.btn-success').on("click",function() {
                var file = $("input[name$='file']").val();
                if(file != ""){
                    var respuesta = confirm('Comfirme para importar la plantilla');
                    if (respuesta){
                        $( "#add" ).submit();
                    }
                }else{
                    alert('Seleccione una plantilla');
                }
            });
        });
    </script>
html;

    $customer = MasterDom::getSession('customer_id');
    if(empty($customer))
        return MasterDom::alertas('error_general');

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Importar Contactos para envio con api de Tecnophone</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                <div class="x_content">
                    <p>Seleccione un archivo Plantilla que se utilizar&aacute; en la realizaci&oacute;n del env&iacute;o.</p>
                    <div class="ln_solid"></div>
                        <form id="add" action="/apiwebtecno/seleccionaClientePost" enctype="multipart/form-data" method="POST">
                            <div class="form-group">
                                <div class="radio">
                                    <br >
                                    <input type="file" accept=".xls,.xlsx,.txt,.csv" name="file"/>
                                    <p class="help-block">Importar un archivo excel, te recomendamos usar la siguiente plantilla, los formatos validos son .xls, .xlsx</p>
                                    <p class="help-block"><a href='/plantillas/Plantilla_Webdinamica.xlsx'><i class="fa fa-file-excel-o"></i> Descarga plantilla</a></p>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                                
                            <div class="form-group">
                                <div class="col-md-12 col-sm-9 col-xs-12">
                                    <a href="/apiwebtecno" class="btn btn-danger pull-left">Cancelar</a>
                                    <a href="#" class="btn btn-success pull-right">Siguiente</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
html;

    View::set('contenido',$html);
    View::set('footer',$this->_contenedor->footer($extraFooter));
    View::render("base_add");
    }

    public function seleccionaClientePost(){
        
        $file = $_FILES['file'];
        
        if(empty($file))
            return MasterDom::alertas('personal','/apiwebtecno/seleccionaCliente','Error','Se cancelo el proceso, no se selecciono ningun documento');
            
        $filename = $file['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);

        if(strtolower($ext) ==  'xls' || strtolower($ext) == 'xlsx' || strtolower($ext) == 'csv' || strtolower($ext) == 'zip' || strtolower($ext) == 'txt')
            return $this->functionExcel($file, $ext);
        else
            return MasterDom::alertas('error_general');
    }

    private function functionExcel($file, $ext){

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $ext = strtolower($ext);
        $archivo = MasterDom::moverDirectorio($file, $customer, 'book');
    
        if($archivo === false)
            return MasterDom::alertas('error_general');

        if($ext ==  'xls' || $ext == 'xlsx'){   

            $excel = MasterDom::procesoExcel('getFilas', $archivo['nombre']);
            $excelArray = json_decode($excel, 1);

            //print_r($excelArray);
            //exit;

            if(empty($excelArray))
                return MasterDom::alertas('personal','/apiwebtecno/seleccionaCliente', 'Error', 'Se cancel&oacute; el proceso, el documento est&aacute; vac&iacute;o.');

            foreach($excelArray AS $key=>$value){
                if($value != '')
                    $array[$key] = $value;
            }
            $file_name = $archivo['nombre'];
        }

        elseif($ext == 'csv'){
            $arch = MasterDom::$_target.$archivo['nombre'];
            $acum = 1;
            if (($fichero = fopen($arch, "r")) !== FALSE) {
                while (($datos = fgetcsv($fichero)) !== FALSE) {
                    if($acum == 1){
                        $array = $datos;
                        //print_r($array);
                        break;
                    }
                 $acum += 1;
                }
              fclose($fichero);
              $file_name = $archivo['nombre'];
            }else{
                return MasterDom::alertas('error_general');
            }
        }else{
            return MasterDom::alertas('personal','/apiwebtecno/seleccionaCliente', 'Error', 'Lo sentimos, ocurri&oacute; un error, el formato del archivo no es v&aacute;lido.');
        }

        /*print_r($array);
    $captureColumna = array(1 => 'NUMERO',
                            2 => 'MSISDN',
                            3 => 'CELULAR',
                            4 => 'MENSAJE',
                            5 => 'TEXTO',
                            6 => 'CONTENIDO',
                            7 => 'CARRIER',
                            8 => 'COMPANIA',
                            9 => 'OPERADOR');
    print_r($captureColumna);
    foreach ($captureColumna as $key => $value) {
        echo strtoupper($value)."<br>";
        $busca = strtoupper($value);
        foreach ($array as $key => $valor) {
            echo "-->".strtoupper($valor)."<br>";
            if (preg_match("/$busca/", strtoupper($valor))) {
                continue;
            }else{
                return MasterDom::alertas('personal','/apiwebtecno/seleccionaCliente','Error',"Lo sentimos, ocurri&oacute un error, la columna {$value} tiene un nombre incorrecto!");
            }
        }
    }*/


    $c_celular = '';
    $c_mensaje = '';
    $c_compania = '';
    $c_url = '';
    //echo "-->";
    //exit;
        foreach($array AS $key=>$value){
            $select = '';

            if ($key == "A"){
                $select = 'selected="selected"';
                $c_celular.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{
                $c_celular.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }

            if ($key == "B"){
                $select = 'selected="selected"';
                $c_mensaje.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{
                $c_mensaje.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }

            if ($key == "C"){
                $select = 'selected="selected"';
                $c_compania.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{
                $c_compania.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }

            /*if ($key == "D"){
                $select = 'selected="selected"';
                $c_url.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }else{
                $c_url.=<<<html
                    <option value="$key" $select >$value</option>
html;
            }*/

        }

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Selecci&oacute;n  de columnas para importar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla deber&aacute; seleccionar la columna del excel que contiene los datos de los clientes...</p>
                    <div class="ln_solid"></div>
                    <form action="/apiwebtecno/guardaDatos" enctype="multipart/form-data" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al n&uacute;mero de celular :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_numero">
                                    $c_celular
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al mensaje :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_mensaje">
                                    $c_mensaje
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente a la compania celular :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_compania">
                                    $c_compania
                                </select>
                            </div>
                        </div>
                        <!--div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente a la URL :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_url">
                                    $c_url
                                </select>
                            </div>
                        </div-->

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="ext" value="$ext" />
                        <input type="hidden" name="nombre_archivo" value="{$file_name}" />
                        <input type="hidden" name="customer_id" value="$customer" />
                      </form>
                  </div>
                </div>
html;

        View::set('contenido',$html);
        View::render("submit_one_add");
    
    }

    public function guardaDatos(){
        $nombreArchivo = MasterDom::getData('nombre_archivo');
        $c_celular = MasterDom::getData('columna_numero');
        $c_mensaje = MasterDom::getData('columna_mensaje');
        $c_compania = MasterDom::getData('columna_compania');
        $c_url = MasterDom::getData('columna_url');
        $msisdnArray = json_decode(MasterDom::procesoExcel('completeArray', $nombreArchivo, true),1);
        $total_registros= count($msisdnArray) -1;

        $numeros_validos = 0;
        $numeros_invalidos = 0;
        //print_r($msisdnArray);

        foreach ($msisdnArray as $key => $value) {
            if ($key == 1) {
                continue;
            }
            $pwd = 'hl%D3"60F;)W';
            $pwd = urlencode($pwd);
            ########################
            $msisdn = substr($value['A'],-10);
            $mensaje = urlencode($value['B']);
            $carrier = strtoupper($value['C']);
            /* se agrego para prueba de api web  */
            //$urlRedirect = $value['D'];
            //$idUnico = ApiUrl::generateStatic($msisdn,$urlRedirect,$carrier);
            /*if ($idUnico==0 || $idUnico=="") {
                mail('tecnico@airmovil.com','id vacio',"Mail id vacio..$msisdn");
                continue;
            }*/
            //$bIdUnico = DinamicwebDao::getByidUnico($msisdn,$idUnico);
            # Busca carrier 
            if (strtoupper($carrier) == 'CARRIER') {
                $carrier = @file_get_contents("http://smpp.amovil.mx/proyectossms/apiCarrieresau.php?msisdn=$msisdn");
            }
            ################
            if (!empty($value) || $msisdn != "" || $mensaje != "" || $carrier != "") {
                //usleep(100000);
                //$response = "https://ws.gtp.bz/api/http_bulk/http.php?user=jose.moreno@airmovil.com&pass=$pwd&api_id=1131611826&ani=$msisdn&msj=$mensaje&carr=$carrier";
                //echo $llamada."<br>";
                //para llamar api de tecnophone
                $response = @file_get_contents("https://ws.gtp.bz/api/http_bulk/http.php?user=jose.moreno@airmovil.com&pass=$pwd&api_id=1131611826&ani=$msisdn&msj=$mensaje&carr=$carrier");
                #print_r($response."<br>");
                if (preg_match("/ani/",$response) || preg_match("/Enviado/",$response)) {
                    $numeros_validos++;
                    $mensajeEnviados[] = $response;
                }else{
                    $numeros_invalidos++;
                    $mensajeNoenviados[] = $response;
                }
            }
        }


        $mE = $this->arrayTable($mensajeEnviados);
        if (!empty($mensajeNoenviados)) {
            $mnE = $this->arrayTable($mensajeNoenviados); // este es la variables $mensajeNoenviados
        }
        
        if ($numeros_validos > 0) {
            $botonFinalizar =<<<html
        <input type="submit" class="btn btn-success pull-right" value="Finalizar Proceso">
html;

        }else{
            $botonFinalizar =<<<html
        <a type="button" class="btn btn-danger pull-right" value="Salir" href="/apiwebtecno/seleccionaCliente" >Salir</a>
html;
        }

        $html=<<<html
            <form action="/apiwebtecno/mensaje" method="POST">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                        <h2>Reporte del env&iacute;o realizado <small>En esta pantalla usted podra ver en detalle los resultados de su env&iacute;o.</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li>
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                            </li>
                            <li>
                                <a class="close-link">
                                    <i class="fa fa-close"></i>
                                </a>
                            </li>
                        </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="table-responsive-lg">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Descripcion</th>
                                <th scope="col" style="text-align: center;">Cantidad</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Total de Contactos :</td>
                                <td style="text-align: center;">$total_registros</td>
                            </tr>
                            <tr>
                                <td>Sms envios correctamente :</td>
                                <td style="text-align: center;">$numeros_validos</td>
                            </tr>
                            <tr>
                                <td>Sms no enviados :</td>
                                <td style="text-align: center;">$numeros_invalidos</td>
                            </tr>
                            <tr>
                            <div class="table-responsive-lg">
                                <td>SMS GET ENVIADOS:</td>

                                <td>
                                    <table class="table table-striped table-hover table-sm table-responsive">
                                        <thead>
                                            <tr>
                                                <!--th style="text-align: center;">N/P</th-->
                                                <th style="text-align: center;">Respuesta correcta</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            $mE
                                        </tbody>
                                    </table>
                                </td>
                            </div>
                            </tr>
                            <tr>
                            <div class="table-responsive-lg">
                                <td>SMS GET NO ENVIADOS:</td>
                            
                                <td>
                                    <div class="dataTable_wrapper">
                                        <table class="table table-striped table-hover table-sm table-responsive">
                                            <thead>
                                                <tr>
                                                    <!--th style="text-align: center;">N/P</th-->
                                                    <th style="text-align: center;">Respuesta no enviados</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                $mnE
                                            </tbody>
                                        </table>
                                    </div>
                                </td>
                            </div>
                            </tr>
                        </tbody>
                    </table>
                  </div>
                  <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                          $botonFinalizar
                          </div>
                    </div>
                </div>
            </form>
html;

        View::set('contenido',$html);
        View::render("detalle_client");
    }

    function arrayTable($array){
        //print_r($array);
        //exit;
        $table ="";
        foreach ($array as $key => $value) {
            $np = $key +1;
            //if ($np <= 3) {
                $table .="
                    <tr>
                        <!--td><p>$np</p></td-->
                        <td><p><small>$value</small></p></td>
                    </tr>";
            //}
        }
    
        return $table;
    }

    public function mensaje(){
        
        return $this->alertas('success_process');
    }

    

}