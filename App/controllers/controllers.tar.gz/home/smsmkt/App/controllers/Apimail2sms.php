<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

error_reporting(E_ALL);

use \Core\View;
use \Core\MasterDom;
use \App\models\Apimail2sms as apimail2smsDao;
use \App\controllers\Contenedor;

class Apimail2sms {

private $_contenedor;

    function __construct() { 
	mail('tecnico@airmovil.com','si lelga','email'.print_r($_POST,1));
/*
    $this->_contenedor = new Contenedor;
    View::set('header',$this->_contenedor->header());
    View::set('footer',$this->_contenedor->footer());
*/
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

    //MasterDom::verificaUsuario();

    $bodypart = $_POST['bodypart'];
    $header = $_POST['headers'];
    $body = $_POST['body'];
    //$datos = print_r($_POST,true);
    $esau = "esau.espinoza@airmovil.com,juan.medina@airmovil.com";
    $jaime = "jaime.ramirez@airmovil.com";
    $tecnico = "tecnico@airmovil.com";

    mail("$esau",
        "respuesta Apimail2sms",
        "bodypart: ".print_r($bodypart,true).
        "headers: ".print_r($header,true).
        "body: ".print_r($body,true));
    if (preg_match('/(.*)@(.*)/i', $header['from'])) {
      $mail = $header['from'];
    }
    $arrmail = explode(' ', $mail);
    foreach ($arrmail as $key => $value) {
      if (preg_match('/(.*)@(.*)/i', $value)) {
        $mailOK = str_replace(array('<','>'), '', $value);
      }
    }

    foreach ($header as $key => $value) {
      if (preg_match('/(.*)Outlook(.*)/i', $value)) {
        $out = $value;
      }
    }

    if (!empty($out)) {
      mail("$esau", "encontro Outlook", "OK".print_r($out,true));
      $mensaje = MasterDom::removeAccents(utf8_encode($header['subject']));
    }
    else {
      $mensaje = MasterDom::removeAccents($header['subject']);
       //mail("$esau", "no entro", "NOOK".print_r($out,true));
    }
    
    $count = 0;

    if (!empty($bodypart)) {
      
      if (preg_match('/((^([a-zA-Z]+),[0-9]{10})/', $bodypart)) {
        $bodypartComa = ",".trim($bodypart).",";
        $bodyN = explode(',', $bodypartComa);
      }
      elseif (preg_match('/(^([a-zA-Z]+)\|[0-9]{10})/', self::quitaCaracter(trim($bodypart,"|")))) {
        $bodypartPaid = "|".self::quitaCaracter(trim($bodypart))."|";
        $bodyN = explode('|', $bodypartPaid);
      }
      elseif (preg_match('/(^([0-9]{10}),)/', trim($bodypart,"|"))) {
        $bodypartComa = ",".trim($bodypart).",";
        $bodyNN = explode(',', $bodypartComa);
        $bodyN = array_reverse($bodyNN);
      }
      elseif (preg_match('/(^([0-9]{10})|)/', self::quitaCaracter(trim($bodypart,"|")))) {
        $bodypartPaid = "|".self::quitaCaracter(trim($bodypart))."|";
        $bodyNN = explode('|', $bodypartPaid);
        $bodyN = array_reverse($bodyNN);
      }


    } elseif (!empty($body)) {

      if (preg_match('/(^([a-zA-Z]+),[0-9]{10})/', $body)) {
        $bodyComa = ",".trim($body).",";
        $bodyN = explode(',', $bodyComa);
        //mail("$esau", "entro primer if", "message".print_r($bodyN,true));
      }
      elseif (preg_match('/(^([a-zA-Z]+)\|[0-9]{10})/', self::quitaCaracter(trim($body,"|")))) {
        //mail("$esau", "paid", "ok:".print_r( quoted_printable_encode(self::quitaCaracter(trim($body))),true));
        //mail("$esau", "paid", "ok:".print_r( htmlspecialchars_decode(trim($body)),true));
        $bodyPaid = "|".self::quitaCaracter(trim($body))."|";
        $bodyN = explode('|', $bodyPaid);
      }
      elseif (preg_match('/(^([0-9]{10}),)/', trim($body,"|"))) {
        $bodyComa = ",".trim($body).",";
        $bodyNN = explode(',', $bodyComa);
        $bodyN = array_reverse($bodyNN);
        //mail("$esau", "se aplico reverse coma", "message".print_r($bodyN,true));
      }
      elseif (preg_match('/(^([0-9]{10})|)/', self::quitaCaracter(trim($body,"|")))) {
        $bodyPaid = "|".self::quitaCaracter(trim($body))."|";
        $bodyNN = explode('|', $bodyPaid);
        $bodyN = array_reverse($bodyNN);
        //mail("$esau", "se aplico reverse paid", "message".print_r($bodyN,true));
      }

    }

    //mail("$esau", "llegada de body", "bodyN|:".print_r($bodyN,true));
    $auxmal = array();
    $aux = array();
    $auxmov = array();
    $auxatt = array();
    $auxmsisdn = array();
    foreach ($bodyN as $key => $value) {
      if (!empty($value)) {      
        if ($value == "telcel") {
          $posicion = $key+1;
        } elseif ($value == "movistar") {
          $posicionmov = $key+1;
        }elseif ($value == "att") {
          $posicionatt = $key+1;
        }

        if (preg_match('/^[0-9]{10}$/', trim($value)) && $posicion == $key) {
          array_push($aux, intval(preg_replace('/[^0-9]+/', '', trim($value)), 10));
          $count = $count +1;
        }
        elseif (preg_match('/^[0-9]{10}$/', trim($value)) && $posicionmov == $key) {
          array_push($auxmov, intval(preg_replace('/[^0-9]+/', '', trim($value)), 10));
          $count = $count +1;
        }
        elseif (preg_match('/^[0-9]{10}$/', trim($value)) && $posicionatt == $key) {
          array_push($auxatt, intval(preg_replace('/[^0-9]+/', '', trim($value)), 10));
          $count = $count +1;
        }
        elseif (preg_match('/^[0-9]{10}$/', trim($value))) {
          array_push($auxmsisdn, intval(preg_replace('/[^0-9]+/', '', trim($value)), 10));
          $count = $count +1;
        }
        else {
          if (!empty(trim($value)) && trim($value) != "telcel" && trim($value) != "movistar" && trim($value) != "att") {
            array_push($auxmal, trim($value));

          }  
        }
      }
    }

    if (!empty($auxmal)) {
      mail("$esau","msisdn incorrecto","message:".print_r($auxmal,true));
    }

mail("$esau","101 antes valida","data ");
    $busca = apimail2smsDao::buscaMail(trim($mailOK)); # buscamos el mail en bd
mail("$esau","102","message:".print_r($_POST,true));
      if ( trim($mailOK) == trim($busca['mail']) && (!empty($aux) || !empty($auxmov) || !empty($auxatt) || !empty($auxmsisdn))) {
        mail("$esau", 
        "datos usuario OK", 
        "mail: ".$mailOK.
        " <>mensaje: ".$mensaje.
        " <>total: ".$count.
        "<br>
          <>numeros telcel: ".print_r($aux,true).
        "<>numeros movistar: ".print_r($auxmov,true).
        "<>numeros att: ".print_r($auxatt,true).
        "<>numeros sin carrier: ".print_r($auxmsisdn,true));

        /* Insertar campania, mail2sms_campaign, msisdn y sms_campaign */

        $fecha = date("Y-m-d H:i:s");

        $datosCampania = new \stdClass();
        $datosCampania->_name = $fecha.":Mail2Sms:".trim($mailOK);

        $id_campaign = apimail2smsDao::insertCampaign($datosCampania);

        $user_id = $busca['user_id'];
        $customer_id = $busca['customer_id'];

        apimail2smsDao::insertCampaignUser($user_id, $id_campaign);

        apimail2smsDao::insertaCampaniaCustomer($customer_id, $id_campaign);

        $datosMailcamp = new \stdClass();
        $datosMailcamp->_mensaje = $mensaje;
        $datosMailcamp->_total = $count;
        $datosMailcamp->_mail_id = $busca['mail2sms_id'];
        $datosMailcamp->_campaign_id = $id_campaign;

        mail("$esau", "se creo campania", "id_campaign:".$id_campaign."<br>datosMailcamp".print_r($datosMailcamp,true));

        apimail2smsDao::insertMailcampaign($datosMailcamp);
        
        $ccsc_id = apimail2smsDao::buscaCCSC($busca['mail2sms_id']);

	$shortCode = array('telcel'=>array('carrier_connection_short_code_id'=>-1,
					'carrier_connection_id'=>-1,
					'carrier_id'=>-1,
					'short_code_id'=>-1),
			 'movistar'=>array('carrier_connection_short_code_id'=>-1,
					'carrier_connection_id'=>-1,
					'carrier_id'=>-1,
					'short_code_id'=>-1), 
			'att'=>array('carrier_connection_short_code_id'=>-1,
                                        'carrier_connection_id'=>-1,
					'carrier_id'=>-1,
					'short_code_id'=>-1)
			);
	foreach($ccsc_id AS $value){
	
	/*
	    $datosCCSCC = new \stdClass();
            $datosCCSCC->_ccsc_id = $ccsc_id['carrier_connection_short_code_id'];
            $datosCCSCC->_campaign_id = $id_campaign;
            apimail2smsDao::insertCCSCC($datosCCSCC);
	*/

	    foreach($shortCode AS $k=>$val){
		if($k == $value['name']){
		    $shortCode[$k]['carrier_connection_short_code_id'] = $value['carrier_connection_short_code_id'];
		    $shortCode[$k]['carrier_connection_id'] = $value['carrier_connection_id'];
		    $shortCode[$k]['carrier_id'] = $value['carrier_id'];
		    $shortCode[$k]['short_code_id'] = $value['short_code_id'];

		    $datosCCSCC = new \stdClass();
            	    $datosCCSCC->_ccsc_id = $value['carrier_connection_short_code_id'];
            	    $datosCCSCC->_campaign_id = $id_campaign;

            	    apimail2smsDao::insertCCSCC($datosCCSCC);
		}
	    }
	}

	/*
        $datosCCSCC = new \stdClass();
        $datosCCSCC->_ccsc_id = $ccsc_id['carrier_connection_short_code_id'];
        $datosCCSCC->_campaign_id = $id_campaign;

        apimail2smsDao::insertCCSCC($datosCCSCC);
	*/

        //$shortCode = apimail2smsDao::buscaShortCode($ccsc_id['carrier_connection_short_code_id']);

mail($esau, 'llega 0', print_r($shortCode, 1));

        if (!empty($aux)) {
          $carrier = "telcel";
          $carrier_id = apimail2smsDao::buscaCarrier($carrier);

mail($esau, 'llega 0.1', print_r($carrier_id, 1));

          /*Comparar si el shortcode pertenece al carrier id*/
          if ($carrier_id['carrier_id'] == $shortCode['telcel']['carrier_id']) {
           $carrier_id = $shortCode['telcel']['carrier_id'];
           $ccsc_id = $shortCode['telcel']['carrier_connection_short_code_id'];
          }
          else{
            $carrier_id = -1;
            $ccsc_id = -1;
          }


          $id_CCSC = apimail2smsDao::insertaCampaniaCarrierShortCode($id_campaign, $carrier_id, $shortCode['telcel']['short_code_id']);

          foreach ($aux as $key => $value) {
            $msisdn = "52".$value;
            //mail("$esau", "msisdn y carrier_id", "message:$msisdn - $carrier_id['carrier_id']");
            
            /*if($carrier_id > 0){

              $registro = apimail2smsDao::buscaCarrierMsisdn($msisdn);

              if(count($registro) > 0){
                $msisdn_id = $registro['msisdn_id'];
              }else{
                $msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);
              }
            }*/

	    $datosSmscampaign = new \stdClass();
            $datosSmscampaign->_campaign_id = $id_campaign;
            $datosSmscampaign->_mensaje = $mensaje;
            $datosSmscampaign->_ccsc_id = $ccsc_id;
mail($esau, 'llega 1', "msisdn: $msisdn, $carrier_id");
            $msisdnArray= apiMail2smsDao::buscaMsisdnId($msisdn,$carrier_id);
	mail($esau, 'llega 1.1', "msisdn: $msisdn, $carrier_id\n".print_r($msisdnArray,1)."\n".count($msisdnArray));
	    if($msisdnArray['msisdn_white_list_id'] == null AND $msisdnArray['msisdnId'] == null){
mail($esau, 'llega 4', "msisdn: $msisdn, $carrier_id");
                $msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);
                $insertaWhite = apiMail2smsDao::insertaWhiteList($msisdn_id, $shortCode['telcel']['carrier_connection_id']);
                $datosSmscampaign->_sce_id = 3;
                $datosSmscampaign->_msisdn_id = $msisdn_id;
            }elseif ($msisdnArray['msisdnId'] > 0 AND $msisdnArray['msisdn_white_list_id'] > 0) {
mail($esau, 'llega 2', "msisdn: $msisdn, $carrier_id");
	 	$datosSmscampaign->_sce_id = 4;
		$datosSmscampaign->_msisdn_id = $msisdnArray['msisdnId'];
              //$msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);
	    }elseif($msisdnArray['msisdnId'] > 0 AND ($msisdnArray['msisdn_white_list_id'] == '' OR $msisdnArray['msisdn_white_list_id'] == null)){
mail($esau, 'llega 3', "msisdn: $msisdn, $carrier_id");
		$insertaWhite = apiMail2smsDao::insertaWhiteList($msisdnArray['msisdnId'], $shortCode['telcel']['carrier_connection_id']);	
		$datosSmscampaign->_sce_id = 3;
                $datosSmscampaign->_msisdn_id = $msisdnArray['msisdnId'];
            }else{
		continue;	
	    }

	    /*
            $datosSmscampaign = new \stdClass();
              $datosSmscampaign->_campaign_id = $id_campaign;
              $datosSmscampaign->_msisdn_id = $msisdn_id;
              $datosSmscampaign->_mensaje = $mensaje;
              $datosSmscampaign->_ccsc_id = $ccsc_id;
              $datosSmscampaign->_sce_id = 4;
	     */

              //mail("$esau", "datosSmscampaign", "message:".print_r($datosSmscampaign,true));

              apimail2smsDao::insertSmsCampaign($datosSmscampaign);
            
            

          }

        }

        if (!empty($auxmov)) {
          $carrier = "movistar";
          $carrier_id = apimail2smsDao::buscaCarrier($carrier);

          /*Comparar si el shortcode pertenece al carrier id*/
          mail("$esau","shortcode y carrier","shortcode:".print_r($shortCode,true)."  carrier_id:".print_r($carrier_id['carrier_id'],true));
          if ($carrier_id['carrier_id'] == $shortCode['movistar']['carrier_id']) {
           $carrier_id = $shortCode['movistar']['carrier_id'];
           $ccsc_id = $shortCode['movistar']['carrier_connection_short_code_id'];
          }
          else{
            $carrier_id = -1;
            $ccsc_id = -1;
          }
          $id_CCSC = apimail2smsDao::insertaCampaniaCarrierShortCode($id_campaign, $carrier_id, $shortCode['movistar']['short_code_id']);
          
          foreach ($auxmov as $key => $value) {
            $msisdn = "52".$value;
            $msisdn_id = apiMail2smsDao::buscaMsisdnId($msisdn,$carrier_id);
            if (empty($msisdn_id)) {
              $msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);
            }else{
              $msisdn_id = $msisdn_id['msisdn_id'];
            }


            $datosSmscampaign = new \stdClass();
            $datosSmscampaign->_campaign_id = $id_campaign;
            $datosSmscampaign->_msisdn_id = $msisdn_id;
            $datosSmscampaign->_mensaje = $mensaje;
            $datosSmscampaign->_ccsc_id = $ccsc_id;
            $datosSmscampaign->_sce_id = 4;

            apimail2smsDao::insertSmsCampaign($datosSmscampaign);

          }
        }

        if (!empty($auxatt)) {
          $carrier = "att";
          $carrier_id = apimail2smsDao::buscaCarrier($carrier);

          /*Comparar si el shortcode pertenece al carrier id*/
          if ($carrier_id['carrier_id'] == $shortCode['att']['carrier_id']) {
           $carrier_id = $shortCode['att']['carrier_id'];
           $ccsc_id = $shortCode['att']['carrier_connection_short_code_id'];
          }
          else{
            $carrier_id = -1;
            $ccsc_id = -1;
          }
          $id_CCSC = apimail2smsDao::insertaCampaniaCarrierShortCode($id_campaign, $carrier_id, $shortCode['att']['short_code_id']);
          
          foreach ($auxatt as $key => $value) {
            $msisdn = "52".$value;
            //mail("$esau","msisdn","msisdn".print_r($msisdn,true)."carrier_id:".print_r($carrier_id,true));
            $msisdn_id = apiMail2smsDao::buscaMsisdnId($msisdn,$carrier_id);
            //mail("$esau","msisdn_id","msisdn_id:".print_r($msisdn_id,true));
            if (empty($msisdn_id)) {
              $msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);
            }else{
              $msisdn_id = $msisdn_id['msisdn_id'];
            }

            $datosSmscampaign = new \stdClass();
            $datosSmscampaign->_campaign_id = $id_campaign;
            $datosSmscampaign->_msisdn_id = $msisdn_id;
            $datosSmscampaign->_mensaje = $mensaje;
            $datosSmscampaign->_ccsc_id = $ccsc_id;
            $datosSmscampaign->_sce_id = 4;

            apimail2smsDao::insertSmsCampaign($datosSmscampaign);

          }
        }

        if (!empty($auxmsisdn)) {
          $carrier_id = "";

          foreach ($auxmsisdn as $key => $value) {

            $msisdn = "52".$value;
            
            $buscaCarrierMsisdn = apimail2smsDao::buscaCarrierMsisdn($msisdn);
            mail("$esau", "buscaCarrierMsisdn", "message".print_r($buscaCarrierMsisdn,true));

            if (!empty($buscaCarrierMsisdn)) {
              $carrier_id = $buscaCarrierMsisdn['carrier_id'];
            } 
            else {
              $carrier_id = -1;
            }

            /*Comparar si el shortcode pertenece al carrier id*/
            if ($carrier_id['carrier_id'] == $shortCode[0]['carrier_id']) {
             $carrier_id = $shortCode[0]['carrier_id'];
             $ccsc_id = $shortCode[0]['carrier_connection_short_code_id'];
             $sce_id = 4;
            }
            else{
              $carrier_id = -1;
              $ccsc_id = -1;
              $sce_id = 1;
            }

            $id_CCSC = apimail2smsDao::insertaCampaniaCarrierShortCode($id_campaign, $carrier_id, $shortCode[0]['short_code_id']);

            $msisdn_id = apimail2smsDao::insertMsisdn($msisdn, $carrier_id);

            $datosSmscampaign = new \stdClass();
            $datosSmscampaign->_campaign_id = $id_campaign;
            $datosSmscampaign->_msisdn_id = $msisdn_id;
            $datosSmscampaign->_mensaje = $mensaje;
            $datosSmscampaign->_ccsc_id = $ccsc_id;
            $datosSmscampaign->_sce_id = $sce_id;

            apimail2smsDao::insertSmsCampaign($datosSmscampaign);

          }
        }

        /**********************/

      }
      else {

        if (empty($aux) && empty($auxmov) && empty($auxatt) && empty($auxmsisdn)) {
          mail("$mailOK,$esau", "no se encontro msisdns", "msisdns:".print_r($aux,true)."".print_r($auxmov,true)."".print_r($auxatt,true)."".print_r($auxmsisdn,true));
        }

          mail("$mailOK,$esau", "usuario no valido:".$mailOK, "Este usuario no es valido para mail2sms");
        
      }


    } # Fin de funcion Index

    public function Hola(){
        //echo "Hola desde apiMail2sms";
      print_r($_SERVER);
    }

    public function add() {
        MasterDom::verificaUsuario();
    
    }


    public function edit(){

        MasterDom::verificaUsuario();
     }


    public function delete(){
        MasterDom::verificaUsuario();
    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con éxito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/badword/mostrar');
        View::set('class', $class);
        View::set('titulo','badword');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

    function quitaCaracter($string)
    {
      $string = htmlspecialchars_decode(trim($string));

      $arrayBusca = array('/=3D/','/=0A/','/=/');
      $arrayCambio = array('','|','');
      //return preg_replace('/(\r\n|\n|\r)/', '|', $string);
      return preg_replace($arrayBusca, $arrayCambio, $string);
    }


}
