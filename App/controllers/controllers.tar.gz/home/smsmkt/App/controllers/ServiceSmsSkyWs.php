<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
use \App\controllers\ClientSkySmsSend;
/*
** Servicio Wsdl
** Esaú
*/
$mailEsau = 'esau.espinoza@airmovil.com';
class ServiceSmsSkyWs
{
	public function __construct()
	{
		
	}

	public function index()
	{
		exit();
	}

	public function sendSmsProceso($params)
	{
		$params = MasterDom::getData('params');
		if ($params != '') {
			mail("$mailEsau","sendSmsProceso","parametros recibidos <br>".print_r($params,1));
			return  1;
		}
		else {
			return 0;
		}
		
	}


}