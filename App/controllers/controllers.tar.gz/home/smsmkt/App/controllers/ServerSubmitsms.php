<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
/*
** Servidor Wsdl
** Esaú
*/
class ServerSubmitsms
{

	public function index()
	{
		if(!extension_loaded("soap")){
		      dl("php_soap.dll");
		}

		ini_set("soap.wsdl_cache_enabled","0");
		
		$server = new \SoapServer("https://smppvier.amovil.mx/wsdl/SubmitSms.wsdl");
		//$server->addFunction("smsInsert");
		$server->addFunction('sumar');
		$server->addFunction('restar');
		$server->handle();
	}

	function sumar($operando1,$operando2){
	      return $operando1+$operando2;
	}
	 
	function restar($operando1,$operando2){
	      return $operando1-$operando2;
	}

	function server(){
		$respuesta = file_get_contents('php://input');
		echo "$respuesta";
	}

}
