<?php
//phpinfo();
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
/*
** Client Wsdl
** Esaú
*/
class ClientSkySmsSend
{

	public function index()
	{
		
	}


	public function sendSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			/*$arrayMsisdn = array(1	=> '525521984193', // Esau
								 /*2	=> '525510123937', // Juancho*/
								 //3 	=> '525567049957', // Monitoreo att
								 //4 	=> '525551865113', // Cesar movistar
								 /*5 	=> '525527633429', // Jimmy telcel
								 6 	=> '525533887179', // Movistar pruebas
								 7 	=> '525543904792', // Jimmy telcel 2
								 8 	=> '527471406668', // Jorge telcel
								 19 => '525542255724', // Chelo movistar
								 10 => '525564454554', // Bach att
								 11 => '525547896311', // Carnal de Juan Telcel
								 12 => '525572828037', // Carnal de cesar movistar
								 13 => '525575203414', // Objeto de Bach 
								 14 => '527473997442', // Novia de jorge att
								 15 => '525577472997', // Virgin
								 16 => '525541670935', // Casa Jimmy
								 17 => '525575520178'  // amigo de Juan movistar*/
								 //18 => '525551761963'	// Att pruebas
							//);
			//for ($i=0; $i < 2 ; $i++) { 
				//$arrayMsisdn = array_merge($arrayMsisdn, $arrayMsisdn);
			//}*/
			$arrayMsisdn = array(	array('msisdn'	=>	'525521984193',	'mensaje'	=> 'airmovil sms test ')/*,	//esau telcel
									array('msisdn' 	=>	'525567049957', 'mensaje'	=> 'airmovil sms test '),	//monitoreo att
									array('msisdn' 	=>	'525551865113', 'mensaje'	=> 'airmovil sms test ')/*,	//cesar movistar
									array('msisdn'	=>	'525510123937',	'mensaje'	=> 'sms test airmovil '),	//att prueba
									array('msisdn'	=>	'525521984193',	'mensaje'	=> 'sms test airmovil '),	//esau telcel
									array('msisdn' 	=>	'525543904792', 'mensaje'	=> 'sms test airmovil '),	//monitoreo att
									array('msisdn' 	=>	'525527633429', 'mensaje'	=> 'sms test airmovil '),	//cesar movistar
									array('msisdn'	=>	'527471406668',	'mensaje'	=> 'sms test airmovil ')*/	//att prueba
							);
			/*$arrayMsisdn = array(	array('msisdn' 	=>	'525518005371', 'mensaje'	=> 'prueba mensaje airmovil uno'),
									array('msisdn' 	=>	'525510123937', 'mensaje'	=> 'prueba mensaje airmovil uno')/*,	//monitoreo att
									array('msisdn' 	=>	'525521984193', 'mensaje'	=> 'tres'),
									array('msisdn' 	=>	'525527633429', 'mensaje'	=> 'cuatro'),
									array('msisdn' 	=>	'525543904792', 'mensaje'	=> 'cinco'),
									array('msisdn' 	=>	'525551865113', 'mensaje'	=> 'seis'),	//monitoreo att
									array('msisdn' 	=>	'527471406668', 'mensaje'	=> 'siete')/*,
									array('msisdn' 	=>	'525567049957', 'mensaje'	=> 'ocho'),
									array('msisdn' 	=>	'525567049957', 'mensaje'	=> 'nueve'),
									array('msisdn' 	=>	'525567049957', 'mensaje'	=> 'diez')*/
							//);			
			/*$arrayMsisdn = array_merge($arrayMsisdn, $arrayMsisdn);
			$arrayMsisdn = array_merge($arrayMsisdn, $arrayMsisdn);
			$arrayMsisdn = array_merge($arrayMsisdn, $arrayMsisdn);*/
			//$arrayMsisdn = array_merge($arrayMsisdn, $arrayMsisdn);

			$count = 0;
			foreach ($arrayMsisdn as $key => $value) {
				$count++;
				$msisdn = substr($value['msisdn'] , -12);
				$mensaje = $value['mensaje'].$count;

				$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
				$location = array('location' => $uriServidor);

				$paramssendSms = 	array(
										array(	'headerRequest'		=>	
											array(	'proveedorId'	=> '',
													'proveedor'		=> '',
													'loteId'		=> '',
													'bloques'		=> ''
													),
											'message'	=> 
												array(	'phoneNumber'	=>	"$msisdn",
														'message' 		=>	"$mensaje",
														'loteDetalleId'	=>	''
												)
										)
									);

				//print_r($paramssendSms);
				//usleep(250000);
				$chpw = $clienteSOAP->__soapCall('sendSms', $paramssendSms, $location, $this->generateWSSecurityHeader());
				/*$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
				$var .= $clienteSOAP->__getLastRequest() . "\n";
				$var .= $clienteSOAP->__getLastResponse();*/
				
				print_r($chpw);
				echo "\n <br>";
			}

			
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function statusSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
			$location = array('location' => $uriServidor);
			$ids = array(13633);
			foreach ($ids as $value) {
				$paramsstatusSms = 	array(
												array(	'headerRequest'		=>	
													array(	'proveedorId'	=> '',
															'proveedor'		=> '',
															'loteId'		=> 1,
															'bloques'		=> 10
														),
													'idMessage'		=> "$value"
												)
											);

				$chpw = $clienteSOAP->__soapCall('statusSms', $paramsstatusSms, $location, $this->generateWSSecurityHeader());
				$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
				$var .= $clienteSOAP->__getLastRequest() . "\n";
				$var .= $clienteSOAP->__getLastResponse();
				/*print $this->_clienteSoap->__getLastRequestHeaders() . "\n";print $this->_clienteSoap->__getLastRequest() . "\n";print $this->_clienteSoap->__getLastResponse();*/
				//echo "--->";
				print_r($chpw);
			}
			
			
			//return $clienteSOAP;
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}


	public function changePasswordSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
			$location = array('location' => $uriServidor);

			$paramschangePasswordSms = 	array(
											array(	'headerRequest'		=>	
												array(	'proveedorId'	=> '1',
														'proveedor'		=> 'airmovil',
														'loteId'		=> 1,
														'bloques'		=> 10
													),
												'newPassword'		=> 'Exa_1987.'
											)
										);

			$chpw = $clienteSOAP->__soapCall('changePasswordSms', $paramschangePasswordSms, $location, $this->generateWSSecurityHeader());
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			/*print $this->_clienteSoap->__getLastRequestHeaders() . "\n";print $this->_clienteSoap->__getLastRequest() . "\n";print $this->_clienteSoap->__getLastResponse();*/
			//echo "--->";
			print_r($chpw);
			
			//return $clienteSOAP;
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function incomingSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'loteId'		=> 1,
												'bloques'		=> 10
												),
										'idMessage'	=> '1381',
										'from'		=> '2018-03-01',
										'to'		=> '2018-03-31'
									)
								);

			$chpw = $clienteSOAP->__soapCall('incomingSms', $paramssendSms, $location, $this->generateWSSecurityHeader());
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function balanceSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'loteId'		=> 1,
												'bloques'		=> 10
												)
									)
								);

			$chpw = $clienteSOAP->__soapCall('balanceSms', $paramssendSms, $location, $this->generateWSSecurityHeader());
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function exchangeSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWSNew.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWsPrueba.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'loteId'		=> 1,
												'bloques'		=> 10
												)
									)
								);

			$chpw = $clienteSOAP->__soapCall('exchangeSms', $paramssendSms, $location, $this->generateWSSecurityHeader());
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}


	public function generateWSSecurityHeader()
	{
		date_default_timezone_set('UTC');

		$password = 'Exa_1987.';

		$user = 'esau';

		$nonce = substr(md5(uniqid('air_', true)),0,16);
    
    	$nonce64 = base64_encode($nonce);

    	$fecha = date('Y-m-d')."T".date('H:i:s')."Z";

    	$token = $nonce64 . $fecha . utf8_encode($password);
    
    	$token64 = base64_encode(sha1($token,true));

    	$transactionId = 1111;//$this->obtenerTransactionId();

		$xml =<<<xhtml
<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
    <wsse:UsernameToken xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
		<wsse:Username>{$user}</wsse:Username>
        <wsse:Password Type="...#PasswordDigest">{$token64}</wsse:Password>
        <wsse:Nonce>{$nonce64}</wsse:Nonce>
        <wsu:Created>{$fecha}</wsu:Created>
    </wsse:UsernameToken>
</wsse:Security>
xhtml;

/*<!--<tns:RequestSOAPHeader xmlns:tns="http://www.huawei.com/schema/common/v2_1">
    <tns:AppId>0101</tns:AppId>
    <tns:TransId>{$transactionId}</tns:TransId>
    <tns:OA></tns:OA>
    <tns:FA></tns:FA>
</tns:RequestSOAPHeader>-->
*/

		return new \SoapHeader('http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd',
								'Security',
								new \SoapVar($xml, XSD_ANYXML),
								true
							);
	}

}
