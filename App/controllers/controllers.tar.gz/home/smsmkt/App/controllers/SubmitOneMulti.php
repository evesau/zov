<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
use \App\controllers\Contenedor;


class SubmitOneMulti
{

private $_contenedor;

    function __construct() {

  $this->aumentarLimites();
  $this->_contenedor = new Contenedor;
  View::set('header',$this->_contenedor->header());
  View::set('footer',$this->_contenedor->footer());
    }

    public static function aumentarLimites(){

      ini_set("memory_limit", "-1");
      ini_set("upload_max_filesize", "50M");
      ini_set("post_max_size", "100M");
      ini_set("max_execution_time", 1000);
      ini_set("max_input_time", 900);
      ini_set("max_file_uploads", "50M");

    }


    public static function volverLimitesDefault(){
      ini_set("memory_limit", "256M");
      ini_set("max_file_uploads", "20M");
      ini_set("upload_max_filesize", "50M");
      ini_set("post_max_size", "8M");
      ini_set("max_execution_time", 30);
      ini_set("max_input_time", 60);

    }

    public function index() {

    }

    public function seleccionaCliente(){
      $extraHeader=<<<html
    <link href="/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
html;
      $extraFooter=<<<html
        <!-- DataTables JavaScript -->
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/bootstrap-progressbar.min.js"></script>
        <script>
          $(document).ready(function() {
            $(".seleccion").on("change", function () {
              valor = $(this).val();
              if(valor == "existente"){
                $('#existente_valida').removeAttr("disabled");
              }else{
                $('#existente_valida').attr('disabled', 'disabled');
              }
            });

            $(".seleccion_base").on("change", function () {
              valor = $(this).val();
              if(valor == "si"){
                $('#nombre_base').removeAttr("disabled");
              }else{
                $('#nombre_base').attr('disabled', 'disabled');
              }
            });

            if($(".seleccion_base:checked").val() == 'si' && $("#nombre_base").val() == '' && $(".seleccion:checked").val() == 'nuevo')
              alert("vacio");

              $('.btn-success').on("click",function() {
                if($(".seleccion_base:checked").val() == 'si' && $("#nombre_base").val() == '' && $(".seleccion:checked").val() == 'nuevo'){
                  bootbox.alert("Error: debes asignar un nombre para la base!");
                  return;
                }
                $( "#add" ).submit();
              });
          });
        </script>
html;

      $customer = MasterDom::getSession('customer_id');
      if(empty($customer))
        return MasterDom::alertas('error_general');

      $cliente = CampaignDao::getClientesCustomer($customer);
      $clientes = false;
      if(!empty($cliente) AND count($cliente) > 0){
        $radio = '';
        foreach($cliente AS $key=>$value){
          $checked = ($key == 0) ? 'checked="checked"' : '';
          $radio.=<<<html
            <div class="radio control-label" style="padding-left: 20px;">
              <label class="">
                <input $checked name="base_existente" type="radio" value="{$value['customer_client_id']}"> {$value['name']}
              </label>
            </div>
html;
      }

      $client=<<<html
        <div class="form-group">
          <div class="ln_solid"></div>
          <div class="radio control-label">
            <label class="action">
              <input value="existente" class="seleccion" name="iCheck" type="radio"> Base Anterior
            </label>
            <br /><br />
            <p class="help-block">Selecciona alguna base de clientes existente:</p>
          </div>
        </div>
        <div class="form-group">
          <fieldset id="existente_valida" disabled>$radio</fieldset>
        </div>
html;
      }

      $html=<<<html
        <div class="x_panel">
          <div class="x_title">
            <h2>Selecci&oacute;n de Contacto</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li><a class="close-link"><i class="fa fa-close"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p>Seleccione la opci&oacute;n deseada para definir los Contactos que se utilizar&aacute;n en la realizaci&oacute;n del env&iacute;o.</p>
            <div class="ln_solid"></div>
            <form id="add" action="/submitOneMulti/seleccionaClientePost" enctype="multipart/form-data" method="POST">
              <div class="form-group">
                <div class="radio">
                  <label class="action"><input value="nuevo" class="seleccion" name="iCheck" checked="checked" type="radio"> Nuevo</label><br /><br />
                  <input type="file" accept=".xls, .xlsx, .csv, .zip" name="file" id="file"/>
                  <p class="help-block">Importar un archivo excel, te recomendamos usar la siguiente plantilla, los formatos v&aacute;lidos son: .xls, .xlsx, .csv</p>
                  <p class="help-block">Es posible importar un archivo .zip, los formatos v&aacute;lidos de los archivos dentro del .zip son: .xls, .xlsx, .csv</p>
                  <p class="help-block"><a href='/plantillas/Plantilla_multicarrier.xlsx'><i class="fa fa-file-excel-o"></i> Descarga plantilla</a></p>
                  <div class="alert alert-warning alert-dismissible fade in" role="alert" style="color: black;">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <strong>Importante!</strong> Dentro del archivo a subir, colocar en la columna definida para el operador: <b>TELCEL, MOVISTAR o ATT</b>, de acuerdo a la compa&ntilde;&iacute;a del n&uacute;mero telef&oacute;nico o <b>CARRIER</b> si se desea que se busque el carrier/operador. 
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label">Deseas guardar la Base : </label>
                <div class="radio">
                  <label class="action"><input value="si" class="seleccion_base" name="base_guardar" type="radio"> Si </label>
                  <label class="action"><input value="no" class="seleccion_base" name="base_guardar" checked="checked" type="radio"> No</label>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label">Nombre de la Base : </label>
                <div class=""><input type="text" class="form-control" placeholder="Nombre de Base" name="base_nombre" id="nombre_base" disabled></div>
              </div>
              $client
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-12 col-sm-9 col-xs-12">
                  <!--a href="#" class="btn btn-success pull-right">Siguiente</a-->
                  <input type="submit" class="btn btn-success pull-right" value="Siguiente" >
                </div>
              </div>
            </form>
          </div>
        </div>
html;
      /*$id_user = $_SESSION['id_user'];
      $customer = MasterDom::getSession('customer_id');
      $getTotalesCustomerMes = CampaignDao::getTotalesCustomerMes($customer);
      $getTotalesCustomerDia = CampaignDao::getTotalesCustomerDia($customer);
      $getTotalesuserMes = CampaignDao::getTotalesUserMes($id_user);
      $getTotalesuserDia = CampaignDao::getTotalesUserDia($id_user);

      $dataUser = CampaignDao::getDataUser($id_user);
      $dataCustomer = CampaignDao::getDataCustomer($customer);

      $totalMesCustomer = number_format($getTotalesCustomerMes['max_mt_month']);
      $totalMesRestaCustomer = number_format($getTotalesCustomerMes['resta_mes']);
      $totalDiaCustomer = number_format($getTotalesCustomerDia['max_mt_day']);
      $totalDiaRestaCustomer = number_format($getTotalesCustomerDia['resta_dia']);
      $totalMesUser = number_format($getTotalesuserMes['max_mt_month']);
      $totalMesRestaUser = number_format($getTotalesuserMes['resta_mes']);
      $totalDiaUser = number_format($getTotalesuserDia['max_mt_day']);
      $totalDiaRestaUser = number_format($getTotalesuserDia['resta_dia']);

      $procentajeTotalCustomerMes = $getTotalesCustomerMes['resta_mes'] * 100 / $getTotalesCustomerMes['max_mt_month'];
      $procentajeTotalCustomerDia = $getTotalesCustomerDia['resta_dia'] * 100 / $getTotalesCustomerDia['max_mt_day'];
      $procentajeTotalUserMes = $getTotalesuserMes['resta_mes'] * 100 / $getTotalesuserMes['max_mt_month'];
      $procentajeTotalUserDia = $getTotalesuserDia['resta_dia'] * 100 / $getTotalesuserDia['max_mt_day'];*/

      /*$html.=<<<html
        <div class="x_panel">
          <div class="x_title">
            <h2>Reporte de bolsa de sms MES y D&Iacute;A </h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li><a class="close-link"><i class="fa fa-close"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <div class="col-md-12">
              <div class="row">
                <div class="col-md-12">
                  <h2>Bolsa sms customer {$dataCustomer['name']}</h2>
                </div>
                <div class="col-md-6" style="padding:10px;">
                  <li>Bolsa de mensajes por mes {$dataCustomer['name']}: <b>{$totalMesCustomer} </b></li>
                  <div class="">
                    <span class="pull-right">Cantidad de sms restantes al mes: <b> {$totalMesRestaCustomer} </b></span>
                    <progress class="col-md-12" value="{$procentajeTotalCustomerMes}" max="100"></progress>
                  </div>
                </div>

                <div class="col-md-6" style="padding:10px;">
                  <li>Bolsa de mensajes por dia {$dataCustomer['name']}: <b>{$totalDiaCustomer} </b></li>
                  <div class="">
                    <span class="pull-right">Cantidad de sms restantes al dia: <b> {$totalDiaRestaCustomer} </b></span>
                    <progress class="col-md-12" value="{$procentajeTotalCustomerDia}" max="100"></progress>
                  </div>
                </div>

                <div class="col-md-12">
                  <h2>Bolsa de sms {$dataUser['first_name']} {$dataUser['last_name']} </h2>
                </div>

                <div class="col-md-6" style="padding:10px;">
                  <li>Bolsa de mensajes por mes {$dataUser['first_name']} {$dataUser['last_name']}: <b>{$totalMesUser} </b></li>
                  <div class="">
                    <span class="pull-right">Cantidad de sms restantes al mes: <b> {$totalMesRestaUser} </b></span>
                    <progress class="col-md-12" value="{$procentajeTotalUserMes}" max="100"></progress>
                  </div>
                </div>

                <div class="col-md-6" style="padding:10px;">
                  <li>Bolsa de mensajes por dia {$dataUser['first_name']} {$dataUser['last_name']}: <b>{$totalDiaUser} </b></li>
                  <div class="">
                    <span class="pull-right">Cantidad de sms restantes al mes: <b> {$totalDiaRestaUser} </b></span>
                    <progress class="col-md-12" value="{$procentajeTotalUserDia}" max="100"></progress>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
html;*/

      View::set('contenido',$html);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render("submit_one_add");
    }

    private function functionCsv($file){

    }

    private function functionTxt($file){

    }

    private function functionExcel($file, $ext){

      $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

      $ext = strtolower($ext);
      $archivo = MasterDom::moverDirectorio($file, $customer, 'csub');
      if($archivo === false)
          return MasterDom::alertas('error_general');
      if($ext ==  'xls' || $ext == 'xlsx'){ 

          $excel = MasterDom::procesoExcel('getFilas', $archivo['nombre']);
          
          $excelArray = json_decode($excel, 1);

          if(empty($excelArray))
            return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el proceso, el documento est&aacute; vac&iacute;o.');

          foreach($excelArray AS $key=>$value){
        if($value != '')
            $array[$key] = $value;
          }
          $file_name = $archivo['nombre'];

      }elseif($ext == 'csv'){
          $arch = MasterDom::$_target.$archivo['nombre'];
          $acum = 1;
          if (($fichero = fopen($arch, "r")) !== FALSE) {
            while (($datos = fgetcsv($fichero)) !== FALSE) {
            if($acum == 1){
              $array = $datos;
              break;
            }
            $acum += 1;
           }
          fclose($fichero);
          $file_name = $archivo['nombre'];
      
          }else{
            return MasterDom::alertas('error_general');
          }
      }elseif($ext == 'zip'){
        $nombreArchivos = MasterDom::descomprimirZip($archivo['nombre']);/*se descomprime el zip y se obtienen los nombres de los archivos que contiene en formato string*/
        $file_name = $nombreArchivos;
        $nombreArchivos = explode("{",$nombreArchivos);/* se convierte en arreglo el string de los nombres de los archivos*/
        $archivos = array();
        foreach ($nombreArchivos as $key => $value) {
          $ext = pathinfo($value, PATHINFO_EXTENSION);
          if($ext!=""){
            $archivos[] = array('nombre'=>$value,'ext'=>$ext);//se obtiene el nombre y extension de los archivos descomprimidos 
          }
        }
        $excelArray = json_decode(MasterDom::procesoExcel('getFilas', $archivos[0]['nombre']), 1);

        if(empty($excelArray))
          //return MasterDom::alertas('error_general');
          return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el proceso, el documento est&aacute; vac&iacute;o.');

        foreach($excelArray AS $key=>$value){
          if($value != '')
              $array[$key] = $value;
        }
      }else{
        //return MasterDom::alertas('error_general');
        return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el proceso, el zip est&aacute; vac&iacute;o.');
      }


  $baseGuardar = (MasterDom::getData('base_guardar') != '') ? MasterDom::getData('base_guardar') : '';
  $baseNombre = (MasterDom::getData('base_nombre') != '') ? MasterDom::getData('base_nombre') : '';

  $opciones = '';
        foreach($array AS $key=>$value){
      $select = ($key == 'A')? 'selected' : '';
            $opciones.=<<<html
                <option value="$key" $selected >$value</option>
html;
        } 

  $operador = '';
        foreach($array AS $key=>$value){
      $select = ($key == 'B') ? 'selected="selected"' : '';
            $operador.=<<<html
                <option value="$key" $select >$value</option>
html;
        }

  $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Selecci&oacute;n columna "Numero de Celular"</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla deber&aacute; seleccionar la columna del excel que contiene los N&uacute;meros de Celulares a los cuales se les realizar&aacute; el env&iacute;o...</p>
                    <div class="ln_solid"></div>
                    <form action="/submitOneMulti/seleccionaClienteMarcacionPost" enctype="multipart/form-data" method="POST">

      <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione Columna Numero Celular : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
        <select class="form-control" name="columna_numero">
            $opciones
                                </select>
                            </div>
                        </div>

      <!--div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al operador de cada celular :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_operador">
                                    $operador
                                </select>
                            </div>
                        </div-->

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="ext" value="$ext" />
                        <input type="hidden" name="nombre_archivo" value="{$file_name}" />
                        <input type="hidden" name="customer_id" value="$customer" />
                        <input type="hidden" name="base_nombre" value="$baseNombre" />
                        <input type="hidden" name="base_guardar" value="$baseGuardar" />
                      </form>
                  </div>
                </div>
html;

        View::set('contenido',$html);
        View::render("submit_one_add");
  
    }

    public function seleccionaClienteMarcacionPost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $customer = MasterDom::getData('customer_id');
        $nombreArchivo = MasterDom::getData('nombre_archivo');
        $columnaOperador = MasterDom::getData('columna_operador');
        $columnaNumero = MasterDom::getData('columna_numero');
        $baseGuardar = MasterDom::getData('base_guardar');
        $baseNombre = MasterDom::getData('base_nombre');
        $ext = MasterDom::getData('ext');

        if(empty($customer) || empty($nombreArchivo) || /*$columnaOperador == '' ||*/ $columnaNumero == '' || (MasterDom::getSession('customer_id') != $customer))
            return MasterDom::alertas('error_general');

  $shortCode = CampaignDao::getCarrierCustomerGroup($customer);
        $shortCodeHtml = '';
        foreach($shortCode AS $k=>$value){
            $ids = CampaignDao::getCarrierCustomer($customer, $value['short_code_id']);
            if(empty($ids))
                continue;

                $disabled = ($k == 0) ? '' : 'disabled';
                $check = ($k == 0) ? 'checked="checked"' : '';

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Marcacion :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <label class="action">
                                    <input class="seleccion" value="_dato_{$k}" name="iCheck" $check type="radio"> {$value['short_code']}
                                </label>
                            </div>
                        </div>
                        <fieldset class="existente_valida_dato_{$k}" $disabled>
html;
            foreach($ids AS $val){

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;carrier :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <div class="checkbox">
                                    <label><input type="checkbox" class"carrier" name="carrier_connection_short_code_id[]" value="{$val['carrier_connection_short_code_id']}" checked="checked">{$val['name']}</label>
                                </div>
                            </div>
                        </div>
html;
            }
            $shortCodeHtml.=<<<html
                        </fieldset>
                        <br />
html;
        }

  $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Configuracion de Marcacion</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla podra seleccionar la marcacion por la cual va a salir el mensaje, puedes seleccionar los carriers para el envio.</p>
                    <div class="ln_solid"></div>
                    <form id="add" action="/submitOneMulti/seleccionaClienteNumerosPost" method="POST">

         $shortCodeHtml

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <a href="#" class="btn btn-success pull-right">Siguiente</a>
                        </div>
                      </div>
      <input type="hidden" name="ext" value="$ext" />
                        <input type="hidden" name="nombre_archivo" value="$nombreArchivo" />
                        <input type="hidden" name="customer_id" value="$customer" />
                        <input type="hidden" name="columna_numero" value="$columnaNumero" />
                        <input type="hidden" name="columna_operador" value="$columnaOperador" />
      <input type="hidden" name="base_nombre" value="$baseNombre" />
                        <input type="hidden" name="base_guardar" value="$baseGuardar" />
                      </form>
                  </div>
                </div>
html;

  $extraHeader=<<<html
<!-- DataTables CSS -->
  <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {
       $(".seleccion").on("change", function () {
                valor = $(this).val();
                $("fieldset[class*='existente_valida']").attr('disabled', 'disabled');
                $('.existente_valida'+ valor).removeAttr("disabled");
            });

      $('.btn-success').on("click",function() {
      var pivote = $(".seleccion:checked").val();
      var buscar = $(".existente_valida" + pivote + " input:checked")
      if(buscar.length == 0){
        bootbox.alert("Error: debes seleccionar por lo menos un carrier!");
    }else
        $( "#add" ).submit();
      }); 

        });
    </script>
html;

        View::set('contenido',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("submit_one_add");
    }

    public function seleccionaClienteNumerosPost(){

  if(!$_POST OR !MasterDom::whiteListeIp())
      return MasterDom::alertas('error_general');

  $customer = MasterDom::getData('customer_id');
  $nombreArchivo = MasterDom::getData('nombre_archivo');
  $columnaOperador = MasterDom::getData('columna_operador');
  $columnaNumero = MasterDom::getData('columna_numero');
  $carrierConnection = MasterDom::getDataAll('carrier_connection_short_code_id');
  $baseNombre = MasterDom::getData('base_nombre');
  $baseGuardar = MasterDom::getData('base_guardar');

  if(empty($customer) || empty($nombreArchivo) || /*$columnaOperador == '' ||*/ $columnaNumero == '' || (MasterDom::getSession('customer_id') != $customer) || empty($carrierConnection))
      return MasterDom::alertas('error_general');

  $carrierConnection = base64_encode(serialize($carrierConnection));

  $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    
    <script> 
      jQuery.validator.addMethod("isBadWord",function(value,element){
          texto  = $("#mensaje").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroMalasPalabras/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando palabras no permitidas."));


    jQuery.validator.addMethod("isDisableWord",function(value,element){
          texto  = $("#mensaje").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroCaracteresEspeciales/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
    }, jQuery.validator.format("Se estan usando caracteres especiales no permitidos."));


    jQuery.validator.addMethod("isBadWordNameCamp",function(value,element){
          texto  = $(":text").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroMalasPalabras/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando palabras no permitidas."));

      jQuery.validator.addMethod("isDisableWordNameCamp",function(value,element){
          texto  = $(":text").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroCaracteresEspeciales/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando caracteres especiales no permitidos."));

   
        $(document).ready(function() {
            
            $('#datetimepicker').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6],
                disabledHours: [0, 1, 2, 3, 4, 5, 6, 7, 8, 18, 19, 20, 21, 22, 23],
                enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17]
          });

      $("#add").validate(
                {
          ignore: "[disabled]",
                    rules: {
                        nombre_campania: {
                            isBadWordNameCamp:true,
                            isDisableWordNameCamp: true,
                            required: true,
                            maxlength: 60,
                            minlength: 3
                        },
                        mensaje: {
                            isBadWord: true,
                            isDisableWord: true,
                            required: true,
                            maxlength: 160,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 60",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        mensaje: {
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 160",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        datetimepicker: {
                            required: "Este campo es obligatorio"
                        }
                    }
      });

      setInterval(function(){ 
        $.get( "/submitOneMulti/getTime", function( data ) {
          $( "#fecha_sistema" ).html( data );
          });
        }, 1000);
      });
    </script>
html;

  $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Configuracion del mensaje a enviar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla podr&aacute; confeccionar el mensaje que desea enviar y programar la fecha en que se realizar&aacute; el env&iacute;o.</p>
                    <div class="ln_solid"></div>
                    <form id="add" action="/submitOneMulti/seleccionaClienteReportePost" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Nombre de la campaña : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
        <input type="text" class="form-control" placeholder="Nombre de Campaña" name="nombre_campania" id="nombre_campania">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Texto del Mensaje : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
        <textarea name="mensaje" id="mensaje" class="resizable_textarea form-control" placeholder="En la redacci&oacute;n del mensaje no es v&aacute;lido el uso de la letra “ñ”, s&iacute;mbolos o vocales acentuadas; El mensaje deber&aacute; ser mayor a 5 caracteres y menor de 160 caracteres. ..."></textarea>
                            </div>
                        </div>


      <div class="form-group row">
                            <label for="middle-name" class="control-label col-md-4 col-sm-4 col-xs-12">Fecha Lanzamiento :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <div class='input-group date' id='datetimepicker'>
                              <input type='text' class="form-control" name="datetimepicker" id='datetimepicker' />
                              <span class="input-group-addon">
                                  <span class="glyphicon glyphicon-calendar"></span>
                              </span>
            </div>
        <p class="help-block">Si no programas la fecha, la campaña se enviar&aacute; inmediatamente; Si la fecha es anterior a la actual, de igual manera se enviar&aacute; autom&aacute;ticamente.</p>
        <p class="help-block"><span id="fecha_sistema"></span></p>
          </div>
                        </div>

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="nombre_archivo" value="{$nombreArchivo}" />
                        <input type="hidden" name="customer_id" value="$customer" />
                        <input type="hidden" name="columna_numero" value="$columnaNumero" />
                        <input type="hidden" name="columna_operador" value="$columnaOperador" />
                        <input type="hidden" name="carrier_connection" value="$carrierConnection" />
                        <input type="hidden" name="base_guardar" value="$baseGuardar" />
                        <input type="hidden" name="base_nombre" value="$baseNombre" />
                      </form>
                  </div>
                </div>
html;
  
  View::set('contenido',$html);
  View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("submit_one_add");
    }

    public function getTime(){
  $fecha = date("Y-m-d H:i:s");
  echo '<b> La fecha del sistema actual es: '.$fecha.'</b>';
  exit;
    }

    public function seleccionaClienteReportePost(){

        $nombreCampania = MasterDom::getData('nombre_campania');
        $mensaje = MasterDom::getData('mensaje');
        $fecha = MasterDom::getData('datetimepicker');
        $customer = MasterDom::getData('customer_id');
        $nombreArchivo = MasterDom::getData('nombre_archivo');
        $columnaOperador = MasterDom::getData('columna_operador');
        $columnaNumero = MasterDom::getData('columna_numero');
        $carrierConnection = MasterDom::getData('carrier_connection');
        $carrierConnectionPost = $carrierConnection;
        $carrierConnection = unserialize(base64_decode($carrierConnection));
        $baseNombre = MasterDom::getData('base_nombre');
        $baseGuardar = MasterDom::getData('base_guardar');

      $extraFooter =<<<html
      <!-- jQuery Modal -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />

      <script>
      $( "#btnEnvio" ).click(function() {
        $( "#envioPost" ).submit();
        $( "#btnEnvio" ).hide();
      });

      $(document).ready(function()
      {
      $("#btnEnvioPrueba").click(function(){
        $.post("/SubmitOnePrueba/envioPruebaCampaign",
          {campania: "$nombreCampania", mensaje: "$mensaje", carrierConnection: "$carrierConnectionPost"},
          function(htmlexterno){
            $("#datosPrueba").html(htmlexterno);
            $("#btnEnvioPrueba").hide();
          });
        });
      });

      </script>
html;

      

  if(/*$columnaOperador == '' ||*/ $columnaNumero == '' || empty($nombreArchivo) || empty($customer) || empty($mensaje) || empty($nombreCampania) || (MasterDom::getSession('customer_id') != $customer))
      return MasterDom::alertas('error_general');

  $params = $this->procesoExcel($nombreArchivo, $columnaNumero, /*$columnaOperador,*/ $carrierConnection, $customer, $fecha);
  $noCarrier = count($params['noCarrier']);
  $blackList = count($params['blackList']);
    $nombreArchivo = ($params['nombreArchivo']);
  //busca carrier
        $msisdnBuscaCarrier = count($params['msisdnBuscaCarrier']);


  $base = '';
  if($baseGuardar == 'si'){
      $nombre = html_entity_decode($baseNombre);
      $base=<<<html
          <tr>
                          <td>Contactos para importar :</td>
                          <td>{$params['msisdnImportar']}</td>
                        </tr>   
      <tr>
                          <td>Nombre para guardar la base :</td>
                          <td>$nombre</td>
                        </tr>
html;
  }

  if($params['contactoEnvios']<=0){
    
    $resultado = 0;

    $valor = 'false';

    $botonEnvio =<<<html

          <input type="submit" class="btn btn-danger pull-right" value="No es posible realizar el env&iacute;o se excedido el l&iacute;mite">
html;

  $html=<<<html
      <form action="/SubmitOneMulti/envioPost" method="POST" > 
        <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripci&oacute;n</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>{$params['countMsisdn']}</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Cliente:</td>
                          <td>{$params['mesDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Cliente:</td>
                          <td>{$params['diaDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Usuario:</td>
                          <td>{$params['mesDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Usuario:</td>
                          <td>{$params['diaDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Limite por d&iacute;a:</td>
                          <td>{$params['diaLimite']}</td>
                        </tr>
                        <tr>
                          <td>Restantes por d&iacute;a:</td>
                          <td>{$params['Mensajes_Faltantes_Day_Usuario']}</td>
                        </tr>
                        <tr>
                          <td>Limite por mes:</td>
                          <td>{$params['mesLimite']}</td>
                        </tr>
                        <tr>
                          <td>Restantes por mes:</td>
                          <td>{$params['Mensajes_Faltantes_Month_Usuario']}</td>
                        </tr>
                          $base
                      </tbody>
                    </table>

                  </div>

          <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                               $botonEnvio
                          </div>
                        </div>

                </div>
              </div>

  <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
        <input type="hidden" value="$mensaje" name='mensaje'/>
        <input type="hidden" value="$fecha" name='datetimepicker'/>
        <input type="hidden" value="$customer" name='customer_id'/>
        <input type="hidden" name='nombreArchivo' value="$nombreArchivo" />
        <input type="hidden" value="$columnaOperador" name='columna_operador'/>
        <input type="hidden" value="$columnaNumero" name='columna_numero'/>
        <input type="hidden" value="$carrierConnectionPost" name='carrier_connection'/>
        <input type="hidden" value="$baseNombre" name='base_nombre'/>
        <input type="hidden" value="$baseGuardar" name='base_guardar'/>
        <input type="hidden" value="$valor" name='valor'/>
  </form>
html;
    
  } else{ // en caso contrario que el anterior no se cumpla se realizá el envío y muestra su descripción. esau

    $resultado = $params['contactoEnvios'];// + $msisdnBuscaCarrier;

    $valor = 'true';

    $botonEnvio =<<<html
      <input type="button" class="btn btn-success pull-right" value="Se realiza el env&iacute;o solamante a los contactos con operador v&aacute;lido" id="btnEnvio">
html;
    
    if ($params['msisdnSembrados'] > 0) {
      $botonEnvioPrueba =<<<html
            <input type="button" id="btnEnvioPrueba" class="btn btn-primary pull-left" value="Realizar env&iacute;o de prueba">      
html;
      $sembrados = $params['msisdnSembrados'];
    }else{
      $botonEnvioPrueba =<<<html
      <label><input type="button" name="no_envio" value="No tienes msisdn sembrados para enviar pruebas" class="btn btn-danger pull-left" ></label>
html;
      $sembrados = 0;
    }

    $resultado = $resultado + $sembrados;

  $html=<<<html
      <form action="/SubmitOneMulti/envioPost" method="POST" id="envioPost"> 
        <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripci&oacute;n</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>{$params['countMsisdn']}</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
      <!--busca carrier-->
                        <tr>
                          <td>Contactos para buscar carrier :</td>
                          <td>$msisdnBuscaCarrier</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Cliente:</td>
                          <td>{$params['mesDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Cliente:</td>
                          <td>{$params['diaDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Usuario:</td>
                          <td>{$params['mesDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Usuario:</td>
                          <td>{$params['diaDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Total de sembrados:</td>
                          <td>$sembrados</td>
                        </tr>
                        <tr>
                          <td>Total de mensajes por procesar:</td>
                          <td>$resultado</td>
                        </tr>
                          $base
                      </tbody>
                    </table>

                  </div>

          <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                               $botonEnvioPrueba
                          
                               $botonEnvio
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12" id="datosPrueba"></div>
                        </div>

                </div>
              </div>

        <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
        <input type="hidden" value="$mensaje" name='mensaje'/>
        <input type="hidden" value="$fecha" name='datetimepicker'/>
        <input type="hidden" value="$customer" name='customer_id'/>
        <input type="hidden" name='nombreArchivo' value="$nombreArchivo" />
        <input type="hidden" value="$columnaOperador" name='columna_operador'/>
        <input type="hidden" value="$columnaNumero" name='columna_numero'/>
        <input type="hidden" value="$carrierConnectionPost" name='carrier_connection'/>
        <input type="hidden" value="$baseNombre" name='base_nombre'/>
        <input type="hidden" value="$baseGuardar" name='base_guardar'/>
        <input type="hidden" value="$valor" name='valor'/>
  </form>
html;

  }

  /*$html=<<<html
      <form action="/SubmitOne/envioPost" method="POST"> 
        <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripci&oacute;n</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>{$params['countMsisdn']}</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Cliente:</td>
                          <td>{$params['mesDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Cliente:</td>
                          <td>{$params['diaDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Usuario:</td>
                          <td>{$params['mesDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Usuario:</td>
                          <td>{$params['diaDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Cantidad de contactos a los que se les realizar&aacute; el env&iacute;o :</td>
                          <td>$resultado</td>
                        </tr>
                          $base
                      </tbody>
                    </table>

                  </div>

          <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                               $botonEnvio
                          </div>
                        </div>

                </div>
              </div>

  <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
        <input type="hidden" value="$mensaje" name='mensaje'/>
        <input type="hidden" value="$fecha" name='datetimepicker'/>
        <input type="hidden" value="$customer" name='customer_id'/>
        <input type="hidden" name='nombreArchivo' value="$nombreArchivo" />
        <input type="hidden" value="$columnaOperador" name='columna_operador'/>
        <input type="hidden" value="$columnaNumero" name='columna_numero'/>
        <input type="hidden" value="$carrierConnectionPost" name='carrier_connection'/>
        <input type="hidden" value="$baseNombre" name='base_nombre'/>
        <input type="hidden" value="$baseGuardar" name='base_guardar'/>
        <input type="hidden" value="$valor" name='valor'/>
  </form>
html;*/

if (!empty($params)) {
    /**************************** Registro *************************/
    $registro = $this->registroUsuario("Envio en: seleccionaClienteReportePost");
    CampaignDao::registroUsuario($registro);
    /***************************************************************/
}
        View::set('footer',$this->_contenedor->footer($extraFooter));
        //View::set('modal',$modal);
        View::set('contenido',$html);
        View::render("submit_one_add"); 
    }

   
    public function envioPost(){

      $valor = MasterDom::getData('valor');

      if ($valor == 'false') {
          
          return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el env&iacute;o por sobrepasar el n&uacute;mero de mensajes permitidos.');

      }elseif ($valor == 'true') {
        
        $nombreCampania = MasterDom::getData('nombre_campania');
        $mensaje = MasterDom::getData('mensaje');
        $fecha = MasterDom::getData('datetimepicker');
        $customer = MasterDom::getData('customer_id');
        $nombreArchivo = MasterDom::getData('nombreArchivo');
        $columnaOperador = MasterDom::getData('columna_operador');
        $columnaNumero = MasterDom::getData('columna_numero');
        $carrierConnection = MasterDom::getData('carrier_connection');
        $carrierConnectionPost = $carrierConnection;
        $carrierConnection = unserialize(base64_decode($carrierConnection));
        $baseNombre = MasterDom::getData('base_nombre');
        $baseGuardar = MasterDom::getData('base_guardar');

        if(/*$columnaOperador == '' ||*/ $columnaNumero == '' || empty($nombreArchivo) || empty($customer) || empty($mensaje) || empty($nombreCampania) || (MasterDom::getSession('customer_id') != $customer))
            return MasterDom::alertas('error_general');
        /*else {echo "entró";}
        exit();*/

        $params = $this->procesoExcelEnvio($nombreArchivo, $columnaNumero, /*$columnaOperador,*/ $carrierConnection, $customer, $carrierConnection, $nombreCampania, $mensaje, $fecha, $baseNombre, $baseGuardar);
        $noCarrier = count($params['noCarrier']);
        $blackList = count($params['blackList']);

      }
        
    }

    private function procesoExcel($nombreArchivo, $columnaNumero, /*$columnaOperador,*/ $carrierConnection, $customer, $fecha){

        $old_date_timestamp = strtotime($fecha);
        $fecha = date('Y-m-d H:i:s', $old_date_timestamp);

  /****************************************************/

      $msisdn = array();
        $archivosZip = explode('{',$nombreArchivo);
        foreach ($archivosZip as $key => $value) {
            if ($value!='') {  
                $msisdn = $this->leerArchivo($msisdn,$value, $columnaNumero, /*$columnaOperador,*/ $carrierConnection, $customer);
            }
        }

  $carrierIds = '';
        foreach($carrierConnection AS $value){
            $carrierIds .= "$value,";
        }
        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = CampaignDao::findCarriers($carrierIds);
        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

        $buscaCarrier = function($valor) use($carrierIdsArray){
            $retorno['status'] = false;
            foreach($carrierIdsArray AS $value){
                if(strtolower($value['name']) == strtolower($valor)){
                    $retorno['status'] = true;
                    $retorno['country_code'] = $value['country_code'];
                    $retorno['carrier_connection_id'] = $value['carrier_connection_id'];
                    $retorno['white_list'] = ($value['white_list'] == 'enable' ) ? true : false;
                    $retorno['carrier_id'] = $value['carrier_id'];
                    $retorno['short_code_id'] = $value['short_code_id'];
                    $retorno['carrier_connection_short_code_id'] = $value['carrier_connection_short_code_id'];
                    $retorno['short_code'] = $value['short_code'];
                    break;
                }
            }
            return $retorno;
        };

        $noCarrier = array();
        $blackList = array();
        $msisdnCorrecto = array();
  //busca carrier
        $msisdnBuscaCarrier = array();
        // msisdn multicarrier
        foreach($msisdn AS $value){
           $carrier = ($value['carrier'] == '') ? '' : $value['carrier'];
           $carrier = strtolower($carrier);
           $buscaCarrierValue = $buscaCarrier($carrier);
           $countryCode = ($buscaCarrierValue['country_code'] > 0) ? $buscaCarrierValue['country_code'] : '52';
  
     //busca carrier
           if($carrier == 'carrier' || $carrier == 'CARRIER'){
                array_push($msisdnBuscaCarrier, array('msisdn' =>$countryCode.$value['msisdn']));
                continue;
           }

           /*if(empty($carrier) || $buscaCarrierValue['status'] === false){
                array_push($noCarrier, array('msisdn' =>$countryCode.$value['msisdn']));
                continue;
           }*/

           if($carrier == 'telcel' || $carrier == 'att' || $carrier == 'movistar'){
                $black = CampaignDao::findBlackList($countryCode.$value['msisdn'], $carrier);
                if($black['number'] != ''){
                    array_push($blackList, array('msisdn'=>$countryCode.$value['msisdn']));
                    continue;
                }
           }

           array_push($msisdnCorrecto, array('msisdn'=>$countryCode.$value['msisdn'], 'carrier_connection_id'=>$buscaCarrierValue['carrier_connection_id'],
                                                'white_list'=>$buscaCarrierValue['white_list'], 'carrier_id'=>$buscaCarrierValue['carrier_id'],
                                                'short_code_id'=>$buscaCarrierValue['short_code_id'],
                                                'carrier_connection_short_code_id'=>$buscaCarrierValue['carrier_connection_short_code_id']));
        }

        $contactosImportar = count($msisdnCorrecto);

        /* Agregamos los msisdn de prueba */
        $sembrados = CampaignDao::getSembrados(MasterDom::getSession('customer_id'));
        if (!empty($sembrados)) {
          $msisdnSembrados = array();
          foreach ($sembrados as $key => $value) {
            array_push($msisdnSembrados, array(
            'msisdn'=>$value['msisdn'],
            'carrier_connection_id'=>$value['carrier_connection_id'],
            'white_list'=>$value['white_list'], 
            'carrier_id'=>$value['carrier_id'],
            'short_code_id'=>$value['short_code_id'],
            'carrier_connection_short_code_id'=>$value['carrier_connection_short_code_id'],
            'msisdn_id'=>$value['msisdn_id']));
          }

          //$msisdnCorrecto = array_merge($msisdnCorrecto,$msisdnSembrados);
        }
        

        

        // Inicia cambios esau
        /** Primero buscar si el usuario tiene mt por dia, despues por mes.
        *   continua buscando con el customer por dia y seguidamente por mes.
        **/        
        //$countMensajes = count($msisdnCorrecto);
  //busca carrier
        $merge = array_merge($msisdnCorrecto,$msisdnBuscaCarrier);
        $countMensajes = count($merge);

        //echo "total_mensajes:$countMensajes \n";
        ##### Datos de usuario por dia #####
        $usuarioDataDia = CampaignDao::getTotalesUserDia(MasterDom::getSession('id_user'));
        $Mensajes_Faltantes_Day_Usuario = $usuarioDataDia['resta_dia'];

        if ($countMensajes > $Mensajes_Faltantes_Day_Usuario) {
          $sms_cut_dia_usuario = $countMensajes - $Mensajes_Faltantes_Day_Usuario;
        }
        else{
          $sms_cut_dia_usuario = 0;
        }

        ##### Datos de usuario por mes ####
        $usuarioDataMes = CampaignDao::getTotalesUserMes(MasterDom::getSession('id_user'));

        $Mensajes_Faltantes_Month_Usuario = $usuarioDataMes['resta_mes'];

        if ($countMensajes > $Mensajes_Faltantes_Month_Usuario) {
          $sms_cut_mes_usuario = $countMensajes - $Mensajes_Faltantes_Month_Usuario;
        }
        else{
          $sms_cut_mes_usuario = 0;
        }

        ##### Datos de customer por dia #####
        $customerDataDia = CampaignDao::getTotalesCustomerDia($customer);
        
        $Mensajes_Faltantes_Day_Customer = $customerDataDia['resta_dia'];
        if ($countMensajes > $Mensajes_Faltantes_Day_Customer) {
          $sms_cut_dia_customer = $countMensajes - $Mensajes_Faltantes_Day_Customer;
        }
        else{
          $sms_cut_dia_customer = 0;
        }

        $customerDataMes = CampaignDao::getTotalesCustomerMes($customer);
        
        $Mensajes_Faltantes_Month_Customer = $customerDataMes['resta_mes'];
        if ($countMensajes > $Mensajes_Faltantes_Month_Customer) {
          $sms_cut_mes_customer = $countMensajes - $Mensajes_Faltantes_Month_Customer;
        }
        else{
          $sms_cut_mes_customer = 0;
        }
        
        if ($sms_cut_dia_usuario > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_mes_usuario > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_dia_customer > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_mes_customer > 0) {
          $contactoEnvios = 0;
        }
        else{
          $contactoEnvios = count($merge);
        }

        if(!empty($msisdnSembrados))
          $contactoEnvios = $contactoEnvios;/* + count($msisdnSembrados);*/


          $params = array(
              'msisdnCorrecto'=>$merge,
              'blackList'=>$blackList,
              'noCarrier'=>$noCarrier,
              'msisdnBuscaCarrier'=>$msisdnBuscaCarrier,
              'diaLimite'=>$usuarioDataDia['max_mt_day'],
              'mesLimite'=>$usuarioDataMes['max_mt_month'],
              'countMsisdn'=>count($merge), //para importar
              'diaDiferencia'=>$sms_cut_dia_customer, //bloqueados máximo de envios diario x Cliente:
              'mesDiferencia'=>$sms_cut_mes_customer, //bloqueados máximo de envios mensual x Cliente:
              'diaDiferenciaU'=>$sms_cut_dia_usuario, //bloqueados máximo de envios diario x Usuario:
              'mesDiferenciaU'=>$sms_cut_mes_usuario, //bloqueados máximo de envios mensual x Usuario:
              'contactoEnvios'=>$contactoEnvios,// este parametro determinara si el envío se realiza
              'Mensajes_Faltantes_Month_Usuario'=>$Mensajes_Faltantes_Month_Usuario,
              'Mensajes_Faltantes_Day_Usuario'=>$Mensajes_Faltantes_Day_Usuario,
              'Mensajes_Faltantes_Month_Customer'=>$Mensajes_Faltantes_Month_Customer,
              'Mensajes_Faltantes_Day_Customer'=>$Mensajes_Faltantes_Day_Customer,
              'nombreArchivo'=>$nombreArchivo,
              'msisdnSembrados'=>count($msisdnSembrados),
              'msisdnImportar'=>$contactoEnvios
            );

      //fin de cambios esau parte de envio sin guardar la base

  return $params;
    }


     /*************************************** METODO PARA OBTENER EL NUMERO Y CARRIER DE UN ARCHIVO YA SEA EXCEL O CSV ***************************************/
    public static function leerArchivo($msisdn = array(),$nombreArchivo, $columnaNumero, /*$columnaOperador,*/ $carrierConnection, $customer){

        $ext = pathinfo($nombreArchivo, PATHINFO_EXTENSION);


        if($ext == 'xls' || $ext == 'xlsx'){
            $msisdnArray = json_decode(MasterDom::procesoExcel('completeArray', $nombreArchivo, true),1);
            //print_r($msisdnArray);
            //echo $msisdnArray[2][B];
            /*$recorrido = '';
            foreach ($msisdnArray as $key => $value) {
              $recorrido .= $key;
              if ($key >= 2) {
                if($msisdnArray[$key][A] != (array('0','1','2','3','4','5','6','7','8','9'))) {
                  return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el env&iacute;o.');
                }else{
                  continue;
                }

                if ($msisdnArray[$key][B] !== (array('0','1','2','3','4','5','6','7','8','9'))) {
                  return MasterDom::alertas('personal','/submitOneMulti/seleccionaCliente', 'Error', 'Se cancel&oacute; el env&iacute;o.');
                }else{
                  continue;
                }
              }else {
                continue;
              }
            }*/
            //print_r($recorrido);

            foreach($msisdnArray AS $key=>$value){ 
                if($value[$columnaNumero] == '' || $key == 1)
                    continue;
                    if ( !(preg_match('/^\d{10}$/',trim($value[$columnaNumero]))))
                        continue;
                        array_push($msisdn,array('msisdn'=>$value[$columnaNumero]/*, 'carrier'=>$value[$columnaOperador]*/));
                }
        }elseif($ext == 'csv'){
            $arch = MasterDom::$_target.$nombreArchivo;
            $acum = 0;
            //$columnaNumero = SubmitOne::convertirIndice($columnaNumero);
            //$columnaOperador = SubmitOne::convertirIndice($columnaOperador);

            if (($fichero = fopen($arch, "r")) !== FALSE) { 
                while (($value = fgetcsv($fichero)) !== FALSE) {
                    $acum += 1;
                    if($acum == 1){continue;}
                    if(!(preg_match('/^\d{10}$/',trim($value[$columnaNumero])))){continue;}
                    array_push($msisdn,array('msisdn'=>$value[$columnaNumero]/*, 'carrier'=>$value[$columnaOperador]*/));
                }
                fclose($fichero);
            }else{
                return MasterDom::alertas('error_general');
            }
        }else{
            return MasterDom::alertas('error_general');
        }
        return $msisdn;
    }

    public static function convertirIndice($indice = ""){
        $abecedario = array('A','B','C','D','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        foreach ($abecedario as $key => $value) {
            if($value==$indice) return $key;
        }
    }

    private function procesoExcelEnvio($nombreArchivo, $columnaNumero/*, $columnaOperador*/, $carrierConnection, $customer, $carrierConnection, $nombreCampania, $mensaje, $fechaOld, $baseNombre, $baseGuardar){

  $old_date = date('m/d/Y g:i a');          
  $old_date_timestamp = strtotime($fechaOld);
  $fecha = date('Y-m-d H:i:s', $old_date_timestamp);

        /*print_r($nombreArchivo);
        echo "<br />";
        print_r($columnaNumero);
        echo "<br />";
        print_r($columnaOperador);
        echo "<br />";
        print_r($carrierConnection);
        echo "<br />";
        print_r($customer);
        echo "<br />";
        print_r($carrierConnection);
        echo "<br />";
        print_r($nombreCampania);
        echo "<br />";
        print_r($mensaje);
        echo "<br />";
        print_r($fecha);
        echo "<br />";
        print_r($baseNombre);
        echo "<br />";
        print_r($baseGuardar); 
        echo "<br />";
        exit();*/

  $customerArray = CampaignDao::getCustomerMt($customer);

  //print_r($customerArray);

        if(empty($customerArray))
            return MasterDom::alertas('error_general');

  $ext = pathinfo($nombreArchivo, PATHINFO_EXTENSION);

        /*print_r($customerArray);
        echo "<br />";
        print_r($ext);
        echo "<br />";
        print_r($nombreArchivo);
        echo "<br />";
        exit();*/

        $msisdn = array();
        $archivosZip = explode('{',$nombreArchivo);
        foreach ($archivosZip as $key => $value) {
            if ($value!='') {  
                $msisdn = $this->leerArchivo($msisdn,$value, $columnaNumero,/* $columnaOperador,*/ $carrierConnection, $customer);
            }
        }

        /*print_r($msisdn);
        echo "<br />";
        print_r(count($msisdn));
        exit(); */

/*
        $msisdnArray = json_decode(MasterDom::procesoExcel('completeArray', $nombreArchivo, true),1);
        $msisdn = array();
        foreach($msisdnArray AS $key=>$value){
            if($value[$columnaNumero] == '' || $key == 1)
                continue;
            if ( !(preg_match('/^\d{10}$/',trim($value[$columnaNumero]))))
                    continue;
            array_push($msisdn, array('msisdn'=>$value[$columnaNumero], 'carrier'=>$value[$columnaOperador]));
        }
*/

        $carrierIds = '';
        foreach($carrierConnection AS $value){
            $carrierIds .= "$value,";
        }

        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = CampaignDao::findCarriers($carrierIds);
        /*print_r($carrierIdsArray);
        exit;*/

        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

        $buscaCarrier = function($valor) use($carrierIdsArray){
            $retorno['status'] = false;
            foreach($carrierIdsArray AS $value){
                if(strtolower($value['name']) == strtolower($valor)){
                    $retorno['status'] = true;
                    $retorno['country_code'] = $value['country_code'];
                    $retorno['carrier_connection_id'] = $value['carrier_connection_id'];
                    $retorno['white_list'] = ($value['white_list'] == 'enable' ) ? true : false;
                    $retorno['carrier_id'] = $value['carrier_id'];
                    $retorno['short_code_id'] = $value['short_code_id'];
                    $retorno['carrier_connection_short_code_id'] = $value['carrier_connection_short_code_id'];
                    $retorno['short_code'] = $value['short_code'];
                    break;
                }
            }
            return $retorno;
        };

        //echo "<br />";
        //print_r($buscaCarrier);
        //exit();

        $noCarrier = array();
        $blackList = array();
        $msisdnCorrecto = array();
  //busca carrier
        $msisdnBuscaCarrier = array();
        foreach($msisdn AS $value){
           $carrier = ($value['carrier'] == '') ? '' : $value['carrier'];
           $carrier = strtolower($carrier);
           $carrier = ($carrier=='') ? 'multicarrier' : $value['carrier'];
           $buscaCarrierValue = $buscaCarrier($carrier);
           $countryCode = ($buscaCarrierValue['country_code'] > 0) ? $buscaCarrierValue['country_code'] : '52';

     //busca carrier
           if($carrier == 'carrier' || $carrier == 'CARRIER'){
                array_push($msisdnBuscaCarrier, array('msisdn' =>$countryCode.$value['msisdn'], 'carrier_id'=>0,
                                                'carrier_connection_short_code_id'=>-1, 'contenido'=>$value['contenido']));
                continue;
           }

           /*if(empty($carrier) || $buscaCarrierValue['status'] === false){
                array_push($noCarrier, array('msisdn' =>$countryCode.$value['msisdn'], 'carrier_id'=>-1,
            'carrier_connection_short_code_id'=>-1));
                continue;
           }*/
           if($carrier == 'telcel' || $carrier == 'att' || $carrier == 'movistar'){
                $black = CampaignDao::findBlackList($countryCode.$value['msisdn'], $carrier);
                if($black['number'] != ''){
                    array_push($blackList, array('msisdn'=>$countryCode.$value['msisdn'], 'carrier_id'=>$buscaCarrierValue['carrier_id'],
            'carrier_connection_short_code_id'=>$buscaCarrierValue['carrier_connection_short_code_id']));
                    continue;
                }
           }

           array_push($msisdnCorrecto, array('msisdn'=>$countryCode.$value['msisdn'], 'carrier_connection_id'=>$buscaCarrierValue['carrier_connection_id'], 
            'white_list'=>$buscaCarrierValue['white_list'], 'carrier_id'=>$buscaCarrierValue['carrier_id'],
            'short_code_id'=>$buscaCarrierValue['short_code_id'],
            'carrier_connection_short_code_id'=>$buscaCarrierValue['carrier_connection_short_code_id']));
        }

        //echo "<br />";
        /*print_r($msisdnCorrecto);
        echo "<br />";
        print_r($msisdnBuscaCarrier);
        exit();*/

        /*$customerArray = CampaignDao::getCustomerMt($customer);
        if(empty($customerArray))
            return MasterDom::alertas('error_general');

        $diaL = $customerArray['max_mt_day'];
        $mesL = $customerArray['max_mt_month'];

        $arrayDia = CampaignDao::getDiaCustomer($customer,$fecha);
        $diaA = ($arrayDia['suma'] == '') ? 0 : $arrayDia['suma'];

        $arrayMes = CampaignDao::getMesCustomer($customer,$fecha);
        $mesA = ($arrayMes['suma'] == '') ? 0 : $arrayMes['suma'];*/

        /* Agregamos los msisdn de prueba */
        $sembrados = CampaignDao::getSembrados(MasterDom::getSession('customer_id'));
        if (!empty($sembrados)) {
          $msisdnSembrados = array();
          foreach ($sembrados as $key => $value) {
            array_push($msisdnSembrados, array(
            'msisdn'=>$value['msisdn'],
            'carrier_connection_id'=>$value['carrier_connection_id'],
            'white_list'=>$value['white_list'], 
            'carrier_id'=>$value['carrier_id'],
            'short_code_id'=>$value['short_code_id'],
            'carrier_connection_short_code_id'=>$value['carrier_connection_short_code_id'],
            'msisdn_id'=>$value['msisdn_id']));
          }

          //$msisdnCorrecto = array_merge($msisdnCorrecto,$msisdnSembrados);
        }
        

        //$count = count($msisdnCorrecto);
        //$merge = array_merge($msisdnCorrecto,$msisdnBuscaCarrier);
        //$msisdnCorrecto = $merge;
        //$count = count($msisdnCorrecto) + count($msisdnBuscaCarrier);
        /*$diaD = (($count + $diaA) > $diaL) ? ($count + $diaA) - $diaL : 0;
        $mesD = (($count + $mesA) > $mesL) ? ($count + $mesA) - $mesL : 0;

        $idUser = $_SESSION['id_user'];
        $userDia = CampaignDao::getViewUserDia($idUser, $fecha);
        $userMes = CampaignDao::getViewUserMes($idUser, $fecha);

        $diaDU = ((($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) > $userDia['Max_Mt_Day_Usuario']) ? (($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) - $userDia['Max_Mt_Day_Usuario'] : 0;
        $mesDU = ((($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) > $userMes['Max_Mt_Month_Usuario']) ? (($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) - $userMes['Max_Mt_Month_Usuario'] : 0;


        if($mesD == 0 && $diaD == 0 && $mesDU == 0 && $diaDU == 0){
          $var = $count;
          } elseif ($mesD > 0 || $diaD > 0 || $mesDU > 0 || $diaDU > 0) {
          if ($mesD >= 1 && $mesD >= $diaD && $mesD >= $mesDU && $mesD >= $diaDU) {
            $var = abs($count-$mesD);
          } elseif (($diaD >= 1 && $mesD == 0 && $mesDU == 0 && $diaDU == 0) || ($diaD >= 1 && $mesD == 0) || ($diaD > $mesD)) {
            $var = abs($count-$diaD);
          } elseif (($mesDU >= 1 && $mesD == 0 && $diaD == 0 && $diaDU == 0) || ($mesDU > $diaDU)) {
            $var = abs($count-$mesDU);
          } elseif (($diaDU >= 1 && $mesDU == 0 && $mesD == 0 && $diaD == 0) || ($diaDU > $mesDU) || ($diaDU == $mesDU)) {
            $var = abs($count-$diaDU);
          } else {
            $var = "Warning";
          }
        } else {
          $var = "ERROR SISTEMA";
        }*/

        //echo "<br />";
        //print_r($var);
        //exit();

  /*$msisdnCut = array_chunk($msisdnCorrecto,$var);
  $msisdnCorrecto = $msisdnCut[0];*/
  //$msisdnCorrecto = $merge;

  $campaniaId = CampaignDao::insertaCampaniaIni($nombreCampania, 4, $fecha, 2);
  if($campaniaId < 1)
            return MasterDom::alertas('error_general');

  $userId = MasterDom::getSession('id_user');
  $campUser = CampaignDao::insertCampaignUser($userId, $campaniaId);
        if($campUser < 1)
            return MasterDom::alertas('error_general');

  $campCustomer = CampaignDao::insertaCampaniaCustomer($customer, $campaniaId);
  if($campCustomer < 1)
            return MasterDom::alertas('error_general');

  /*echo "Hola";
  echo "<br />";
  print_r($carrierIdsArray);
  echo "<br />";
  print_r($campaniaId);
  exit();*/

  foreach($carrierIdsArray AS $key=>$value){
      if(CampaignDao::insertaCampaniaCarrierShortCode($campaniaId, $value['carrier_id'], 
      $value['short_code_id']) < 1)
    return MasterDom::alertas('error_general');

      if(CampaignDao::insertaCarrierConnectionShortCodeCampaign($campaniaId, $value['carrier_connection_short_code_id']) < 1)
    return MasterDom::alertas('error_general');
  }

  /*
  $organizaMsisdn = function($array){
      foreach($array AS $key=>$value){
    $carrier = ($value['carrier_id'] == '' ) ? -1 : $value['carrier_id'];
              $id = CampaignDao::insertaMsisdn($value['msisdn'], $value['carrier_id']);
              if($id == false){
                    $map = CampaignDao::getMsisdnCatalogo($value['msisdn'], $carrier);
                    if($map['msisdn'] != '')
                      $id = $map['msisdn_id'];
                    else{
                      $id = CampaignDao::insertaMsisdn($value['msisdn'], -1);
                      unset($array[$key]);
                      array_push($noCarrier, array('msisdn' =>$value['msisdn'], 'msisdn_id'=>$id));
                      continue;
                    }
              }
              $array[$key]['msisdn_id'] = $id;
            }

      return $array;
        };
  */
  //busca carrier Correcto
        $organizaMsisdn = function($array){
            foreach($array AS $key=>$value){
                $carrier = ($value['carrier_id'] == '' ) ? -1 : $value['carrier_id'];
                $map = CampaignDao::getMsisdnCatalogoBuscaCarrier($value['msisdn']);
                    if($map['msisdn'] > 0 AND $map['carrier_id'] == $carrier){ // msisdn y carrier_id son iguales en la tabla msisdn
                        $id = $map['msisdn_id'];
                     }elseif($map['msisdn'] > 0 AND ($map['carrier_id'] == '-2' OR $map['carrier_id'] == '0')){ // cuando msisdn existe y esta buscando carrier
                        $id = $map['msisdn_id'];
                     }elseif($map['msisdn'] > 0 AND $map['carrier_id'] == '-1'){ // cuando msisdn existe y carrier_id esta sin carrier, updeteamos para buscar carrier
                        $id = $map['msisdn_id'];
                        @CampaignDao::updateMsisdnBuscaCarrier($id);
                     }elseif($map['msisdn']>0){ // cuando existe msisdn pero esta con carrier diferente
                        $id = $map['msisdn_id'];
                     }else{ // cuando el msisdn no existe
                        $id = CampaignDao::insertaMsisdn($value['msisdn'], $carrier);
                        /*
                        unset($array[$key]);
                        array_push($noCarrier, array('msisdn' =>$value['msisdn'], 'msisdn_id'=>$id));
                        continue;
                        */
                     }

                $array[$key]['msisdn_id'] = $id;
            }

            return $array;
        };

  //busca carrier
        $organizaMsisdnCarrier = function($array){
            foreach($array AS $key=>$value){
                $carrier = ($value['carrier_id'] == '' ) ? -1 : $value['carrier_id'];
                $map = CampaignDao::getMsisdnCatalogoBuscaCarrier($value['msisdn']);
                    if($map['msisdn'] > 0 AND $map['carrier_id'] >= 0){ // cuando el msisdn y carrier_id existe
                        $id = $map['msisdn_id'];
                     }elseif($map['msisdn'] > 0 AND $map['carrier_id'] == '-2'){ // cuando msisdn existe y esta procesando busca carrier
                        $id = $map['msisdn_id'];
                     }elseif($map['msisdn'] > 0 AND $map['carrier_id'] == '-1'){ // cuando msisdn existe y cambia a buscar carrier
                        $id = $map['msisdn_id'];
                        @CampaignDao::updateMsisdnBuscaCarrier($id);
                     }elseif ($map['msisdn_id'] > 0) { // cuando existe msisdn pero esta con carrier diferente
                        $id = $map['msisdn_id'];
                     }else{
                        $id = CampaignDao::insertaMsisdn($value['msisdn'], 0);
                     }

                $array[$key]['msisdn_id'] = $id;
            }

            return $array;
        };

  $msisdnCorrecto = $organizaMsisdn($msisdnCorrecto);
  $blackList = $organizaMsisdn($blackList);
  $noCarrier = $organizaMsisdn($noCarrier);
  $msisdnBuscaCarrier = $organizaMsisdnCarrier($msisdnBuscaCarrier);

  /*print_r($msisdnCorrecto);
  echo "---->";
  print_r($msisdnBuscaCarrier);

  exit;*/

  /*foreach ($msisdnSembrados as $key => $value) {
      $clave=array_search($value,$msisdnCorrecto);
        unset($msisdnCorrecto[$clave]);
  }

  foreach ($msisdnSembrados as $key => $value) {
      $clave=array_search($value,$msisdnBuscaCarrier);
        unset($msisdnBuscaCarrier[$clave]);
  }*/
  /*foreach ($msisdnSembrados as $key => $value) {
    if ($clave=array_search($value,$msisdnCorrecto)) {
      print_r('clave:'.$clave);
      unset($msisdnCorrecto[$clave]);
    }
  }*/
  /*print_r($msisdnCorrecto);
  exit;*/
  /*echo "array diff -->";
  $msisdnGuardar = array_diff_assoc($msisdnCorrecto,$msisdnSembrados);
  print_r($msisdnGuardar);
  exit(); */
  
  $base = '';
        if($baseGuardar == 'si'){
            $nombre = MasterDom::acentosHtml($baseNombre);
      if($nombre == '')
    $nombre = uniqid();

      $clientId = CampaignDao::insertaClient($nombre, 1);
      if($clientId < 1)
              return MasterDom::alertas('error_general');

      $customerClientId = CampaignDao::insertaCustomerClient($customer, $clientId);
      if($customerClientId < 1)
                return MasterDom::alertas('error_general');

      if (!empty($msisdnCorrecto)) {
        foreach($msisdnCorrecto AS $key => $value){
            @CampaignDao::insertaClientMsisdn($clientId, $value['msisdn_id']);
        }
      }

      if (!empty($msisdnBuscaCarrier)) {
        foreach ($msisdnBuscaCarrier as $key => $value) {
          @CampaignDao::insertaClientMsisdn($clientId, $value['msisdn_id']);
        }
      }

      /*foreach($msisdnBuscaCarrier AS $key=>$value){
              foreach ($msisdnSembrados as $k => $val) {
                if ($val['msisdn'] == $value['msisdn']) {
                  continue;
                }else{
                  @CampaignDao::insertaClientMsisdn($clientId, $value['msisdn_id']);
                }
              }
            }*/
        }
  
  $msisdnErrores = array();
  foreach($msisdnCorrecto AS $key=>$value){
      $whiteList = 4;
      $estatusWhite = false;
      if($value['white_list']){
    $dataWhite = CampaignDao::getMsisdnWhiteList($value['msisdn_id'], $value['carrier_connection_id']);
    if($dataWhite['status'] == 1)
        $whiteList = 4;
    elseif($dataWhite['status'] == ''){
        $estatusWhite = true;
        $whiteList = 3;
    }elseif ($dataWhite['status'] == 3) {
        $whiteList = 13;
    }else
        $whiteList = 4;
      }

      if(CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], $value['carrier_connection_short_code_id'], $whiteList, 4, $mensaje) < 1)
    array_push($msisdnErrores, array('msisdn'=>$value['msisdn'], 'msisdn_id'=>$value['msisdn_id']));

      if($value['white_list'] AND ($estatusWhite === true)){
    @CampaignDao::insertMsisdnWhiteList($value['msisdn_id'], $value['carrier_connection_id'], 0);
      }
  }

  foreach($blackList AS $key=>$value)
      @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], $value['carrier_connection_short_code_id'], 2, 4, $mensaje);

  //busca carrier
        foreach($msisdnBuscaCarrier AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], $value['carrier_connection_short_code_id'], 10, 4, $mensaje);

  foreach($noCarrier AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], -1, 1, 4, $mensaje);  

  foreach($msisdnErrores AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], -1, 7, 4, $mensaje);

  @CampaignDao::estatusCampaign($campaniaId, 3);
  
  $campaniaSecurity = MasterDom::setParamSecure($campaniaId); 
  header("Location: /SubmitOneMulti/campaignStatus/$campaniaSecurity");
  exit();
    }

    public function campaignStatus($campania){

  $customer = MasterDom::getSession('customer_id');

        if(empty($customer))
            return MasterDom::alertas('error_general');
  
  $campania = MasterDom::getParamSecure($campania);
  $campania = (int)$campania;
  if($campania == '')
            return MasterDom::alertas('error_general');

  $dataCampaign = CampaignDao::campaignCustomerEstatus($customer, $campania);
  if($dataCampaign['customer_id'] == '')
      return MasterDom::alertas('error_general');

  $datosCampaign = CampaignDao::campaignCustomerEstatusMts($campania);
  if(empty($dataCampaign))  
      return MasterDom::alertas('error_general');

  if ($customer != '' && $campania != '' && $dataCampaign != '' && $datosCampaign != '') {
    /**************************** Registro *************************/
    $registro = $this->registroUsuario("Campania _{$campania}_ enviada: campaignStatus");
    CampaignDao::registroUsuario($registro);
    /***************************************************************/
  }

  $blackList = 0;
  $totalMensajes = 0;
  $noCarrier = 0;
  $envioWhiteList = 0;
  $procesoWhiteList = 0;
  $preparadoParaEnvio = 0;
  $encolado = 0;
  $notelcel = 0;
  $eppsencolado = 0;
  $errorwl = 0;
  $bcarrier = 0;
  $bbcarrier = 0;

  foreach($datosCampaign AS $key=>$value){

      if($value['estatus'] == 'blacklist')
    $blackList = $value['marcadores'];

      if($value['estatus'] == 'sin carrier')
    $noCarrier = $value['marcadores'];

      if($value['estatus'] == 'envio white list')
    $envioWhiteList = $value['marcadores'];

      if($value['estatus'] == 'proceso white list')
    $procesoWhiteList = $value['marcadores'];

      if($value['estatus'] == 'preparado para envio')
    $preparadoParaEnvio = $value['marcadores'];

      if($value['estatus'] == 'encolado')
    $encolado = $value['marcadores']; 

      if($value['estatus'] == 'no telcel')
        $notelcel = $value['marcadores'];

      if($valie['estatus'] == 'en proceso por ser encolado')
        $eppsencolado = $value['marcadores'];

      if($value['estatus'] == 'error white list')
        $errorwl = $value['marcadores'];

      if($value['estatus'] == 'busca carrier')
        $bcarrier = $value['marcadores'];

      if($value['estatus'] == 'buscando carrier')
        $bbcarrier = $value['marcadores'];
  
      if($value['estatus'] != 'blacklist' AND $value['estatus'] != 'sin carrier' AND $value['estatus'] != 'error')
    $totalMensajes += $value['marcadores'];
  }

  $porcentajeMt = (($envioWhiteList+$procesoWhiteList+$preparadoParaEnvio+$encolado + $notelcel + $eppsencolado + $errorwl + $bcarrier + $bbcarrier) / $totalMensajes) * 100;

  $html=<<<html
       <div class="page-title">
              <div class="title_left">
                <h3>Reporte <small>Envio</small></h3>
              </div>
 
            </div>
       <div class="row">
     <div class="x_content">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripcion</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Total de mensajes x enviar :</td>
                          <td>$totalMensajes</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
    

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
                  <div class="x_title">
                    <h2>Encolados listo para envio</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
            <div class="progress">
                  <div class="progress-bar" style="width: $porcentajeMt%;">
                 $porcentajeMt%
               </div>
              </div>
           </div>
        </div>
     </div>
<!--
     <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>White List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="progress">
                        <div class="progress-bar" style="width: 60%;">
                         60%
                       </div>
                    </div>
                 </div>
              </div>
           </div>
-->

    </div>
html;

  View::set('contenido',$html);
        View::render("submit_one_add"); 
    }

    private function baseExistenteData($baseExistente){


  $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general'); 
  $validate = CampaignDao::validateCustomerCliente($customer, $baseExistente);



  if(empty($validate))
      return MasterDom::alertas('error_general');

  $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Configuracion del mensaje a enviar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla podra confeccionar el mensaje que desea enviar y programar la fecha en que se realizara el env&iacute;o.</p>
                    <div class="ln_solid"></div>
                    <form id="add" action="/submitOneMulti/seleccionaClienteMarcacionExitentePost" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Nombre de la campaña : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" class="form-control" placeholder="Nombre de Campaña" name="nombre_campania" id="nombre_campania">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Texto del Mensaje : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <textarea name="mensaje" id="mensaje" class="resizable_textarea form-control" placeholder="En la redacción del mensaje no es válido el uso de la letra “ñ”, símbolos o vocales acentuadas El mensaje debera ser mayor a 5 caracteres y menor de 160 caracteres. ..."></textarea>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="middle-name" class="control-label col-md-4 col-sm-4 col-xs-12">Fecha Lanzamiento :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <div class='input-group date' id='datetimepicker'>
                              <input type='text' class="form-control" name="datetimepicker" id='datetimepicker' />
                              <span class="input-group-addon">
                                  <span class="glyphicon glyphicon-calendar"></span>
                              </span>
                              </div>
                                <p class="help-block">Si no programas la fecha, la campaña se enviar&aacute; inmediatamente; Si la fecha es anterior a la actual, de igual manera se enviar&aacute; autom&aacute;ticamente.</p>
                                <p class="help-block"><span id="fecha_sistema"></span></p>
                            </div>
                        </div>

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="base_existente" value="$baseExistente" />
                      </form>
                  </div>
                </div>
html;

  $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        jQuery.validator.addMethod("isBadWord",function(value,element){
          texto  = $("#mensaje").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroMalasPalabras/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando palabras no permitidas."));


    jQuery.validator.addMethod("isDisableWord",function(value,element){
          texto  = $("#mensaje").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroCaracteresEspeciales/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
    }, jQuery.validator.format("Se estan usando caracteres especiales no permitidos."));


    jQuery.validator.addMethod("isBadWordNameCamp",function(value,element){
          texto  = $(":text").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroMalasPalabras/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando palabras no permitidas."));

      jQuery.validator.addMethod("isDisableWordNameCamp",function(value,element){
          texto  = $(":text").val();
          data = {"url" : texto};
          console.debug(data);

        val = 1;
        $.ajax(
        {
           type: "POST",
           url: "/FiltroCaracteresEspeciales/index",
           data: data,
           async:false,    
           success: function(data){
                if(data.message == true){
                    console.debug("ok success true");
                    val = 0;              
                }
                else{
                    console.debug("ok success false");
                    val = 1;
                }
            
           },

           error: function(xhr, textStatus, errorThrown){
                return false;
           }
        });
        return this.optional(element) || 0 != val;
      }, jQuery.validator.format("Se estan usando caracteres especiales no permitidos."));

   
        $(document).ready(function() {
            
            $('#datetimepicker').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6],
                disabledHours: [0, 1, 2, 3, 4, 5, 6, 7, 8, 20, 21, 22, 23, 24],
                enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
          });

      $("#add").validate(
                {
          ignore: "[disabled]",
                    rules: {
                        nombre_campania: {
                            isBadWordNameCamp:true,
                            isDisableWordNameCamp: true,
                            required: true,
                            maxlength: 60,
                            minlength: 3
                        },
                        mensaje: {
                            isBadWord: true,
                            isDisableWord: true,
                            required: true,
                            maxlength: 160,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 60",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        mensaje: {
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 160",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        datetimepicker: {
                            required: "Este campo es obligatorio"
                        }
                    }
      });

            setInterval(function(){ 
                $.get( "/submitOneMulti/getTime", function( data ) {
                        $( "#fecha_sistema" ).html( data );
                });
            }, 1000);
        });
    </script>
html;

        View::set('contenido',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("submit_one_add");

    }

    public function seleccionaClienteMarcacionExitentePost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $nombreCampania = MasterDom::getData('nombre_campania');
        $mensaje = MasterDom::getData('mensaje');
        $fecha = MasterDom::getData('datetimepicker');
        $baseExistente = MasterDom::getData('base_existente');

        $shortCode = CampaignDao::getCarrierCustomerGroup($customer);
        $shortCodeHtml = '';
        foreach($shortCode AS $k=>$value){
            $ids = CampaignDao::getCarrierCustomer($customer, $value['short_code_id']);
            if(empty($ids))
                continue;

                $disabled = ($k == 0) ? '' : 'disabled';
                $check = ($k == 0) ? 'checked="checked"' : '';

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Marcacion :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <label class="action">
                                    <input class="seleccion" value="_dato_{$k}" name="iCheck" $check type="radio"> {$value['short_code']}
                                </label>
                            </div>
                        </div>
                        <fieldset class="existente_valida_dato_{$k}" $disabled>
html;
            foreach($ids AS $val){

                $shortCodeHtml.=<<<html
                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;carrier :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <div class="checkbox">
                                    <label><input type="checkbox" class"carrier" name="carrier_connection_short_code_id[]" value="{$val['carrier_connection_short_code_id']}" checked="checked">{$val['name']}</label>
                                </div>
                            </div>
                        </div>
html;
            }
            $shortCodeHtml.=<<<html
                        </fieldset>
                        <br />
html;
        }


  $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Configuracion de Marcacion</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla podra seleccionar la marcacion por la cual va a salir el mensaje, puedes seleccionar los carriers para el envio.</p>
                    <div class="ln_solid"></div>
                    <form id="add" action="/submitOneMulti/seleccionaClienteReporteExistentePost" method="POST">

                     $shortCodeHtml

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <a href="#" class="btn btn-success pull-right">Siguiente</a>
                        </div>
                      </div>
      <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
            <input type="hidden" value="$mensaje" name='mensaje'/>
            <input type="hidden" value="$fecha" name='datetimepicker'/>
            <input type="hidden" value="$customer" name='customer_id'/>
      <input type="hidden" name="base_existente" value="$baseExistente" />
                      </form>
                  </div>
                </div>
html;

        $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {
             $(".seleccion").on("change", function () {
                valor = $(this).val();
                $("fieldset[class*='existente_valida']").attr('disabled', 'disabled');
                $('.existente_valida'+ valor).removeAttr("disabled");
            });

            $('.btn-success').on("click",function() {
                var pivote = $(".seleccion:checked").val();
                var buscar = $(".existente_valida" + pivote + " input:checked")
                if(buscar.length == 0){
                    bootbox.alert("Error: debes seleccionar por lo menos un carrier!");
                }else
                    $( "#add" ).submit();
            }); 

        });
    </script>
html;

        View::set('contenido',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("submit_one_add");
    }

    public function seleccionaClienteReporteExistentePost(){


  if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

  $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

  $nombreCampania = MasterDom::getData('nombre_campania');
        $mensaje = MasterDom::getData('mensaje');
        $fecha = MasterDom::getData('datetimepicker');
        $baseExistente = MasterDom::getData('base_existente');
  $carrierConnectionArray = MasterDom::getDataAll('carrier_connection_short_code_id');
  $carrierConnection = base64_encode(serialize($carrierConnectionArray));

          $extraFooter =<<<html
          <!-- jQuery Modal -->
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />

          <script>
          $( "#btnEnvio" ).click(function() {
            $( "#envioPostExistente" ).submit();
            $( "#btnEnvio" ).hide();
            $( "#datosPrueba" ).hide();
          });

          $(document).ready(function()
          {
          $("#btnEnvioPrueba").click(function(){
            $.post("/SubmitOnePrueba/envioPruebaCampaign",
              {campania: "$nombreCampania", mensaje: "$mensaje", carrierConnection: "$carrierConnection"},
              function(htmlexterno){
                $("#datosPrueba").html(htmlexterno);
                $("#btnEnvioPrueba").hide();
              });
            });
          });

          </script>
html;


        if(empty($nombreCampania) || empty($mensaje) || $baseExistente == '')
            return MasterDom::alertas('error_general');

  $validate = CampaignDao::validateCustomerCliente($customer, $baseExistente);
        if(empty($validate))
            return MasterDom::alertas('error_general');

  $params = $this->procesoBaseExistenteArray($baseExistente, $carrierConnectionArray, $customer, $fecha);
  $noCarrier = count($params['noCarrier']);
        $blackList = count($params['blackList']);


  if($params['contactoEnvios'] <= 0 /*$params['Mensajes_Faltantes_Month_Customer'] < 0 || $params['Mensajes_Faltantes_Day_Customer'] < 0 || $params['Mensajes_Faltantes_Month_Usuario'] < 0 || $params['Mensajes_Faltantes_Day_Usuario'] < 0*/){ // DEfine si se cancela el envío. esau

    $resultado = 0;

    $botonEnvio =<<<html
      <form action="/SubmitOneMulti/seleccionaCliente"> 
          <input type="submit" class="btn btn-danger pull-right" value="No es posible realizar el envío">
      </form>
html;

$html=<<<html
      <form action="/SubmitOneMulti/envioPost" method="POST"> 
        <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripci&oacute;n</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>{$params['countMsisdn']}</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Cliente:</td>
                          <td>{$params['mesDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Cliente:</td>
                          <td>{$params['diaDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios mensual x Usuario:</td>
                          <td>{$params['mesDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para env&iacute;o por alcanzar el m&aacute;ximo de envios diario x Usuario:</td>
                          <td>{$params['diaDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Limite por d&iacute;a:</td>
                          <td>{$params['diaLimite']}</td>
                        </tr>
                        <tr>
                          <td>Restantes por d&iacute;a:</td>
                          <td>{$params['Mensajes_Faltantes_Day_Usuario']}</td>
                        </tr>
                        <tr>
                          <td>Limite por mes:</td>
                          <td>{$params['mesLimite']}</td>
                        </tr>
                        <tr>
                          <td>Restantes por mes:</td>
                          <td>{$params['Mensajes_Faltantes_Month_Usuario']}</td>
                        </tr>
                          $base
                      </tbody>
                    </table>

                  </div>

          <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                               $botonEnvio
                          </div>
                        </div>

                </div>
              </div>

  <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
        <input type="hidden" value="$mensaje" name='mensaje'/>
        <input type="hidden" value="$fecha" name='datetimepicker'/>
        <input type="hidden" value="$customer" name='customer_id'/>
        <input type="hidden" name='nombreArchivo' value="$nombreArchivo" />
        <input type="hidden" value="$columnaOperador" name='columna_operador'/>
        <input type="hidden" value="$columnaNumero" name='columna_numero'/>
        <input type="hidden" value="$carrierConnectionPost" name='carrier_connection'/>
        <input type="hidden" value="$baseNombre" name='base_nombre'/>
        <input type="hidden" value="$baseGuardar" name='base_guardar'/>
        <input type="hidden" value="$valor" name='valor'/>
  </form>
html;

  } else{

    $resultado = $params['contactoEnvios'];

    $botonEnvio =<<<html
      <input type="button" class="btn btn-success pull-right" value="Se realiza el env&iacute;o solamante a los contactos con operador v&aacute;lido" id="btnEnvio">
html;

    if ($params['msisdnSembrados'] > 0) {
      $botonEnvioPrueba =<<<html
            <input type="button" id="btnEnvioPrueba" class="btn btn-primary pull-left" value="Realizar env&iacute;o de prueba">      
html;
    }else{
      $botonEnvioPrueba =<<<html
      <label><input type="button" name="no_envio" value="No tienes msisdn sembrados para enviar pruebas" class="btn btn-danger pull-left" ></label>
html;
    }

  }

  $html=<<<html
            <form action="/submitOneMulti/envioPostExistente" method="POST" id="envioPostExistente">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripcion</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>{$params['countMsisdn']}</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$noCarrier</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$blackList</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para envio por alcanzar el maximo de envios mensual x Cliente:</td>
                          <td>{$params['mesDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para envio por alcanzar el maximo de envios diario x Cliente:</td>
                          <td>{$params['diaDiferencia']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para envio por alcanzar el maximo de envios mensual x Usuario:</td>
                          <td>{$params['mesDiferenciaU']}</td>
                        </tr>
                        <tr>
                          <td>Celulares bloqueados para envio por alcanzar el maximo de envios diario x Usuario:</td>
                          <td>{$params['diaDiferenciaU']}</td>
                        </tr>
                        <!--tr>
                          <td>Total de sembrados:</td>
                          <td>{$params['msisdnSembrados']}</td>
                        </tr-->
                        <tr>
                          <td>Cantidad de contactos a los que se les realizar&aacute; el envio :</td>
                          <td>$resultado</td>
                        </tr>
                        $base
                      </tbody>
                    </table>

                  </div>
      <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                          $botonEnvioPrueba

                          $botonEnvio
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12" id="datosPrueba"></div>
                        </div>

                </div>
              </div>

        <input type="hidden" name='nombre_campania' value="$nombreCampania"/>
        <input type="hidden" value="$mensaje" name='mensaje'/>
        <input type="hidden" value="$fecha" name='datetimepicker'/>
        <input type="hidden" value="$carrierConnection" name='carrier_connection'/>
        <input type="hidden" value="$baseExistente" name='base_existente'/>
        </form>
html;

        View::set('contenido',$html);
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("submit_one_add");
    }

    private function procesoBaseExistenteArray($idClient, $carrierConnection, $customer, $fecha){

        $old_date_timestamp = strtotime($fecha);
        $fecha = date('Y-m-d H:i:s', $old_date_timestamp);

  /****************************************************/

  $msisdn = array();
  $clientCarrier = CampaignDao::clientMsisdnCarrier($customer, $idClient);
        if(count($clientCarrier) >= 1){
      foreach($clientCarrier AS $value)
                array_push($msisdn, array('msisdn'=>$value['msisdn'], 'carrier'=>$value['carrier_id']));
        }
        else
            return MasterDom::alertas('error_general');

        $carrierIds = '';
        foreach($carrierConnection AS $value){
            $carrierIds .= "$value,";
        }
        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = CampaignDao::findCarriers($carrierIds);
        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

        $buscaCarrier = function($valor) use($carrierIdsArray){
            $retorno['status'] = false; 
            foreach($carrierIdsArray AS $value){ 
                if($value['carrier_id'] == $valor){
                    $retorno['status'] = true; 
                    $retorno['country_code'] = $value['country_code'];
                    $retorno['carrier_connection_id'] = $value['carrier_connection_id'];
                    $retorno['white_list'] = ($value['white_list'] == 'enable' ) ? true : false;
                    $retorno['carrier_id'] = $value['carrier_id'];
                    $retorno['short_code_id'] = $value['short_code_id'];
                    $retorno['carrier_connection_short_code_id'] = $value['carrier_connection_short_code_id'];
                    $retorno['short_code'] = $value['short_code'];
                    break;
                }
            }
            return $retorno;
        };


  $noCarrier = array();
        $blackList = array();
        $msisdnCorrecto = array();
        foreach($msisdn AS $value){
           $carrier = $value['carrier'];
           $buscaCarrierValue = $buscaCarrier($carrier);
           if(empty($carrier) || $buscaCarrierValue['status'] === false){
                array_push($noCarrier, array('msisdn' =>$value['msisdn']));
                continue;
           }
           if($carrier == 'telcel' || $carrier == 'att' || $carrier == 'movistar'){
                $black = CampaignDao::findBlackList($value['msisdn'], $value['carrier']);
                if($black['number'] != ''){
                    array_push($blackList, array('msisdn'=>$value['msisdn']));
                    continue;
                }
           }

           array_push($msisdnCorrecto, array('msisdn'=>$countryCode.$value['msisdn'], 'carrier_connection_id'=>$buscaCarrierValue['carrier_connection_id'],
                                                'white_list'=>$buscaCarrierValue['white_list'], 'carrier_id'=>$buscaCarrierValue['carrier_id'],
                                                'short_code_id'=>$buscaCarrierValue['short_code_id'],
                                                'carrier_connection_short_code_id'=>$buscaCarrierValue['carrier_connection_short_code_id']));
        }


        /* Agregamos los msisdn de prueba */
        $sembrados = CampaignDao::getSembrados(MasterDom::getSession('customer_id'));
        if (!empty($sembrados)) {
          $msisdnSembrados = array();
          foreach ($sembrados as $key => $value) {
            array_push($msisdnSembrados, array(
            'msisdn'=>$value['msisdn'],
            'carrier_connection_id'=>$value['carrier_connection_id'],
            'white_list'=>$value['white_list'], 
            'carrier_id'=>$value['carrier_id'],
            'short_code_id'=>$value['short_code_id'],
            'carrier_connection_short_code_id'=>$value['carrier_connection_short_code_id']));
          }
          
          //$msisdnCorrecto = array_merge($msisdnCorrecto,$msisdnSembrados);
        }
        
        // quitaremos valores repetidos
        //$msisdnCorrecto = array_unique($msisdnCorrecto);

        // Inica cambios esau para base existente
        /** Primero buscar si el usuario tiene mt por dia, despues por mes.
        *   continua buscando con el customer por dia y seguidamente por mes.
        **/        
        $countMensajes = count($msisdnCorrecto);
        //echo "total_mensajes:$countMensajes \n";
        ##### Datos de usuario por dia #####
        $usuarioDataDia = CampaignDao::getTotalesUserDia(MasterDom::getSession('id_user'));

        $Mensajes_Faltantes_Day_Usuario = $usuarioDataDia['resta_dia'];

        if ($countMensajes > $Mensajes_Faltantes_Day_Usuario) {
          $sms_cut_dia_usuario = $countMensajes - $Mensajes_Faltantes_Day_Usuario;
        }
        else{
          $sms_cut_dia_usuario = 0;
        }

        ##### Datos de usuario por mes ####
        $usuarioDataMes = CampaignDao::getTotalesUserMes(MasterDom::getSession('id_user'));

        $Mensajes_Faltantes_Month_Usuario = $usuarioDataMes['resta_mes'];

        if ($countMensajes > $Mensajes_Faltantes_Month_Usuario) {
          $sms_cut_mes_usuario = $countMensajes - $Mensajes_Faltantes_Month_Usuario;
        }
        else{
          $sms_cut_mes_usuario = 0;
        }

        ##### Datos de customer por dia #####
        $customerDataDia = CampaignDao::getTotalesCustomerDia($customer);
        
        $Mensajes_Faltantes_Day_Customer = $customerDataDia['resta_dia'];
        if ($countMensajes > $Mensajes_Faltantes_Day_Customer) {
          $sms_cut_dia_customer = $countMensajes - $Mensajes_Faltantes_Day_Customer;
        }
        else{
          $sms_cut_dia_customer = 0;
        }

        $customerDataMes = CampaignDao::getTotalesCustomerMes($customer);
        
        $Mensajes_Faltantes_Month_Customer = $customerDataMes['resta_mes'];
        if ($countMensajes > $Mensajes_Faltantes_Month_Customer) {
          $sms_cut_mes_customer = $countMensajes - $Mensajes_Faltantes_Month_Customer;
        }
        else{
          $sms_cut_mes_customer = 0;
        }


        if ($sms_cut_dia_usuario > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_mes_usuario > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_dia_customer > 0) {
          $contactoEnvios = 0;
        }
        elseif ($sms_cut_mes_customer > 0) {
          $contactoEnvios = 0;
        }
        else{
          $contactoEnvios = count($msisdnCorrecto);
        }


  /*$customerArray = CampaignDao::getCustomerMt($customer);
        if(empty($customerArray))
            return MasterDom::alertas('error_general');

        $diaL = $customerArray['max_mt_day'];
        $mesL = $customerArray['max_mt_month'];

        $arrayDia = CampaignDao::getDiaCustomer($customer,$fecha);
        $diaA = ($arrayDia['suma'] == '') ? 0 : $arrayDia['suma'];

        $arrayMes = CampaignDao::getMesCustomer($customer,$fecha);
        $mesA = ($arrayMes['suma'] == '') ? 0 : $arrayMes['suma'];

        $count = count($msisdnCorrecto);
        $diaD = (($count + $diaA) > $diaL) ? ($count + $diaA) - $diaL : 0;
        $mesD = (($count + $mesA) > $mesL) ? ($count + $mesA) - $mesL : 0;

        $idUser = $_SESSION['id_user'];
        $userDia = CampaignDao::getViewUserDia($idUser,$fecha);
        $userMes = CampaignDao::getViewUserMes($idUser,$fecha);

        $Mensajes_Faltantes_Month_Customer = $userMes['No_Mensajes_Faltantes_Month_Customer'];
        $Mensajes_Faltantes_Day_Customer = $userDia['No_Mensajes_Faltantes_Day_Customer'];
        $Mensajes_Faltantes_Month_Usuario = $userMes['No_Mensajes_Faltantes_Month_Usuario'];
        $Mensajes_Faltantes_Day_Usuario = $userDia['No_Mensajes_Faltantes_Day_Usuario'];

       $diaDU = ((($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) > $userDia['Max_Mt_Day_Usuario']) ? (($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) - $userDia['Max_Mt_Day_Usuario'] : 0;
       $mesDU = ((($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) > $userMes['Max_Mt_Month_Usuario']) ? (($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) - $userMes['Max_Mt_Month_Usuario'] : 0;

       if($mesD == 0 && $diaD == 0 && $mesDU == 0 && $diaDU == 0){
          $var = $count;
        } elseif ($mesD > 0 || $diaD > 0 || $mesDU > 0 || $diaDU > 0) {
          if ($mesD >= 1 && $mesD >= $diaD && $mesD >= $mesDU && $mesD >= $diaDU) {
            $var = abs($count-$mesD);
          } elseif (($diaD >= 1 && $mesD == 0 && $mesDU == 0 && $diaDU == 0) || ($diaD >= 1 && $mesD == 0) || ($diaD > $mesD)) {
            $var = abs($count-$diaD);
          } elseif (($mesDU >= 1 && $mesD == 0 && $diaD == 0 && $diaDU == 0) || ($mesDU > $diaDU)) {
            $var = abs($count-$mesDU);
          } elseif (($diaDU >= 1 && $mesDU == 0 && $mesD == 0 && $diaD == 0) || ($diaDU > $mesDU) || ($diaDU == $mesDU)) {
            $var = abs($count-$diaDU);
          } else {
            $var = "Warning";
          }
        } else {
          $var = "ERROR SISTEMA";
        }*/

        $params = array(
              'msisdnCorrecto'=>$msisdnCorrecto,
              'blackList'=>$blackList,
              'noCarrier'=>$noCarrier,
              'diaLimite'=>$usuarioDataDia['max_mt_day'],
              'mesLimite'=>$usuarioDataMes['max_mt_month'],
              'countMsisdn'=>count($msisdnCorrecto),
              'diaDiferencia'=>$sms_cut_dia_customer, //bloqueados máximo de envios diario x Cliente:
              'mesDiferencia'=>$sms_cut_mes_customer, //bloqueados máximo de envios mensual x Cliente:
              'diaDiferenciaU'=>$sms_cut_dia_usuario, //bloqueados máximo de envios diario x Usuario:
              'mesDiferenciaU'=>$sms_cut_mes_usuario, //bloqueados máximo de envios mensual x Usuario:
              'contactoEnvios'=>$contactoEnvios,// este parametro determinara si el envío se realiza
              'Mensajes_Faltantes_Month_Usuario'=>$Mensajes_Faltantes_Month_Usuario,
              'Mensajes_Faltantes_Day_Usuario'=>$Mensajes_Faltantes_Day_Usuario,
              'Mensajes_Faltantes_Month_Customer'=>$Mensajes_Faltantes_Month_Customer,
              'Mensajes_Faltantes_Day_Customer'=>$Mensajes_Faltantes_Day_Customer,
              'nombreArchivo'=>$nombreArchivo,
              'msisdnSembrados'=>count($msisdnSembrados)
            );
        // fin  cambios esau base existente

        return $params; 
    }

    public function envioPostExistente(){
      
  if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $nombreCampania = MasterDom::getData('nombre_campania');
        $mensaje = MasterDom::getData('mensaje');
        $fecha = MasterDom::getData('datetimepicker');
        $baseExistente = MasterDom::getData('base_existente');
        $carrierConnectionArray = MasterDom::getDataAll('carrier_connection');
        $carrierConnection = unserialize(base64_decode($carrierConnectionArray));

        if(empty($nombreCampania) || empty($mensaje) || $baseExistente == '')
            return MasterDom::alertas('error_general');

       $validate = CampaignDao::validateCustomerCliente($customer, $baseExistente);
        if(empty($validate))
            return MasterDom::alertas('error_general');

        return $this->procesoBaseExistenteArrayExistente($baseExistente, $carrierConnection, $customer, $fecha, $mensaje, $nombreCampania);

    } 

    private function procesoBaseExistenteArrayExistente($idClient, $carrierConnection, $customer, $fechaOld, $mensaje, $nombreCampania){

  $old_date = date('m/d/Y g:i a');
        $old_date_timestamp = strtotime($fechaOld);
        $fecha = date('Y-m-d H:i:s', $old_date_timestamp);


        $customerArray = CampaignDao::getCustomerMt($customer);
        if(empty($customerArray))
            return MasterDom::alertas('error_general');

   $msisdn = array();
        $clientCarrier = CampaignDao::clientMsisdnCarrier($customer, $idClient);
        if(count($clientCarrier) >= 1){
            foreach($clientCarrier AS $value)
                array_push($msisdn, array('msisdn'=>$value['msisdn'], 'carrier'=>$value['carrier_id'], 'msisdn_id'=>$value['msisdn_id']));
        }
        else
            return MasterDom::alertas('error_general');

        $carrierIds = '';
        foreach($carrierConnection AS $value){
            $carrierIds .= "$value,";
        }
        $carrierIds = rtrim($carrierIds, ",");
        $carrierIdsArray = CampaignDao::findCarriers($carrierIds);
        if(empty($carrierIdsArray))
            return MasterDom::alertas('error_general');

  $buscaCarrier = function($valor) use($carrierIdsArray){
            $retorno['status'] = false;
            foreach($carrierIdsArray AS $value){
                if($value['carrier_id'] == $valor){
                    $retorno['status'] = true;
                    $retorno['country_code'] = $value['country_code'];
                    $retorno['carrier_connection_id'] = $value['carrier_connection_id'];
                    $retorno['white_list'] = ($value['white_list'] == 'enable' ) ? true : false;
                    $retorno['carrier_id'] = $value['carrier_id'];
                    $retorno['short_code_id'] = $value['short_code_id'];
                    $retorno['carrier_connection_short_code_id'] = $value['carrier_connection_short_code_id'];
                    $retorno['short_code'] = $value['short_code'];
                    break;
                }
            }
            return $retorno;
        };

  $noCarrier = array();
        $blackList = array();
        $msisdnCorrecto = array();
        foreach($msisdn AS $value){
           $carrier = $value['carrier'];
           $buscaCarrierValue = $buscaCarrier($carrier);
           if(empty($carrier) || $buscaCarrierValue['status'] === false){
                array_push($noCarrier, array('msisdn' =>$value['msisdn']));
                continue;
           }
           if($carrier == 'telcel' || $carrier == 'att' || $carrier == 'movistar'){
                $black = CampaignDao::findBlackList($value['msisdn'], $value['carrier']);
                if($black['number'] != ''){
                    array_push($blackList, array('msisdn'=>$value['msisdn']));
                    continue;
                }
           }

           array_push($msisdnCorrecto, array('msisdn'=>$countryCode.$value['msisdn'], 'carrier_connection_id'=>$buscaCarrierValue['carrier_connection_id'],
                                                'white_list'=>$buscaCarrierValue['white_list'], 'carrier_id'=>$buscaCarrierValue['carrier_id'],
                                                'short_code_id'=>$buscaCarrierValue['short_code_id'],
                                                'carrier_connection_short_code_id'=>$buscaCarrierValue['carrier_connection_short_code_id'], 'msisdn_id'=>$value['msisdn_id']));
        }


        /* Agregamos los msisdn de prueba */
        $sembrados = CampaignDao::getSembrados(MasterDom::getSession('customer_id'));
        if (!empty($sembrados)) {
          $msisdnSembrados = array();
          foreach ($sembrados as $key => $value) {
            array_push($msisdnSembrados, array(
            'msisdn'=>$value['msisdn'],
            'carrier_connection_id'=>$value['carrier_connection_id'],
            'white_list'=>$value['white_list'], 
            'carrier_id'=>$value['carrier_id'],
            'short_code_id'=>$value['short_code_id'],
            'carrier_connection_short_code_id'=>$value['carrier_connection_short_code_id'],
            'msisdn_id'=>$value['msisdn_id'])
            );
          }
          
          //$msisdnCorrecto = array_merge($msisdnCorrecto,$msisdnSembrados);
        }
        

  $customerArray = CampaignDao::getCustomerMt($customer);
        if(empty($customerArray))
            return MasterDom::alertas('error_general');

  $diaL = $customerArray['max_mt_day'];
        $mesL = $customerArray['max_mt_month'];

        $arrayDia = CampaignDao::getDiaCustomer($customer,$fecha);
        $diaA = ($arrayDia['suma'] == '') ? 0 : $arrayDia['suma'];

        $arrayMes = CampaignDao::getMesCustomer($customer,$fecha);
        $mesA = ($arrayMes['suma'] == '') ? 0 : $arrayMes['suma'];

        $count = count($msisdnCorrecto);
        $diaD = (($count + $diaA) > $diaL) ? ($count + $diaA) - $diaL : 0;
        $mesD = (($count + $mesA) > $mesL) ? ($count + $mesA) - $mesL : 0;

        $idUser = $_SESSION['id_user'];
        $userDia = CampaignDao::getViewUserDia($idUser,$fecha);
        $userMes = CampaignDao::getViewUserMes($idUser,$fecha);

        $diaDU = ((($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) > $userDia['Max_Mt_Day_Usuario']) ? (($userDia['Max_Mt_Day_Usuario'] - $userDia['No_Mensajes_Faltantes_Day_Usuario']) + $count) - $userDia['Max_Mt_Day_Usuario'] : 0;
        $mesDU = ((($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) > $userMes['Max_Mt_Month_Usuario']) ? (($userMes['Max_Mt_Month_Usuario'] - $userMes['No_Mensajes_Faltantes_Month_Usuario']) + $count) - $userMes['Max_Mt_Month_Usuario'] : 0;

    if($mesD == 0 && $diaD == 0 && $mesDU == 0 && $diaDU == 0){
          $var = $count;
        } elseif ($mesD > 0 || $diaD > 0 || $mesDU > 0 || $diaDU > 0) {
          if ($mesD >= 1 && $mesD >= $diaD && $mesD >= $mesDU && $mesD >= $diaDU) {
            $var = abs($count-$mesD);
          } elseif (($diaD >= 1 && $mesD == 0 && $mesDU == 0 && $diaDU == 0) || ($diaD >= 1 && $mesD == 0) || ($diaD > $mesD)) {
            $var = abs($count-$diaD);
          } elseif (($mesDU >= 1 && $mesD == 0 && $diaD == 0 && $diaDU == 0) || ($mesDU > $diaDU)) {
            $var = abs($count-$mesDU);
          } elseif (($diaDU >= 1 && $mesDU == 0 && $mesD == 0 && $diaD == 0) || ($diaDU > $mesDU) || ($diaDU == $mesDU)) {
            $var = abs($count-$diaDU);
          } else {
            $var = "Warning";
          }
        } else {
          $var = "ERROR SISTEMA";
        }

  $msisdnCut = array_chunk($msisdnCorrecto,$var);
  $msisdnCorrecto = $msisdnCut[0];


  $campaniaId = CampaignDao::insertaCampaniaIni($nombreCampania, 4, $fecha, 2);
  if($campaniaId < 1)
            return MasterDom::alertas('error_general');

  $campCustomer = CampaignDao::insertaCampaniaCustomer($customer, $campaniaId);
  if($campCustomer < 1)
            return MasterDom::alertas('error_general');

  $campUser = CampaignDao::insertCampaignUser($idUser, $campaniaId);

        if($campUser < 1)
            return MasterDom::alertas('error_general');

        foreach($carrierIdsArray AS $key=>$value){
            if(CampaignDao::insertaCampaniaCarrierShortCode($campaniaId, $value['carrier_id'],
                        $value['short_code_id']) < 1)
                return MasterDom::alertas('error_general');

            if(CampaignDao::insertaCarrierConnectionShortCodeCampaign($campaniaId, $value['carrier_connection_short_code_id']) < 1)
                return MasterDom::alertas('error_general');
        }

  $msisdnErrores = array();
        foreach($msisdnCorrecto AS $key=>$value){
            $whiteList = 4;
            $estatusWhite = false;
            if($value['white_list']){
                $dataWhite = CampaignDao::getMsisdnWhiteList($value['msisdn_id'], $value['carrier_connection_id']);
                if($dataWhite['status'] == 1)
                    $whiteList = 4;
                elseif($dataWhite['status'] == ''){
                    $estatusWhite = true;
                    $whiteList = 3;
                }elseif ($dataWhite['status'] == 3) {
                    $whiteList = 13;
                }else
                    $whiteList = 4;
            }

      if(CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], $value['carrier_connection_short_code_id'], $whiteList, 4, $mensaje) < 1)
                array_push($msisdnErrores, array('msisdn'=>$value['msisdn'], 'msisdn_id'=>$value['msisdn_id']));

            if($value['white_list'] AND ($estatusWhite === true)){
                @CampaignDao::insertMsisdnWhiteList($value['msisdn_id'], $value['carrier_connection_id'], 0);
            }
        } 

  foreach($blackList AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], $value['carrier_connection_short_code_id'],2 , 4, $mensaje);

        foreach($noCarrier AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], -1,1 , 4, $mensaje);

        foreach($msisdnErrores AS $key=>$value)
            @CampaignDao::insertSmsCampaign($campaniaId, $fecha, $value['msisdn_id'], -1,1 , 7, $mensaje);

        @CampaignDao::estatusCampaign($campaniaId, 3);

        $campaniaSecurity = MasterDom::setParamSecure($campaniaId);
        header("Location: /SubmitOneMulti/campaignStatus/$campaniaSecurity");
        exit();
    } 

    public function seleccionaClientePost(){
      $check = MasterDom::getData('iCheck');
      if(empty($check))
          return MasterDom::alertas('error_general'); 

      if($check == 'nuevo'){
            $file = $_FILES['file'];
          if(empty($file))
            return MasterDom::alertas('error_general');
        
          $filename = $file['name'];
          $ext = pathinfo($filename, PATHINFO_EXTENSION);

          if(strtolower($ext) ==  'xls' || strtolower($ext) == 'xlsx' || strtolower($ext) == 'csv' || strtolower($ext) == 'zip' || strtolower($ext) == 'txt')
            return $this->functionExcel($file, $ext);
          else
            return MasterDom::alertas('error_general');
      }
      $baseExistente = (int) MasterDom::getData('base_existente');
      return $this->baseExistenteData($baseExistente);
    }

    function registroUsuario($accion){

        $id_usuario = $_SESSION['id_user'];
        $nickname = $_SESSION['usuario'];
        $customer = $_SESSION['name_customer'];
        $script = explode("/",$_SERVER["REQUEST_URI"]);
        $ip = $_SERVER['REMOTE_ADDR'];
        $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

        $registro = new \stdClass;
        $registro->_id_usuario = $id_usuario;
        $registro->_nickname = $nickname;
        $registro->_customer = $customer;
        $registro->_script = $script[1];
        $registro->_ip = $ip;
        $registro->_modulo = $modulo;
        $registro->_accion = $accion;
          
        return $registro;

    }

}
