<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Query as QueryDao;
use \App\controllers\Contenedor;

class Query{
    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){

        $row = QueryDao::getData();
        $html = '';
        foreach($row AS $key=>$value){
            $campaign_id = $value['campaign_id'];
            $modules_id = $value['modules_id'];
            print_r($campaign_id . "<br />");
            print_r($modules_id);


//             $html.= <<<html
//             <tr>
//                 <td><input type="checkbox" name="borrar[]" value="{$value[0]}"/></td>
//                 <td>{$value['deferred_id']}</td>
//                 <td>{$value['campaign_id']}</td>
//                 <td>{$value['customer_id']}</td>
//                 <td>{$value['modules_id']}</td>
//                 <td class="center"><a href="/cupones/edit/{$value[0]}" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
//             </tr>
// html;
        }
        View::set('table',$html);
        View::render("query");
    }

    private function alertas($caso = 'error_general'){
        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'error_producto')
            $mensaje = 'Ocurrio un error al insertar los productos.';
        elseif($caso == 'error_categoria')
            $mensaje = 'Ocurrio un error al insertar las categorias.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito los elementos seleccionados.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
                $mensaje = 'Se modifo con exito el cupon.';
                $class = 'success';
            }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrio algo inesperado.';
        View::set('regreso','/Query');
        View::set('regreso','/Menu');
        View::set('class', $class);
        View::set('titulo','Query');
        View::set('mensaje', $mensaje);
            View::render("mensaje");
    }
}