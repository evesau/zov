<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\SmsPush AS SmsPushDao;

class SmsPushTEST{

    private $_contenedor;

    function __construct(){
    }

    public function index(){

	$this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());

      $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;

      $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <!-- marked -->
	<script src="/suggest/js/marked.min.js"></script>
	<script src="/suggest/js/highlight.pack.js"></script>

	<!-- plugin script -->
	<script src="/suggest/js/bootstrap-suggest.js"></script>

    <script>    
        $(document).ready(function() {

          $('#datetimepicker').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6]
          });

      $("#add").validate(
                {
        ignore: "[disabled]",
                    rules: {
                        nombre_campania: {
                            required: true,
                            maxlength: 160,
                            minlength: 3
                        },
                        mensaje: {
                            required: true,
                            maxlength:360,
                            minlength: 3
                        },
			titulo: {
                            required: true,
                            maxlength: 100,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 60",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        mensaje: {
                            required: "Este campo es obligatorio"
                        },
			titulo:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 100",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        datetimepicker: {
                            required: "Este campo es obligatorio"
                        }
                    }
      });

      setInterval(function(){ 
      $.get( "/Santander/getTime", function( data ) {
        $( "#fecha_sistema" ).html( data );
      } );
      }, 1000);

	

$('#mensaje').suggest('@', {
  data: ["nombre@","apellido@","telefono@","cuenta@","sexo@"],
  map: function(user) {
    return {
      value: user,
      text: '<strong>'+user+'</strong>'
    }
  }
})



        });
    </script>
html;

      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render("smspush_add");
    }

    public function enviarPush() {

	$this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());

      $campania = MasterDom::getDataAll('nombre_campania');
      $campania = MasterDom::procesoAcentosNormal($campania);
      $titulo = MasterDom::getDataAll('titulo');
      $titulo = MasterDom::procesoAcentosNormal($titulo);
      $tipo = MasterDom::getDataAll('tipo_mensaje');
      $mensaje = MasterDom::getDataAll('mensaje');
      $mensaje = MasterDom::procesoAcentosNormal($mensaje);
      $fecha = MasterDom::getDataAll('datetimepicker');
      $old_date_timestamp = strtotime($fecha);
      $fechaEnvio = date('Y-m-d H:i:s', $old_date_timestamp);

      $seconds  = strtotime(date('Y-m-d H:i:s')) - strtotime($fechaEnvio);

        $months = floor($seconds / (3600*24*30));
        $day = floor($seconds / (3600*24));
        $hours = floor($seconds / 3600);
        $mins = floor(($seconds - ($hours*3600)) / 60);
        $secs = floor($seconds % 60);

	$data = new \stdClass;
	$data->_campania = $campania;
	$data->_titulo = $titulo;
	$data->_mensaje = $mensaje;
	$data->_estatus = 0;
	$data->_tipo_mensaje = $tipo;
	$data->_delivery_date = $fechaEnvio;
	$data->_total = 0;	

	/*--------insertar en tabla customer-----------*/
        $addCustom = SmsPushDao::insertCampania($data);

        if ($addCustom == '')
            return MasterDom::alertas('error_general', '/SmsPush', 'SmsPush Campania');

	return MasterDom::alertas('success_add', '/SmsPush', 'SmsPush Campania');
    }

    public function crontabPush(){

	$registrationIds = array("cLpFhcLy1VI:APA91bEfBnk3-mi0WcJeHAqloDPZUXjaPyN3RybMfMj8LccyqwVAwlN-pTGwzav-9kieDZ2-9wMJSNbGNplYJCKmL4yMzdn8xf49fdmpm_63PXgty9BCNcQudoZVPghAywX0ZEMGacXz");
                 
      $msg = array(
        'message'  => 'test' ,
        'title' => 'titulo',
        'action' => '1',
        'vibrate'=> 1,
        'sound' => 1
      );     
             
      $data['data'] = $msg;
             
      $fields = array(
        'registration_ids'        => $registrationIds,
        'data'  => $data
        //'priority'             => "high",
        //"content_available" => true
      );

      $headers = array(
        'Authorization: key=AIzaSyD9xIH06QzDD5BKgN44eC49e3igTkNXtXw',
        'Content-Type: application/json'
      );

      $json = json_encode( $fields );

      $ch = curl_init();
      curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
      curl_setopt( $ch,CURLOPT_POST, true );
      curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
      curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
      curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
      curl_setopt( $ch,CURLOPT_POSTFIELDS, $json );
      $result = curl_exec($ch );
      curl_close( $ch );
      echo $result;
    }

    public function restInsertToken(){

	$token = MasterDom::getDataAll('token');
	$token = MasterDom::procesoAcentosNormal($token);

	$numero = MasterDom::getDataAll('telefono');

	$json['action'] = 'error';
	$json['id'] = 0;	

	$data = new \stdClass;
	$data->_token = $token;
	$data->_msisdn = $numero;

	$id = SmsPushDao::insert($data);
	if($id > 0){
	    $json['action'] = 'success';
	    $json['id'] = $id;
  	}

	header('Content-Type: application/json');
	echo json_encode($json);
	exit();
    }

    public function restInsertProfile(){

        $nombre = MasterDom::getDataAll('nombre');
        $nombre = MasterDom::procesoAcentosNormal($nombre);

        $apellido = MasterDom::getDataAll('apellido');
	$apellido = MasterDom::procesoAcentosNormal($apellido);

	$sistemaOperativo = MasterDom::getDataAll('sistema_operativo');
	$cuenta = MasterDom::getDataAll('cuenta');
	$sexo = MasterDom::getDataAll('sexo');
	$pushDevice = MasterDom::getDataAll('push_device');

        $json['action'] = 'success';

        $data = new \stdClass;
	$data->_nombre = $nombre;
	$data->_apellido = $apellido;
	$data->_sistema_operativo = $sistemaOperativo;
	$data->_cuenta = $cuenta;
	$data->_push->_device = $pushDevice;
	$data->_estatus = 1;
	$data->_sexo = $sexo;
	$data->_push_device = $pushDevice;

        $id = SmsPushDao::updateToken($data);

        if($id === FALSE || $id == 0){
            $json['action'] = 'error';
        }

        header('Content-Type: application/json');
        echo json_encode($json);
        exit();
    }

    public function crontab(){

	$query = SmsPushDao::getAllCampania();
print_r($query);
	if (count($query) < 1){
	    exit();
	}

	$ids = '';
	foreach($query AS $val){
	   $ids .= "{$val['push_campania_id']} ,";	
	}
	$ids = trim($ids, ",");
	$data = new \stdClass;
	$data->_push_campania_id = $ids;
	$data->_estatus = 2;
	$updateCamp = SmsPushDao::updateCampaniaEstatus($data);
	
	$texto = '';
	$tipo = 1;
	$estatus = 1;
	$device = SmsPushDao::getAll();

	$replace = array('nombre','apellido', 'telefono' , 'cuenta', 'sexo');
	foreach($query AS $value){
	    $array = array();
	    $arrayDevice = array();
	    $acum = 0;
	    foreach($device AS $dev){
		$texto = html_entity_decode($value['mensaje'], ENT_COMPAT, 'UTF-8');
	 	//recorre replce
		foreach($replace AS $rep){
		    $remplazo = $rep;
		    if ($rep == 'telefono'){
			$remplazo = 'msisdn';
		    }
		    $texto = preg_replace("/@$rep@/i", MasterDom::regresoAcentos($dev[$remplazo]), $texto);
		}

		$registrationIds = array($dev['token']);

      		$msg = array(
        	    'message'  => $texto ,
        	    'title' => html_entity_decode($value['titulo'], ENT_COMPAT, 'UTF-8'),
        	    'action' => $value['tipo_mensaje'],
        	    'vibrate'=> 1,
        	    'sound' => 1
      		);

      		$dataJ['data'] = $msg;

      		$fields = array(
        	    'registration_ids' => $registrationIds,
        	    'data'  => $dataJ,
        	    'priority' => "high",
        	    "content_available" => true
      		);

      		$headers = array(
        	    'Authorization: key=AIzaSyDNyxkuNGU_u2KwzeTwWjqQgwPG01xa39A',
        	    'Content-Type: application/json'
      		);

      		$json = json_encode( $fields );

      		$ch = curl_init();
      		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
      		curl_setopt( $ch,CURLOPT_POST, true );
      		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
      		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
      		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
      		curl_setopt( $ch,CURLOPT_POSTFIELDS, $json );
      		$result = curl_exec($ch );
      		curl_close( $ch );

		$resultado = json_decode($result, 1);
		$success = $resultado['success'];

		if($success == 1)
		    $acum += 1;
	    }
	    echo "//////***SUCCESS: $acum****///////\n";

	    $data = new \stdClass;
            $data->_push_campania_id = $value['push_campania_id'];
            $data->_estatus = 1;
            $updateCamp = SmsPushDao::updateCampaniaEstatus($data);

	    $data = new \stdClass;
	    $data->_push_campania_id = $value['push_campania_id'];
	    $data->_total = $acum;
	    $update = SmsPushDao::update($data);
	}
		
    }

    public function muestra(){

	$this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());	

        $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {

             var table = $('#muestra-cupones').DataTable({
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                            "lengthMenu": "Mostrar _MENU_ entradas",
                            "search": "Buscar:",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                bootbox.confirm("&iquest;Desactivaras los carriers seleccionados?", function(result) {
                    if (result) 
                        $( "#delete_form" ).submit();
                });
            });
        } );
</script>
html;


        View::set('header',$this->_contenedor->header($extraHeader));
        $row = SmsPushDao::getAllCampaniaTabla();
        $html = '';
        foreach($row AS $key=>$value){

            $id = MasterDom::setParamSecure($value['push_campania_id']);
	    $nombre = html_entity_decode($value['campania'], ENT_COMPAT, 'UTF-8');
	    $titulo = html_entity_decode($value['titulo'], ENT_COMPAT, 'UTF-8');
	    $fecha = $value['delivery_date'];
	    $total = html_entity_decode($value['total'], ENT_COMPAT, 'UTF-8');
		/*
			<th class="no-sort"><input type="checkbox" id="checkAll"/></th>
                                            <th>Nombre</th>
                                            <th>Titulo</th>
                                            <th>Total Enviados</th>
                                            <th>Estatus</th>
                                            <th>Action</th>
		*/

	    if($value['estatus'] == 0){
		$estatus = 'Nueva';
	    }else if($value['estatus'] == 1){
		$estatus = 'Enviado';
	    }else if($value['estatus'] == 2){
		$estatus = 'Enviando';
	    }else{
		$estatus = 'Cancelado';
	    }

	    $link = ($value['estatus'] == 0 ) ? "<a href=\"/SmsPushTest/edit/$id\" type=\"button\" class=\"btn btn-primary btn-circle center-block\"><i class=\"fa fa-pencil-square-o\"></i></a>" : "<i  type=\"button\" class=\"btn btn-default btn-circle center-block\"><i class=\"fa fa-pencil-square-o\"></i></i>";

            $html.=<<<html
                <tr>
                    <td><input type="checkbox" name="borrar[]" value="{$value['push_campania_id']}"/></td>
                    <td>$nombre</td>
                    <td>$titulo</td>
                    <td>$fecha</td>
		    <td>$total</td>
                    <td>$estatus</td>
                    <td class="center">$link</td>
                </tr>
html;
        }

        View::set('table',$html);
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("smspush_all");
    }

    public function add(){}

    public function edit($id){
      $this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());
            $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;

      $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <!-- marked -->
  <script src="/suggest/js/marked.min.js"></script>
  <script src="/suggest/js/highlight.pack.js"></script>

  <!-- plugin script -->
  <script src="/suggest/js/bootstrap-suggest.js"></script>

    <script>    
        $(document).ready(function() {

          $('#datetimepicker').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6]
          });

      $("#add").validate(
                {
        ignore: "[disabled]",
                    rules: {
                        nombre_campania: {
                            required: true,
                            maxlength: 160,
                            minlength: 3
                        },
                        mensaje: {
                            required: true,
                            maxlength:360,
                            minlength: 3
                        },
      titulo: {
                            required: true,
                            maxlength: 100,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 60",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        mensaje: {
                            required: "Este campo es obligatorio"
                        },
      titulo:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 100",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        datetimepicker: {
                            required: "Este campo es obligatorio"
                        }
                    }
      });

      setInterval(function(){ 
      $.get( "/Santander/getTime", function( data ) {
        $( "#fecha_sistema" ).html( data );
      } );
      }, 1000);

$('#mensaje').suggest('@', {
  data: ["nombre@","apellido@","telefono@","cuenta@","sexo@"],
  map: function(user) {
    return {
      value: user,
      text: '<strong>'+user+'</strong>'
    }
  }
})
        });
    </script>
html;

      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      $id = MasterDom::getParamSecure($id);
        if(empty($id) OR ($id == 0))
            return MasterDom::alertas('error_general');

        $data = SmsPushDao::getById($id);
        if(empty($data) OR (count($data) < 1))
            return MasterDom::alertas('error_general');
        $id = $data['push_campania_id'];
        $nCampania = $data['campania'];
        $tituloMensaje = $data['titulo'];
        $mensaje = $data['mensaje'];
        $fecha = $data['delivery_date'];
        $tipoMensaje = $data['tipo_mensaje'];
        View::set('id', $id);
		    View::set('campania',$nCampania);
		    View::set('titulo', $tituloMensaje);
		    View::set('mensaje', $mensaje);
		    View::set('fecha', $fecha);
		    View::set('tipoMensaje', $tipoMensaje);
		    View::render("smspush_edi");
    }

    public function updatePush(){
      $this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());
      $id = MasterDom::getDataAll('id_push');

      $campania = MasterDom::getDataAll('nombre_campania');
      $campania = MasterDom::procesoAcentosNormal($campania);
      $titulo = MasterDom::getDataAll('titulo');
      $titulo = MasterDom::procesoAcentosNormal($titulo);
      $tipo = MasterDom::getDataAll('tipo_mensaje');
      $mensaje = MasterDom::getDataAll('mensaje');
      $fecha = MasterDom::getDataAll('datetimepicker');
      $old_date_timestamp = strtotime($fecha);
      $fechaEnvio = date('Y-m-d H:i:s', $old_date_timestamp);

      $seconds  = strtotime(date('Y-m-d H:i:s')) - strtotime($fechaEnvio);

        $months = floor($seconds / (3600*24*30));
        $day = floor($seconds / (3600*24));
        $hours = floor($seconds / 3600);
        $mins = floor(($seconds - ($hours*3600)) / 60);
        $secs = floor($seconds % 60);

      $data = new \stdClass;
      $data->_id = $id;
      $data->_campania = $campania;
      $data->_titulo = $titulo;
      $data->_mensaje = $mensaje;
      $data->_tipo_mensaje = $tipo;
      $data->_delivery_date = $fechaEnvio;

      $addCustom = SmsPushDao::updateRowCampania($data);

      if ($addCustom == '')
        return MasterDom::alertas('error_general', '/SmsPushTest/muestra', 'SmsPush Campania');

      return MasterDom::alertas('success_add', '/SmsPushTest/muestra', 'SmsPush Campania');
      
    }

    public function delete($id){

      $this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());

      $val = MasterDom::getDataAll('borrar');

      $arr = array();
      foreach ($val as $key => $value) {
        array_push($arr, $value);
        SmsPushDao::delete($value);
      }

      if($val > 0)
        return MasterDom::alertas('success_add', '/SmsPushTest/muestra', 'Se ha eliminado correctamente');
      else
        return MasterDom::alertas('error_general', '/SmsPushTest/muestra', 'No se selecciono un mensaje para borrar');
    }

}

