<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Customer as CustomerDao;
use \App\controllers\Contenedor;
use \App\models\Menu as MenuDao;
use \App\controllers\Menu;

class Customer{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {
        MasterDom::verificaUsuario();
        View::render("menu");
    }

    public function add(){

        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script>
        $(document).ready(function(){
            $("#add").validate(
                {
                    rules: {
                        
                       customer: {
                            required: true,
                            maxlength: 20,
                            minlength: 3
                        },

                        max_dia: {
                            required: true,
                            digits: true
                        },

                        max_mes: {
                            required: true,
                            digits: true
                        },
                        
                        img: {
                            extension: "jpg|png"
                        },

                        'modules[]': {
                            required: true
                        },

                        'shortcode_carrier[]': {
                            required: true
                        },

                        nombre: {
                            required: true,
                            maxlength: 20,
                            minlength: 3
                        },

                        apellido: {
                            required: true,
                            maxlength: 20,
                            minlength: 3
                        },

                        mail: {
                            required: true,
                            email: true
                        },
                        
                        nickname: {
                            required: true,
                            maxlength: 20,
                            minlength: 3,
                            ExisteUsuario: true
                        },

                        pass1: "required",
                        pass2: {
                            equalTo: "#pass1"
                        },

                        img_usr: {
                            extension: "jpg|png"
                        }

                    },

                    messages: {
                        customer: {
                            required: "Este campo es obligatorio",
                            maxlenght: "Solo se acepta un máximo de 20 caracteres",
                            minlenght: "No puedes ingresar menos de 3 caracteres"
                        },
                        max_dia: {
                            required: "Este campo es obligatorio",
                            digits: "Solo se aceptan valores númericos"
                        },
                        max_mes: {
                            required: "Este campo es obligatorio",
                            digits: "Solo se aceptan valores númericos"
                        },
                        img: "Este campo es obligatorio",
                        'modules[]': "Este campo es obligatorio",
                        'shortcode_carrier[]': "Este campo es obligatorio",
                        nombre: {
                            required: "Este campo es obligatorio",
                            maxlenght: "Solo se acepta un máximo de 20 caracteres",
                            minlenght: "No puedes ingresar menos de 3 caracteres"
                        },
                        apellido: {
                            required: "Este campo es obligatorio",
                            maxlenght: "Solo se acepta un máximo de 20 caracteres",
                            minlenght: "No puedes ingresar menos de 3 caracteres"
                        },
                        mail: {
                            required: "Este campo es obligatorio",
                            mail: "Ingresa un email válido"
                        },
                        nickname: {
                            required: "Este campo es obligatorio",
                            maxlenght: "Solo se acepta un máximo de 20 caracteres",
                            minlenght: "No puedes ingresar menos de 3 caracteres",
                            ExisteUsuario: "Este usuario ya existe"
                        },
                        pass1: "Este campo es obligatorio",
                        pass2: "Debe ingresar la contraseña igual a la que anterior ingresaste",
                        img_usr: "La imagen debe tener extensión jpg o png"
                    }                    
                }
            );
        });
        </script>
html;

        $allModules = CustomerDao::getAllModules();
        $modulesop = '';
        foreach ($allModules as $key => $value) {
            $modules = $value['name'];
            $modules_id = $value['modules_id'];
            //$modulesop .= "<div class='checkbox'><input type='checkbox' name='modules[]' cheked='checked' id='modules' value=".$modules_id." />".$modules."</div>";
            $modulesop .= "<label class='checkbox-inline'><input type='checkbox' name='modules[]' cheked='checked' value=".$modules_id.">".$modules." | </label>";
        }

        $allShortCode = CustomerDao::getShortCodeAndCarrier();
        $shortcode = '';
        foreach ($allShortCode as $key => $value) {
            $short_code = $value['short_code'];
            $carrier = $value['name'];
            $id_ccsc = $value['carrier_connection_short_code_id'];
            $carrier_name = $value['carrier_name'];
            $shortcode .= "<option value=".$id_ccsc.">".$short_code." - ".$carrier." - ".$carrier_name."</option>";
        }

        View::set('show_shortcode_carrier',$shortcode);
        View::set('showmodules',$modulesop);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("customeradd");
    }

    public function addCustomer(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return $this->alertas('error_general');

        //-----sacar datos del formulario-----------

        $custom = new \stdClass();

        if (empty(MasterDom::getDataAll('modules'))){ return $this->alertas('error_generall'); }
        else {$custom->modules = MasterDom::getDataAll('modules');} //echo 'modules vacios'; 

        if (empty(MasterDom::getDataAll('shortcode_carrier'))){ return $this->alertas('error_generall'); }
        else {$custom->_shortcode = MasterDom::getDataAll('shortcode_carrier');} //echo 'shortcode_carrier vacios'; 

        $ruta_servidor='/home/smsmkt/public/img/customer';
        $nombreImagen=$_FILES['img']['name'];
        $rutaTemporal=$_FILES['img']['tmp_name'];
        $rutaDestino=$ruta_servidor."/".$nombreImagen;
        move_uploaded_file($rutaTemporal, $rutaDestino);
        
        $custom->_name  = MasterDom::getData('customer');
        $custom->_mtday  = MasterDom::getData('max_dia');
        $custom->_mtmonth = MasterDom::getData('max_mes');
        $custom->_image = $nombreImagen;
        //$custom->_shortcode = $_POST['shortcode_carrier'];
       
        if ( MasterDom::getData('status') == '') $custom->_status  = 0;
        else $custom->_status = 1;

        //--------insertar en tabla customer-----------
        $addCustom = CustomerDao::insert($custom);

        if ($addCustom == '')
            return $this->alertas('error_general');

        // ------ insertar datos en tabla customer_modules-------
        foreach ($custom->modules as $key => $value) {
            CustomerDao::insertCustomModules($addCustom,$value);   
        }

        //--insertar datos en tabla custome_carrier_connection_short_code--

        foreach ($custom->_shortcode as $key => $val) {
            CustomerDao::insertCustomCCSC($addCustom,$val);
        }
        
        //----------Vaciar datos del primer usuario-------------
        $ruta_servidor_usr='/home/smsmkt/public/img/usr';
        $nombreImagen_usr=$_FILES['img_usr']['name'];
        $rutaTemporal_usr=$_FILES['img_usr']['tmp_name'];
        $rutaDestino_usr=$ruta_servidor_usr."/".$nombreImagen_usr; //en localhost W es "\\"
        move_uploaded_file($rutaTemporal_usr, $rutaDestino_usr);

        $user = new \stdClass();

        $user->_nickname  = MasterDom::getData('nickname');
        $user->_fname  = MasterDom::getData('nombre');
        $user->_lname  = MasterDom::getData('apellido');
        $user->_image = $nombreImagen_usr;
        $user->_pass1 = MasterDom::getData('pass1');
        $user->_mail = MasterDom::getData('mail');        
        $user->_status = 1;
        $user->_max_dia = MasterDom::getData('max_dia');
        $user->_max_mes = MasterDom::getData('max_mes');

        /*--------insertar primer usuario del customer----------*/
        //$adduser = new Menu;
        //$addUser = $adduser->insert($user);

        $addUser = CustomerDao::insertUser($user);

        if (!empty($addCustom) && !empty($addUser)) {

            foreach ($custom->modules as $key => $value) {
                CustomerDao::insertUserModules($addUser,$value);
            }

            CustomerDao::insertUserCustomer($addUser,$addCustom);

            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Agrego customer {$addCustom}");
            CustomerDao::registroUsuario($registro);
            $registro1 = $this->registroUsuario("Agrego user customer {$addUser}");
            CustomerDao::registroUsuario($registro1);
            /***************************************************************/

            return $this->alertas('success_add');
            
        }else {

            return $this->alertas('error_general');

        }

        

    }

    public function edit(){

        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

        <script>
        $(document).ready(function() {

                $( "#idcustomer" ).change(function() {
                    $.ajax({
                        type:'POST',
                        url:'/Customer/datosUserBD',
                        dataType:'json',
                        data: {id_customer : $(this).val()},
                        async: false,
                        success:function(data){
                            console.debug(data);
                            $('input:checkbox').removeAttr('checked'); //Limpia todos los checkbox
                            $("#multiple").val([""]).trigger("change"); //Limpia el select2

                            $('#id').val(data._id);
                            $('#customer').val(data._name);
                            $('#max_dia').val(data._maxmtday);
                            $('#max_mes').val(data._maxmtmonth);
                            $('#img_hidden').val(data._img);
                            $('#multiple').val(data._shortcode).trigger("change");
                                                    
                            if(data._status == 1){
                                $('#status').prop("checked", true);
                            }else{
                                $('#status').prop("checked", false);
                            }

                            $.each(data._modules,function(i,v){
                                    $("input[name='modules[]']").each(function( index ) {
                                        //console.log(index+':'+$( this ).val() );
                                        if($( this ).val() == v){
                                            //console.log('ok');
                                            $(this).prop('checked',true)
                                        }
                                    });
                            });
                        },
                        error: function(xhr, textStatus, errorThrown){
                            console.debug("no success");
                            return false;
                        }
                    });
                });

            
                $("#edit").validate(
                {
                    rules: {
                        idcustomer: {
                            required: true
                        },
                       customer: {
                            required: true,
                            maxlength: 20,
                            minlength: 3
                        },

                        max_dia: {
                            required: true,
                            digits: true
                        },

                        max_mes: {
                            required: true,
                            digits: true
                        },
                        
                        img: {
                            extension: "jpg|png"
                        },

                        'modules[]': {
                            required: true
                        },
                        'shortcode_carrier[]':  {
                            required: true
                        }
                    },
                    messages: {
                        idcustomer: {
                            required: "Selecciona un customer"
                        },
                        customer: {
                            required: "Este campo es obligatorio",
                            maxlenght: "Solo se acepta un máximo de 20 caracteres",
                            minlenght: "No puedes ingresar menos de 3 caracteres"
                        },
                        max_dia: {
                            required: "Este campo es obligatorio",
                            digits: "Solo se aceptan valores númericos"
                        },
                        max_mes: {
                            required: "Este campo es obligatorio",
                            digits: "Solo se aceptan valores númericos"
                        },
                        img: "Este campo es obligatorio",
                        'modules[]': "Este campo es obligatorio",
                        'shortcode_carrier[]': "Este campo es obligatorio"
                    }                    
                });
            });

        </script>
html;

        $allModules = CustomerDao::getAllModules();
        $modulesop ='';// '<ul class="nav-pills">';
        foreach ($allModules as $key => $value) {
            $modules = $value['name'];
            $modules_id = $value['modules_id'];
            //$modulesop .= "<li><input type='checkbox' name='modules[]' cheked='checked' id='modules' value=".$modules_id." />".$modules."</li>"; 
            $modulesop .= "<label class='checkbox-inline'><input type='checkbox' name='modules[]' cheked='checked' value=".$modules_id.">".$modules." | </label>";
        }

        $allShortCode = CustomerDao::getShortCodeAndCarrier();
        $shortcode = '';
        foreach ($allShortCode as $key => $value) {
            $short_code = $value['short_code'];
            $carrier = $value['name'];
            $id_ccsc = $value['carrier_connection_short_code_id'];
            $carrier_name = $value['carrier_name'];
            $shortcode .= "<option value=".$id_ccsc.">".$short_code." - ".$carrier." - ".$carrier_name."</option>";
        }
        
        $this->showAllCustomer();
        View::set('show_shortcode_carrier',$shortcode);
        View::set('showmodules', $modulesop);
        View::set('header', $this->_contenedor->header($extraHeader));
        View::set('footer', $this->_contenedor->footer($extraFooter));
        View::render("customeredit");
        
    }

    public function showAllCustomer(){

        $allCustomer = CustomerDao::getAll();
        $customop = '';
        foreach ($allCustomer as $key => $value) {
            $customer = $value['name'];
            $customer_id = $value['customer_id'];
            $customop .= "<option value=".$customer_id.">".$customer."</option>";
        }

        View::set('showcustomer', $customop);
    }


    public function datosUserBD(){

        $id   = MasterDom::getData('id_customer');
        $data = CustomerDao::getDataCustomer($id);

        $modules = array();
        $data_modules = CustomerDao::getById($id);
        foreach ($data_modules as $key => $value) {
            $modules[] = $value['modules_id'];
        }

        $shortcode_array = array();
        $shortcode = CustomerDao::getShortCodeById($id);
        foreach ($shortcode as $key => $value) {
            $shortcode_array[] = $value['carrier_connection_short_code_id'];
        }
        
        $custom = new \stdClass();
        $custom->_name = $data['name'];
        $custom->_maxmtday = $data['max_mt_day'];
        $custom->_maxmtmonth = $data['max_mt_month'];
        $custom->_img =$data['img'];
        $custom->_status = $data['status'];
        $custom->_modules= $modules;
        $custom->_shortcode = $shortcode_array;

        $json = json_encode($custom);
        echo $json;
    }

    public function editCustomer(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return $this->alertas('error_general');

        $customer = new \stdClass();

        if (!empty(MasterDom::getDataAll('modules'))) { $customer->modules = MasterDom::getDataAll('modules'); }
        else { return $this->alertas('error_general');}   //echo 'modules vacios';

        if (empty(MasterDom::getDataAll('shortcode_carrier'))){ return $this->alertas('error_generall'); }
        else {$custom->_shortcode = MasterDom::getDataAll('shortcode_carrier');} //echo 'shortcode_carrier vacios'; 
        
        $ruta_servidor='/home/smsmkt/public/img/customer';
        $nombreImagen=$_FILES['img']['name'];
        $rutaTemporal=$_FILES['img']['tmp_name'];
        $rutaDestino=$ruta_servidor."/".$nombreImagen;
        move_uploaded_file($rutaTemporal, $rutaDestino);
        
        $customer->_id     = MasterDom::getData('idcustomer');
        $customer->_customer  = MasterDom::getData('customer');
        $customer->_maxmtday  = MasterDom::getData('max_dia');
        $customer->_maxmtmonth   = MasterDom::getData('max_mes');        

        if ( MasterDom::getData('status') == '') $customer->_status  = 0;
        else $customer->_status = 1;

        if ($nombreImagen == '') $customer->_img = MasterDom::getData('img_hidden');
        else $customer->_img = $nombreImagen;

        /*----------Actualizar Datos de la tabla customer---------*/
        $editcustomer = CustomerDao::update($customer);

        if ($editcustomer === FALSE)
            return $this->alertas('error_general');
        

        /*-----Actualizar datos de la tabla customer_modules------*/
        CustomerDao::deleteCustomerModules($customer->_id);

        foreach ($customer->modules as $key => $value) {
            $insert = CustomerDao::insertCustomerModules($customer->_id,$value);
        }

        if (empty($insert))
            return $this->alertas('error_general');

        /*--Actualiza tabla custom_short_code_carrier_connection--*/

        CustomerDao::deleteCustomSCCC($customer->_id);

        foreach ($custom->_shortcode as $key => $val) {
            $insertCSCC = CustomerDao::insertCustomCCSC($customer->_id, $val);
        }

        if (empty($insertCSCC))
            return $this->alertas('error_general');


        /*---Los modulos de todos los usuarios que pertenezcan a este customer también deben actualizarse ---*/
        
        $users = CustomerDao::getUsers($customer->_id);

        foreach ($users as $key => $value) {
            $modules_user = CustomerDao::getModulesUser($value['user_id']);

            foreach ($modules_user as $k => $val) {
                if (in_array($val['modules_id'], $customer->modules)) {
                    //echo "El valor $val['modules_id'] del arreglo user se encontro en el arreglo customer, se mantiene \n";
                } else {
                    //echo "El valor $val['modules_id'] del arreglo user no se encontro en el arreglo customer, se borra \n";
                }
            }
        }

        /* -----------------------------------------------------------------------------------------*/ 

        if (!empty($editcustomer) || !empty($insert) || !empty($insertCSCC) || !empty($users)) {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Actualizo customer {$customer->_id}");
            CustomerDao::registroUsuario($registro);
            /***************************************************************/
        }

        return $this->alertas('success_add');
    }

    public function delete(){

                $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script>
        $(document).ready(function(){
            $("#add").validate(
                {
                    rules: {
                       customer: {
                            required: true
                        }

                    },
                    messages: {
                        customer: {
                            required: "Elija un Customer"
                        }
                    }                    
                }
            );
        });
        </script>
html;

        $this->showAllCustomer();
        View::render("customerdelete");
    }

    public function deletecustomer(){

                    $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script>
        $(document).ready(function(){
            $("#add").validate(
                {
                    rules: {
                       customer: {
                            required: true
                        }

                    },
                    messages: {
                        customer: {
                            required: "Elija un Customer"
                        }
                    }                    
                }
            );
        });
        </script>
html;
        if(!$_POST OR !MasterDom::whiteListeIp())
            return $this->alertas('error_general');

        $id = MasterDom::getData('customer');
        $id_customer = MasterDom::getSession('customer_id');

        if ($id == $id_customer) {
            return $this->alertas('error_general');
        }

        //CustomerDao::delete($id);
        if (CustomerDao::delete($id)) {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Elimino customer {$id}");
            CustomerDao::registroUsuario($registro);
            /***************************************************************/
        }
        //CustomerDao::deleteCustomerModules($id);

         return $this->alertas('success_add');

    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Success.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'error_producto')
            $mensaje = 'Ocurrio un error al insertar los productos.';
        else
            $mensaje = 'Ocurrio algo inesperado.';

        View::set('regreso','/Menu');
        View::set('class', $class);
        View::set('titulo','Customer');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

    
}