<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Bolsasms as BolsasmsDao;
use \App\controllers\Contenedor;

class Bolsasms
{
	private $_contenedor;

	function __construct() 
	{ 
		$this->_contenedor = new Contenedor;
		View::set('header',$this->_contenedor->header());
		View::set('footer',$this->_contenedor->footer());
	}

	public function index()
	{
		MasterDom::verificaUsuario();

		$option = '';
		$customers = BolsasmsDao::getcustomers();
		foreach ($customers as $key => $value) {
			$option .= "<option value=\"{$value['customer_id']}\">{$value['name']}</option>";
		}

		$bolsa = BolsasmsDao::getAll();
		//print_r($bolsa);
		foreach ($bolsa as $key => $value) {
			foreach ($customers as $key => $val) {
				if ($value['customer_id']==$val['customer_id']) {
					$customer = $val['name'];
				}
			}
			if ($value['estatus']==1) {
				$estatus = 'Activo';
			}elseif ($value['estatus']==2) {
				$estatus = 'Vencido';
			}else{
				$estatus = 'Cancelado';
			}

			if ($estatus=='Activo') {
				$acciones = "<a href=\"/bolsasms/edit/{$value['sms_bag_id']}\" type=\"button\" class=\"btn btn-success btn-circle center-block\" title=\"Editar\">
								<i class=\"fa fa-edit\" aria-hidden=\"true\"></i>
							</a>
							<a href=\"/bolsasms/aplicar/{$value['sms_bag_id']}\" type=\"button\" class=\"btn btn-warning btn-circle center-block\" title=\"Aplicar\">
								<i class=\"fa fa-check-square\" aria-hidden=\"true\"></i>
							</a>
				";
			}else{
				$acciones = 'Sin acciones';
			}
			$html.= <<<html
			<tr>
			    <td><input type="checkbox" name="borrar[]" value="{$value['sms_bag_id']}"/></td>
			    <td>{$value['fecha_compra']}</td>
			    <td>{$value['fecha_expira']}</td>
			    <td>{$value['cantidad']}</td>
			    <td>$customer</td>
			    <td>$estatus</td>
			    <td>$acciones</td>
			</tr>
html;
		}

		View::set("customers",$option);
		View::set("table",$html);
		View::render("bolsasms");
	}
}