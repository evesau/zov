<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//use \Core\View;
use \Core\MasterDom;
//use \App\models\Dinamicweb as DinamicwebDao;
//use \App\controllers\Contenedor;
//use \App\controllers\ApiUrl;
//require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Wsapp {

private $_contenedor;

    /*function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }*/

    public function index($params) {
        $params = MasterDom::getData($params);

        if (!empty($params)) {
            mail("tecnico@airmovil.com","Recibi datos","Params: ".print_r($params,1));
            echo 1;
            exit();
        }else{
            echo 0;
            exit();
        }
    }

}