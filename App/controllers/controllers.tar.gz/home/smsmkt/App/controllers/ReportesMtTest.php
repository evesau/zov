<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//include '/usr/local/bin/vendor/autoload.php';

use \Core\View;
use \Core\MasterDom;
use \App\models\Reportesmt as ReportesDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ReportesMtTest{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function obtenerLimite($registros, $inicio, $limite){
        $seleccion = array();
        for($i = $inicio; $i<count($registros); $i ++) {
            array_push($seleccion, $registros[$i]);
            if($i == ($inicio + $limite)){
                break;
            }
        }
        return $seleccion;
    }

    /*metodo para hacer la busqueda de MT*/
    public function buscarMt(){
        header("Content-type: application/json; charset=utf-8");
        if (!empty($_GET)){
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $fecha_inicio = MasterDom::getData('fecha_inicio');
            $fecha_fin = MasterDom::getData('fecha_fin');

            $customer_id = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            //$fecha_ini = $this->formatoFechaReporte($inicio);
            //$fecha_fin = $this->formatoFechaFinReporte($fin);

            $data = new \stdClass();
            $data->customer_id = $customer_id;
            $data->where = '';
            $data->campaign_id = $id_campania;

            if( !empty($carrier) || !empty($destination) || !empty($source) || !empty($estatus) || !empty($customer_id) || !empty($fecha_inicio) || !empty($fecha_fin) ){

                if( !empty($carrier) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sms.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'")';
                    }else{
                        $data->where .= ' WHERE (sms.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'" )';
                    }
                }

                if( !empty($destination) ){
                    if($data->where != ''){
                        $data->where .= ' AND msisdn_log = "'.$destination.'"';
                    }else{
                        $data->where .= ' WHERE msisdn_log = "'.$destination.'"';
                    }   
                }

                if( !empty($source) ){
                    if($data->where != ''){
                        $data->where .= ' AND sms.source = '.$source;
                    }else{
                        $data->where .= ' WHERE sms.source = '.$source;   
                    }
                }

                if( !empty($estatus) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sms.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR sms.status_dlr = "'.$estatus.'")';
                    }else{
                        $data->where .= ' WHERE (sms.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR sms.status_dlr = "'.$estatus.'")';
                    }
                }

                if( !empty($fecha_inicio) ){
                    if($data->where != ''){
                        //$data->where .= ' AND (sms.entry_time >= "'.$fecha_inicio.'" OR  sc.delivery_date >= "'.$fecha_inicio.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", sms.entry_time >= "'.$fecha_inicio.'"))';
                    }else{
                        //$data->where .= ' WHERE (sms.entry_time >= "'.$fecha_inicio.'" OR  sc.delivery_date >= "'.$fecha_inicio.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", sms.entry_time >= "'.$fecha_inicio.'"))';
                    }
                }

                if( !empty($fecha_fin) ){
                    if($data->where != ''){
                        //$data->where .= ' AND (sms.entry_time <= "'.$fecha_fin.'" OR  sc.delivery_date <= "'.$fecha_fin.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", sms.entry_time <= "'.$fecha_fin.'"))';
                    }else{
                        //$data->where .= ' WHERE (sms.entry_time <= "'.$fecha_fin.'" OR  sc.delivery_date <= "'.$fecha_fin.'")';
                        $data->where .= ' WHERE (IF(sms.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", sms.entry_time <= "'.$fecha_fin.'"))';
                    }
                }

                if( !empty($id_campania) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sc.campaign_id = '.$id_campania.')';
                    }else{
                        $data->where .= ' WHERE (sc.campaign_id = '.$id_campania.')';
                    }
                }else{

                    if( empty($fecha_inicio) && empty($fecha_fin) ){
                        $campaign = ReportesDao::getMaxCampaign(MasterDom::getSession('customer_id'));
                        if($data->where != ''){
                            $data->where .= ' AND (sc.campaign_id = '.$campaign['campaign_id'].')';
                        }else{
                            $data->where .= ' WHERE (sc.campaign_id = '.$campaign['campaign_id'].')';
                        }
                    }
                }
            }

            $registros = ReportesDao::getDataBuscarTest($data);
            $prueba = array("draw"=>$draw, "recordsTotal"=>count($registros), "recordsFiltered"=>count($registros),"data"=>$this->obtenerLimite($registros, $start, $length));
            //mail('jorge.manon@airmovil.com', 'Query Reportes', 'Limites: ('.$start.', '.$length.', '.$draw.')<br><br>'.json_encode($prueba));
            echo json_encode($prueba);
        }
    }

    public function mt(){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
        <!-- jQuery -->
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <script>
        $(document).ready(function() {
            var anio = (new Date).getFullYear();
            
            $('#datetimepicker4').datetimepicker({
                format: 'YYYY-MM-DD H:m:s',
                //minDate: new Date(),
                //maxDate: moment(),
                daysOfWeekDisabled: [0, 6],
                inline: false,
                sideBySide: false
            });
            $('#datetimepicker5').datetimepicker({
                format: 'YYYY-MM-DD H:m:s',
                //minDate: new Date(),
                //maxDate: moment(),
                daysOfWeekDisabled: [0, 6],
                inline: false,
                sideBySide: false
            });

            $("input[id=datetimepicker4]").val("");
            $("input[id=datetimepicker5]").val("");



            var table = $("#reporte_mt").DataTable({
                "processing": true,
                "serverSide": true,
                "bLengthChange": false,
                "searching": false,
                "ordering": false,
                "iDisplayLength": 20,
                "ajax": {
                    "url": '/ReportesMtTest/buscarMt',
                    "dataType":'json'
                },
                "columns": [
                    { "data": "FECHA" },
                    { "data": "CARRIER" },
                    { "data": "DESTINATION" },
                    { "data": "SHORTCODE" },
                    { "data": "CONTENT" },
                    { "data": "ESTATUSSMS" }
                ],
                "language": {
                    "emptyTable": "No hay datos disponibles",
                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                    "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                    "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords":  "No se encontraron resultados",
                    "search": "Buscar:",
                    "processing":     "Procesando...",
                    "paginate" : {
                        "next": "Siguiente",
                        "previous" : "Anterior"
                    }
                }
            });
        });

        function actualizarDataTable(){
            $("#reporte_mt").dataTable().fnDestroy();
            cambioCampania();
        }

        function actualizarDataTableSearchReportMT(){
            $("#reporte_mt").dataTable().fnDestroy();
            cambioCampania();
        }



        function cambioCampania(){

            var table2 = $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/ReportesMtTest/buscarMt',
                                        "dataType":'json',
                                        "data": {
                                            carrier: $("input:text[name=carrier]").val(),
                                            destination: $("input:text[name=destination]").val(),
                                            source: $("input:text[name=source]").val(),
                                            estatus: $("select[name=estatus]").val(),
                                            id_camp: $("#id_campania").val(),
                                            fecha_inicio: $("#datetimepicker4").val(),
                                            fecha_fin: $("#datetimepicker5").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        function actualizarDataTableCampaniaFecha(){
            $("#reporte_mt").dataTable().fnDestroy();
            muestraInfo()
        }


        $("#reporte").click(function(){

            var carrier = $("input:text[name=carrier]").val();
            var destination = $("input:text[name=destination]").val();
            var source = $("input:text[name=source]").val();
            var estatus = $("select[name=estatus]").val();
            var id_camp = $("#id_campania").val();
            var fecha_inicio = $("#datetimepicker4").val();
            var fecha_fin = $("#datetimepicker5").val();

            //alert("/ReportesMtTest/reporte_mt?carrier="+carrier+"&destination="+destination+"&source="+source+"&estatus="+estatus+"&id_camp="+id_camp+"&fecha_inicio="+fecha_inicio+"&fecha_fin="+fecha_fin);




            location.href = "/ReportesMtTest/reporte_mt?carrier="+carrier+"&destination="+destination+"&source="+source+"&estatus="+estatus+"&id_camp="+id_camp+"&fecha_inicio="+fecha_inicio+"&fecha_fin="+fecha_fin;

        });

</script>

html;
        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaignMT($id_custom);  
        $row = array_reverse($row);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['campaign_id'].'::'.$value['name_campaign']." -- ".$value['short_code']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mt_test");
    }

    //$id_campania = (MasterDom::getData('id_camp') != "null")? MasterDom::getData('id_camp') : '';

    public function reporte_mt(){
        if (!empty($_GET)){
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $fecha_inicio = (MasterDom::getData('fecha_inicio') != "null")? MasterDom::getData('fecha_inicio') : '';
            $fecha_fin = (MasterDom::getData('fecha_fin') != "null")? MasterDom::getData('fecha_fin') : '';

            $customer_id = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = (MasterDom::getData('id_camp') != "null")? MasterDom::getData('id_camp') : '';

            //$fecha_ini = $this->formatoFechaReporte($inicio);
            //$fecha_fin = $this->formatoFechaFinReporte($fin);

            $data = new \stdClass();
            $data->customer_id = $customer_id;
            $data->where = '';
            $data->campaign_id = $id_campania;

            if( !empty($carrier) || !empty($destination) || !empty($source) || !empty($estatus) || !empty($customer_id) || !empty($fecha_inicio) || !empty($fecha_fin) ){

                if( !empty($carrier) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sms.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'")';
                    }else{
                        $data->where .= ' WHERE (sms.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'" )';
                    }
                }

                if( !empty($destination) ){
                    if($data->where != ''){
                        $data->where .= ' AND msisdn_log = "'.$destination.'"';
                    }else{
                        $data->where .= ' WHERE msisdn_log = "'.$destination.'"';
                    }   
                }

                if( !empty($source) ){
                    if($data->where != ''){
                        $data->where .= ' AND sms.source = '.$source;
                    }else{
                        $data->where .= ' WHERE sms.source = '.$source;   
                    }
                }

                if( !empty($estatus) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sms.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR sms.status_dlr = "'.$estatus.'")';
                    }else{
                        $data->where .= ' WHERE (sms.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR sms.status_dlr = "'.$estatus.'")';
                    }
                }

                if( !empty($fecha_inicio) ){
                    if($data->where != ''){
                        //$data->where .= ' AND (sms.entry_time >= "'.$fecha_inicio.'" OR  sc.delivery_date >= "'.$fecha_inicio.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", sms.entry_time >= "'.$fecha_inicio.'"))';
                    }else{
                        //$data->where .= ' WHERE (sms.entry_time >= "'.$fecha_inicio.'" OR  sc.delivery_date >= "'.$fecha_inicio.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", sms.entry_time >= "'.$fecha_inicio.'"))';
                    }
                }

                if( !empty($fecha_fin) ){
                    if($data->where != ''){
                        //$data->where .= ' AND (sms.entry_time <= "'.$fecha_fin.'" OR  sc.delivery_date <= "'.$fecha_fin.'")';
                        $data->where .= ' AND (IF(sms.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", sms.entry_time <= "'.$fecha_fin.'"))';
                    }else{
                        //$data->where .= ' WHERE (sms.entry_time <= "'.$fecha_fin.'" OR  sc.delivery_date <= "'.$fecha_fin.'")';
                        $data->where .= ' WHERE (IF(sms.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", sms.entry_time <= "'.$fecha_fin.'"))';
                    }
                }

                if( !empty($id_campania) ){
                    if($data->where != ''){
                        $data->where .= ' AND (sc.campaign_id = '.$id_campania.')';
                    }else{
                        $data->where .= ' WHERE (sc.campaign_id = '.$id_campania.')';
                    }
                }else{

                    if( empty($fecha_inicio) && empty($fecha_fin) ){
                        $campaign = ReportesDao::getMaxCampaign(MasterDom::getSession('customer_id'));
                        if($data->where != ''){
                            $data->where .= ' AND (sc.campaign_id = '.$campaign['campaign_id'].')';
                        }else{
                            $data->where .= ' WHERE (sc.campaign_id = '.$campaign['campaign_id'].')';
                        }
                    }
                }
            }


            $registros = ReportesDao::getDataBuscarTest($data);

        $this->crearExcel($registros);
        exit;
        }
    }

    public static function crearExcel($mensajes){
        $encabezado = array('FECHA','CARRIER','DESTINATION','SHORTCODE','CONTENT','ESTATUSSMS');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$encabezado[$i]]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Reportesmt.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }
}
