<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
//use \App\models\ApiDoppler AS ApiDopplerDao;

class WebHookTelegram {
  private $token_telegram = '422712978:AAGjXp75d9zEzQqkuQNYOnTq8c2VqQZB4s8';

  /*METODO PARA RECIBIR MENSAJE DE CLIENTE AL BOT DE TELEGRAM*/
  public function setWebHook(){
    $input = json_decode(file_get_contents('php://input'), true);

    $chat = new \stdClass();
    $chat->id = $input['message']['chat']['id'];
    $chat->first_name = $input['message']['chat']['first_name'];
    $chat->last_name = $input['message']['chat']['last_name'];
    $chat->type = $input['message']['chat']['type'];
    $chat->date = $input['message']['date'];
    $chat->text = $input['message']['text'];

    if(preg_match('/Jonathan|jonathan|JONATHAN|Erick|erick|ERICK/', $chat->first_name)){
      $mensaje = $chat->first_name." eres gay";
    }else{
      $mensaje = "Hola haz dicho: ".$chat->text;
    }



    $response = $this->sendMessageTelegram($chat->id, $mensaje);


    mail(
      'jorge.manon@airmovil.com',
      'BOT_FACEBOOK',
      'Contenido Telegram: <br> Chat ID: '.
      $chat->id.'<br>Nombre: '.
      $chat->first_name.' '.
      $chat->last_name.'<br> Tipo: '.
      $chat->type.'<br> Fecha: '.
      $chat->date.'<br>Mensaje: '.
      $chat->text.'<br><br>Contenido: '.json_encode($response));
  }

  /*METODO PARA ENVIAR MENSAJE AL CLIENTE DESDE EL BOT DE TELEGRAM*/
  function sendMessageTelegram($chatId, $text) {
    $token = "422712978:AAGjXp75d9zEzQqkuQNYOnTq8c2VqQZB4s8";
    $data = [
        'text' => $text,
        'chat_id' => $chatId
    ];

    return file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
  }

}



















