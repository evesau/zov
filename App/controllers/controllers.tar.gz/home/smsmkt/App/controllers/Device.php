<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Device as DeviceDao;
use \App\controllers\Contenedor;

class Device{

private $_contenedor;

    function __construct() {
      $this->_contenedor = new Contenedor;
    	View::set('header',$this->_contenedor->header());
    	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {
      $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {

             var table = $('#muestra-cupones').DataTable({
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                            "lengthMenu": "Mostrar _MENU_ entradas",
                            "search": "Buscar:",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                bootbox.confirm("&iquest;Eliminaras los mensajes push, seleccionados?", function(result) {
                    if (result) 
                        $( "#delete_form" ).submit();
                });
            });
        } );
</script>
html;
      
      $devices = DeviceDao::getAllDevice(MasterDom::getSession('customer_id'));
      $tabla = '';
      foreach ($devices as $key => $value) {

        switch($value['estatus']){
          case 0:
            $value['estatus'] = 'OCULTO';
            break;
          case 1:
            $value['estatus'] = 'VISIBLE';
            break;
          case 2:
            $value['estatus'] = 'ELIMINADO';
            break;
        }
        $nombre = htmlspecialchars_decode($value['nombre']).' '. htmlspecialchars_decode(($value['apellido']));
        $tabla .=<<<html
          <tr>
            <td style="vertical-align:middle;" class="sorting_1"><input type="checkbox" name="borrar[]" value="{$value['push_device']}"></td>
            <td style="vertical-align:middle;">{$value['msisdn']}</td>
            <td style="vertical-align:middle;">{$value['sistema_operativo']}</td>
            <td style="vertical-align:middle;">{$nombre}</td>
            <td style="vertical-align:middle;">{$value['cuenta']}</td>
            <td style="vertical-align:middle;">{$value['estatus']}</td>
            <td style="vertical-align:middle;">{$value['sexo']}</td>
            <td style="vertical-align:middle; text-align:center;">
              <a class="btn btn-info" href="/Device/edit/{$value['push_device']}" type="button">
                <i class="fa fa-pencil-square-o"></i>
              </a>
            </td>
          </tr>
html;
      }

      View::set('tabla',$tabla);
      View::set('header',$this->_contenedor->header($extraHeader));
    	View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('device_all');
    }

    public function add(){
      $extraHeader =<<<html
      <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="/css/custom.min.css">
      <link rel="stylesheet" href="/css/validate/cmxform.css">
html;
      $extraFooter =<<<html

      <script src="/js/jquery.dataTables.min.js"></script>
      <script src="/js/dataTables.bootstrap.min.js"></script>
      <script src="/js/bootbox.min.js"></script>
      <script src="/js/validate/jquery.validate.js"></script>
      <script>
        $(document).ready(function(){

          $("#opcion").change(function(){
            var opcion = $("#opcion").val();
            if(opcion == 1){
              window.location = "/Device/add";
            }else{
              if(opcion == 2){
                $("#contenedor").html('<div class="form-group"><label class="control-label col-md-2 col-sm-2 col-xs-2">Archivo CSV: </label><div class="col-md-9 col-sm-9 col-xs-12"><input class="form-control" type="file" name="archivo" id="archivo" /></div></div>');
              }
            }
          });

          $("#add").validate({
            rules: {
              token:{
                required: true
              },
              msisdn: {
                required: true
              },
              sistema_operativo: {
                required: true
              },
              nombre: {
                required: true
              },
              apellido: {
                required: true
              },
              cuenta: {
                required: true
              },
              archivo: {
                required: true
              }
            },
            messages: {
              token:{
                required: "Este campo es requerido"
              },
              msisdn: {
                required: "Este campo es requerido"
              },
              sistema_operativo: {
                required: "Este campo es requerido"
              },
              nombre: {
                required: "Este campo es requerido"
              },
              apellido: {
                required: "Este campo es requerido"
              },
              cuenta: {
                required: "Este campo es requerido"
              },
              archivo: {
                required: "Este campo es requerido"
              }
            }
          });

        });
      </script>
html;

      $sSexo = '';
      foreach (array('Femenino','Masculino') as $key => $value) {
        $sSexo .= '<option value="'.$value.'" >'.$value.'</option>';
      }

      $sEstatus = '';
      foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
        $sEstatus .= '<option value="'.$key.'" >'.$value.'</option>';
      }

      View::set('sEstatus',$sEstatus);
      View::set('sSexo',$sSexo);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('device_add');
    }

    public function edit($id){
      $extraHeader =<<<html
      <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="/css/custom.min.css">
      <link rel="stylesheet" href="/css/validate/cmxform.css">
html;
      $extraFooter =<<<html
      <script src="/js/validate/jquery.validate.js"></script>
      <script src="/js/jquery.dataTables.min.js"></script>
      <script src="/js/dataTables.bootstrap.min.js"></script>
      <script src="/js/bootbox.min.js"></script>
      <script>
        $(document).ready(function(){

          $("#edit").validate({
            rules: {
              token:{
                required: true
              },
              msisdn: {
                required: true
              },
              sistema_operativo: {
                required: true
              },
              nombre: {
                required: true
              },
              apellido: {
                required: true
              },
              cuenta: {
                required: true
              }
            },
            messages: {
              token:{
                required: "Este campo es requerido"
              },
              msisdn: {
                required: "Este campo es requerido"
              },
              sistema_operativo: {
                required: "Este campo es requerido"
              },
              nombre: {
                required: "Este campo es requerido"
              },
              apellido: {
                required: "Este campo es requerido"
              },
              cuenta: {
                required: "Este campo es requerido"
              }
            }
          });

        });
      </script>
html;
      $device = DeviceDao::getById($id);

      $sSexo = '';
      foreach (array('Femenino','Masculino') as $key => $value) {
        $selected = (strtolower($device['sexo']) == strtolower($value))? 'selected' : '';
        $sSexo .= '<option '.$selected.' value="'.$value.'" >'.$value.'</option>';
      }

      $sEstatus = '';
      foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
        $selected = ($device['estatus'] == $key)? 'selected' : '';
        $sEstatus .= '<option '.$selected.' value="'.$key.'" >'.$value.'</option>';
      }

      View::set('sEstatus',$sEstatus);
      View::set('sSexo',$sSexo);
      View::set('device',$device);

      View::set('header',$this->_contenedor->header($extraHeader));
    	View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('device_edit');
    }

    public function delete(){
      $ids = MasterDom::getDataAll('borrar');
      foreach ($ids as $key => $value) {
        DeviceDao::delete($value);
      }
      Header("Location: /Device/");
    }

      public function deviceAdd(){
        $opcion = MasterDom::getData("opcion");
        if($opcion==1){
          $device = new \stdClass();
          $device->_token = MasterDom::getData("token");
          $device->_msisdn = MasterDom::getData("msisdn");
          $device->_estatus = MasterDom::getData("estatus");
          $device->_sistema_operativo = MasterDom::getData("sistema_operativo");
          $device->_nombre = MasterDom::getData("nombre");
          $device->_apellido = MasterDom::getData("apellido");
          $device->_cuenta = MasterDom::getData("cuenta");
          $device->_sexo = MasterDom::getData("sexo");

          DeviceDao::insert($device);

        }else{
          if($opcion == 2){
            $archivo = $_FILES['archivo'];

            if (($fichero = fopen($archivo['tmp_name'], "r")) !== FALSE) {
              $contador = 0;
              while (($datos = fgetcsv($fichero, 1000)) !== FALSE) {
                if($contador != 0){
                  $device = new \stdClass();
                  $device->_token = $datos[0];
                  $device->_msisdn = $datos[1];
                  $device->_estatus = $datos[2];
                  $device->_sistema_operativo = $datos[3];
                  $device->_nombre = $datos[4];
                  $device->_apellido = $datos[5];
                  $device->_cuenta = $datos[6];
                  $device->_sexo = $datos[7];
                  DeviceDao::insert($device);
                }
                $contador +=1;
              }
            }
          }
          Header("Location: /Device/");
        }


      }

    public function deviceEdit(){
      $device = new \stdClass();
      $device->_push_device = MasterDom::getData("push_device");
      $device->_token = MasterDom::getData("token");
      $device->_msisdn = MasterDom::getData("msisdn");
      $device->_estatus = MasterDom::getData("estatus");
      $device->_sistema_operativo = MasterDom::getData("sistema_operativo");
      $device->_nombre = MasterDom::getData("nombre");
      $device->_apellido = MasterDom::getData("apellido");
      $device->_cuenta = MasterDom::getData("cuenta");
      $device->_sexo = MasterDom::getData("sexo");

      echo DeviceDao::update($device);
      Header("Location: /Device/");
    }

}
