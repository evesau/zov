<?php

$arreglo = array(0 =>array('msisdn' => 525510123937,'carrier_connection_id' => 4,'white_list' => 1),
				1 =>array('msisdn' => 525510123938,'carrier_connection_id' => 4,'white_list' => 1),
				2 =>array('msisdn' => 525510123939,'carrier_connection_id' => 4,'white_list' => 1),
				3 =>array('msisdn' => 525510123939,'carrier_connection_id' => 4,'white_list' => 1),
				4 =>array('msisdn' => 525510123938,'carrier_connection_id' => 4,'white_list' => 1)
			);

$arreglo1 = array(	0 =>array('msisdn' => 525510123939,'carrier_connection_id' => 4,'white_list' => 1),
				   	1 =>array('msisdn' => 525510123938,'carrier_connection_id' => 4,'white_list' => 1));

print_r($arreglo);
echo "-->";
print_r($arreglo1);

foreach ($arreglo1 as $key => $value) {
	if($clave=array_search($value,$arreglo))
	{
	 unset($arreglo[$clave]);
	}
}


/*if($clave=array_search($arreglo1,$arreglo))
{
 unset($arreglo[$clave]);
}*/
print_r($arreglo);

?>