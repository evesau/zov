<?php  
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Reporteglobal as ReporteglobalDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Reporteglobal {

private $_contenedor;

	function __construct() {
		$this->_contenedor = new Contenedor;
		View::set('header',$this->_contenedor->header());
		View::set('footer',$this->_contenedor->footer());
	}

	public function index() {
		MasterDom::verificaUsuario();

		$extraHeader =<<<html
		<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;
		$extraFooter =<<<html
		<!-- DataTables JavaScript -->
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <!-- DateTimePicker -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script type="text/javascript">
            $(function () {
                $('#datetimepicker1').datetimepicker();
                $('#datetimepicker2').datetimepicker();
            });
        </script>
        <script>

            $(document).ready(function(){

                anio = (new Date).getFullYear();

                //console.debug(anio);

                $('#datetimepicker1').datetimepicker({
                    format: 'YYYY-MM-DD',
                    dayOfWeekDisabled: [0,6]

                });

                $('#datetimepicker2').datetimepicker({
                    format: 'YYYY-MM-DD',
                    dayOfWeekDisabled: [0,6]
                });

                // fecha minima 
                /*$("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });*/
                // fecha maxima
                /*$("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").maxDate(e.date);
                });*/
                // fecha minima 
                /*$("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").minDate(e.date);
                });*/
                // fecha maxima
                /*$("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });*/


                var table = $("#muestra_reporte").DataTable({
                               "processing": true,
                               "serverSide": true,
                               "bLengthChange": false,
                               "searching": false,
                               "ordering": false,
                               "iDisplayLength": 20,
                               "ajax": {
                                           "url": '/Reporteglobal/datosjsonGlobal',
                                           "dataType":'json'
                                       },
                               "columns": [
                                   { "data": "fecha" },
                                   { "data": "key_santander" },
                                   { "data": "msisdn" },
                                   { "data": "campania" },
                                   { "data": "mensaje" },
                                   { "data": "direction" }
                               ],
                               "language": {
                                   "emptyTable": "No hay datos disponibles",
                                   "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                   "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                   "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                   "lengthMenu": "Mostrar _MENU_ registros",
                                   "zeroRecords":  "No se encontraron resultados",
                                   "search": "Buscar:",
                                   "processing":     "Procesando...",
                                   "paginate" : {
                                       "next": "Siguiente",
                                       "previous" : "Anterior"
                                   }
                               }
                            }); // Fin de tabla

                $("#btnBuscar").click(function(){

                  $("#muestra_reporte").dataTable().fnDestroy();

                  var table = $("#muestra_reporte").DataTable({
                                 "processing": true,
                                 "serverSide": true,
                                 "bLengthChange": false,
                                 "searching": false,
                                 "ordering": false,
                                 "iDisplayLength": 20,
                                 "ajax": {
                                             "url": '/Reporteglobal/buscar_reporte',
                                             "dataType":'json',
                                             "data": {fecha_inicial: $("#datetimepicker1").val(),
                                                      fecha_final: $("#datetimepicker2").val(),
                                                      key_santander: $("input:text[name=key_santander]").val(),
                                                      msisdn: $("input:text[name=msisdn]").val(),
                                                      campania: $("#campania").val()
                                                    }
                                          },
                                 "columns": [
                                     { "data": "fecha" },
                                     { "data": "key_santander" },
                                     { "data": "msisdn" },
                                     { "data": "campania" },
                                     { "data": "mensaje" },
                                     { "data": "direction" }
                                 ],
                                 "language": {
                                     "emptyTable": "No hay datos disponibles",
                                     "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                     "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                     "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                     "lengthMenu": "Mostrar _MENU_ registros",
                                     "zeroRecords":  "No se encontraron resultados",
                                     "search": "Buscar:",
                                     "processing":     "Procesando...",
                                     "paginate" : {
                                         "next": "Siguiente",
                                         "previous" : "Anterior"
                                     }
                                 }
                              }); // Fin de tabla

                }); // Fin de Buscar



            }); // Fin de document).ready


        </script>

        <script>
        $(document).ready(function(){
          $("#descargarReporte").click(function(){

            $( "#buscar_form" ).attr('action', '/Reporteglobal/descargarReporte');
            $( "#buscar_form" ).attr('method', 'POST');
            $( "#buscar_form" ).attr('target', '_blank');
            $( "#buscar_form" ).submit();

            //$.post( "/Reporteglobal/descargarReporte", $( "#buscar_form" ).serialize() );

          }); 
        });
        </script>
        <!--script type="text/javascript">
        $(document).ready(function() {

            var table = $('#muestra_reporte').DataTable({
                "language": {
                                    "emptyTable": "No hay datos disponibles",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                    "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                    "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                    "lengthMenu": "Mostrar _MENU_ registros",
                                    "zeroRecords":  "No se encontraron resultados",
                                    "search": "Buscar:",
                                    "processing": "Procesando...",
                                    "paginate" : {
                                        "next": "Siguiente",
                                        "previous" : "Anterior"
                                    }
                                }
            });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                    bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                        if (result) 
                            $( "#delete_form" ).submit();
                    });
            });
        } );
        </script-->
        
html;

    $campania = ReporteglobalDao::getAllCampaignSms();
    $campanias = '';
    foreach ($campania as $key => $value) {
      $campanias .= "<option value=".$value['campaign_id'].">".$value['name']."</option>";
    }
		
    View::set('show_campanias',$campanias);
		View::set('header',$this->_contenedor->header($extraHeader));
		View::set('footer',$this->_contenedor->footer($extraFooter));
		View::render("reporteglobal");

	} // Fin function index

    public function datosjsonGlobal(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $recordsTotalFiltered = count(ReporteglobalDao::getAll());

        $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPart($start,$length));

        echo json_encode($datos);

    } // Fin function datosjsonGlobal

    public function buscar_reporte(){
        $key_santander = MasterDom::getData('key_santander');
        $msisdn =MasterDom::getData('msisdn');
        if ($msisdn != "") {
          $msisdn = "52".$msisdn;
        }else{
          $msisdn = "";
        }
        
        $campanias = MasterDom::getDataAll('campania');
        
        $campania ='';
        foreach ($campanias as $key => $value) {
          $campania .= $value.",";
        }
        $campania = trim($campania,",");


        $fecha_inicial = MasterDom::getData('fecha_inicial');
        $fecha_final = MasterDom::getData('fecha_final');

        if ($fecha_inicial == "") {
          $fecha_inicial = date('Y-m-d 00:00:00');
        }else{
          $fecha_inicial = $this->fechaInicial($fecha_inicial);
        }

        if ($fecha_final == "") {
          $fecha_final = date('Y-m-d G:i:s');
        }else{
          $fecha_final = $this->fechaFinal($fecha_final);
        }

        /*echo "key: $key_santander\n";
        echo "msisdn: $msisdn\n";
        echo "campania: $campania\n";*/
        //echo "fecha_inicial_controller: $fecha_inicial\n";
        //echo "fecha_final_controller: $fecha_final\n";

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        if (!empty($key_santander) && !empty($msisdn) && !empty($campania)) { // todos los parametros
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParams($fecha_inicial,$fecha_final,$key_santander,$msisdn,$campania));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParams($fecha_inicial,$fecha_final,$key_santander,$msisdn,$campania,$start,$length));
        } elseif (!empty($key_santander) && !empty($msisdn) && empty($campania)) { // key_santander, msisdn
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsKeyMsisdn($fecha_inicial,$fecha_final,$key_santander,$msisdn));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsKeyMsisdn($fecha_inicial,$fecha_final,$key_santander,$msisdn,$start,$length));
        } elseif (!empty($key_santander) && empty($msisdn) && !empty($campania)) { // key_santander, campania
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsKeyCampaign($fecha_inicial,$fecha_final,$key_santander,$campania));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsKeyCampaign($fecha_inicial,$fecha_final,$key_santander,$campania,$start,$length));
        } elseif (!empty($key_santander) && empty($msisdn) && empty($campania)) { // key_santander
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsKey($fecha_inicial,$fecha_final,$key_santander));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsKey($fecha_inicial,$fecha_final,$key_santander,$start,$length));
        } elseif (empty($key_santander) && !empty($msisdn) && !empty($campania)) { // msisdn, campania
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsMsisdnCampaign($fecha_inicial,$fecha_final,$msisdn,$campania));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsMsisdnCampaign($fecha_inicial,$fecha_final,$msisdn,$campania,$start,$length));
        } elseif (empty($key_santander) && !empty($msisdn) && empty($campania)) { // msisdn
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsMsisdn($fecha_inicial,$fecha_final,$msisdn));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsMsisdn($fecha_inicial,$fecha_final,$msisdn,$start,$length));
        } elseif (empty($key_santander) && empty($msisdn) && !empty($campania)) { // campania
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsCampaign($fecha_inicial,$fecha_final,$campania));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsCampaign($fecha_inicial,$fecha_final,$campania,$start,$length));
        } elseif (empty($key_santander) && empty($msisdn) && empty($campania)) { // solo fechas
          $recordsTotalFiltered = count(ReporteglobalDao::getAllParamsDates($fecha_inicial,$fecha_final));
          $datos =  array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReporteglobalDao::getAllPartParamsDates($fecha_inicial,$fecha_final,$start,$length));
        }

        echo json_encode($datos);

        

    } // Fin function buscar_reporte

    public function descargarReporte(){

        $key_santander = MasterDom::getData('key_santander');
        $msisdn =MasterDom::getData('msisdn');
        if ($msisdn != "") {
          $msisdn = "52".$msisdn;
        }else{
          $msisdn = "";
        }
        
        $campanias = MasterDom::getDataAll('campania');
        
        $campania ='';
        foreach ($campanias as $key => $value) {
          $campania .= $value.",";
        }
        $campania = trim($campania,",");


        $fecha_inicial = MasterDom::getData('fecha_inicial');
        $fecha_final = MasterDom::getData('fecha_final');

        if ($fecha_inicial == "") {
          $fecha_inicial = date('Y-m-d 00:00:00');
        }else{
          $fecha_inicial = $this->fechaInicial($fecha_inicial);
        }

        if ($fecha_final == "") {
          $fecha_final = date('Y-m-d G:i:s');
        }else{
          $fecha_final = $this->fechaFinal($fecha_final);
        }


        if (!empty($key_santander) && !empty($msisdn) && !empty($campania)) { // todos los parametros
          
          $datos = ReporteglobalDao::getAllParams($fecha_inicial,$fecha_final,$key_santander,$msisdn,$campania);
          
        } elseif (!empty($key_santander) && !empty($msisdn) && empty($campania)) { // key_santander, msisdn
          
          $datos = ReporteglobalDao::getAllParamsKeyMsisdn($fecha_inicial,$fecha_final,$key_santander,$msisdn);
          
        } elseif (!empty($key_santander) && empty($msisdn) && !empty($campania)) { // key_santander, campania
          
          $datos = ReporteglobalDao::getAllParamsKeyCampaign($fecha_inicial,$fecha_final,$key_santander,$campania);
          
        } elseif (!empty($key_santander) && empty($msisdn) && empty($campania)) { // key_santander
          
          $datos = ReporteglobalDao::getAllParamsKey($fecha_inicial,$fecha_final,$key_santander);

        } elseif (empty($key_santander) && !empty($msisdn) && !empty($campania)) { // msisdn, campania
          
          $datos = ReporteglobalDao::getAllParamsMsisdnCampaign($fecha_inicial,$fecha_final,$msisdn,$campania);
          
        } elseif (empty($key_santander) && !empty($msisdn) && empty($campania)) { // msisdn
          
          $datos = ReporteglobalDao::getAllParamsMsisdn($fecha_inicial,$fecha_final,$msisdn);
          
        } elseif (empty($key_santander) && empty($msisdn) && !empty($campania)) { // campania
          
          $datos = ReporteglobalDao::getAllParamsCampaign($fecha_inicial,$fecha_final,$campania);
          
        } elseif (empty($key_santander) && empty($msisdn) && empty($campania)) { // solo fechas
          
          $datos = ReporteglobalDao::getAllParamsDates($fecha_inicial,$fecha_final);
          
        }

       //print_r($datos);
       $this->crearExcel($datos);
       exit;

    }


    public static function crearExcel($mensajes){
        $encabezado = array('FECHA','KEY_SANTANDER','MSISDN','CAMPANIA','MENSAJE','DIRECTION');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i <= $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Reporteglobal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    } // Fin crear excel




    public function fechaInicial($fecha){

        $param = explode('/',$fecha);

            $dia = $param[1];
            $mes = $param[0];
            $anio = explode(" ",$param[2]);
            $anio = $anio[0];

        $fecha = $anio."-".$mes."-".$dia." 00:00:00";


        return $fecha;
    } // Fin function fechaInicial


    public function fechaFinal($fecha){

        $param = explode('/',$fecha);

            $dia = $param[1];
            $mes = $param[0];
            $anio = explode(" ",$param[2]);
            $anio = $anio[0];

        $fecha = $anio."-".$mes."-".$dia." 23:59:59";


        return $fecha;
    } // Fin function fechaFinal



} // Fin Class

?>