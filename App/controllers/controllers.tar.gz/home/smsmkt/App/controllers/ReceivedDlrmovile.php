<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Campania as CampaniaDao;
use \App\controllers\Contenedor;

class ReceivedDlrmovile
{
	public function index(){
		$get = print_r($_GET,1);
		$post = print_r($_POST,1);
		mail("tecnico@airmovil.com","ReceivedDlrmovile","get: ".$get." <br> post: ".$post. " php input: ".file_get_contents("php://input"));
	}
}