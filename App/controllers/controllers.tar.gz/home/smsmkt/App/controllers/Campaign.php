<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Campaign as CampaignDao;
use \App\controllers\Contenedor;

class Campaign
{

private $_contenedor;

    function __construct() { 

	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {

	$extraHeader=<<<html
<!-- DataTables CSS -->
	<link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

	$extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>	
	$(document).ready(function() {

	     var table = $('#muestra-cupones').DataTable();

    	    $("#checkAll").change(function () {
    		$("input:checkbox").prop('checked', $(this).prop("checked"));
    	    });

    	    $(document).on("click", "#delete", function(e) {
            	bootbox.confirm("&iquest;Desactivaras los carriers seleccionados?", function(result) {
		    if (result) 
		        $( "#delete_form" ).submit();
            	});
            });
	} );
</script>
html;


	View::set('header',$this->_contenedor->header($extraHeader));
	$row = CampaignDao::getAllCampaign(MasterDom::getSession('customer_id'));
	$html = '';
	foreach($row AS $key=>$value){

	    $id = MasterDom::setParamSecure($value['campaign_id']);
	    $html.=<<<html
		<tr>
		    <td>{$value['nombre']}</td>
		    <td>{$value['modulo']}</td>
		    <td>{$value['status']}</td>
		    <td class="center"><a href="/campaign/edit/$id" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
		</tr>
html;
	}	

	View::set('table',$html);
	View::set('footer',$this->_contenedor->footer($extraFooter));
	View::render("campaign_all");
    }

    private function jqueryShortCode(){
        $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script>    
        $(document).ready(function() {
             var table = $('#muestra-cupones').DataTable();
        } );

        jQuery.validator.addMethod("ExisteUsuario",function(value,element)
            {

                data = {"nombre" : value},
                eReport = '';
                var nombre_hidden = $("#nombre_hidden").val();

                var val = 0;

                $.ajax(
                {
                   type: "POST",
                   url: "/carrier/validaNombreShortCode",
                   dataType: "json",
                   data: data,
                   async:false,    
                   success: function(data){
                        if(data == true)
                           val = 1;
                   },
                   error: function(xhr, textStatus, errorThrown){
                        val = 0;
                   }
                });

                if(nombre_hidden == value)
                    val = 1;
                
                return this.optional(element) || 0 != val;
            }, jQuery.validator.format("Ya existe"));

	    $("#add").validate(
                {
                    rules: {
                        nombre: {
                            required: true,
                            maxlength: 60,
                            minlength: 3,
                            ExisteUsuario: true
                        }
                    }
        });
</script>
html;
        return array('header'=>$extraHeader, 'footer'=>$extraFooter);
    }

    private function jqueryCompany(){
	$extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

	$extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script>    
        $(document).ready(function() {
             var table = $('#muestra-cupones').DataTable();
        } );

        jQuery.validator.addMethod("ExisteUsuario",function(value,element)
            {

                data = {"nombre" : value},
                eReport = '';
                var nombre_hidden = $("#nombre_hidden").val();

                var val = 0;

                $.ajax(
                {
                   type: "POST",
                   url: "/carrier/validaNombreCompany",
                   dataType: "json",
                   data: data,
                   async:false,    
                   success: function(data){
                        if(data == true)
                           val = 1;
                   },
                   error: function(xhr, textStatus, errorThrown){
                        val = 0;
                   }
                });

                if(nombre_hidden == value)
                    val = 1;
                
                return this.optional(element) || 0 != val;
            }, jQuery.validator.format("Ya existe este nombre"));

	    $("#add").validate(
                {
                    rules: {
                        nombre: {
                            required: true,
                            maxlength: 60,
                            minlength: 3,
                            ExisteUsuario: true
                        }
                    }
        });
</script>
html;
	return array('header'=>$extraHeader, 'footer'=>$extraFooter);
    }

    public function add(){

	$extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
 	<link rel="stylesheet" href="/css/validate/screen.css">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>   

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>



    <script>    
	$(document).ready(function() {

	$('#wizard_verticle').smartWizard({
            transitionEffect: 'slide',
	    onFinish: function() {
		alert("final");
            },
	    onLeaveStep: leaveAStepCallback
        });

        $('.buttonNext').addClass('btn btn-success');
        $('.buttonPrevious').addClass('btn btn-primary');
        $('.buttonFinish').addClass('btn btn-default');


	jQuery('#datetimepicker').datetimepicker();


	$( "#short_code" ).on('change',function() {
	    $("#carrier").html("");
	    $.get("/campaign/selectCarrier?short_code_id=" + $(this).val(), function(respuestaSolicitud){
		$("#carrier").html(respuestaSolicitud);
	    });
	});

      });

function leaveAStepCallback(obj, context) {
    alert("Leaving step " + context.fromStep + " to go to step " + context.toStep);
    return true;
}

    </script>
html;

	$carrier = CampaignDao::getCarrier(MasterDom::getSession('customer_id'));
	if(count($carrier) < 1)
	    return MasterDom::alertas('personal', '/campaign', 'Campaign','Lo sentimos no cuentas con ningun Short Code asociado comunicate con el Web Master.');

	View::set('short_code', $this->forSelect($carrier,'short_code_id', 'short_code'));
        View::set('header',$this->_contenedor->header($extraHeader));
	View::set('footer',$this->_contenedor->footer($extraFooter));

        View::render("campaign_add");
    }

    public function selectCarrier(){
	
	$shortCode = (int)MasterDom::getData('short_code_id');
	if(empty($shortCode))
	    return;

	$session = MasterDom::getSession('customer_id');				
	if(empty($session))
	    return;

	$data = CampaignDao::getCarrierCustomer($session, $shortCode);
	if(empty($data))
	    return;

	$html='';
	foreach($data AS $value){
	    $html.=<<<html
<input type="checkbox" name="carrier_connection_short_code_id" value="{$value['carrier_connection_short_code_id']}"> {$value['name']}<br>
html;
	}

	echo $html;
	return;
    }

    private function forSelect($array, $key, $value){
	$html = '<option value="0">Selecciona</option>';
	foreach($array AS $val){
	    $html.=<<<html
<option value="{$val[$key]}">{$val[$value]}</option>
html;
	}

	return $html;
    }

    public function edit($id){
	$id = MasterDom::getParamSecure($id);
	if(empty($id) OR ($id == 0))
	    return MasterDom::alertas('error_general');

	$data = CarrierDao::getById($id);
	if(empty($data) OR (count($data) < 1))
	    return MasterDom::alertas('error_general');

	$carrier = new \stdClass();
	$carrier->_nombre  = $data['carrier_name'];
        $carrier->_host  = $data['host'];
        $carrier->_puerto = $data['port'];
        $carrier->_system_id = $data['system_id'];
        $carrier->_password = $data['password'];
        $carrier->_system_type  = ($data['system_type'] == 'nulo') ? '' : $data['system_type'];
        $carrier->_source_ton = $data['source_ton'];
        $carrier->_source_npi = $data['source_npi'];
        $carrier->_destination_ton = $data['destination_ton'];
        $carrier->_destination_npi = $data['destination_npi'];
        $carrier->_addr_ton = $data['addr_ton'];
        $carrier->_addr_npi = $data['addr_npi'];
        $carrier->_supports_wap_push = ($data['supports_wap_push'] == 1 ) ? 'checked="checked"' :'' ;
        $carrier->_mode = $data['mode'];
        $carrier->_status = ($data['status'] == 1) ? 'checked="checked"' :'' ;
        $carrier->_tps_submit_one = $data['tps_submit_one'];
        $carrier->_tps_submit_multi = $data['tps_submit_multi'];
        $carrier->_submit_multi_size = $data['submit_multi_size'];
        $carrier->_white_list = ($data['white_list'] == 'enable') ? 'checked="checked"' :'' ;
        $carrier->_white_list_user = $data['white_list_user'];
        $carrier->_white_list_pwd = $data['white_list_pwd'];
        $carrier->_country_code = $data['country_code'];
        $carrier->_carrier = $data['carrier_id'];
        $carrier->_shortCode = $data['short_code_id'];
	$carrier->_id = $data['carrier_connection_short_code_id'];
	$carrier->_carrier_connection_id = $data['carrier_connection_id'];

	$obtieneSelect = function($metodo, $valor){
            $show = $this->$metodo(true);
            $html = '';
            foreach($show AS $value){
		$selected = ($value['id'] == $valor) ? 'selected="selected"' : '';
                $html.=<<<html
                <option value="{$value['id']}" $selected >{$value['value']}</option>
html;
            }

            return $html;
        };

        $carrierShow = $obtieneSelect('showCarrier', $carrier->_carrier);
        $shortCodeShow = $obtieneSelect('showShortCode', $carrier->_shortCode);

	$showMode = '';
	foreach(array('TRX','TR','RX') AS $value){
	    $selected = ($value == $carrier->_mode) ? 'selected="selected"' : '';
	    $showMode.=<<<html
                <option value="$value" $selected >$value</option>
html;
	}

	$jquery = $this->setJquery();
	View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
	View::set('carrier', $carrier);
        View::set('shortCodeShow', $shortCodeShow);
	View::set('carrierShow', $carrierShow);
	View::set('modeShow', $showMode);
        View::render("carrier_edit");
    }

    private function getObjCarrier($edit = false){

	$carrier = new \stdClass();

	if($edit){
	    $carrier->_id = MasterDom::getData('id');
            $carrier->_carrier_connection_id = MasterDom::getData('carrier_connection_id');

	    if(empty($carrier->_id) OR empty($carrier->_carrier_connection_id))
		return MasterDom::alertas('error_general');
	}

        $carrier->_nombre  = MasterDom::getData('nombre');
        $carrier->_host  = MasterDom::getData('host');
        $carrier->_puerto = MasterDom::getData('puerto');
        $carrier->_system_id = MasterDom::getData('system_id');
        $carrier->_password = MasterDom::getData('password');
        $carrier->_system_type  = MasterDom::getData('system_type');
        $carrier->_source_ton = MasterDom::getData('source_ton');
        $carrier->_source_npi = MasterDom::getData('source_npi');
        $carrier->_destination_ton = MasterDom::getData('destination_ton');
        $carrier->_destination_npi = MasterDom::getData('destination_npi');
        $carrier->_addr_ton = MasterDom::getData('addr_ton');
        $carrier->_addr_npi = MasterDom::getData('addr_npi');
        $carrier->_supports_wap_push = MasterDom::getData('supports_wap_push');
        $carrier->_mode = MasterDom::getData('mode');
        $carrier->_status = MasterDom::getData('status');
        $carrier->_tps_submit_one = MasterDom::getData('tps_submit_one');
        $carrier->_tps_submit_multi = MasterDom::getData('tps_submit_multi');
        $carrier->_submit_multi_size = MasterDom::getData('submit_multi_size');
        $carrier->_white_list = MasterDom::getData('white_list');
        $carrier->_white_list_user = MasterDom::getData('white_list_user');
        $carrier->_white_list_pwd = MasterDom::getData('white_list_pwd');
        $carrier->_country_code = MasterDom::getData('country_code');
        $carrier->_carrier = MasterDom::getData('carrier');
        $carrier->_shortCode = MasterDom::getData('short_code');

        if(empty($carrier->_nombre) || empty($carrier->_host) || empty($carrier->_puerto) || empty($carrier->_system_id)
                || empty($carrier->_password) || ($carrier->_source_ton == '') || ($carrier->_source_npi == '') || ($carrier->_destination_ton == '')
                || ($carrier->_destination_npi == '') || ($carrier->_addr_ton == '') || ($carrier->_addr_npi == '') || empty($carrier->_mode)
                || ($carrier->_tps_submit_one == '') || ($carrier->_tps_submit_multi == '') || ($carrier->_submit_multi_size == '')
                || empty($carrier->_carrier) || empty($carrier->_shortCode)){
            return MasterDom::alertas('error_general');
	}

        $carrier->_status = ($carrier->_status == 'on') ? 1 : 0;
        $carrier->_supports_wap_push = ($carrier->_supports_wap_push == 'on') ? 1 : 0;
        $carrier->_white_list = ($carrier->_white_list == 'on') ? 'enable' : 'disable';

	return $carrier;
    }

    public function addCompany(){

	if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

	$nombre = MasterDom::getData('nombre');
	if(empty($nombre))
	    return MasterDom::alertas('error_general');

	if(!CarrierDao::insertCompany($nombre))
	    return MasterDom::alertas('error_general');

	return MasterDom::alertas('success_add');	
    }

    public function editCompany($id){

	$id = MasterDom::getParamSecure($id);
        if(empty($id) OR ($id == 0))
            return MasterDom::alertas('error_general');

        $data = CarrierDao::getIdCompany($id);
        if(empty($data) OR (count($data) < 1))
            return MasterDom::alertas('error_general');

	$jquery = $this->jqueryCompany();
	$carrier = new \stdClass();
	$carrier->_nombre = $data['name'];
	$carrier->_id = $data['carrier_id'];
	View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
	View::set('carrier', $carrier);
        View::render("carrier_company_edit");
    }

    public function editCompanyPost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
	$id = MasterDom::getData('id');
        if(empty($nombre) OR empty($id))
            return MasterDom::alertas('error_general');

        if(CarrierDao::updateCompany($id, $nombre) === false)
            return MasterDom::alertas('error_general');

        return MasterDom::alertas('success_add');
    }

    public function indexShortCode() {

        $row = CarrierDao::getAllShortCode();
        $html = '';
        foreach($row AS $key=>$value){

            $id = MasterDom::setParamSecure($value['short_code_id']);
            $html.=<<<html
                <tr>
                    <td>{$value['short_code']}</td>
                    <td class="center"><a href="/carrier/editShortCode/$id" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a></td>
                </tr>
html;
        }

        $jquery = $this->jqueryShortCode();
        View::set('table',$html);
        View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
        View::render("carrier_short_code_all");
    }

    public function addShortCode(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
        if(empty($nombre))
            return MasterDom::alertas('error_general');

        if(!CarrierDao::insertShortCode($nombre))
            return MasterDom::alertas('error_general');

        return MasterDom::alertas('success_add');
    }

    public function editShortCode($id){

        $id = MasterDom::getParamSecure($id);
        if(empty($id) OR ($id == 0))
            return MasterDom::alertas('error_general');

        $data = CarrierDao::getIdShortCode($id);
        if(empty($data) OR (count($data) < 1))
            return MasterDom::alertas('error_general');

        $jquery = $this->jqueryShortCode();
        $carrier = new \stdClass();
        $carrier->_nombre = $data['short_code'];
        $carrier->_id = $data['short_code_id'];
        View::set('header',$this->_contenedor->header($jquery['header']));
        View::set('footer',$this->_contenedor->footer($jquery['footer']));
        View::set('carrier', $carrier);
        View::render("carrier_short_code_edit");
    }

    public function editShortCodePost(){

        if(!$_POST OR !MasterDom::whiteListeIp())
            return MasterDom::alertas('error_general');

        $nombre = MasterDom::getData('nombre');
        $id = MasterDom::getData('id');
        if(empty($nombre) OR empty($id))
            return MasterDom::alertas('error_general');

        if(CarrierDao::updateShortCode($id, $nombre) === false)
            return MasterDom::alertas('error_general');

        return MasterDom::alertas('success_add');
    }

    public function addCarrier(){

	if(!$_POST OR !MasterDom::whiteListeIp())
	    return MasterDom::alertas('error_general');

        $carrier = $this->getObjCarrier();

      	$idCarrier = CarrierDao::insert($carrier); 
	if(!$idCarrier OR empty($idCarrier) OR ($idCarrier < 1)){
	    return MasterDom::alertas('error_general');
	}

	$connection = CarrierDao::insertCarrierShortCode($idCarrier, $carrier->_shortCode, $carrier->_carrier);
	if(!$connection OR empty($connection) OR ($connection < 1)){
            return MasterDom::alertas('error_general');
        }
	
	try{
	    $json['card']['reconnect'] = 'true';
	    $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
	    return MasterDom::alertas('success_add');
	}catch(Exception $e){
	    return MasterDom::alertas('error_carrier');
	}
    }

    public function editCarrier(){
	
	if(!$_POST OR !MasterDom::whiteListeIp()){
            return MasterDom::alertas('error_general');
	}

        $carrier = $this->getObjCarrier(true);
	if(CarrierDao::update($carrier) === false){
	    return MasterDom::alertas('error_general');
	}

	if(CarrierDao::updateRelation($carrier->_id, $carrier->_shortCode, $carrier->_carrier) === false){
	    return MasterDom::alertas('error_general');
	}

	try{
            $json['card']['reconnect'] = 'true';
            $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
            return MasterDom::alertas('success_add');
        }catch(Exception $e){
            return MasterDom::alertas('error_carrier');
        }
    }

    public function delete(){

	if(!$_POST OR !MasterDom::whiteListeIp())
	    return MasterDom::alertas('error_general');

	$row = MasterDom::getDataAll('borrar');
	if(count($row) < 1 OR empty($row))
	    return MasterDom::alertas('error_general');

	foreach($row AS $value){
	    $id = (int)$value;
	    if($value == '')
		continue;
	    CarrierDao::delete($id);
	}

	try{
            $json['card']['reconnect'] = 'true';
            $reinicio = MasterDom::curlPostJava('config/ReconnectJson/', $json);
            return MasterDom::alertas('success_add');
        }catch(Exception $e){
            return MasterDom::alertas('error_carrier');
        }
    }

    public function validaNombre (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByName(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

	return;
    }

    public function validaNombreCompany (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByNameCompany(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

        return;
    }

    public function validaNombreShortCode (){

        if(!empty($_POST['nombre'])){

            $row = CarrierDao::getByNameShortCode(MasterDom::procesoAcentos('nombre'));

            if(empty($row)) {
                echo "true";
                return true;
               //puede registrarse
            } else{
                echo "false";
                return false;
                //echo "ya hay alguien con ese nombre";
            }
        } else{
            echo "false"; //post invalido
        }

        return;
    }
}
