<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiDoppler AS ApiDopplerDao;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ApiDoppler{

    private $_contenedor;
    private $_host_doppler = 'https://restapi.fromdoppler.com/accounts/';
    private $_api_key='2B55B4D51DA0C1F6CF721687D4E8BF7F';
    private $_usuario_doppler = 'jorge.manon%40airmovil.com';
    private $_url_peticion;

    function __construct(){
        $this->_url_peticion = $this->_host_doppler.''.$this->_usuario_doppler;
        if($_GET['url'] != 'ApiDoppler/servicio' || $_GET['url'] != 'ApiDoppler/updateCampaigns' || $_GET['url'] != 'ApiDoppler/verificarCampaignAutomated'){
            $this->_contenedor = new Contenedor;
            View::set('header',$this->_contenedor->header());
            View::set('footer',$this->_contenedor->footer());
        }
    }

    public function index(){
        $extraHeader=<<<html
        <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />



html;
        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
        <script>
            $(document).ready(function(){

              $('#tabla_campaign').DataTable({
                "language": {
                  "emptyTable": "No hay datos disponibles",
                  "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                  "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                  "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                  "lengthMenu": "Mostrar _MENU_ registros",
                  "zeroRecords":  "No se encontraron resultados",
                  "search": "Buscar:",
                  "processing": "Procesando...",
                  "paginate" : {
                      "next": "Siguiente",
                      "previous" : "Anterior"
                  }
                }
              });

              $("#delete").click(function(){
                var num = $("input:checkbox:checked").length;
                if(num > 0){
                  $("#all").attr("action","/ApiDoppler/delete");
                  //$("#all").attr("target","_blank");
                  $("#all").submit();
                }else{
                  alertify.alert("Se debe seleccionar al menos una campaña");
                  //alertify.error('Se debe seleccionar al menos una campaña');
                }
              });


              $("#btnShow").click(function(){
                var num = $("input:checkbox:checked").length;
                if(num > 0){
                  $("#all").submit();
                }else{
                  alertify.alert("Se debe seleccionar al menos una campaña");
                  //alertify.error('Se debe seleccionar al menos una campaña');
                }
              });

            });
        </script>
html;
        
        $tabla = '';
        $status_traductor = array('draft' => 'Borrador', 'shipped' => 'Enviado', 'shipping' => 'Enviando', 'scheduled' => 'Programado');
        $type_traductor = array('automated' => 'Automatizada', 'scheduled' => 'Programada', 'immediate' => 'Inmediata');
            foreach (ApiDopplerDao::getCampaigns() as $key => $value) {
                $value = (Object) $value;
                //if($value->status != 'draft'){
                    $fecha_envio = ($value->send_date != '')? $value->send_date : 'Envío Pendiente';
                    $editable = ($value->status == 'shipped')? 'hidden':'';
                    $tabla .=<<<html
                    <tr>
                        <td><input type="checkbox" name="campaign_id[]" value="{$value->doppler_campaign_id}" /></td>
                        <td>{$value->doppler_campaign_id}</td>
                        <td>{$fecha_envio}</td>
                        <td>{$type_traductor[$value->type]}</td>
                        <td>{$value->nombre}</td>
                        <td>{$value->email_sender}</td>
                        <td>{$value->subject}</td>
                        <td>{$status_traductor[$value->status]}</td>
                        <td>{$value->totalClicks}</td>
                        <td>{$value->uniqueOpens}</td>
                        <td>{$value->totalUnopened}</td>
                        <td>{$value->totalHardBounces}</td>
                        <td>{$value->totalSoftBounces}</td>
                        <td>{$value->successFullDeliveries}</td>
                        <td>{$value->totalRecipients}</td>
                        <td>
                            <a href="/ApiDoppler/edit/$value->doppler_campaign_id" {$editable}><span class="btn btn-primary btn-circle fa fa-pencil"></span></a>
                        </td>
                    </tr>
html;
                //}
            }
        //print_r($detalle_envio = $this->getReporteCampaign('9606688'));
        View::set('tabla', $tabla);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_all");
    }

    public function add(){
      $fecha = date('Y-m-d H:i:s'); //inicializo la fecha con la hora
      $nuevafecha = strtotime ( '+0 hour' , strtotime ( $fecha ) ) ;
      $nuevafecha = strtotime ( '+32 minute' , $nuevafecha ) ; // utilizo "nuevafecha"
      $nuevafecha = strtotime ( '+0 second' , $nuevafecha ) ; // utilizo "nuevafecha"
      $nuevafecha = date ('H:i:s' , $nuevafecha);
      $extraHeader=<<<html
      <style rel="stylesheet" href="https://raw.githubusercontent.com/rtsinani/jquery-datepicker-skins/master/css/nigran.datepicker.css"></style>
html;
      $extraFooter=<<<html
      <script src="/js/validate/jquery.validate.js"></script>
      <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
      <script>
         $(document).ready(function(){

            $("#add").validate({
              rules:{
                name:{
                  required: true
                },
                fromName:{
                  required: true
                },
                fromEmail:{
                  required: true
                },
                subject:{
                  required: true
                },
                muestra:{
                  required: true
                },
                hour_automated:{
                  required: true
                },
                scheduledDate:{
                  required: true
                },
                content:{
                  required: true,
                  minlength: 3
                }
              },
              messages:{
                name:{
                  required: "Este campos es requerido"
                },
                fromName:{
                  required: "Este campos es requerido"
                },
                fromEmail:{
                  required: "Este campos es requerido"
                },
                subject:{
                  required: "Este campos es requerido"
                },
                muestra:{
                  required: "Este campos es requerido"
                },
                hour_automated:{
                  required: "Este campos es requerido"
                },
                scheduledDate:{
                  required: "Este campos es requerido"
                },
                content:{
                  required: "Este campos es requerido",
                  minlength: "Debe contener al menos 3 caracteres"
                }
              }
            });

            var fecha = moment();
            fecha.add("32","minute");

            $('#datetimepicker').datetimepicker({
               minDate: fecha,
               daysOfWeekDisabled: [0,6],
               format:'YYYY-MM-DD HH:mm:ss'
            });

            $('#datetimepicker2').datetimepicker({
              format:'DD/MM/YYYY HH:mm:ss'
            }).on('dp.change', function(e){

              var dias = ['Domingo','Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado' ];
              var fecha_hora = e.date.format('YYYY-MM-DD HH:mm:ss');

              if($("#type_automated").val() == 'semanal'){
                var hora = e.date.format('HH:mm');
                $("#hour_automated").val(hora);
                $("#muestra").val(hora);
              }else{
                if($("#type_automated").val() == 'mensual'){
                  var fecha = new Date(fecha_hora);
                  var dia = e.date.format('DD');
                  var hora = e.date.format('HH:mm');

                  $("#muestra").val('Dias '+dia+' a las '+hora);
                  $("#hour_automated").val(fecha_hora);
                }
              }

            });

            $("#type").change(function(){
               var valor = $(this).val();

               if(valor == 'immediate'){
                  $("#fechaCampaign").hide();
               }else{
                  $("#fechaCampaign").show();
               }

               if(valor == 'automated'){
                $("#automatica").show();
                $("#automated_options").hide();
                $("#automated_days").hide();

                $("#fechaCampaign").hide();

               }else{
                $("#automatica").hide();
                $("#automated_options").hide();
               }

            });

            $("#type_automated").change(function(){
              var valor = $(this).val();
              if(valor == ''){
                $("#automated_options").hide();
                $("#automated_days").hide();
              }else{

                if(valor == 'semanal'){
                  $("#automated_days").show();
                }else{
                  if(valor == 'semanal'){

                  }
                  $("#automated_days").hide();
                }
                $("#automated_options").show();
              }
            });

            $("#btnImportar").click(function(){ 
               //var f = $("#add");              
               //var formData = new FormData(document.getElementById("add"));
               //formData.append( 'plantilla' , f.files[0]);

               var archivo = $("#plantilla").prop('files')[0];
               var datos = new FormData();
               datos.append('plantilla', archivo);

               $.ajax({
                  url: "/ApiDoppler/importar",
                  type: "POST",
                  data: datos,
                  cache: false,
                  processData: false,
                  contentType: false,
                  dataType: "html",
                  success: function(res){
                    CKEDITOR.instances.content.setData(res);
                     //$("#content").val(res);
                  },
                  error: function(error, exception){
                     $("#response").html('Error: <br>'+error+'<br>'+exception);
                  }
               });

            });

            $("#btnAgregar").click(function(){
               $("#add").attr("action","/ApiDoppler/campaignAdd");
               $("#add").submit();
            });

            $("#type").change();

            $("#automated_days").hide();

            CKEDITOR.replace('content');

            $("#content").keyup(function(){
              alert($(this).val());
            });

         });

      </script>
html;
      $sListId = '';
      foreach($this->getLists()->items AS $keyList => $valueList){
        $sListId .=<<<html
        <option value="{$valueList->listId}">{$valueList->name}</option>
html;
      }

      $sDias = '';
      foreach(ApiDopplerDao::getDays() AS $keyDay => $valueDay){
        $sDias .=<<<html
        <label class="col-md-3 col-sm-3 col-xs-3 btn btn-success">
           <input class="with-gap" type="checkbox" name="days[]" value="{$valueDay['doppler_day_id']}"/>
           <span class="custom-control-description">{$valueDay['nombre']}</span>
        </label>
html;
      }

      View::set('sListId',$sListId);
      View::set('sDias',$sDias);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render("api_doppler_add");
    }

    public function campaignAdd(){
        $campaign = array(
          "name" => MasterDom::getData('name'),
          "fromName" => MasterDom::getData('fromName'),
          "fromEmail" => MasterDom::getData('fromEmail'),
          "subject" => MasterDom::getData('subject'),
          "status" => 'draft'
        );

        $campaña = new \stdClass();
        $campaña->_campaignId = '';
        $campaña->_shippingId = '';
        $campaña->_type = MasterDom::getDataAll('type');
        $campaña->_fecha_envio = '';
        $campaña->_name = MasterDom::getData('name');
        $campaña->_fromEmail = MasterDom::getData('fromEmail');
        $campaña->_fromName = MasterDom::getData('fromName');
        $campaña->_subject = MasterDom::getData('subject');
        $campaña->_status = MasterDom::getData('status');
        $campaña->_uniqueClicks = 0;
        $campaña->_totalClicks = 0;
        $campaña->_uniqueOpens = 0;
        $campaña->_totalUnopened = 0;
        $campaña->_totalHardBounces = 0;
        $campaña->_totalSoftBounces = 0;
        $campaña->_totalRecipients = 0;
        $campaña->_successFullDeliveries = 0;
        $campaña->_hour_automated = MasterDom::getData('hour_automated');
        $content = MasterDom::getDataAll('content');
        $campaña->_type_automated = MasterDom::getData('type_automated');
        $doppler_days = MasterDom::getDataAll('days');

        $hour_automated = new \DateTime(MasterDom::getData('hour_automated'));
        $hour_automated = $hour_automated->format('H:i');
         if(MasterDom::getDataAll('scheduledDate') != ''){
            $fecha = date('Y-m-d H:i:s', strtotime(MasterDom::getDataAll('scheduledDate')));
            $scheduledDate = explode(' ',$fecha);
            $scheduledDate = $scheduledDate[0].'T'.$scheduledDate[1].".-06:00";
         }else{
            $fecha = date('Y-m-d H:i:s'); //inicializo la fecha con la hora
            $nuevafecha = strtotime ( '+0 hour' , strtotime ( $fecha ) ) ;
            $nuevafecha = strtotime ( '+32 minute' , $nuevafecha ) ; // utilizo "nuevafecha"
            $nuevafecha = strtotime ( '+0 second' , $nuevafecha ) ; // utilizo "nuevafecha"
            $nuevafecha = date ( 'Y-m-d H:i:s' , $nuevafecha );
            $scheduledDate = $nuevafecha.".-06:00";
         }
        $list_id = MasterDom::getData('listId');
        $response = $this->crearBorrador($campaign);
        $campaign_id = $response->createdResourceId;
        $response = $this->asignarContent($campaign_id, $content);
        $response = $this->asignarList($campaign_id, $list_id);
        $scheduledDate_aux = MasterDom::getDataAll('scheduledDate').".-06:00";
        $response = $this->enviar($campaign_id, $scheduledDate_aux, ($campaña->_type == 'automated')? 'scheduled':$campaña->_type); 
        $shippingId = $response->createdResourceId;
        $campaña->_campaignId = $campaign_id;
        $campaña->_fecha_envio = date('Y-m-d H:i:s');
        $campaña->_shippingId = $shippingId;
        $campaña->_doppler_campaign_parent_id = 0;
        $campaña->_shippingId = 0;

        ApiDopplerDao::insertCampaign($campaña);
        if($campaña->_type_automated == 'semanal'){
          foreach ($doppler_days as $key => $value){
            $campaña->_hour_automated = date( 'Y-m-d').'T'.$hour_automated.'.-06:00';
            $campaña->_day = $value;
            ApiDopplerDao::insertDopplerAutomatedDay($campaña);
          }
        }elseif($campaña->_type_automated == 'mensual') {
          $campaña->_hour_automated = date( MasterDom::getData('hour_automated')).'.-06:00';
          $campaña->_day = 1;
          ApiDopplerDao::insertDopplerAutomatedDay($campaña);
        }

        if($campaña->_type =='automated'){
          if($campaña->_type_automated == 'semanal'){
            $response = $this->cancelarEnvio($campaign_id, $shippingId);
            $scheduledDate = $this->reprogramarEnvioSemanal($campaign_id);
            $response = $this->enviar($campaign_id, $scheduledDate, 'scheduled'); 
            $shippingId = $response->createdResourceId;
            $campaña->_shippingId = $shippingId;
            ApiDopplerDao::updateShippingId($campaña);
          }elseif($campaña->_type_automated == 'mensual'){
            $response = $this->cancelarEnvio($campaign_id, $shippingId);
            $scheduledDate = $this->reprogramarEnvioMensual($campaign_id);
            $response = $this->enviar($campaign_id, $scheduledDate, 'scheduled'); 
            $shippingId = $response->createdResourceId;
            $campaña->_shippingId = $shippingId;
            ApiDopplerDao::updateShippingId($campaña);
          }
        }

        if($shippingId != ''){
            View::set('regreso','/ApiDoppler/');
            View::set('titulo','Envio de Campaña API');
            View::set('class','success');
            View::set('mensaje',$response->message.'<br>Shipping Id: '.$shippingId);
            View::render("mensaje");
        }else{
            $mensaje = '';
            foreach ($response->errors as $key => $value) {
               $mensaje .=<<<html
               <div class="alert alert-danger alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>{$value->key}</strong>{$value->detail}
               </div>
html;
            }

            View::set('regreso','/ApiDoppler/');
            View::set('titulo','Envio de Campaña API');
            View::set('class','danger');
            View::set('mensaje','Ha ocurrido un problema con el envio de la campaña<br>Detalle: '.$mensaje);
            View::render("mensaje");
        }
    }

    public function edit($campaign_id){
      $campaign = ApiDopplerDao::getCampaignById($campaign_id);

      if($campaign['doppler_campaign_parent_id'] == 0){
        $dias = ApiDopplerDao::getDayCampaignAutomated($campaign_id);
        if($dias[0]['type'] == 'semanal'){
          $hora = $this->reprogramarEnvioSemanal($campaign_id);
        }elseif ($dias[0]['type'] == 'mensual') {
          $hora = $this->reprogramarEnvioMensual($campaign_id);
          $visible = 'hidden';
        }
        
      }else{
        $dias = ApiDopplerDao::getDayCampaignAutomated($campaign['doppler_campaign_parent_id']);
        if($dias[0]['type'] == 'semanal'){
          $hora = $this->reprogramarEnvioSemanal($campaign['doppler_campaign_parent_id']);
        }elseif ($dias[0]['type'] == 'mensual') {
          $hora = $this->reprogramarEnvioMensual($campaign['doppler_campaign_parent_id']);
          $visible = 'hidden';
        }
      }

      $sListId = '';
      foreach($this->getLists()->items AS $keyList => $valueList){
        $sListId .=<<<html
        <option value="{$valueList->listId}">{$valueList->name}</option>
html;
      }      

      $sDias = '';
      foreach(ApiDopplerDao::getDays() AS $keyDay => $valueDay){
        $selected = '';
        foreach ($dias as $key => $value) {
          if($valueDay['doppler_day_id'] == $value['doppler_day_id']){
            $selected = 'checked';
            break;
          }
        }

        $sDias .=<<<html
        <label class="col-md-3 col-sm-3 col-xs-3 btn btn-success">
           <input class="with-gap" type="checkbox" name="days[]" value="{$valueDay['doppler_day_id']}" {$selected} disabled/>
           <span class="custom-control-description">{$valueDay['nombre']}</span>
        </label>
html;
        }

        $hora = str_replace('.-06:00','',$hora);
        $hora = str_replace('T',' ',$hora);

        View::set('fecha',$hora);
        View::set('type_shipping',$dias[0]['type']);
        View::set('sListId',$sListId);
        View::set('sDias',$sDias);
        View::set('visible',$visible);
        View::set('campaign',$campaign);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render('api_doppler_edit');
    }

    public function campaignEdit(){
      $campaign = new \stdClass();
      $campaign->_campaignId = MasterDom::getData('campaignId');
      $campaign->_shippingId = MasterDom::getData('shippingId');
      $campaign->_listId = MasterDom::getData('listId');
      $campaign->_hour_automated = MasterDom::getData('hour_automated');
      $campaign->_type = 'scheduled';
      $campaign->_campaign_parent_id = MasterDom::getData('campaign_parent_id');
      $errores = array();

      $response = $this->cancelarEnvio($campaign->_campaignId, $campaign->_shippingId);
      if($response->reason != '' || $response->detail != ''){
        if($response->reason != ''){
          array_push($errores,$response->reason);
        }
        if($response->detail != ''){
          array_push($errores,$response->detail);
        }
      }

      if($response->errors !=''){
        foreach ($response->errors as $key => $value) {
          array_push($errores,$value->detail);
        }
      }

      //print_r($response);
      //echo '<:::::::::::::::::::::::::::::::::::::::::::::::::::::::><br><br><br>';
      $response = $this->asignarList($campaign->_campaignId, $campaign->_listId);
      if($response->reason != '' || $response->detail != ''){
        if($response->reason != ''){
          array_push($errores,$response->reason);
        }
        if($response->detail != ''){
          array_push($errores,$response->detail);
        }
      }

      if($response->errors !=''){
        foreach ($response->errors as $key => $value) {
          array_push($errores,$value->detail);
        }
      }

      //print_r($response);
      //echo '<:::::::::::::::::::::::::::::::::::::::::::::::::::::::><br><br><br>';


      if($campaign->_campaign_parent_id == 0){
        $dias = ApiDopplerDao::getDayCampaignAutomated($campaign_id);
        if($dias[0]['type'] == 'semanal'){
          $campaign->_hour_automated = $this->reprogramarEnvioSemanal($campaign_id);
        }elseif ($dias[0]['type'] == 'mensual') {
          $campaign->_hour_automated = $this->reprogramarEnvioMensual($campaign_id);
        }
        
      }else{
        $dias = ApiDopplerDao::getDayCampaignAutomated($campaign->_campaign_parent_id);
        if($dias[0]['type'] == 'semanal'){
          $campaign->_hour_automated = $this->reprogramarEnvioSemanal($campaign->_campaign_parent_id);
        }elseif ($dias[0]['type'] == 'mensual') {
          $campaign->_hour_automated = $this->reprogramarEnvioMensual($campaign->_campaign_parent_id);
        }
      }

      $response = $this->enviar($campaign->_campaignId, $campaign->_hour_automated,$campaign->_type);
      if($response->reason != '' || $response->detail != ''){
        if($response->reason != ''){
          array_push($errores,$response->reason);
        }
        if($response->detail != ''){
          array_push($errores,$response->detail);
        }
      }

      if($response->errors !=''){
        foreach ($response->errors as $key => $value) {
          array_push($errores,$value->detail);
        }
      }

      //print_r($response);
      //echo '<:::::::::::::::::::::::::::::::::::::::::::::::::::::::><br><br><br>';
      $shippingId = $response->createdResourceId;
      $campaign->_shippingId = $shippingId;
      ApiDopplerDao::updateShippingId($campaña);

      if($shippingId != ''){
            View::set('regreso','/ApiDoppler/');
            View::set('titulo','Envio de Campaña API');
            View::set('class','success');
            View::set('mensaje',$response->message.'<br>Shipping Id: '.$shippingId);
            View::render("mensaje");
        }else{
            $mensaje = '';
            foreach ($errores as $key => $value) {
               $mensaje .=<<<html
               <div class="alert alert-danger alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>Error: </strong>  {$value}
               </div>
html;
            }
            View::set('regreso','/ApiDoppler/');
            View::set('titulo','Envio de Campaña API');
            View::set('class','danger');
            View::set('mensaje','Ha ocurrido un problema con el envio de la campaña<br>Detalle: '.$mensaje);
            View::render("mensaje");
        }
    }


    public function addList(){
      $extraFooter=<<<html
      <script src="/js/validate/jquery.validate.js"></script>
      <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
      <script>
         $(document).ready(function(){

          $("#add").validate({
            rules:{
              name:{
                required: true,
                minlength: 3
              },
              content:{
                required: true,
                minlength: 10
              }
            },
            messages:{
              name:{
                required: "Este campo es requerido",
                minlength: "Debe contener a menos 3 caracteres"
              },
              content:{
                required: "Este campo es requerido",
                minlength: "Debe contener a menos 10 caracteres"
              }
            }
          });

            $("#btnImportar").click(function(){ 

               var archivo = $("#suscriptores_list").prop('files')[0];
               var datos = new FormData();
               datos.append('suscriptores_list', archivo);

               $.ajax({
                  url: "/ApiDoppler/importarCSV",
                  type: "POST",
                  data: datos,
                  cache: false,
                  processData: false,
                  contentType: false,
                  dataType: "html",
                  success: function(res){
                    //CKEDITOR.instances.content.setData(res);
                     $("#content").val(res);
                  },
                  error: function(error, exception){
                     $("#response").html('Error: <br>'+error+'<br>'+exception);
                  }
               });
            });

            $("#accion").change(function(){
              var accion = $(this).val();
              if(accion == "crear"){
                $("#contenedor_list_id").hide();
                $("#contendor_list_nombre").show();
              }else{
                if(accion == "reemplazar"){
                  $("#contenedor_list_id").show();
                  $("#contendor_list_nombre").hide();
                }
              }
            });

            $("#btnAgregar").click(function(){

              var listId = 0;
              $("#response").html("");

              var accion = $("#accion").val();
              if(accion == "crear"){
                /**********CREAR LISTA*****************************/
                $.ajax({
                  url: '/ApiDoppler/crearLista',
                  type: 'POST',
                  data: {'name': $("#name").val()},
                  success: function(response){
                    var obj = $.parseJSON(response);
                    var datos = eval (obj);

                    if(datos['status'] == undefined){
                      $("#response").append('<div class="alert alert-success" role="alert"><strong>Atenci&oacute;n</strong> '+datos['message']+' with id: '+datos['createdResourceId']+'.</div>');
                      $("#contenedor_list_id").html("<input class='form-control' id='list_id' name='list_id' type='text' value='"+datos['createdResourceId']+"'>");
                      $("#contenedor_list_id").show();
                      $("#add").attr("action","/ApiDoppler/importCSVSuscriptores");
                      $("#add").attr("method","POST");
                      //$("#add").attr("target","_blank");
                      $("#add").submit();
                    }else{
                      if(datos['title'] != undefined){
                        $("#response").append('<div class="alert alert-danger" role="alert"><strong>Atenci&oacute;n Error:</strong> '+datos['title']+'.</div>');
                      }
                    }
                  }
                });
                /*************************************************/
              }else{

                $.ajax({
                  url: "/ApiDoppler/vaciarLista",
                  type: "POST",
                  data: {'list_id': $('#list_id').val()},
                  success: function(res){
                     $("#response").html(res);
                  },
                  error: function(error, exception){
                     $("#response").html('Error: <br>'+error+'<br>'+exception);
                  }
               });


                $("#add").attr("action","/ApiDoppler/importCSVSuscriptores");
                $("#add").attr("method","POST");
                //$("#add").attr("target","_blank");
                $("#add").submit();

              }

              
              
            });//fin del evento click btnAgregar

            $("#accion").change();
            $("#content").keyup(function () {
              var value = $(this).val();
              //alert("-"+value+"-\\n-");
              //$("#response").html(value);
            }).keyup();
         });

      </script>
html;
      $sListId = '';
      foreach($this->getLists()->items AS $keyList => $valueList){
        $sListId .=<<<html
        <option value="{$valueList->listId}">{$valueList->name}</option>
html;
      }
      View::set('sListId', $sListId);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('api_doppler_list_add');
    }

    public function vaciarLista(){
      $list_id = MasterDom::getData('list_id');
      $suscriptores = $this->getSuscriberByListId($list_id);

      foreach ($suscriptores->items as $key => $value) {
        echo $this->eliminarSuscriptorLista($list_id, $value->email);

        }
    }

    public function eliminarSuscriptorLista($list_id, $email){
      $email = str_replace('@', '%40',$email);
      $url = "$this->_url_peticion/lists/$list_id/subscribers/$email?api_key=$this->_api_key";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        //curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,array('Accept: application/json'));
        $response = json_decode(curl_exec($ch));
        curl_close($ch);
        if($response->message != ''){
          return <<<html
          <div class="alert alert-success">
            <strong>Atenci&oacute;n! </strong> {$response->message}
          </div>
html;
        }else{
          return <<<html
          <div class="alert alert-danger">
            <strong>Atenci&oacute;n! </strong> {$response->title}
          </div>
html;
        }        
    }

    public function importarCSV(){
      $csv = $_FILES['suscriptores_list'];
      $carpeta = explode('.', $csv['name'])[0];
      $type = $csv['type'];
      $nombre = $csv['tmp_name'];
      
      if (($fichero = fopen($nombre, "r")) !== FALSE) {
          while (($datos = fgetcsv($fichero, 1000)) !== FALSE) {
            $i=0;
              foreach ($datos as $key => $value) {
                if($i==0){
                  echo $value;
                }else{
                  echo ','.$value;
                }

                $i++;
                
              }
              echo htmlentities("\n");
          }
      }
    }

    public function crearLista(){
      $data = array(
        "name" => MasterDom::getData('name'),
        "currentStatus" => "ready",
        "subscribersCount" => 0,
        "hasScheduledCampaigns" => true,
        "hasFormsAssociated" => true,
        "hasSegmentsAssociated" => true,
        "hasEventsAssociated" => true
      );
      $url = "$this->_url_peticion/lists?api_key=$this->_api_key";
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_HTTPHEADER,
        array(
          'Content-Type: application/json',
          'Accept: application/json'
          )
      );
      $response = json_decode(curl_exec($ch));
      curl_close($ch);
      echo json_encode($response);
    }

    public function importCSVSuscriptores(){
      $data = MasterDom::getData('content');
      $list_id = MasterDom::getData('list_id');
      $url = "$this->_url_peticion/lists/$list_id/subscribers/import-csv?api_key=$this->_api_key";
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_HTTPHEADER,
        array(
          'Content-Type: text/csv',
          'Accept: application/json')
        );
      curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
      $response = json_decode(curl_exec($ch));
      curl_close($ch);
      
      if($response->createdResourceId != ''){
        $mensaje =<<<html
        <div class="alert alert-success">
          <strong>Atenci&oacute;n!</strong> {$response->message}
        </div>
html;
        View::set('regreso','/ApiDoppler/addList');
        View::set('titulo','Creaci&oacute;n de Listas');
        View::set('class','success');
        View::set('mensaje',"Transaccion Detalle:".$mensaje);
        View::render("mensaje");
      }else{
        $mensaje =<<<html
        <div class="alert alert-danger">
          <strong>Atenci&oacute;n! </strong> {$response->title}
        </div>
html;
        View::set('regreso','/ApiDoppler/addList');
        View::set('titulo','Creaci&oacute;n de Listas');
        View::set('class','danger');
        View::set('mensaje','Ha ocurrido un problema con el envio de la campaña<br>Detalle: '.$mensaje);
        View::render("mensaje");
      }
        
    }

    public function delete(){
      $mensaje = '';
      foreach (MasterDom::getDataAll('campaign_id') as $key => $value) {
        $campaign = ApiDopplerDao::getCampaignById($value);
        $response = $this->cancelarEnvio($campaign['doppler_campaign_id'], $campaign['shippingId']);
        if($response->reason == '' || preg_match('/[*]*draft[*]*/', $response->reason)){
          $class = 'success';
          ApiDopplerDao::deleteCampaign($value);
        }else{
          $class = 'warning';
        }

        //$traducir = json_decode(file_get_contents("https://statickidz.com/scripts/traductor/index.php?source=en&target=es&q=".urlencode($response->reason)));


        //$error = $traducir->translation;

        $mensaje .=<<<html
        <div class="alert alert-{$class} alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <strong>Campa&ntilde;a Id:   {$value}</strong>    {$response->reason}
        </div>
html;
      }

      if($response->reason == '' || preg_match('/[*]*draft[*]*/', $response->reason)){
        View::set('regreso','/ApiDoppler/');
        View::set('titulo','Envio de Campaña API');
        View::set('class','success');
        View::set('mensaje',"Transaccion Detalle:".$mensaje);
        View::render("mensaje");
      }else{
        View::set('regreso','/ApiDoppler/');
        View::set('titulo','Envio de Campaña API');
        View::set('class','danger');
        View::set('mensaje','Ha ocurrido un problema con el envio de la campaña<br>Detalle: '.$mensaje);
        View::render("mensaje");
      }

    }

    public function reprogramarEnvioSemanal($campaign_id){
          $dias = ApiDopplerDao::getDays();
          $dias_programadas = ApiDopplerDao::getDayCampaignAutomated($campaign_id);
          $fecha = date('Y-m-d H:i:s'); //inicializo la fecha con la hora
          $fecha = strtotime ( '+0 hour' , strtotime ( $fecha ) ) ;
          $fecha = strtotime ( '+32 minute' , $fecha ) ;
          $fecha = strtotime ( '+0 second' , $fecha ) ;
          $fecha_actual = new \DateTime( date ( 'Y-m-d H:i:s' , $fecha ));
          $esDiaProgramado = false;
          $index = 0;
          for($i=0; $i<count($dias_programadas); $i++) {
            if(date('N') == $dias_programadas[$i]['doppler_day_id']){
              $esDiaProgramado = true;
              $index = $i;
            }
          }

          if($esDiaProgramado){
            #echo "Es dia programado<br>";
            $fecha_aux = new \DateTime($dias_programadas[$index]['hour']);
            $fecha_aux = new \DateTime($fecha_actual->format('Y-m-d').' '.$fecha_aux->format('H:i:s'));

            if($fecha_actual < $fecha_aux){
              $scheduled = $fecha_aux->format('Y-m-d H:i:s').".-06:00";
            }else{
              if(($index+1) >= count($dias_programadas) ){
                $dia = $dias_programadas[0]['doppler_day_id'];
              }else{
                $dia = $dias_programadas[$index+1]['doppler_day_id'];
              }
              
              foreach ($dias as $keyDias => $valueDias) {
                $fecha_actual->add(new \DateInterval('P1D'));
                if($dia == $fecha_actual->format('N')){
                  $scheduled = $fecha_actual->format('Y-m-d').'T'.$fecha_aux->format('H:i:s').".-06:00";
                  break;
                }   
              }
            }
          }else{
            #echo 'No es dia programado<br>';
            for ($i=0; $i<count($dias_programadas); $i++) {
              $valor = $dias_programadas[$i];
              if(date("N") < $valor['doppler_day_id']){
                  if(($i+1)>count($dias_programadas)){
                    $dia = $dias_programadas[0]['doppler_day_id'];
                  }elseif(date('N') < $valor['doppler_day_id']){
                    $dia = $valor['doppler_day_id'];
                  }
                break;
              }elseif(date("N") > $valor['doppler_day_id']) {
                if(($i+1)>count($dias_programadas)){
                  $dia = $dias_programadas[0]['doppler_day_id'];
                }elseif(count($dias_programadas) > 1){
                  $dia = $dias_programadas[$i+1]['doppler_day_id'];
                }else{
                  $dia = $valor['doppler_day_id'];
                }
              }
            }

            $fecha_aux = new \DateTime($dias_programadas['0']['hour']);

            foreach ($dias as $keyDias => $valueDias) {
              if($dia == $fecha_actual->format('N')){
                $scheduled = $fecha_actual->format('Y-m-d').'T'.$fecha_aux->format('H:i:s').".-06:00";
                break;
              }else{
                $fecha_actual->add(new \DateInterval('P1D'));
              }
            }
          }

          //echo $scheduled.'<br>';
          return $scheduled;
    }

    public function reprogramarEnvioMensual($campaign_id){
      $dias_programadas = ApiDopplerDao::getDayCampaignAutomated($campaign_id);
      $fecha = date('Y-m-d H:i:s');
      $fecha = strtotime ( '+0 hour' , strtotime ( $fecha ) ) ;
      $fecha = strtotime ( '+32 minute' , $fecha ) ;
      $fecha = strtotime ( '+0 second' , $fecha ) ;
      $fecha_actual = new \DateTime( date ( 'Y-m-d H:i:s' , $fecha ));
      $fecha_programada = new \DateTime( $dias_programadas[0]['hour']);
      if($fecha_actual > $fecha_programada){
        $fecha_programada->add(new \DateInterval('P1M'));
      }
      $scheduled = $fecha_programada->format('Y-m-d').'T'.$fecha_programada->format('H:i:s').".-06:00";
      return $scheduled;
    }

    public function showDetalle(){
        $extraFooter =<<<html
        <script>
            $(document).ready(function(){
                $("#btnCrear").click(function(){
                    $.ajax({
                        url: '/ApiDoppler/crearGrupo',
                        type: 'POST',
                        data: $('#campaigns').serialize(),
                        success: function(data){
                            $('#response_group_add').html(data);   
                            setTimeout(function(){
                              $('#response_group_add').html("");
                            }, 2000);                           
                        }
                    });
                });                 
            });
        </script>
html;
        $status_traductor = array('opened' => 'Abierto', 'notOpened' => 'Sin Abrir');
        $nombreCampaign = '';
        $totalClicks = 0;
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $entregados = 0;
        $totales = 0;

        $campaign_div = '';
        $campaigns = MasterDom::getDataAll('campaign_id');
        foreach ($campaigns as $llave => $id) {
            $campaign_div .= '<input type="hidden" name="campaign_id[]" value="'.$id.'"/>';
            $reporte = (Object) ApiDopplerDao::getCampaignById($id);
            $nombreCampaign .= '<h5><span>'.$reporte->nombre.'</span></h5>';
            $totalClicks += intval($reporte->totalClicks);
            $totales += intval($reporte->totalRecipients);
            $abiertos += intval($reporte->uniqueOpens);
            $no_abiertos += intval($reporte->totalUnopened);
            $rechazados_hard += intval($reporte->totalHardBounces);
            $rechazados_soft += intval($reporte->totalSoftBounces);
            $entregados += intval($reporte->successFullDeliveries);
        }

        $totalClicks_p = round($totalClicks*(100/$totales),2);
        $abiertos_p = round($abiertos*(100/$totales),2);
        $no_abiertos_p = round($no_abiertos*(100/$totales),2);
        $abiertos_p = round($abiertos*(100/$totales),2);
        $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
        $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
        $entregados_p = round($entregados*(100/$totales),2);   

        $tabla .=<<<html
          <tr style='text-align: center;'>
            <td>{$nombreCampaign}</td>
            <td>
              <h4><span>{$abiertos}</span></h4>
              <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$no_abiertos}</span></h4>
              <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$rechazados_hard}</span></h4>
              <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$rechazados_soft}</span></h4>
              <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$totalClicks}</span></h4>
              <h5><span style="color: #4c4949;">{$totalClicks_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$entregados}</span></h4>
              <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
            </td>
            <td>
              <h4><span>{$totales}</span></h4>
              <h5><span style="color: #4c4949;">100 %</span></h5>
            </td>
                        
          </tr>
html;

        View::set('tabla', $tabla);
        View::set('campaign_div', $campaign_div);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show");
    }

    public function showGroups(){
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $totales = 0;
        $totalClicks = 0;
        $totalesClicks = 0;
        $campaign_div = '';
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroups();
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);       
                $nombreCampaign = '<label>'.$value['nombre_campaign'].'</label><br>';
                $totales = intval($reporte->totalRecipients);
                $totalClicks = intval($reporte->totalClicks);
                $totalesClicks = intval($reporte->totalClicks);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);
            }else{
                $reporte = (Object) ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<label>'.$value['nombre_campaign'].'</label><br>';
                $totales += intval($reporte->totalRecipients);
                $totalClicks += intval($reporte->totalClicks);
                $totalesClicks += intval($reporte->totalClicks);
                $abiertos += intval($reporte->uniqueOpens);
                $no_abiertos += intval($reporte->totalUnopened);
                $rechazados_hard += intval($reporte->totalHardBounces);
                $rechazados_soft += intval($reporte->totalSoftBounces);
                $entregados += intval($reporte->successFullDeliveries);
            }    

            if($grupos[$key+1]['doppler_group_id'] != $aux){
                
                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $totalClicks_p = round($totalClicks*(100/$totalesClicks),2);
                $entregados_p = round($entregados*(100/$totales),2);   


                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td><h5><span > {$value['nombre']} </span></h5></td>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totalClicks}</span></h4>
                            <h5><span style="color: #4c4949;">{$totalClicks_p}%</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100%</span></h5>
                        </td>
                        <td>
                            <a href="/ApiDoppler/showGroup/{$value['doppler_group_id']}"><span class="btn btn-primary"><i class="fa fa-eye"></i></span></a>
                        </td>
                    </tr>
html;
            }

        }     

        View::set('tabla', $tabla);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show_groups");
    }

    public function showGroup($doppler_group_id){
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $entregados = 0;
        $totalClicks = 0;
        $totalesClicks = 0;
        $totales = 0;
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroup($doppler_group_id);
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);               
                $nombreCampaign = '<h5><span>'.$value['nombre_campaign'].'</span></h5>';
                $totales = intval($reporte->totalRecipients);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);
                $totalClicks = intval($reporte->totalClicks);
                $totalesClicks = intval($reporte->totalClicks);

                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $entregados_p = round($entregados*(100/$totales),2);   
                $totalClicks_p = round($totalClicks*(100/$totalesClicks),2);   
                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totalClicks}</span></h4>
                            <h5><span style="color: #4c4949;">{$totalClicks_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;


            }else{
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign = '<h5><span>'.$value['nombre_campaign'].'</span></h5>';
                $totales_campaign = intval($reporte->totalRecipients);
                $totales += $totales_campaign;
                $abiertos_campaign = intval($reporte->uniqueOpens);
                $abiertos += $abiertos_campaign;
                $no_abiertos_campaign = intval($reporte->totalUnopened);
                $no_abiertos += $no_abiertos_campaign;
                $rechazados_hard_campaign = intval($reporte->totalHardBounces);
                $rechazados_hard += $rechazados_hard_campaign;
                $rechazados_soft_campaign = intval($reporte->totalSoftBounces);
                $rechazados_soft += $rechazados_soft_campaign;
                $entregados_campaign = intval($reporte->successFullDeliveries);
                $entregados += $entregados_campaign;

                $totalClicks_campaign = intval($reporte->totalClicks);
                $totalClicks += $totalClicks_campaign;

                $totalesClicks_campaign = intval($reporte->totalClicks);
                $totalesClicks += $totalesClicks_campaign;
        
                $abiertos_p = round($abiertos_campaign*(100/$totales_campaign),2);
                $no_abiertos_p = round($no_abiertos_campaign*(100/$totales_campaign),2);
                $abiertos_p = round($abiertos_campaign*(100/$totales_campaign),2);
                $rechazados_hard_p = round($rechazados_hard_campaign*(100/$totales_campaign),2);
                $rechazados_soft_p = round($rechazados_soft_campaign*(100/$totales_campaign),2);
                $entregados_p = round($entregados_campaign*(100/$totales_campaign),2);      
                $totalClicks_p = round($totalClicks_campaign*(100/$totalesClicks_campaign),2);      

                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td>{$nombreCampaign}</td>
                        <td>
                            <h4><span>{$abiertos_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totalClicks_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">{$totalClicks_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales_campaign}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;
            }    

            if( (count($grupos)-1) == $key ){
                $doppler_grupo_nombre = $value['nombre'];
                $abiertos_p = round($abiertos*(100/$totales),2);
                $no_abiertos_p = round($no_abiertos*(100/$totales),2);
                $abiertos_p = round($abiertos*(100/$totales),2);
                $rechazados_hard_p = round($rechazados_hard*(100/$totales),2);
                $rechazados_soft_p = round($rechazados_soft*(100/$totales),2);
                $entregados_p = round($entregados*(100/$totales),2);
                $totalClicks_p = round($totalClicks*(100/$totalesClicks),2);

                $tabla .=<<<html
                    <tr style='text-align: center;'>
                        <td><h5><span>TOTALES</span></h5></td>
                        <td>
                            <h4><span>{$abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$no_abiertos}</span></h4>
                            <h5><span style="color: #4c4949;">{$no_abiertos_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_hard}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_hard_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$rechazados_soft}</span></h4>
                            <h5><span style="color: #4c4949;">{$rechazados_soft_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$entregados}</span></h4>
                            <h5><span style="color: #4c4949;">{$entregados_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totalClicks}</span></h4>
                            <h5><span style="color: #4c4949;">{$totalClicks_p} %</span></h5>
                        </td>
                        <td>
                            <h4><span>{$totales}</span></h4>
                            <h5><span style="color: #4c4949;">100 %</span></h5>
                        </td>
                    </tr>
html;
            }
        }     

        View::set('tabla', $tabla);
        View::set('doppler_grupo_nombre', $doppler_grupo_nombre);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("api_doppler_show_group");
    }

    public function crearGrupo(){
        $grupo = new \stdClass();
        $grupo->_group_id = ApiDopplerDao::getGroupId()['id'];
        $grupo->_name =  MasterDom::getData('name');
        foreach (MasterDom::getDataAll('campaign_id') as $key => $value) {
            $grupo->_campaign_id = $value;
            $id = ApiDopplerDao::insertGroup($grupo);
            if($id >0){
                echo "<h2><span class='label label-primary'>La campaña $grupo->_campaign_id fue agregada correctamente al grupo $grupo->_name</span></h2>";
            }else{
                echo "<h2><span class='label label-warning'>La campaña $grupo->_campaign_id no pudo ser agregada correctamente al grupo $grupo->_name</span></h2>";
            }
        }
    }



    public static function crearExcel(){
        $encabezado = array('GRUPO','CAMPAÑAS','ABIERTOS','NO ABIERTOS','RECHAZADOS HARD','RECHAZADOS SOFT','ENTREGADOS','TOTALES');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Taurus Silver")
        ->setLastModifiedBy("Taurus Silver")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de grupos")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");

        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }
        $fila++;
        $nombreCampaign = '';
        $abiertos = 0;
        $no_abiertos = 0;
        $rechazados_hard = 0;
        $rechazados_soft = 0;
        $entregados = 0;
        $totales = 0;
        $aux = '';
        $tabla = '';    
        $grupos = ApiDopplerDao::getGroups();
        foreach ($grupos as $key => $value) {
            if($aux != $value['doppler_group_id']){
                $aux = $value['doppler_group_id'];
                //$reporte = $this->getReporteCampaign($value['doppler_campaign_id']);
                $reporte = (Object) ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<'.$value['nombre_campaign'].'>';
                $totales = intval($reporte->totalRecipients);
                $abiertos = intval($reporte->uniqueOpens);
                $no_abiertos = intval($reporte->totalUnopened);
                $rechazados_hard = intval($reporte->totalHardBounces);
                $rechazados_soft = intval($reporte->totalSoftBounces);
                $entregados = intval($reporte->successFullDeliveries);
            }else{
                //$reporte = $this->getReporteCampaign($value['doppler_campaign_id']);
                $reporte = (Object)ApiDopplerDao::getCampaignById($value['doppler_campaign_id']);
                $nombreCampaign .= '<'.$value['nombre_campaign'].'>';
                $totales += intval($reporte->totalRecipients);
                $abiertos += intval($reporte->uniqueOpens);
                $no_abiertos += intval($reporte->totalUnopened);
                $rechazados_hard += intval($reporte->totalHardBounces);
                $rechazados_soft += intval($reporte->totalSoftBounces);
        $entregados += intval($reporte->successFullDeliveries);
            }    

            if($grupos[$key+1]['doppler_group_id'] != $aux){
                
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A'.$fila, $value['nombre'])
                ->setCellValue('B'.$fila, $nombreCampaign)
                ->setCellValue('C'.$fila, $abiertos)
                ->setCellValue('D'.$fila, $no_abiertos)
                ->setCellValue('E'.$fila, $rechazados_hard)
                ->setCellValue('F'.$fila, $rechazados_soft)
                ->setCellValue('G'.$fila, $entregados)
        ->setCellValue('H'.$fila, $totales);

                $fila++;
            }

        }
        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Reporte de Grupos.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }


    


    public function servicio1(){}

    public function servicio(){
        $response_campanias = json_decode(file_get_contents($this->_url_peticion."/campaigns?page=1&per_page=10&api_key=$this->_api_key")); 
        $texto = '';
        $datos = new \stdClass();
        $datos->campaign_id = 1;
        $marcacion = '27268';

        $contenido = "Mensaje de prueba de Correo";
        $contenido = urlencode($contenido);
        foreach ($response_campanias->items as $key => $value) {
            $response_suscriptor = json_decode(file_get_contents($this->_url_peticion.'/campaigns/'.$value->campaignId.'/deliveries?page=1&per_page=10&api_key='.$this->_api_key));
            $existe = count(ApiDopplerDao::getCampaignIdExist($value->campaignId));
            $suscriptor = new \stdClass();
            $suscriptor->campaignId = $value->campaignId;

            foreach ($response_suscriptor->items as $llave => $valor) {
                $suscriptor->suscriptorEmail = $valor->subscriberEmail;
                $suscriptor->deliveryStatus = $valor->deliveryStatus;
                if($existe==0){
                    $id = ApiDopplerDao::insert($suscriptor);
                    echo 'Insertado::::::::  ID: '.$id.'<br>';

                    if($suscriptor->deliveryStatus == 'opened'){
                        $suscriptorEmail = str_replace('@','%40',$valor->subscriberEmail);
                        echo 'Email::::::'.$suscriptorEmail.'<br>';
                        $response = json_decode(file_get_contents($this->_url_peticion.'/subscribers/'.$suscriptorEmail.'?api_key='.$this->_api_key)); 
                        foreach ($response->fields as $key => $value) {            
                            if($value->name == 'phone'){
                                $telefono = $value->value;
                            }
                        }
                        echo 'TELEFONO: '.$telefono.'<br>';
                        $carrier = file_get_contents('http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn='.$telefono);
                        echo 'CARRIER TEXTO: '.$carrier.'<br>';
                        switch(strtolower($carrier)){
                            case 'telcel':
                                $carrier = 1;
                                break;
                            case 'movistar':
                                $carrier = 2;
                                break;
                            case 'att':
                                $carrier = 3;
                                break;
                            default:
                                $carrier = -1;
                                break;
                        }
                        $datos->carrier_id = $carrier;
                        $carrier_array = ApiDopplerDao::getCarrierConectionShortCodeId($datos);
                        $carrier = $carrier_array['carrier_connection_short_code_id'];

                        echo 'CARRIER CONNECTION SHORT CODE ID:::::::: '.$carrier.'<br>';
                        $envio = file_get_contents("http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=$contenido&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id);
                        echo 'ENVIO::::::'.$envio.'<br>';
                        $texto .= "Respuesta: ".$telefono."<::::::>".$carrier.'<br>ENVIO::::::'.$envio."<br>http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=MT_DOPPLER_SMS&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id."***************************************************************************";
                    }
                }elseif ($existe>0){
                    $suscriber = ApiDopplerDao::getById($suscriptor);
                    echo $suscriptor->deliveryStatus.'<<<<<>>>>>'.$suscriber['delivery_status'].'<br>';
                    if($suscriptor->deliveryStatus != $suscriber['delivery_status']){
                        $suscriptorEmail = str_replace('@','%40',$valor->subscriberEmail);
                        echo 'Email::::::'.$suscriptorEmail.'<br>';
                        $response = json_decode(file_get_contents($this->_url_peticion.'/subscribers/'.$suscriptorEmail.'?api_key=2B55B4D51DA0C1F6CF721687D4E8BF7F')); 
                        foreach ($response->fields as $key => $value) {            
                            if($value->name == 'phone'){
                                $telefono = $value->value;
                            }
                        }
                        echo 'TELEFONO: '.$telefono.'<br>';
                        $carrier = file_get_contents('http://smpp.amovil.mx/buscarcarriers/apiBuscaCarrier.php?msisdn='.$telefono);
                        echo 'CARRIER TEXTO: '.$carrier.'<br>';
                        switch(strtolower($carrier)){
                            case 'telcel':
                                $carrier = 1;
                                break;
                            case 'movistar':
                                $carrier = 2;
                                break;
                            case 'att':
                                $carrier = 3;
                                break;
                            default:
                                $carrier = -1;
                                break;
                        }
                        $datos->carrier_id = $carrier;
                        $carrier_array = ApiDopplerDao::getCarrierConectionShortCodeId($datos);
                        $carrier = $carrier_array['carrier_connection_short_code_id'];

                        echo 'CARRIER CONNECTION SHORT CODE ID:::::::: '.$carrier.'<br>';
                        $envio = file_get_contents("http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=$contenido&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id);
                        echo 'ENVIO::::::'.$envio.'<br>';

                        $texto .= "Respuesta: ".$telefono."<::::::>".$carrier.'<br>ENVIO::::::'.$envio."<br>http://smppvier.amovil.mx:6654/send/submitGet/?destination=52$telefono&source=$marcacion&text=MT_DOPPLER_SMS&user=airmovil&pwd=4irM0v77k&customer=1&carrier=$carrier&campaign=".$datos->campaign_id."***************************************************************************";
                        ApiDopplerDao::update($suscriptor);
                    }
                }   
            }
        }

        echo $texto;
        mail("jorge.manon@airmovil.com,juan.medina@airmovil.com","checador de campañas Doppler","Se ha terminado de actualizar los estados de envio de las campañas:    ".$texto);
    }

    public function updateCampaigns1(){}
    
    public function updateCampaigns(){
        $response = $this->getCampaigns();
        foreach($response->items as $key => $value) {
                    if($value->status != 'draft'){
                        $detalle_envio = $this->getReporteCampaign($value->campaignId);
                        $campaign->_campaignId = $value->campaignId;
                        $fecha = substr($value->scheduledDate,0,10).' '.substr($value->scheduledDate,11,-5);
                        $campaign->_fecha_envio = $fecha;
                        $campaign->_name = $value->name;
                        $campaign->_fromEmail = $value->fromEmail;
                        $campaign->_subject = $value->subject;
                        $campaign->_status = $value->status;
                        preg_match('/shippings[\/][0-9]*/',$value->_links[1]->href, $shippingId, PREG_OFFSET_CAPTURE);
                        $campaign->_shippingId = str_replace('shippings/', '', $shippingId[0][0]);
                        if(count($detalle_envio) != 0){
                                $campaign->_uniqueOpens = $detalle_envio->uniqueOpens;
                                $campaign->_totalUnopened = $detalle_envio->totalUnopened;
                                $campaign->_totalHardBounces = $detalle_envio->totalHardBounces;
                                $campaign->_totalSoftBounces = $detalle_envio->totalSoftBounces;
                                $campaign->_totalRecipients = $detalle_envio->totalRecipients;
                                $campaign->_successFullDeliveries = $detalle_envio->successFullDeliveries;
                                $campaign->_uniqueClicks = $detalle_envio->uniqueClicks;
                                $campaign->_totalClicks = $detalle_envio->totalClicks;
                        }else{
                                $campaign->_uniqueOpens = 0;
                                $campaign->_totalUnopened = 0;
                                $campaign->_totalHardBounces = 0;
                                $campaign->_totalSoftBounces = 0;
                                $campaign->_totalRecipients = 0;
                                $campaign->_successFullDeliveries = 0;
                                $campaign->_uniqueClicks = 0;
                                $campaign->_totalClicks = 0;
                        }
                        if( count(ApiDopplerDao::getCampaign($value->campaignId)) == 0){
                            ApiDopplerDao::insertCampaign($campaign);
                            echo 'Se ha insertado correctamente...<br>';
                        }else{
                            ApiDopplerDao::updateCampaign($campaign);
                            echo 'Se ha actualizado correctamente...<br>';
                        }
                    }
        }
        mail("jorge.manon@airmovil.com","Actualizador de Capañas","Se ha actualizado la base de datos de las camp?s::::::: ");
    }



    public function importar(){
      $plantilla = $_FILES['plantilla'];
      $carpeta = explode('.', $plantilla['name'])[0];
      $type = $plantilla['type'];
      $tmp_name = $plantilla['tmp_name'];
      $size = $plantilla['size'];
      $ruta_destino = dirname(__DIR__).'/../public/plantillas_contenido/';

      exec('unzip -d '.$ruta_destino.$carpeta.' '.$tmp_name);
      exec('chmod -R 777 '.$ruta_destino.$carpeta);

      $lineas = file($ruta_destino.$carpeta.'/index.html');
      foreach ($lineas as $key => $value) {
         //$value = htmlspecialchars($value); 
         preg_match("/<img src=\"[A-Za-z0-9_-|\/]*.(png|jpg|jpeg|PNG|JPG|JPEG)\"/", $value, $texto);
         if($texto[0] != ''){
            $nombre_imagen = str_replace('"', '', $texto[0]);
            $nombre_imagen = str_replace('<img src=', '', $nombre_imagen);
            $imagen = MasterDom::convertBase64Image($ruta_destino.$carpeta.'/'.$nombre_imagen);
            $valor = str_replace($nombre_imagen,$imagen, $value);
            echo $valor;
         }else{
            preg_match("/<a href=\"[A-Za-z0-9_-|\/]*.(png|jpg|jpeg|PNG|JPG|JPEG|zip|ZIP|pdf|PDF)\"/", $value, $texto);
            if($texto[0] != ''){
               $nombre_imagen = str_replace('"', '', $texto[0]);
               $nombre_imagen = str_replace('<a href=', '', $nombre_imagen);
               $imagen = MasterDom::convertBase64Image($ruta_destino.$carpeta.'/'.$nombre_imagen);
               $valor = str_replace($nombre_imagen,$imagen, $value);
               echo $valor;
            }else{
               echo $value;
            }
         }  
      }
    }

    public function verificarCampaignAutomated1(){}

    public function verificarCampaignAutomated(){
      $reportes = '';
      foreach (ApiDopplerDao::getCampaignAutomated() as $keyCampaign => $valueCampaign) { 

        echo ':::::::::::::::::::::::::::::::::::::::::::::CAMPAÑA::::::::::::::::::::::::::::::::::::::::::::::::::';
        print_r($valueCampaign);
        echo ':::::::::::::::::::::::::::::::::::::::::::::FIN CAMPAÑA::::::::::::::::::::::::::::::::::::::::::::::::::';

        echo count(ApiDopplerDao::getCampaignsParentById($valueCampaign['doppler_campaign_id'])).'<br>';
        echo '::::::::';
        if( count(ApiDopplerDao::getCampaignsParentById($valueCampaign['doppler_campaign_id'])) <1 ){
          $content = $this->getContentByCampaignId($valueCampaign['doppler_campaign_id']);
          $list_id = $this->getListByCampaign($valueCampaign['doppler_campaign_id']);
          
          $campaña = new \stdClass();
          $campaña->_campaignId = '';
          $campaña->_shippingId = '';
          $campaña->_type = 'scheduled';
          $campaña->_fecha_envio = '';
          $campaña->_name = $valueCampaign['nombre'];
          $campaña->_fromEmail = $valueCampaign['email_sender'];
          $campaña->_fromName = $valueCampaign['name_sender'];
          $campaña->_subject = $valueCampaign['subject'];
          $campaña->_status = 'draft';
          $campaña->_uniqueClicks = 0;
          $campaña->_totalClicks = 0;
          $campaña->_uniqueOpens = 0;
          $campaña->_totalUnopened = 0;
          $campaña->_totalHardBounces = 0;
          $campaña->_totalSoftBounces = 0;
          $campaña->_totalRecipients = 0;
          $campaña->_successFullDeliveries = 0;
          $campaña->_doppler_campaign_parent_id = $valueCampaign['doppler_campaign_id'];

          $campaign = array(
            "name" => $valueCampaign['nombre'],
            "fromName" => $valueCampaign['name_sender'],
            "fromEmail" => $valueCampaign['email_sender'],
            "subject" => $valueCampaign['subject'],
            "status" => 'draft'
          );
          $response = $this->crearBorrador($campaign);
          print_r($response);
          echo '<br>:::::::::::::::::::::::::::::::::::FIN DE CREAR BORRADOR::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';
          $campaign_id = $response->createdResourceId;
          $response = $this->asignarContent($campaign_id, $content);
          print_r($response);
          echo '<br>:::::::::::::::::::::::::::::::::::::::FIN DE ASIGNAR CONTENIDO::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';
          $response = $this->asignarList($campaign_id, $list_id);
          print_r($response);
          echo '<br>:::::::::::::::::::::FIN DE ASIGNAR LISTA::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';

          $fecha = date('Y-m-d H:i:s');
          $nuevafecha = strtotime ( '+40 minute' , strtotime($fecha));
          $nuevafecha = date ( 'Y-m-d H:i:s' , $nuevafecha );
          $scheduledDate = $nuevafecha.".-06:00";

          $response = $this->enviar($campaign_id, $scheduledDate,'scheduled'); 
          print_r($response);
          echo '<br>::::::::::::::::::::::::::::::::::::FIN DE ENVIAR 1:::::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';
          $shippingId = $response->createdResourceId;
          $campaña->_campaignId = $campaign_id;
          $campaña->_fecha_envio = $scheduledDate;
          $campaña->_shippingId = $shippingId;
          ApiDopplerDao::insertCampaign($campaña);
          $response = $this->cancelarEnvio($campaign_id, $shippingId);
          print_r($response);
          echo '<br>:::::::::::::::::::::::::::::::::::::::::FIN DE CANCELAR::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';

          if($valueCampaign['automated_type'] == 'semanal'){
            $scheduledDate = $this->reprogramarEnvioSemanal($valueCampaign['doppler_campaign_id']);
          }elseif ($valueCampaign['automated_type'] == 'mensual') {
            $scheduledDate = $this->reprogramarEnvioMensual($valueCampaign['doppler_campaign_id']);
          }


          echo $valueCampaign['doppler_campaign_id'].'<br>';
          print_r($scheduledDate);
          echo '<br>:::::::::::::::::::::::::::::::::::::::::FIN DE LA FECHA PROGRAMADA::::::::::::::::::::::::::::::::::::::::::::::::::::<br>';
          $response = $this->enviar($campaign_id, $scheduledDate, 'scheduled'); 
          print_r($response);
          echo '<br>:::::::::::::::::::::::::::::::::::::::::::::FIN DE ENVIAR 2::::::::::::::::::::::::::::::::::::::::::::::::<br>';
          $shippingId = $response->createdResourceId;
          $campaña->_shippingId = $shippingId;
          ApiDopplerDao::updateShippingId($campaña);

          $reporte .= 'Se ha programado la campaña: '.json_encode($campaña).'<br><br><br><br>';
        }//fin del if que verifica si hay campaña programada
      }//fin del for que itera las campañas automatizadas

      mail("jorge.manon@airmovil.com","Automatizador de campañas","Se ha actualizado la base de datos de las camp?s::::::: <br>".$reporte);

    }

    public function crearBorrador($campaign){
      $data_string = json_encode($campaign);
      $url = "$this->_url_peticion/campaigns?api_key=$this->_api_key";
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_HTTPHEADER,
        array(
          'Content-Type: application/json;charset=UTF-8',
          'Accept: application/json','Content-Length: '.strlen($data_string)
          )
      );
      $response = json_decode(curl_exec($ch));
      curl_close($ch);
      return $response;
    }

    public function asignarContent($campaign_id, $content){
        $data = array($content);
        $url = "$this->_url_peticion/campaigns/$campaign_id/content?api_key=$this->_api_key";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,
          array(
            'Content-Type: text/html;',
            'Accept: application/json')
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $response = json_decode(curl_exec($ch));
        curl_close($ch);
        //print_r($response);
        //echo '<br><br><br>';
        return $response;
    }

    public function asignarList($campaign_id, $list_id){
        $data = array("lists" => array( array("id" => $list_id,"name" => "listaCumple" ) ) );
        $url = "$this->_url_peticion/campaigns/$campaign_id/recipients?api_key=$this->_api_key";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,
          array(
            'Content-Type: application/json',
            'Accept: application/json')
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
        $response = json_decode(curl_exec($ch));
        curl_close($ch);
        return $response;
    }

    public function enviar($campaign_id, $scheduledDate, $type){
         if($type == 'scheduled'){
            $data = array(
              "type" => $type,
              "scheduledDate" => $scheduledDate,
              "status" => "waiting");
         }else{
            $data = array(
              "type" => $type,
              "status" => "processing");
         }   
        
        $url = "$this->_url_peticion/campaigns/$campaign_id/shippings?api_key=$this->_api_key";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,
          array(
            'Content-Type: application/json',
            'Accept: application/json')
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
        $response = json_decode(curl_exec($ch));
        curl_close($ch);
        return $response;
        
    }

    public function cancelarEnvio($campaign_id, $shipping_id){
      $fecha = date('Y-m-d H:i:s');
      $nuevafecha = strtotime ( '+0 hour' , strtotime ( $fecha ) ) ;
      $nuevafecha = strtotime ( '+0 minute' , $nuevafecha ) ;
      $nuevafecha = strtotime ( '+0 second' , $nuevafecha ) ;
      $nuevafecha = date ( 'Y-m-d H:i:s' , $nuevafecha );

        $data = array(
            "type" => "scheduled",
            "scheduledDate" => $nuevafecha.".-06:00",
            "status" => "waiting"
        );

        $url = "$this->_url_peticion/campaigns/$campaign_id/shippings/$shipping_id?api_key=$this->_api_key";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,array('Accept: application/json'));
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
        $response = json_decode(curl_exec($ch));
        curl_close($ch);

        //print_r($response);
        return $response;
    }

    

    public function getReporteCampaign($campaign_id){
        return json_decode(file_get_contents("$this->_url_peticion/campaigns/$campaign_id/results-summary?api_key=$this->_api_key"));
    }

    public function getCampaigns(){
        return json_decode(file_get_contents($this->_url_peticion."/campaigns?page=1&per_page=10&api_key=$this->_api_key")); 
    }

    public function getCampaign($campaign_id){
        return json_decode(file_get_contents($this->_url_peticion.'/campaigns/'.$campaign_id.'/deliveries?page=1&per_page=10&api_key='.$this->_api_key));
    }

    public function getSuscriberById($listId){
        return json_decode(file_get_contents($this->_url_peticion."/lists/".$listId."/subscribers?page=1&per_page=10&api_key=".$this->_api_key));
    }

    public function getFieldsById($email){
        $email = str_replace('@','%40',$email);
        return json_decode(file_get_contents($this->_url_peticion."/subscribers/".$email."?api_key=".$this->_api_key));
    
    }
    
    public function getLists(){
        return json_decode(file_get_contents($this->_url_peticion."/lists?page=1&per_page=10&api_key=$this->_api_key"));
    }

    public function getListById($list_id){
        return json_decode(file_get_contents("$this->_url_peticion/lists/$list_id/subscribers?page=1&per_page=10&api_key=$this->_api_key"));
    }

    public function getSuscriberByListId($list_id){
      return json_decode(file_get_contents("$this->_url_peticion/lists/$list_id/subscribers?page=1&per_page=10&api_key=$this->_api_key"));
    }

    public function getContentByCampaignId($campaign_id){
//      echo "$this->_url_peticion/campaigns/$campaign_id/content?api_key=$this->_api_key<br>";
      return file_get_contents("$this->_url_peticion/campaigns/$campaign_id/content?api_key=$this->_api_key");
    }
    
    public function getListByCampaign($campaign_id){
      $response = json_decode(file_get_contents("$this->_url_peticion/campaigns/$campaign_id/recipients?api_key=$this->_api_key"));
      return $response->lists[0]->id;
    }

    public function getFileds(){
      $response = json_decode(file_get_contents("$this->_url_peticion/fields?api_key=$this->_api_key"));
      return $response->items;
    }

    public function crearPlantilla(){
        $encabezado = array();

        $fields = $this->getFileds();
        foreach ($fields as $key => $value) {
          array_push($encabezado, $value->name);
        }

        //$encabezado = array('GRUPO','CAMPAÑAS','ABIERTOS','NO ABIERTOS','RECHAZADOS HARD','RECHAZADOS SOFT','ENTREGADOS','TOTALES');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T');
        $title = "Titulo Plantilla Suscriptores";
        $name_sheet = "Plantilla Suscriptores";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Taurus Silver")
        ->setLastModifiedBy("Taurus Silver")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Plantilla suscriptores")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Plantillas");

        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }
        $objPHPExcel->getActiveSheet()->setTitle('Plantilla Suscriptores');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Plantilla Suscriptores.csv"');
        header('Cache-Control: max-age=0');
        //$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        $objWriter->save('php://output');

    }
}







