<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\FiltroMalasPalabras as FiltroMalasPalabrasDao;
use \App\controllers\FiltroMalasPalabras;

class FiltroMalasPalabras{

	private $_contenedor;

	    function __construct()
	    { 
			$this->_contenedor = new Contenedor;
	    }

	    public function index() { //Función principal

			if(!empty($_POST['url'])){ //Comprobamos si el parámetro enviado por POST no está vacío

						$url = $_POST['url'];

						if(filter_var($url, FILTER_VALIDATE_URL)){

							$arrContextOptions=array(
							    "ssl"=>array(
							        "verify_peer"=>false,
							        "verify_peer_name"=>false,
							    ),
							);

							$url = file_get_contents($url, false, stream_context_create($arrContextOptions));

							//$search_badWords = "La url es valida";

							$search_badWords = $this->revisaBadWords($url);//Función para revisar si hay malas palabras en la URL

						} elseif(!filter_var($url, FILTER_VALIDATE_URL)) {

							$search_badWords = $this->revisaBadWords($url);// No es url, pero hay una mala palabra

						} else {
							
							$search_badWords = $search_badWords->Mensaje = array("message" => FALSE);//."1er if"; 
																									 //No hay malas palabras en el parámetro enviado
						}

			} else{

				$search_badWords = $search_badWords->Mensaje = array("message" => FALSE);//."2do if"; 
																						 //Parámetro enviado por POST está vacío
			}
			
		header('Content-Type: application/json; charset=utf-8');
		$json = json_encode($search_badWords);
		echo $json;

		}

		public function revisaBadWords($search_badWords){//Funcion detectadora de insultos

					$badword = FiltroMalasPalabrasDao::getAllBadWords(); //Consulta que contiene los insultos a detectar

					foreach ($badword as $key => $value) {
					 
						if(preg_match("/".$value['word']."/i",$search_badWords)){/*Usamos expresiones regulares
																		  		  para comprobar si en el texto existe algun insulto.
																		  		  Tambièn usamos los datos insertados en la base de datos.
																	      		  Tambien se usa el modificador i para que no diferencie entre mayuscula y minuscula*/

							return $search_badWords = array("message" => TRUE);//."Hay malas palabras";
																										   //Si se ejecuta el if() y detecta al menos una mala palabra almacenada en la BD, devuelve TRUE
							exit;
						}

					}

			return $search_badWords = array("message" => FALSE);//."ninguna mala palabra";
																							//Si no se detecta ninguna mala palabra devuelve FALSE
		}//Fin de la funcion

		public function intento(){
			View::render('test');
		}

		public function prueba_url(){
			View::render('test_url');
		}
}