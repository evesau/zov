<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiPush AS ApiPushDao;
use \App\models\ApiPushNotification AS ApiPushNotificationDao;

class ApiPushNotification{
	const MAIL = "cesar.cortes@airmovil.com";

	const TYPE_ERROR = "error";
	const MSG_ERROR = "Se ha encontrado un error.";

	public function crearToken($fecha, $user, $password){
		$fecha1 = md5($fecha);
		$fecha2 = md5($fecha1);
		$username = md5("$user-$password");
		return md5("$username-$fecha2");
    }

    public function sendMailNotification($msj, $err){

    	$data = new \stdClass();
    	$data->_HTTP_HOST = $_SERVER['HTTP_HOST'];
		$data->_SERVER_PORT = $_SERVER['SERVER_PORT'];
		$data->_REQUEST_URI = $_SERVER['REQUEST_URI'];
		$data->_PHP_SELF = $_SERVER['PHP_SELF'];

		mail(self::MAIL, $data->_REQUEST_URI,"\nMENSAJE DE ERROR: ".$msj."\n".$err."\n");
    }

    // ENVIO DE UN MENSAJE PARA UN SOLO DISPOSITIVO
	public function submitOneJson(){

		$json[] = file_get_contents("php://input");

		$param = $this->validateObjJson($json);
		$get_object_vars = get_object_vars(json_decode($param));

		if($get_object_vars['response']){
			$input = json_decode(file_get_contents("php://input"), 1);
			
			MasterDom::validateIp($input['access']['user']);
			MasterDom::validatePermission($input['access']['user'], $input['card']['customer'], MasterDom::getData('url'));
			$token = $this->crearToken($input['access']['date'], $input['access']['user'], $input['access']['password']);
			MasterDom::validarToken($input['access']['date'], $input['access']['user'], $input['access']['password'], $token);


			$data = new \stdClass();
			$data->_customer = $input['card']['customer'];
			$data->_type = $input['card']['type'];
			$data->_title = $input['card']['title'];
			$data->_message = $input['card']['message'];
			$data->_base64_token = $input['card']['base64_token'];

			if(!empty($data->_customer) && !empty($data->_type) && !empty($data->_title) && !empty($data->_message) && !empty($data->_base64_token)){

				if(strtoupper($data->_type) == "ANDROID" || strtoupper($data->_type) == "IOS"){
					if(strlen($data->_message) <= 320 && strlen($data->_title)<=50){
						echo json_encode($this->sendNotification($data->_type,$data->_base64_token, $data->_title, $data->_message));
						$user = ApiPushNotificationDao::getUser($input['access']['user']);
						ApiPushNotificationDao::insertCampaignReport($input['card']['customer'], $user['user_id'],MasterDom::getData('url'),1);
					}else{
						echo json_encode(array(self::TYPE_ERROR=>self::MSG_ERROR));
						$arrCaracteres = array();
						if(strlen($data->_message)>=321 && strlen($data->_title)>50){
							array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en message mayor a 320 y title mayor a 50"));
						}elseif(strlen($data->_message)>=321){
							array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en message mayor a 320"));
						}elseif(strlen($data->_title)>50){
							array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en title mayor a 50"));
						}else{
							array_push($arrCaracteres, array("error"=>"Los parametros estan vacios de message y title"));
						}
						
						$err = print_r($arrCaracteres, 1);
						$this->sendMailNotification("EL PARAMETRO DE message y tittle, parece que tiene algunos errores\n", $err);
					}
				}else{
					echo json_encode(array(self::TYPE_ERROR=>self::MSG_ERROR));
					$this->sendMailNotification("EL PARAMETRO DE Type, no coincide con - ANDROID o IOS -", $data->_type);
				}
					
			}else{
				$err = array();

				if(empty($data->_customer))
					array_push($err, "parametro customer esta vacio");
				if(empty($data->_type))
					array_push($err, "parametro type esta vacio");
				if(empty($data->_title))
					array_push($err, "parametro title esta vacio");
				if(empty($data->_message))
					array_push($err, "parametro message esta vacio");
				if(empty($data->_base64_token))
					array_push($err, "parametro base64_token esta vacio");
				
				$err = print_r($err, 1);
				echo json_encode(array(self::TYPE_ERROR=>self::MSG_ERROR));
				$this->sendMailNotification("EXISTEN VALORES VACIOS EN EL ENVIO", $err);
			}
		}else{
			echo json_encode(array("error"=>$get_object_vars['message']));
			$this->sendMailNotification($get_object_vars['message'], "");
		}
	}

	// ENVIO VARIOS MENSAJES A DISTINTOS DISPOSITIVOS
	public function submitMultiJson(){

		$json[] = file_get_contents("php://input");

		$param = $this->validateObjJson($json);
		$get_object_vars = get_object_vars(json_decode($param));

		if($get_object_vars['response']){
			$input = json_decode(file_get_contents("php://input"), 1);
			MasterDom::validateIp($input['acceso']['user']);
			MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));
			$input['acceso']['fecha'] = date('Y-m-d H:i:s');
			$token = $this->crearToken($input['acceso']['date'], $input['acceso']['user'], $input['acceso']['password']);
			$valido = MasterDom::validarToken($input['acceso']['date'], $input['acceso']['user'], $input['acceso']['password'], $token);

			
			$title = $input['card']['title'];
			$message = $input['card']['message'];
			$destination = $input['card']['destination'];

			if(!empty($title) && !empty($message)){
				$arrayMsgResponse = array();
				foreach ($destination as $key => $value) {
					if(!empty($value['type']) && !empty($value['base64_token'])){
						$response = $this->sendNotification($value['type'], $value['base64_token'], $title, $message);
						if($response['success'] == "add to queue"){
							array_push($arrayMsgResponse, array("success"=>$response['success']));
						}else{
							array_push($arrayMsgResponse, array("error"=>$response['success']));
						}
					}else{
						echo json_encode(array(self::TYPE_ERROR=>self::MSG_ERROR));
						$arrError = array();
						if(empty($value['type']) && empty($value['base64_token'])){
							array_push($arrError, array("error"=>"El parametro type y base64_token de la posicion # {$key} del json estan vacios.\n"));
						}elseif(empty($value['type'])){
							array_push($arrError, array("error"=>"El parametro type de la posicion # {$key} del json esta vacio.\n"));
						}elseif(empty($value['base64_token'])){
							array_push($arrError, array("error"=>"El parametro base64_token de la posicion # {$key} del json estan vacios.\n"));
						}

						$err = print_r($arrError, 1);
						$this->sendMailNotification("Al parecer hay algunos errores en los parametros de - type y base64_token -\n", $err);
					}
				}
				
				if(count($arrayMsgResponse)>0){
					echo json_encode($arrayMsgResponse);
					foreach ($arrayMsgResponse as $key => $value) {
						if($value['success'] == 'add to queue'){
							$user = ApiPushNotificationDao::getUser($input['acceso']['user']);
							ApiPushNotificationDao::insertCampaignReport($input['card']['customer'], $user['user_id'],MasterDom::getData('url'),count($input['card']['destination']));
						}
					}
				}
				

			}else{
				echo json_encode(array(self::TYPE_ERROR=>self::MSG_ERROR));
				$arrCaracteres = array();
				if(strlen($message)>=321 && strlen($title)>50){
					array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en message mayor a 320 y title mayor a 50"));
				}elseif(strlen($message)>=321){
					array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en message mayor a 320"));
				}elseif(strlen($title)>50){
					array_push($arrCaracteres, array("error"=>"Cantidad de caracteres en title mayor a 50"));
				}else{
					array_push($arrCaracteres, array("error"=>"Los parametros estan vacios de message y title"));
				}
						
				$err = print_r($arrCaracteres, 1);
				$this->sendMailNotification("EL PARAMETRO DE message y tittle, parece que tiene algunos errores\n", $err);
			}



		}else{
			echo json_encode(array("error"=>$get_object_vars['message']));
			$this->sendMailNotification($get_object_vars['message'], "");
		}
	}

	public function submitMultiJsonCustom(){
		$input = json_decode(file_get_contents("php://input"), 1);
		MasterDom::validateIp($input['acceso']['user']);
		MasterDom::validatePermission($input['acceso']['user'], $input['card']['customer'], MasterDom::getData('url'));
		$vacio = MasterDom::isArrayEmpty($input);
		$input['acceso']['fecha'] = date('Y-m-d H:i:s');
		$token = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);
		$valido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $token);


		if($vacio == 0 && $valido == 0){
			foreach ($input['card']['destination'] as $key => $value) {
				$tipo = $value['tipo'];
				$title = $value['title'];
				$message = $value['message'];
				$base64_token = $value['base64_token'];
				echo "****" . json_encode($this->sendNotification($tipo, $base64_token, $title, $message));
				//sleep(5);
			}

			$user = ApiPushNotificationDao::getUser($input['acceso']['user']);
			ApiPushNotificationDao::insertCampaignReport($input['card']['customer'], $user['user_id'],MasterDom::getData('url'),count($input['card']['destination']));
		}else{
			$error = MasterDom::alertsService($vacio);
		    if($error == ''){
		    	echo json_encode(MasterDom::alertsService($valido));
		    }else{
		    	echo json_encode($error);
		    }
		}		
	}

	public function jsonTokenRegister(){
		$input = json_decode(file_get_contents("php://input"), 1);

		$card = $this->isArrayEmpty($input['card']);
		$acceso = $this->isArrayEmpty($input['acceso']);

		if($card == 1 AND $acceso == 1){
			echo json_encode($this->registerToken($input['card']));
		}else{
			if($card != 1)
				echo json_encode($card);
			if($acceso != 1)
				echo json_encode($acceso);
		}
	}

	public function getInsertTokenMulti(){
		$input = json_decode(file_get_contents("php://input"), 1);
		$title = $input['card']['title'];
		print_r($title);
	}

	public function jsonTokenRegisterMulti1(){
		$input = json_decode(file_get_contents("php://input"), 1);
		$card = $this->isArrayEmpty($input['card']);
		$acceso = $this->isArrayEmpty($input['acceso']);

		if($card == 1 AND $acceso == 1){
			foreach ($input['card']['destination'] as $key => $value) {
				$tipo = $value['tipo'];
				$base64_token = $value['base64_token'];
				$stdClass = new \stdClass();
				$stdClass->_tipo = $value['tipo'];
				$stdClass->_base64_token = $value['base64_token'];
				echo json_encode($this->registerTokenMulti($stdClass));
				sleep(1);
			}
		}else{
			if($card != 1)
				echo json_encode($card);
			if($acceso != 1)
				echo json_encode($acceso);
		}
	}

	public function testGSM(){
		// API access key from Google API's Console
		define( 'API_ACCESS_KEY', 'AIzaSyDXdINyzsSuo6tqtD8WpbuFvwD3gMHAP-M' );
		$registrationIds = array("ea2SxsynPPw:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3AdobsV8AxrM2nWxQok_Ue");
		// prep the bundle
		$msg = array
		(
			'message' 	=> 'here is a message. message',
			'title'		=> 'This is a title. title',
			'subtitle'	=> 'This is a subtitle. subtitle',
			'tickerText'	=> 'Ticker text here...Ticker text here...Ticker text here',
			'vibrate'	=> 1,
			'sound'		=> 1,
			'largeIcon'	=> 'large_icon',
			'smallIcon'	=> 'small_icon'
		);
		$fields = array
		(
			'registration_ids' 	=> $registrationIds,
			'data'			=> $msg
		);
		 
		$headers = array
		(
			'Authorization: key=' . "AIzaSyDXdINyzsSuo6tqtD8WpbuFvwD3gMHAP-M",
			'Content-Type: application/json'
		);


		exit;
		 
		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		$result = curl_exec($ch );
		curl_close( $ch );
		echo $result;
	}

	public function sendNotification($tipo, $token, $title, $msgBody){
		$registrationIds = array($token);
		$tipo = strtoupper($tipo);

		if($tipo == "IOS"){
			$msg = array( 
				'title' => $title,
				'body' => $msgBody, 
				'action' => 1, 
				'vibrate'=> 1, 
				'sound' => 1
			);

			$fields = array( 
				'registration_ids' => $registrationIds, 
				'notification'  => $msg,
				'priority' => "high"
			);

			$headers = array(
				'Authorization: key=AIzaSyD9xIH06QzDD5BKgN44eC49e3igTkNXtXw',
				'Content-Type: application/json'
			);
		}

		if($tipo == "ANDROID"){
			$msg = array( 
				'title' => $title,
				'message' => $msgBody,
				'action' => 3,
				'vibrate'=> 1,
				'sound' => 1
			);

			$dataJ['data'] = $msg;

			$fields = array( 
				'registration_ids' => $registrationIds, 'data'  => $dataJ, 'priority' => "high", "content_available" => true
			);

			$headers = array(
				'Authorization: key=AIzaSyDNyxkuNGU_u2KwzeTwWjqQgwPG01xa39A',
				'Content-Type: application/json'
			);
		}
		return $this->insertCurl($fields, $headers);
	}

	public function insertCurl($fields, $headers){
		$json = json_encode( $fields );

		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, $json );
		$result = curl_exec($ch );
		curl_close( $ch );

		$resultado = json_decode($result, 1);
		$success = $resultado['success'];
		$val;
		if($success == 1){
			$val = array("success"=>"add to queue");
		}else{
			$val = array("success"=>"Lo sentimos ha ocurrido un problema");
			mail("cesar.cortes@airmovil.com", "/ApiPushNotification/insertCurl/", "Ha ocurrido un error al tratar de enviar el push notification");
		}

		return $val;
	}

	##################################################################################################
	################################## REGISTRO DE TOKEN DISPOSITIVO #################################
	##################################################################################################	
	public function registerOneDevice(){

		$input = json_decode(file_get_contents("php://input"), 1);
		$obj = $input;
		//$input['acceso']['fecha'] = date('Y-m-d H:i:s');

		$input = json_decode(file_get_contents("php://input"), 1);
		$error = json_last_error();
		//$input['acceso']['fecha'] = date('Y-m-d H:i:s');
		
		$json[] = $input;

		if($this->validateJson($json) == "Sin errores"){
			$token = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);
			$tokenValido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $token);
			$banderas = array();
			if($tokenValido==0){ // VALIDA EL SI EL TOKEN ES VALIDO
				$validateIp = MasterDom::validateIp($input['acceso']['user']);
				if(empty($validateIp)){ // VALIDA SI LA IP DE DONDE SE ENVIA, ES VALIDA PARA REALIZAR EL ENVIO
					$device = new \stdClass();
					$device->_customer_id = $input['card']['customer'];
					// VERIFICA QUE EL CAMPO DE TIPO NO SEA NULO y VERIFICA QUE EL DISPOSITIVO SEA ANDROID O IOS
					$tipo = (strtolower($input['card']['tipo']) == "android" || strtolower($input['card']['tipo']) == 'ios') ? 0 : 1;
					$bandera = (!empty($input['card']['tipo']) && $tipo == 0 ) ? 0 : 1;
					array_push($banderas, $bandera);
					$device->_sistema_operativo = strtoupper($input['card']['tipo']);
					// VERIFICAR QUE EL TOKEN TENGA PARAMETROS
					$bandera = (!empty($input['card']['destination'])) ? 0 : 2;
					array_push($banderas, $bandera);
					$device->_token = $input['card']['destination'];
					// VERIFICAR QUE EL MSISDN SEA A 10 DIGITOS Y NO SEA VACIO
					$bandera = (!empty($input['card']['msisdn']) && strlen($input['card']['msisdn']) == 10) ? 0 : 3;
					array_push($banderas, $bandera);
					$device->_msisdn = "52".$input['card']['msisdn'];
					$device->_nombre = (!empty($input['card']['nombre'])) ? $input['card']['nombre'] : "";
					$device->_apellido = (!empty($input['card']['apellidos'])) ? $input['card']['apellidos'] : "";
					$device->_cuenta = (!empty($input['card']['cuenta'])) ? $input['card']['cuenta'] : "";
					$device->_sexo = (!empty($input['card']['sexo'])) ? $input['card']['sexo'] : "";
					
					if($banderas[0] == 0 && $banderas[1] == 0 && $banderas[2] == 0){
						// BUSQUEDA DE TOKEN, SI ES QUE EXISTE 
						$busquedaToken = ApiPushNotificationDao::searchToken($device->_customer_id, $device->_token, $device->_msisdn);
						
						if(empty($busquedaToken)){
							// INSERTAR EL TOKEN
							$id = ApiPushNotificationDao::insertToken($device);
							echo ($id > 0) ? json_encode(array('success'=>'se ha insertado correctamente el token')) : json_encode(array('success'=>'ha ocurrido un error al insertar'));
						}else{
							$update = new \stdClass();
							$update->_push_device = $busquedaToken['push_device'];
							$update->_msisdn = $device->_msisdn;
							$update->_nombre = $device->_nombre;
							$update->_apellido = $device->_apellido;
							$update->_cuenta = $device->_cuenta;
							$update->_sexo = $device->_sexo;
							// ACTUALIZACION DE DE DATOS DEL USUARIO
							if(ApiPushNotificationDao::updateRegisterToken($update) == 1)
								echo json_encode(array("success"=>"Se ha actualizado la informacion sobre este registro"));
							else
								echo json_encode(array("success"=>"Este usuario ya esta registrado."));
						}
					}else{
						if($banderas[0] == 1)
							$msj1 = "\nError en el la obtenicion del campo sismeta_operativo -> {$input['card']['tipo']} <- parametro recibido y requerido\n";

						if($banderas[1] == 2)
							$msj2 = "\nError en el la obtenicion del campo destination(token) device -> {$input['card']['destination']} <- parametro recibido y requerido\n";

						if($banderas[2] == 3)
							$msj3 = "\nError en el la obtenicion del campo msisdn -> {$input['card']['msisdn']} <- parametro recibido y requerido \n";

						$rqt = "\n".print_r($obj, 1)."\n";
 
						mail("cesar.cortes@airmovil.com", "RegisterOneDevice","Json rqt{$rqt} \n Se ha hecho uso de la api '/ApiPushNotification/RegisterOneDevice' \n {$msj1} \n {$msj2} \n {$msj3}");

							echo json_encode(array('error' => 'error desconocido.'));

					}

				}else{
					echo $validateIp;
				}
			}else{
				echo json_encode(array("error"=>"error desconocido."));
			}
			//$validateIp = MasterDom::validateIp($input['acceso']['user']);
		}else{
			echo json_encode(array("error"=>$this->validateJson($json)));
			mail("cesar.cortes@airmovil.com", "RegisterOneDevice","Se ha enviado el json con un parametro enterio faltante.");
		}
	}

	public function tokenRegisterMulti(){
		$input = json_decode(file_get_contents("php://input"), 1);
		$error = json_last_error();
		$input['acceso']['fecha'] = date('Y-m-d H:i:s');
		
		$json[] = $input;

		if($this->validateJson($json) == "Sin errores"){
			$token = $this->crearToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password']);
			$validateIp = MasterDom::validateIp($input['acceso']['user']);
			$tokenValido = MasterDom::validarToken($input['acceso']['fecha'], $input['acceso']['user'], $input['acceso']['password'], $token);
			if(empty($validateIp)){
				if($tokenValido == 0){
					// CUSTOMER PARA GUARDAR LOS TOKEN
					$customer = $input['card']['customer'];
					// RECORRIDO DE LO CADA TOKEN 
					$arr = array();
					$arrData = array();
					foreach ($input['card']['destination'] as $key => $value) {
						$data = new \stdClass();
						$data->_customer_id = $customer;
						if("ANDROID" == strtoupper($value['tipo']) || "IOS" == strtoupper($value['tipo']))
							$data->_sistema_operativo = $value['tipo'];
						else
							$valor1 = "parametro tipo debe ser ANDROID o IOS";

						if(!empty($value['base64_token']))
							$data->_token = $value['base64_token'];
						else
							$valor2 = "parametro base64_token esta vacio";

						$data->_msisdn = $value['msisdn'];
						$data->_nombre = $value['nombre'];
						$data->_apellido = $value['apellidos'];
						$data->_sexo = $value['sexo'];
						$data->_cuenta = $value['cuenta'];

						$getObjectVars = get_object_vars($data);
						
						if(count($getObjectVars)==8){
							// BUSQUEDA DE TOKEN CON CUSTOMER EN BASE DE DATOS 
							$busquedaToken = ApiPushNotificationDao::searchToken($data->_customer_id, $data->_token, $data->_msisdn);
							if(count($busquedaToken)){
								//echo json_encode(array("success"=>"El Registro #{$key}, ya esta registrado"))."\n";
								$update = new \stdClass();
								$update->_push_device = $busquedaToken['push_device'];
								$update->_msisdn = $data->_msisdn;
								$update->_nombre = $data->_nombre;
								$update->_apellido = $data->_apellido;
								$update->_cuenta = $data->_cuenta;
								$update->_sexo = $data->_sexo;
								// ACTUALIZACION DE DE DATOS DEL USUARIO
								if(ApiPushNotificationDao::updateRegisterToken($update) == 1)
									echo json_encode(array("success"=>"Se ha actualizado la informacion sobre este registro"))."\n";
								else
									echo json_encode(array("success"=>"Este usuario ya esta registrado."))."\n";
							}else{
								$id = ApiPushNotificationDao::insertToken($data);
								echo ($id > 0) ? json_encode(array('success'=>'se ha insertado correctamente el token'))."\n" : json_encode(array('success'=>'ha ocurrido un error al insertar'))."\n";
							}
						}else{
							echo json_encode(array("error"=>"El Registro #{$key} no se inserto. Errores: ".$valor1.$valor2)) . "\n";
						}

					}
				}
			}else{
				echo "error de metodo";
			}
		}else{
			echo json_encode(array("error"=>$this->validateJson($json)));
			mail("cesar.cortes@airmovil.com", "RegisterOneDevice","Se ha enviado el json con un parametro enterio faltante.");
		}
	}

	public function deleteDevice(){
		$input = json_decode(file_get_contents("php://input"), 1);
		//$error = json_last_error();
		$input['acceso']['fecha'] = date('Y-m-d H:i:s');
		echo "1";
		
		$json[] = $input;

		echo $this->validateJson($json);
	}

	public function validateObjJson($json){

		foreach($json as $string) {
			json_decode($string);
			switch(json_last_error()) {
				case JSON_ERROR_NONE:
					$arr = array("response"=>true,"message"=>"Sin errores");
				break;
				case JSON_ERROR_DEPTH:
					$arr = array("response"=>false,"message"=>"Excedido tamaño máximo de la pila");
				break;
				case JSON_ERROR_STATE_MISMATCH:
					$arr = array("response"=>false,"message"=>"Desbordamiento de buffer o los modos no coinciden");
				break;
				case JSON_ERROR_CTRL_CHAR:
					$arr = array("response"=>false,"message"=>"Encontrado carácter de control no esperado");
				break;
				case JSON_ERROR_SYNTAX:
					$arr = array("response"=>false,"message"=>"Error de sintaxis, JSON mal formado");
				break;
				case JSON_ERROR_UTF8:
					$arr = array("response"=>false,"message"=>"Caracteres UTF-8 malformados, posiblemente están mal codificados");
				break;
				default:
					$arr = array("response"=>false,"message"=>"Error desconocido");
				break;
			}
			return json_encode($arr);
			//echo PHP_EOL;
		}
	}

	########
	public function validateJson($json){

		foreach ($json as $string) {
			json_decode($string);
			
			switch(json_last_error()) {
				case JSON_ERROR_NONE:
					$val = 'Sin errores';
				break;
				case JSON_ERROR_DEPTH:
					$val = 'Excedido tamaño máximo de la pila';
				break;
				case JSON_ERROR_STATE_MISMATCH:
					$val = 'Desbordamiento de buffer o los modos no coinciden';
				break;
				case JSON_ERROR_CTRL_CHAR:
					$val = 'Encontrado carácter de control no esperado';
				break;
				case JSON_ERROR_SYNTAX:
					$val = 'Error de sintaxis, JSON mal formado';
				break;
				case JSON_ERROR_UTF8:
					$val = 'Caracteres UTF-8 malformados, posiblemente están mal codificados';
				break;
				default:
					$val = 'Error desconocido';
				break;
			}
			//return $val;
		echo $val;
		}
	}

	public function validateArr($array1, $array2){
		if($array1 == 1 AND $array2 == 1)
			return true;
		else
			return array("Error" => "Al parecer e");
	}

	// Regresa el estatus en 1, si el array esta lleno
	public function isArrayEmpty($array) {
		if(!empty($array)){
			$countKeyArray = count($array);
			$sumValueSuccess = array();

			foreach ($array as $key => $value) {
				if(!empty($key) AND !empty($value))
					array_push($sumValueSuccess, 1);
				else
					array_push($sumValueSuccess, 0);
			}
		
			$status = (array_sum($sumValueSuccess) == $countKeyArray) ? 3 : 2; // 3= Correcto y 2= tiene un dato vacio
		}else{
			$status = 1; // EL arreglo tiene un error al leer los paramentros
		}
		
		$alertsService = $this->alertsService($status);
		return 1;
	}

	public function registerToken($data){
		return $this->alertsService(4);
	}

	public function registerTokenMulti($data){
		return $this->alertsService(4);
	}

	public function alertsService($param){
		if($param == 1)
			$msg = array("Error" => "El objeto json, no esta formado de la forma correcta");
		if($param == 2)
			$msg = array("Error" => "Los datos del json no estan completos");
		if($param == 3)
			$msg = true;

		if($param == 4)
			$msg = array("Success" => "Se ha registrado el token satisfactoriamente.");

		return $msg;
	}

	public function recepcionJson(){
		$input = json_decode(file_get_contents("php://input"), 1);
		print_r($input);
	}

	public function pruebas(){

		$hoy = date('Y-m-d H:i:s');
		$token = $this->crearToken($hoy, "cesar", "cesar");
		$user = "cesar";
		$password = "cesar";
		$message = "";for ($i=1; $i <= 14; $i++) { $message .= "0123456789";}
		$title = "";for ($i=1; $i <= 14; $i++) { $title .= "A";}
		$tokenDevice = "ea2SxsynPPw:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3AdobsV8AxrM2nWxQok_Ue";

		// SUBMITONEJSON
			$submitOneJson = new \stdClass();
			$submitOneJson->card->customer = 1;
			$submitOneJson->card->type = "ANDROID";
			$submitOneJson->card->title = $title;
			$submitOneJson->card->message = $message;
			$submitOneJson->card->base64_token = $tokenDevice;
			$submitOneJson->access->token = $token;
			$submitOneJson->access->date = $hoy;
			$submitOneJson->access->user = "cesar";
			$submitOneJson->access->password = "cesar";
		// FIN SUBMITONEJSON

		// SUBMITMULTIJSON
			$submitMultiJson =new \stdClass();
			$submitMultiJson->card->customer = 1;
			$submitMultiJson->card->title = $title;
			$submitMultiJson->card->message = $message;
			for ($i=0; $i < 3; $i++) { 
				$submitMultiJson->card->destination[$i]->type = "";
				$submitMultiJson->card->destination[$i]->base64_token = $tokenDevice;
			}

			$submitMultiJson->acceso->token = $token;
			$submitMultiJson->acceso->date = $hoy;
			$submitMultiJson->acceso->user = "cesar";
			$submitMultiJson->acceso->password = "cesar";
		// FIN DE SUBMITMULTIJSON

		// REGISTRO TOKEN
			$registerOneDevice = new \stdClass();
			$registerOneDevice->card->customer = 1;
			$registerOneDevice->card->tipo = "ANDROID";
			$registerOneDevice->card->destination = $token."123";
			$registerOneDevice->card->msisdn = "5511223344";
			$registerOneDevice->card->nombre = "Nombre prueba";
			$registerOneDevice->card->apellidos = "Apellidos prueba";
			$registerOneDevice->card->sexo = "masculino";
			$registerOneDevice->card->cuenta = "123456789012345678";
			$registerOneDevice->acceso->token = $token;
			$registerOneDevice->acceso->fecha = $hoy;
			$registerOneDevice->acceso->user = "cesar";
			$registerOneDevice->acceso->password = "cesar";

		$data_string1 = json_encode($submitMultiJson);
		$data_string = <<<json
{
	"card": {
		"customer": 1,
		"title": "envio de mensaje",
		"message": "01234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789",
		"destination": [{
			"type": "ANDROID",
			"base64_token": "ea2Sxsy:APA91bFguFH7ssC58X4FwHKtmxil-"
		}, {
			"type": "ANDROID",
			"base64_token": "ea2Sxsy:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3"
		}, {
			"type": "ANDROID",
			"base64_token": "ea2Sxsy:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3AdobsV8AxrM2nWxQok_Ue"
		}, {
			"type": "ANDROID",
			"base64_token": "ea2Sxsy:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3"
		}, {
			"type": "ANDROID",
			"base64_token": "ea2Sxsy:APA91bFguFH7ssC58X4FwHKtmxil-M8xE_rOoWGH6er1DhJHbXNyNdnRO6ZUZmK3vQ1AwYk1_Q1Ema5KK60sttJzO93wKQBuH0CiLbCM08nx9ib9xNSffE3AdobsV8AxrM2nWxQok_Ue"
		}]
	},
	"acceso": {
		"token": "0eeee375deb9f2d20b26814cb55d896e",
		"date": "2018-02-07 15:03:34",
		"user": "cesar",
		"password": "cesar"
	}
}
json;

		$result = file_get_contents('https://smppvier.amovil.mx/ApiPushNotification/submitMultiJson', null, stream_context_create(array(
			'http' => array(
				'method' => 'POST',
				'header' => array('Content-Type: application/json'."\r\n". 
					'Content-Length: ' . strlen($data_string) . "\r\n"),
					'content' => $data_string)
				)
			));

		echo $result;
	}

}