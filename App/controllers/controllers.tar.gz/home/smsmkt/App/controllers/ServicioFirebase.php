<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\Cliente AS ClienteDao;

class ServicioFirebase{

    private $_contenedor;

    function __construct(){
      $this->_contenedor = new Contenedor;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer());
    }

    public function index(){
      $extraFooter =<<<html
      <script>
        $(document).ready(function(){

          $("#btnEnviar").click(function(){
            $.ajax({
              type: "POST",
              url: "/ServicioFirebase/enviarPush",
              data: $("#form").serialize(),
              success: function(data){
                alert("Enviados correctamente");
              }
            });
          });

          $("#tipo").change(function(){
            var opcion = $("#tipo").val();
            if(opcion == 1){
              var contenido = '<div class="col-md-12 col-sm-12 col-xs-12 col-lg-4"><label> Sueldo:</label><input class="form-control" type="text" name="sueldo" id="sueldo" /></div>';
              $("#contenedor").html(contenido);
            }else{
              if(opcion == 2){
                var contenido1 = '<div class="col-md-12 col-sm-12 col-xs-12 col-lg-4"><label> Cliente:</label><input class="form-control" type="text" name="cliente" id="cliente" /></div>';
                $("#contenedor").html(contenido1);
              }else{
                if(opcion == 3){
                  var contenido3 = '<div class="col-md-12 col-sm-12 col-xs-12 col-lg-4"><label> Status:</label><input class="form-control" type="text" name="status" id="status" /></div>';
                  contenido3 += '<div class="col-md-12 col-sm-12 col-xs-12 col-lg-4"><label> Costo:</label><input class="form-control" type="text" name="costo" id="costo" /></div>';
                  $("#contenedor").html(contenido3);
                }//if 3
              }//else 2
            }//else 1

          });//evento change

        });//evento ready
      </script>
html;
      View::set('header',$this->_contenedor->header());
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render("servicio_all");
    }

    public function enviarPush() {
      define( 'API_ACCESS_KEY', 'AIzaSyDNyxkuNGU_u2KwzeTwWjqQgwPG01xa39A');

      $sueldo = isset($_POST['sueldo'])? $_POST['sueldo'] : '';
      $cliente = isset($_POST['cliente'])? $_POST['cliente'] : '';
      $status = isset($_POST['status'])? $_POST['status'] : '';
      $costo = isset($_POST['costo'])? $_POST['costo'] : '';
      $registrationIds ="e9Ne0mUtwFo:APA91bEbJo3JGGar8v8smLJwrmsuEpzI1Ss14w6JOou2subWJtOyTqMOwbiSKQ9i_NOLrrzQiNNw3GVYSBRIYkdIN2fjjRnjmz4x3oD7lZEpkxpvD5j28Ac6Z9wE2GdhZHv_EDDTyfoN";

      $texto = "";
      $texto .= ($sueldo!='')? "Se han depositado correctamente los $".$sueldo : '';
      $texto .= ($cliente!='')? "Se han tranferido correctamente a ".$cliente : '';
      $texto .= ($status!='')? "Status del servicio:  ".$status." \nCosto: $".$costo : '';


      $msg = array(
        'body' 	=> MasterDom::getData('texto')." ".$texto,
        'title'	=> MasterDom::getData('titulo'),
        'sueldo' => $sueldo,
        'cliente' => $cliente,
        'status' => $status,
        'costo' => $costo,
        'icon'	=> 'myicon',
        'sound' => 'mySound'
      );

      $fields = array(
        'to'		=> $registrationIds,
        'notification'	=> $msg
      );

      $headers = array(
        'Authorization: key='.API_ACCESS_KEY,
        'Content-Type: application/json'
      );

      $ch = curl_init();
      curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
      curl_setopt( $ch,CURLOPT_POST, true );
      curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
      curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
      curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
      curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
      $result = curl_exec($ch );
      curl_close( $ch );
      echo $result;
    }
    public function add(){}
    public function edit($id){}
    public function delete($id){}

}
