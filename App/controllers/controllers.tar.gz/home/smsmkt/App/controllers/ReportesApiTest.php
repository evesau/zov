<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//include '/usr/local/bin/vendor/autoload.php';

use \Core\View;
use \Core\MasterDom;
use \App\models\ReportesApiTest as ReportesDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class ReportesApiTest{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function obtenerLimite($registros, $inicio, $limite){
        $seleccion = array();
        for($i = $inicio; $i<count($registros); $i ++) {
            array_push($seleccion, $registros[$i]);
            if($i == ($inicio + $limite)){
                break;
            }
        }
        return $seleccion; 
    }

    public function api(){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
        <!-- jQuery -->
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
        <style>
            input{
                border-radius: 10px;
            }
        </style>
html;

         $extraFooter=<<<html
         <script src="/js/jquery.dataTables.min.js"></script>
         <script src="/js/dataTables.bootstrap.min.js"></script>
         <script src="/js/bootbox.min.js"></script>
         <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
         <script src="/js/validate/jquery.validate.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
         <script>

         $(document).ready(function() {

            var anio = (new Date).getFullYear();
            $('#datetimepicker4').datetimepicker({
                format: 'YYYY-MM-DD H:m:s',
                daysOfWeekDisabled: [0, 6],
                inline: false,
                sideBySide: false
            });
            $('#datetimepicker5').datetimepicker({
                format: 'YYYY-MM-DD H:m:s',
                daysOfWeekDisabled: [0, 6],
                inline: false,
                sideBySide: false
            });

            $("input[id=datetimepicker4]").val("");
            $("input[id=datetimepicker5]").val("");

            $("#btnBuscar").click(function(){
                $("#reporte_mt").dataTable().fnDestroy();
                buscar();
            });

            $("#btnDescargar").click(function(){
                $("#mt_api").attr("action", "/ReportesApiTest/descargarExcel");
                $("#mt_api").attr("target", "_blank");
                $("#mt_api").attr("method", "POST");
                $("#mt_api").submit();
            });

            /**********FUNCTION BUSCAR********/
            function buscar(){
                
                var table2 = $("#reporte_mt").DataTable({
                    "processing": true,
                    "serverSide": true,
                    "bLengthChange": false,
                    "searching": false,
                    "ordering": false,
                    "iDisplayLength": 10,
                    "ajax": {
                        "url": '/ReportesApiTest/buscarMtApi',
                        "dataType":'json',
                        "data": {
                            id_camp: $("#id_campania option:selected").val(),
                            carrier: $('#carrier').val(),
                            destination: $('#destination').val(),
                            source: $('#source').val(),
                            estatus: $('#estatus').val(),
                            fecha_inicio: $('#datetimepicker4').val(),
                            fecha_fin: $('#datetimepicker5').val()
                        }
                    },
                    "columns": [
                        { "data": "FECHA" },
                        { "data": "CARRIER" },
                        { "data": "DESTINATION" },
                        { "data": "SHORTCODE" },
                        { "data": "CONTENT" },
                        { "data": "ESTATUSSMS" }
                    ],
                    "language": {
                        "emptyTable": "No hay datos disponibles",
                        "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                        "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                        "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                        "lengthMenu": "Mostrar _MENU_ entradas",
                        "zeroRecords":  "No se encontraron resultados",
                        "search": "Buscar:",
                        "processing":     "Procesando...",
                        "paginate" : {
                            "next": "Siguiente",
                            "previous" : "Anterior"
                        }
                    }
                });
            }
            /**********FUNCTION BUSCAR********/

            buscar();
        });

    </script>
html;
         $row = array_reverse(ReportesDao::getAllCampaignApi(MasterDom::getSession('customer_id')));
         $select = "";
         foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name_campaign']." -- ".$value['short_code']."</option>";
         }

         View::set('select',$select);
         View::set('header',$this->_contenedor->header($extraHeader));
         View::set('footer',$this->_contenedor->footer($extraFooter));
         View::render("reporte_api_test");
    }


    public function buscarMtApi(){
        header("Content-type: application/json; charset=utf-8");
        if (!empty($_GET)){
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $fecha_inicio = MasterDom::getData('fecha_inicio');
            $fecha_fin = MasterDom::getData('fecha_fin');

            $customer_id = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $datos = new \stdClass();
            $datos->customer_id = $customer_id;
            $datos->where = '';
            $datos->campaign_id = $id_campania;

            if( !empty($carrier) || !empty($destination) || !empty($source) || !empty($estatus) || !empty($customer_id) || !empty($fecha_inicio) || !empty($fecha_fin) ){

                if( !empty($carrier) ){
                  $datos->where .= ' AND (s.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'")';
                }
                if( !empty($destination) ){
                  $datos->where .= ' AND msisdn_log = "'.$destination.'"';  
                }
                if( !empty($source) ){
                    $datos->where .= ' AND s.source = '.$source;
                }
                if( !empty($estatus) ){
                    $datos->where .= ' AND (s.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR s.status_dlr = "'.$estatus.'")';
                }
                if( !empty($fecha_inicio) ){
                    $datos->where .= ' AND (IF(s.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", s.entry_time >= "'.$fecha_inicio.'"))';
                }
                if( !empty($fecha_fin) ){
                    $datos->where .= ' AND (IF(s.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", s.entry_time <= "'.$fecha_fin.'"))';
                }
                if( !empty($id_campania) ){
                    $datos->where .= ' AND (sc.campaign_id = "'.$id_campania.'")';
                }else{
                    if( empty($fecha_inicio) && empty($fecha_fin) ){
                        $campaign = ReportesDao::getMaxCampaign(MasterDom::getSession('customer_id'));
                        $datos->where .= ' AND (sc.campaign_id = "'.$campaign['campaign_id'].'")';
                    }
                }
            }

            $registros = ReportesDao::getDataSMSApi($datos);
            $prueba = array("draw"=>$draw, "recordsTotal"=>count($registros), "recordsFiltered"=>count($registros),"data"=>$this->obtenerLimite($registros, $start, $length));
            //mail('jorge.manon@airmovil.com', 'Query Reportes', "Reportes Api Test: ".json_encode($prueba).":::::::::::::::::::::::::::".json_encode($registros));
            echo json_encode($prueba);
        }
    }

    public function descargarExcel(){
        header("Content-type: application/json; charset=utf-8");
        if (!empty($_GET)){
            $start = MasterDom::getData('start');
            $length = MasterDom::getData('length');
            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $fecha_inicio = MasterDom::getData('fecha_inicio');
            $fecha_fin = MasterDom::getData('fecha_fin');

            $customer_id = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $datos = new \stdClass();
            $datos->customer_id = $customer_id;
            $datos->where = '';
            $datos->campaign_id = $id_campania;

            if( !empty($carrier) || !empty($destination) || !empty($source) || !empty($estatus) || !empty($customer_id) || !empty($fecha_inicio) || !empty($fecha_fin) ){

                if( !empty($carrier) ){
                  $datos->where .= ' AND (s.carrier = "'.$carrier.'" OR ca.name = "'.$carrier.'")';
                }
                if( !empty($destination) ){
                  $datos->where .= ' AND msisdn_log = "'.$destination.'"';  
                }
                if( !empty($source) ){
                    $datos->where .= ' AND s.source = '.$source;
                }
                if( !empty($estatus) ){
                    $datos->where .= ' AND (s.status = "'.$estatus.'" OR  sce.estatus = "'.$estatus.'" OR s.status_dlr = "'.$estatus.'")';
                }
                if( !empty($fecha_inicio) ){
                    $datos->where .= ' AND (IF(s.entry_time is null, sc.delivery_date >= "'.$fecha_inicio.'", s.entry_time >= "'.$fecha_inicio.'"))';
                }
                if( !empty($fecha_fin) ){
                    $datos->where .= ' AND (IF(s.entry_time is null, sc.delivery_date <= "'.$fecha_fin.'", s.entry_time <= "'.$fecha_fin.'"))';
                }
                if( !empty($id_campania) ){
                    $datos->where .= ' AND (sc.campaign_id = '.$id_campania.')';
                }else{
                    if( empty($fecha_inicio) && empty($fecha_fin) ){
                        $campaign = ReportesDao::getMaxCampaign(MasterDom::getSession('customer_id'));
                        $datos->where .= ' AND (sc.campaign_id = '.$campaign['campaign_id'].')';
                    }
                }
            }

            $registros = ReportesDao::getDataSMSApi($datos);
            $this->crearExcel($registros);
        }
    }

    public static function crearExcel($mensajes){
        $encabezado = array('FECHA','CARRIER','DESTINATION','SHORTCODE','CONTENT','ESTATUSSMS');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }
}
