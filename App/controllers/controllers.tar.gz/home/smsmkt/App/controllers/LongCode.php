<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\LongCode as LongCodeDao;
use \App\controllers\Contenedor;

class LongCode{

private $_contenedor;

    function __construct() {
      $this->_contenedor = new Contenedor;
    	View::set('header',$this->_contenedor->header());
    	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {
      $extraHeader =<<<html
      <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="/css/custom.min.css">
      <link rel="stylesheet" href="/css/validate/cmxform.css">
html;
      $extraFooter =<<<html
      <script src="/js/validate/jquery.validate.js"></script>
      <script src="/js/jquery.dataTables.min.js"></script>
      <script src="/js/dataTables.bootstrap.min.js"></script>
      <script src="/js/bootbox.min.js"></script>
html;
      $devices = LongCodeDao::getAll();
      $tabla = '';
      foreach ($devices as $key => $value) {

        $tabla .= '<tr>';
        $tabla .= '<td class="sorting_1"><input type="checkbox" name="borrar[]" value="'.$value['long_code_campania'].'"></td>';
        $tabla .= '<td>'.$value['mensaje'].'</td>';
        $tabla .= '<td>'.$value['fecha'].'</td>';
        $tabla .= '<td>'.$value['total'].'</td>';
        $tabla .= '<td><a href="/LongCode/edit/'.$value['push_device'].'" type="button" ><i class="fa fa-pencil-square-o"></i></a></td>';
        $tabla .= '</tr>';
      }

      View::set('tabla',$tabla);
      View::set('header',$this->_contenedor->header($extraHeader));
    	View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('long_code_all');
    }

    public function add(){
      $extraHeader =<<<html
      <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="/css/custom.min.css">
      <link rel="stylesheet" href="/css/validate/cmxform.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;
      $extraFooter =<<<html

      <script src="/js/jquery.dataTables.min.js"></script>
      <script src="/js/dataTables.bootstrap.min.js"></script>
      <script src="/js/bootbox.min.js"></script>
      <script src="/js/validate/jquery.validate.js"></script>

      <!-- LIBRERIA PARA AGREGAR FECHA-->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
      <script>
        $(document).ready(function(){

          $('#fecha').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6]
          });

          $("#add").validate({
            rules: {
              token:{
                required: true
              },
              msisdn: {
                required: true
              },
              sistema_operativo: {
                required: true
              },
              nombre: {
                required: true
              },
              apellido: {
                required: true
              },
              cuenta: {
                required: true
              },
              archivo: {
                required: true
              }
            },
            messages: {
              token:{
                required: "Este campo es requerido"
              },
              msisdn: {
                required: "Este campo es requerido"
              },
              sistema_operativo: {
                required: "Este campo es requerido"
              },
              nombre: {
                required: "Este campo es requerido"
              },
              apellido: {
                required: "Este campo es requerido"
              },
              cuenta: {
                required: "Este campo es requerido"
              },
              archivo: {
                required: "Este campo es requerido"
              }
            }
          });

        });
      </script>
html;

      $sSexo = '';
      foreach (array('Femenino','Masculino') as $key => $value) {
        $sSexo .= '<option value="'.$value.'" >'.$value.'</option>';
      }

      $sEstatus = '';
      foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
        $sEstatus .= '<option value="'.$key.'" >'.$value.'</option>';
      }

      View::set('sEstatus',$sEstatus);
      View::set('sSexo',$sSexo);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('long_code_add');
    }

    public function edit($id){
      $extraHeader =<<<html
      <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
      <link rel="stylesheet" href="/css/custom.min.css">
      <link rel="stylesheet" href="/css/validate/cmxform.css">
html;
      $extraFooter =<<<html
      <script src="/js/validate/jquery.validate.js"></script>
      <script src="/js/jquery.dataTables.min.js"></script>
      <script src="/js/dataTables.bootstrap.min.js"></script>
      <script src="/js/bootbox.min.js"></script>
      <script>
        $(document).ready(function(){

          $("#edit").validate({
            rules: {
              token:{
                required: true
              },
              msisdn: {
                required: true
              },
              sistema_operativo: {
                required: true
              },
              nombre: {
                required: true
              },
              apellido: {
                required: true
              },
              cuenta: {
                required: true
              }
            },
            messages: {
              token:{
                required: "Este campo es requerido"
              },
              msisdn: {
                required: "Este campo es requerido"
              },
              sistema_operativo: {
                required: "Este campo es requerido"
              },
              nombre: {
                required: "Este campo es requerido"
              },
              apellido: {
                required: "Este campo es requerido"
              },
              cuenta: {
                required: "Este campo es requerido"
              }
            }
          });

        });
      </script>
html;
      $device = LongCodeDao::getById($id);

      $sSexo = '';
      foreach (array('Femenino','Masculino') as $key => $value) {
        $selected = (strtolower($device['sexo']) == strtolower($value))? 'selected' : '';
        $sSexo .= '<option '.$selected.' value="'.$value.'" >'.$value.'</option>';
      }

      $sEstatus = '';
      foreach (array('Oculto','Visible','Eliminado') as $key => $value) {
        $selected = ($device['estatus'] == $key)? 'selected' : '';
        $sEstatus .= '<option '.$selected.' value="'.$key.'" >'.$value.'</option>';
      }

      View::set('sEstatus',$sEstatus);
      View::set('sSexo',$sSexo);
      View::set('device',$device);

      View::set('header',$this->_contenedor->header($extraHeader));
    	View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render('device_edit');
    }

    public function delete(){
      $ids = MasterDom::getDataAll('borrar');
      foreach ($ids as $key => $value) {
        LongCodeDao::delete($value);
      }
      Header("Location: /Device/");
    }

      public function campaniaAdd(){
          $campania = new \stdClass();
          $campania->_nombre = MasterDom::getData("nombre");
          $campania->_mensaje = MasterDom::getData("mensaje");
          $campania->_fecha = MasterDom::getData("fecha");
          $campania->_numeros = explode(',',MasterDom::getData("numeros"));

          print_r($campania);
          //LongCodeDao::insert($device);

      }

    public function deviceEdit(){
      $device = new \stdClass();
      $device->_push_device = MasterDom::getData("push_device");
      $device->_token = MasterDom::getData("token");
      $device->_msisdn = MasterDom::getData("msisdn");
      $device->_estatus = MasterDom::getData("estatus");
      $device->_sistema_operativo = MasterDom::getData("sistema_operativo");
      $device->_nombre = MasterDom::getData("nombre");
      $device->_apellido = MasterDom::getData("apellido");
      $device->_cuenta = MasterDom::getData("cuenta");
      $device->_sexo = MasterDom::getData("sexo");

      echo LongCodeDao::update($device);
      Header("Location: /Device/");
    }

}
