<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

//include '/usr/local/bin/vendor/autoload.php';

use \Core\View;
use \Core\MasterDom;
use \App\models\Reportes as ReportesDao;
use \App\controllers\Contenedor;

class Reportes{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){

        $extraHeader=<<<html
    <!-- DataTables CSS -->
    <link href="../css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DateTimePicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

html;

        $extraFooter=<<<html
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <script>
    $(document).ready(function() {

        var anio = (new Date).getFullYear();

        $('#datetimepicker').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
        $('#datetimepicker1').datetimepicker({
                format: 'DD/MM/YYYY',
                minDate: "01/01/" + anio,
                //maxDate: moment(),
                daysOfWeekDisabled: [0, 6]
        });

        $("#datetimepicker").on("dp.change", function (e) {
                $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
        });
        $("#datetimepicker1").on("dp.change", function (e) {
                $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
        });

            var table = $('#reportes').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "bLengthChange": false,
                        "searching": false,
                        "ordering": false,
                        "iDisplayLength": 20,
                        "ajax": {
                                    "url": '/Reportes/datosJsonReporteTotal',
                                    "dataType":'json'
                                },
                        "columns": [
                            { "data": "name_campaign" },
                            { "data": "modulo" },
                            { "data": "delivery_date" },
                            { "data": "name" },
                            { "data": "short_code" },
                            { "data": "total_mensajes" }
                        ],
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing": "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });
        });

        function actualizarDataTableSearch(){

            $("#reportes").dataTable().fnDestroy();
            cambioCampaniaSearch();
        }

        function cambioCampaniaSearch(){

            var table2 = $('#reportes').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "bLengthChange": false,
                        "searching": false,
                        "ordering": false,
                        "iDisplayLength": 20,
                        "ajax": {
                                    "url": '/Reportes/searchDate',
                                    "dataType":'json',
                                    "data": {
                                        fecha_ini: $("input:text[name=datetimepicker]").val(),
                                        fecha_fin: $("input:text[name=datetimepicker1]").val(),
                                        status: $("input:text[name=status]").val(),
                                        direction: $("select[name=direction]").val(),
                                        shortcode: $("input:text[name=shortcode]").val(),
                                        campania: $("input:text[name=campania]").val()
                                    }
                                },
                        "columns": [
                            { "data": "name_campaign" },
                            { "data": "modulo" },
                            { "data": "delivery_date" },
                            { "data": "name" },
                            { "data": "short_code" },
                            { "data": "total_mensajes" }
                        ],
                        "language": {
                            "emptyTable": "No hay datos disponibles",
                            "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                            "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                            "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                            "lengthMenu": "Mostrar _MENU_ registros",
                            "zeroRecords":  "No se encontraron resultados",
                            "search": "Buscar:",
                            "processing":     "Procesando...",
                            "paginate" : {
                                "next": "Siguiente",
                                "previous" : "Anterior"
                            }
                        }
                     });
        }

    </script>
html;
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');
        $id_user = MasterDom::getSession('id_user');

        $total_telcel = ReportesDao:: getTotalTelcel($id_custom);
        $total_movistar = ReportesDao:: getTotalMovistar($id_custom);
        $total_att = ReportesDao:: getTotalATT($id_custom);

        $tt=count($total_telcel);
        $tm=count($total_movistar);
        $tatt=count($total_att);

        View::set('telcel',$tt);
        View::set('movi',$tm);
        View::set('att',$tatt);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes");
    }

    public function datosJsonReporteTotal(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getTotalMessages($id_custom);

        if(empty($row)){
            $recordsTotal = 0;
        }else{
            $recordsTotal = count(ReportesDao::getTotalMessages($id_custom));
        }

            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotal, "recordsFiltered"=>$recordsTotal,"data"=>ReportesDao::getTotalMessagesCop($id_custom, $start, $length));
            echo json_encode($prueba);
    }

    public function searchDate(){

        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $status = MasterDom::getData('status');
            $campania = MasterDom::getData('campania');
            $direction = MasterDom::getData('direction');
            $shortcode = MasterDom::getData('shortcode');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);

            if(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearch($id_custom, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCop($id_custom, $start, $length, $fecha_ini, $fecha_fin));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampania($id_custom, $campania, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaCop($id_custom, $campania, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) &&empty($campania) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchShortcode($id_custom, $shortcode, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchShortcodeCop($id_custom, $shortcode, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($status) && empty($campania) &&empty($shortcode) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchStatus($id_custom, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchStatusCop($id_custom, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($direction) && empty($campania) &&empty($shortcode) && empty($status)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchDirection($id_custom, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchDirectionCop($id_custom, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaShortCode($id_custom, $campania, $shortcode, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaShortCodeCop($id_custom, $campania, $shortcode, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($status) && empty($shortcode) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaStatus($id_custom, $campania, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaStatusCop($id_custom, $campania, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($direction) && empty($status) && empty($shortcode)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaDirection($id_custom, $campania, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaDirectionCop($id_custom, $campania, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) && !empty($status) && empty($campania) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchShortcodeStatus($id_custom, $shortcode, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchShortcodeStatusCop($id_custom, $shortcode, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($shortcode) && !empty($direction) && empty($campania) && empty($status)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchShortcodeDirection($id_custom, $shortcode, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchShortcodeDirectionCop($id_custom, $shortcode, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($status) && empty($direction)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaShortCodeStatus($id_custom, $campania, $shortcode, $status, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaShortCodeStatusCop($id_custom, $campania, $shortcode, $status, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($direction) && empty($status)) {

                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaShortCodeDirection($id_custom, $campania, $shortcode, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaShortCodeDirectionCop($id_custom, $campania, $shortcode, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && !empty($campania) && !empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchCampaniaShortCodeStatusDirection($id_custom, $campania, $shortcode, $status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchCampaniaShortCodeStatusDirectionCop($id_custom, $campania, $shortcode, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchStatusDirection($id_custom, $status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchStatusDirectionCop($id_custom, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }elseif(!empty($fecha_ini) && !empty($fecha_fin) && empty($campania) && !empty($shortcode) && !empty($status) && !empty($direction)) {
                $recordsTotalFiltered = count(ReportesDao::getTotalMessagesSearchShorCodeStatusDirection($id_custom, $shortcode ,$status, $direction, $fecha_ini, $fecha_fin));

                $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalMessagesSearchShortCodeStatusDirectionCop($id_custom, $shortcode, $status, $direction, $fecha_ini, $fecha_fin, $start, $length));

                echo json_encode($resultado);

            }

        }

    }

    public function mt(){
        MasterDom::verificaUsuario();

    $extraHeader=<<<html
    <!-- jQuery -->
    <!-- DataTables CSS -->
    <link href="/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DateTimePicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

    <!-- DataTable Reporte MT Principal -->
    <script>

        $(document).ready(function() {

            var anio = (new Date).getFullYear();

            $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
            $('#datetimepicker1').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker").on("dp.change", function (e) {
                    $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker1").on("dp.change", function (e) {
                    $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
            });

            $('#datetimepicker2').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
            $('#datetimepicker3').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    //maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker2").on("dp.change", function (e) {
                    $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker3").on("dp.change", function (e) {
                    $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
            });

            $('#datetimepicker4').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });
            $('#datetimepicker5').datetimepicker({
                    format: 'DD/MM/YYYY',
                    minDate: "01/01/" + anio,
                    maxDate: moment(),
                    daysOfWeekDisabled: [0, 6]
            });

            $("#datetimepicker4").on("dp.change", function (e) {
                    $('#datetimepicker5').data("DateTimePicker").minDate(e.date);
            });
            $("#datetimepicker5").on("dp.change", function (e) {
                    $('#datetimepicker4').data("DateTimePicker").maxDate(e.date);
            });

             var table = $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonMT',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                "lengthMenu": "Mostrar _MENU_ registros",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        });

        function actualizarDataTable(){

            $("#reporte_mt").dataTable().fnDestroy();
            cambioCampania();
        }

        function cambioCampania(){

            var table2 = $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getData',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

    </script>
    <!-- Fin DataTable Reporte MT Principal -->

    <!-- DataTable Reporte MT por campaña y fecha -->
    <script>
        function muestraCalendario(){
            $('#calendario').show();
            $('#shorcode').hide();
            $("input:text[name=muestra1]").val("ok");
            $("input:text[name=muestra2]").val("cambio");
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shorcode').hide();
            $("input:text[name=muestra2]").val("ok");
            $("input:text[name=muestra1]").val("cambio");
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shorcode').show();
            $("input:text[name=muestra2]").val("cambio");
            $("input:text[name=muestra1]").val("cambio");
        }

        function actualizarDataTableCampaniaFecha(){

            $("#reporte_mt").dataTable().fnDestroy();
            muestraInfo()
        }

        function muestraInfo(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMT',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

        <!-- Fin DataTable Reporte MT por campaña y fecha -->

        <!-- DataTable Reporte MT por fecha -->
        <script>

        function actualizarDataTableFecha(){

            $("#reporte_mt").dataTable().fnDestroy();
            muestraInfoDetalle()
        }

        function muestraInfoDetalle(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMTFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

        <!-- Fin DataTable Reporte MT por fecha -->

        <!-- DataTable Search Report MT -->
        <script>

        function actualizarDataTableSearchReportMT(){

            $("#reporte_mt").dataTable().fnDestroy();
            var muestra1 = $("input:text[name=muestra1]").val();
            var muestra2 = $("input:text[name=muestra2]").val();
            //var c = $("input:text[name=fechas]").val();
            if(muestra1 == "ok"){
                cambioDataTableSearchReportMTFechas()
            } else if(muestra2 == "ok"){
                cambioDataTableSearchReportMTFechasAll()
            } else {
                cambioDataTableSearchReportMT()
            }

        }

        function cambioDataTableSearchReportMT(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/searchDateReportMT',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker4]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker5]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val(),
                                                 id_camp: $("#id_campania option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        function cambioDataTableSearchReportMTFechas(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/searchDateReportMTCamFechas',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val(),
                                                 id_camp: $("#id_campania_1 option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }


        function cambioDataTableSearchReportMTFechasAll(){

            $("#reporte_mt").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/searchDateReportMTFechas',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val(),
                                                 carrier: $("input:text[name=carrier]").val(),
                                                 destination: $("input:text[name=destination]").val(),
                                                 source: $("input:text[name=source]").val(),
                                                 estatus: $("select[name=estatus]").val()
                                                 //id_camp: $("#id_campania_1 option:selected").val()
                                        }
                                    },
                            "columns": [
                                { "data": "FECHA" },
                                { "data": "CARRIER" },
                                { "data": "DESTINATION" },
                                { "data": "SHORTCODE" },
                                { "data": "CONTENT" },
                                { "data": "ESTATUSSMS" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Search Report MT -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#mtdetalle").validate({
                    rules: {
                        campania: {
                            required: true
                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;
        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaign($id_custom);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name_campaign']." -- ".$value['short_code']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mt");
    }

    public function datosJsonMT(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $search = MasterDom::getData('search');

        $value = MasterDom::getData('value');

        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaign($id_custom);
        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        $recordsTotalFiltered = count(ReportesDao::reportMT($id_custom, $result));

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCop($id_custom, $result, $start, $length));

        echo json_encode($prueba);
    }

    public function searchDateReportMT(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);


            if (empty($id_campania)) {

                $row = ReportesDao::getAllCampaign($id_custom);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }

                if(empty($result)){
                    $result = 0;
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMT($result, $destination));

                    $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::getTotalSearchReporteMTCop($result, $destination, $start, $length));

                    echo json_encode($prueba);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierTotal($result, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCopCarrier($result, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopEstatusTotal($result, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTEstatus($result, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceTotal($result, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSource($result, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceEstatusTotal($result, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceEstatus($result, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierEstatusTotal($result, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierEstatus($result, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceTotal($result, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSource($result, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotal($result, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceEstatus($result, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationEstatusTotal($result, $destination, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationEstatus($result, $destination, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceTotal($result, $destination, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSource($result, $destination, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotal($result, $destination, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceEstatus($result, $destination, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierTotal($result, $destination, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrier($result, $destination, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotal($result, $destination, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierEstatus($result, $destination, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotal($result, $destination, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierSource($result, $destination, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopAllTotal($result, $destination, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTAll($result, $destination, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios sobre la campania actual
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(ReportesDao::reportMT($id_custom, $result));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCop($id_custom, $result, $start, $length));

                    echo json_encode($resultado);
                }



            }else/*if (!empty($id_campania))*/ {

                if(!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination

                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMT($id_campania, $destination));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCop($id_campania, $destination, $start, $length));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierTotal($id_campania, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCopCarrier($id_campania, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopEstatusTotal($id_campania, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTEstatus($id_campania, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceTotal($id_campania, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSource($id_campania, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceEstatusTotal($id_campania, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceEstatus($id_campania, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierEstatusTotal($id_campania, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierEstatus($id_campania, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceTotal($id_campania, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSource($id_campania, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotal($id_campania, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceEstatus($id_campania, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationEstatusTotal($id_campania, $destination, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationEstatus($id_campania, $destination, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceTotal($id_campania, $destination, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSource($id_campania, $destination, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotal($id_campania, $destination, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceEstatus($id_campania, $destination, $source, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierTotal($id_campania, $destination, $carrier));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrier($id_campania, $destination, $carrier, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotal($id_campania, $destination, $carrier, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierEstatus($id_campania, $destination, $carrier, $estatus, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotal($id_campania, $destination, $carrier, $source));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierSource($id_campania, $destination, $carrier, $source, $start, $length));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus

                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopAllTotal($id_campania, $destination, $carrier, $source, $estatus));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTAll($id_campania, $destination, $carrier, $source, $estatus, $start, $length));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(ReportesDao::reportMT($id_custom, $id_campania));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCop($id_custom, $id_campania, $start, $length));

                    echo json_encode($resultado);
                }

            }
        }

    }

    public function searchDateReportMTCamFechas(){

        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_custom = MasterDom::getSession('customer_id');
            $carrier = MasterDom::getData('carrier');
            $destination = MasterDom::getData('destination');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');
            $id_campania = MasterDom::getData('id_camp');

            $fecha_ini = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);


            if (empty($id_campania)) {

                $row = ReportesDao::getAllCampaign($id_custom);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }

                if(empty($result)){
                    $result = 0;
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCFechas($result, $destination, $fecha_ini, $fecha_fin));

                    $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::getTotalSearchReporteMTCopCFechas($result, $destination, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($prueba);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierTotalCFechas($result, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCopCarrierCFechas($result, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopEstatusTotalCFechas($result, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTEstatusCFechas($result, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceTotalCFechas($result, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceCFechas($result, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceEstatusTotalCFechas($result, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceEstatusCFechas($result, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierEstatusTotalCFechas($result, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierEstatusCFechas($result, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceTotalCFechas($result, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceCFechas($result, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotalCFechas($result, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceEstatusCFechas($result, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationEstatusTotalCFechas($result, $destination, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationEstatusCFechas($result, $destination, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceTotalCFechas($result, $destination, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceCFechas($result, $destination, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotalCFechas($result, $destination, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceEstatusCFechas($result, $destination, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierTotalCFechas($result, $destination, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierCFechas($result, $destination, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotalCFechas($result, $destination, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierEstatusCFechas($result, $destination, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotalCFechas($result, $destination, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierSourceCFechas($result, $destination, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus sobre la campania actual
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopAllTotalCFechas($result, $destination, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTAllCFechas($result, $destination, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios sobre la campania actual
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(ReportesDao::reportMTCFechas($id_custom, $result, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCopCFechas($id_custom, $result, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }



            }else/*if (!empty($id_campania))*/ {

                if(!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination

                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCFechas($id_campania, $destination, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCopCFechas($id_campania, $destination, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierTotalCFechas($id_campania, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCopCarrierCFechas($id_campania, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopEstatusTotalCFechas($id_campania, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTEstatusCFechas($id_campania, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceTotalCFechas($id_campania, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceCFechas($id_campania, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopSourceEstatusTotalCFechas($id_campania, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTSourceEstatusCFechas($id_campania, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierEstatusTotalCFechas($id_campania, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierEstatusCFechas($id_campania, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceTotalCFechas($id_campania, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceCFechas($id_campania, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopCarrierSourceEstatusTotalCFechas($id_campania, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTCarrierSourceEstatusCFechas($id_campania, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationEstatusTotalCFechas($id_campania, $destination, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationEstatusCFechas($id_campania, $destination, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceTotalCFechas($id_campania, $destination, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceCFechas($id_campania, $destination, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationSourceEstatusTotalCFechas($id_campania, $destination, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationSourceEstatusCFechas($id_campania, $destination, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierTotalCFechas($id_campania, $destination, $carrier, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierCFechas($id_campania, $destination, $carrier, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierEstatusTotalCFechas($id_campania, $destination, $carrier, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierEstatusCFechas($id_campania, $destination, $carrier, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopDestinationCarrierSourceTotalCFechas($id_campania, $destination, $carrier, $source, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTDestinationCarrierSourceCFechas($id_campania, $destination, $carrier, $source, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Carrier & Source & Estatus

                    $recordsTotalFiltered = count(ReportesDao::getTotalSearchReporteMTCopAllTotalCFechas($id_campania, $destination, $carrier, $source, $estatus, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::getTotalSearchReporteMTAllCFechas($id_campania, $destination, $carrier, $source, $estatus, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);

                }
                elseif (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                    $id_custom = MasterDom::getSession('customer_id');

                    $recordsTotalFiltered = count(ReportesDao::reportMTCFechas($id_custom, $id_campania, $fecha_ini, $fecha_fin));

                    $resultado = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCopCFechas($id_custom, $id_campania, $start, $length, $fecha_ini, $fecha_fin));

                    echo json_encode($resultado);
                }

            }
        }

    }


    public function reporte_mt(){

        # Reporte Excel
        // print_r($_POST);
        // exit;
        $cam1 = MasterDom::getData('muestra1');
        $cam2 = MasterDom::getData('muestra2');
        if ($cam1 == "cambiar" && $cam2 == "cambiar") {
            $id_campania = MasterDom::getData("reporte");
            $id_customer = MasterDom::getSession('customer_id');
            $destination = MasterDom::getData('destination');
            $carrier = MasterDom::getData('carrier');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');



            /*echo "<br>id:$id_campania<br>";
            echo "<br>destination:$destination<br>";
            echo "<br>carrier:$carrier<br>";
            echo "<br>source:$source<br>";
            echo "<br>estatus:$estatus<br>";
            echo "<br>customer:$id_customer<br>";

            exit;*/



            if (empty($id_campania)){
                /*$mensajes = ReportesDao::reportMT($id_customer, $result);
                $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                ReportesDao::registroUsuario($registro);*/
                $row = ReportesDao::getAllCampaign($id_customer);
                foreach ($row as $key => $value) {
                    if ($value === end($row)) {
                        $result = $value['campaign_id'];
                    }
                }
                if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos los parametros vacios
                    $mensajes = ReportesDao::reportMTE($id_customer, $result);
                    //print_r($mensajes);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTEEstatus($id_customer, $result, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source excel campania actual
                    $mensajes = ReportesDao::reportMTESource($id_customer, $result, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTESourceEstatus($id_customer, $result, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier excel campania actual
                    $mensajes = ReportesDao::reportMTECarrier($id_customer, $result, $carrier);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTECarrierEstatus($id_customer, $result, $carrier, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source excel campania actual
                    $mensajes = ReportesDao::reportMTECarrierSource($id_customer, $result, $carrier, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTECarrierSourceEstatus($id_customer, $result, $carrier, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination excel campania actual
                    $mensajes = ReportesDao::reportMTEDestination($id_customer, $result, $destination);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationEstatus($id_customer, $result, $destination, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationSource($id_customer, $result, $destination, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationSourceEstatus($id_customer, $result, $destination, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationCarrier($id_customer, $result, $destination, $carrier);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationCarrierEstatus($id_customer, $result, $destination, $carrier, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source excel campania actual
                    $mensajes = ReportesDao::reportMTEDestinationCarrierSource($id_customer, $result, $destination, $carrier, $source);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }
                elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Todos los campos/excel campania actual
                    $mensajes = ReportesDao::reportMTEAllSources($id_customer, $result, $destination, $carrier, $source, $estatus);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$result}");
                    ReportesDao::registroUsuario($registro);
                }

            }else{

                    /*$mensajes = ReportesDao::reportMTE($id_customer, $id_campania);
                    $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                    ReportesDao::registroUsuario($registro);*/
                    if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos los parametros vacios
                        $mensajes = ReportesDao::reportMTE($id_customer, $id_campania);
                        //print_r($mensajes);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTEEstatus($id_customer, $id_campania, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source excel campania actual
                        $mensajes = ReportesDao::reportMTESource($id_customer, $id_campania, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTESourceEstatus($id_customer, $id_campania, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier excel campania actual
                        $mensajes = ReportesDao::reportMTECarrier($id_customer, $id_campania, $carrier);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTECarrierEstatus($id_customer, $id_campania, $carrier, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source excel campania actual
                        $mensajes = ReportesDao::reportMTECarrierSource($id_customer, $id_campania, $carrier, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTECarrierSourceEstatus($id_customer, $id_campania, $carrier, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination excel campania actual
                        $mensajes = ReportesDao::reportMTEDestination($id_customer, $id_campania, $destination);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationEstatus($id_customer, $id_campania, $destination, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationSource($id_customer, $id_campania, $destination, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationSourceEstatus($id_customer, $id_campania, $destination, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationCarrier($id_customer, $id_campania, $destination, $carrier);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationCarrierEstatus($id_customer, $id_campania, $destination, $carrier, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source excel campania actual
                        $mensajes = ReportesDao::reportMTEDestinationCarrierSource($id_customer, $id_campania, $destination, $carrier, $source);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }
                    elseif (!empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Todos los campos/excel campania actual
                        $mensajes = ReportesDao::reportMTEAllSources($id_customer, $id_campania, $destination, $carrier, $source, $estatus);
                        $registro = $this->registroUsuario("Descargo reporte mt campania {$id_campania}");
                        ReportesDao::registroUsuario($registro);
                    }

                }
                //print_r($mensajes);
                //exit();
            $method='creaExcel';
            $titulo = 'Reporte';
            $nombre = 'Airmovil';
            $array = $mensajes;
            $columna = 7;
            // echo "no entro al metodo descarga\n";
            header("Content-Type: application/
                vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
            // header("Content-type: application/vnd.ms-excel");
            header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
            header("Content-type:   application/x-msexcel; charset=utf-8");
            header("Content-Disposition: attachment;filename=Mensajes_Enviados.xls");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Cache-Control: private",false);
            header("Cache-Control: max-age=0");
                    //echo "pase las cabeceras\n\n";
            header('Cache-Control: max-age=1');

            // If you're serving to IE over SSL, then the following may be needed
            header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
            header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header ('Pragma: public'); // HTTP/1.0

            header("Content-Transfer-Encoding: Binary");
            header("Pragma: no-cache");
            header("Expires: 0");

            ob_end_clean();
            ob_start();

            $html = "<table cellspacing='' cellpadding='' border = '1px' >
                         <tr>
                         <th  bgcolor = '#AAB7B8'>FECHA</th>
                         <th bgcolor = '#AAB7B8'>CARRIER</th>
                         <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                         <th bgcolor = '#AAB7B8'>DESTINATION</th>
                         <th bgcolor = '#AAB7B8'>SHORTCODE</th>
                         <th bgcolor = '#AAB7B8'>CONTENT</th>
                         <th bgcolor = '#AAB7B8'>ESTATUS SMS</th>
                         </tr>
                         " ;
            foreach ($mensajes as $key => $value) {
                $html .= "<tr>
                            <td>{$value['FECHA']}</td>
                            <td>{$value['CARRIER']}</td>
                            <td>".substr($value['DESTINATION'], 2, 10)."</td>
                            <td>{$value['SHORTCODE']}</td>
                            <td>{$value['CONTENT']}</td>
                            <td>{$value['ESTATUSSMS']}</td>
                        </tr>";
            }

            $html .= "
                    </table>";

            // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
             //echo "\npase el metodo descarga";
            //print_r($reportExcel);
            // print_r($html);
            echo $html;
             // exit;
        } // fin de if cambiar
        elseif ($cam1 == "ok") { // enviar a otra funcion de reportes campania y fechas
            self::reporte_mtDetalle();
        }
        elseif ($cam2 == "ok") { // envia a otra funcion de solo reportes por fechas
            self::reporte_mtDetalleFechas();
        }else{ // se sale de la funcion
            exit;
        }

       
    }


    public function mo(){
        MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

        <!-- DataTable Principal MO -->
        <script>

            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker1').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
                });

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });


                 var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonMO',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

            });

            function actualizarDataTableMO(){

                $("#reporte_mo").dataTable().fnDestroy();
                cambioCampaniaMO();
            }

            function cambioCampaniaMO(){

                var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonMO',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            }

        </script>
        <!-- Fin DataTable Principal MO -->
        <!-- DataTable Reporte MO por campaña y fecha -->
        <script>

        function muestraCalendario(){
            $('#calendario').show();
            $('#shorcode').hide();
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shorcode').hide();
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shorcode').show();
        }

        function actualizarDataTableCampaniaFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoMO()
        }

        function muestraInfoMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMO',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>
        <!-- Fin DataTable Reporte MO por campaña y fecha -->

        <!-- DataTable Reporte MO por fecha -->
        <script>

        function actualizarDataTableFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoDetalleMO()
        }


        function muestraInfoDetalleMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMOFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });


        }

        </script>

    <!-- Fin DataTable Reporte MO por fecha -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#modetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

            });
    });
    </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaignMO($id_custom);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name']." -- ".$value['short_code']."</option>";
            //$select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mo");
    }


    public function mogeneral(){
        MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

        <!-- DataTable Principal MO -->
        <script>

            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker1').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
                });

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });


                 var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonMO',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

            });

            function actualizarDataTableMO(){

                $("#reporte_mo").dataTable().fnDestroy();
                cambioCampaniaMO();
            }

            function cambioCampaniaMO(){

                var table = $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonMO',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            }

        </script>
        <!-- Fin DataTable Principal MO -->
        <!-- DataTable Reporte MO por campaña y fecha -->
        <script>

        function muestraCalendario(){
            $('#calendario').show();
            $('#shorcode').hide();
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shorcode').hide();
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shorcode').show();
        }

        function actualizarDataTableCampaniaFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoMO()
        }

        function muestraInfoMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMO',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>
        <!-- Fin DataTable Reporte MO por campaña y fecha -->

        <!-- DataTable Reporte MO por fecha -->
        <script>

        function actualizarDataTableFechaMO(){

            $("#reporte_mo").dataTable().fnDestroy();
            muestraInfoDetalleMO()
        }


        function muestraInfoDetalleMO(){

            $("#reporte_mo").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateMOFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });


        }

        </script>

    <!-- Fin DataTable Reporte MO por fecha -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#modetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

            });
    });
    </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaignMO($id_custom);
        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['campaign_id'].">".$value['name']." -- ".$value['short_code']."</option>";
            //$select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("reportes_mo");
    }

    public function datosJsonMO(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');
        $length = MasterDom::getData('length');
        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');
        $id_custom = MasterDom::getSession('customer_id');
        $id_campania = $_GET['id_camp'];
        
        if(empty($id_campania)){

            $recordsTotalFiltered = count(ReportesDao::reportMOTotal());

            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCopTotal($start, $length));
            print_r(json_encode($prueba));
            exit;

            //echo json_encode($prueba);
        } elseif(!empty($id_campania)){
            $recordsTotalFiltered = count(ReportesDao::reportMO($id_custom, $id_campania));
        
            $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCop($id_custom, $id_campania, $start, $length));
        
            print_r(json_encode($prueba));
            exit;
            //echo json_encode($prueba);
        }
    }


    public function reporte_mo(){

        # Reporte Excel

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('reporte');
        $datos->_id_customer = MasterDom::getSession('customer_id');

        $row = ReportesDao::getAllCampaignMO($datos->_id_customer);
        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        if ($datos->_id_campaign == 0){
            $mensajes = ReportesDao::reportMO($datos->_id_customer, $result);
            $registro = $this->registroUsuario("Descargo reporte mo campania {$result}");
            ReportesDao::registroUsuario($registro);
        }else{
                $mensajes = ReportesDao::reportMOExcel($datos->_id_campaign,$datos->_id_customer);
                $registro = $this->registroUsuario("Descargo reporte mo campania {$datos->_id_campaign}");
                ReportesDao::registroUsuario($registro);
        }

        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_moDetalle(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker1');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = ReportesDao::reportMOExcelDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle campania {$datos->_id_campaign}");
        ReportesDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


        public function reporte_moDetalleFechas(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = ReportesDao::reportMOExcelDetalleFechaCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle por fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
        ReportesDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Entrantes.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function getData(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('id_camp');

        $id_customer = MasterDom::getSession('customer_id');

        $row = ReportesDao::getAllCampaign($id_customer);

        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if($id_campania !=0){

            $recordsTotalFiltered = count(ReportesDao::getData($id_campania));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCop( $id_customer,$id_campania, $start, $length));
            echo json_encode($mensajes);

        }else{

            $recordsTotalFiltered = count(ReportesDao::reportMT($id_customer, $result));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMTCop($id_customer, $result, $start, $length));
            echo json_encode($mensajes);

        }

    }

    public function getDataMO(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('reporte');
        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllCampaignMO($id_custom);

        foreach ($row as $key => $value) {
            if ($value === end($row)) {
                $result = $value['campaign_id'];
            }
        }

        if(empty($result)){
            $result = 0;
        }

        if (!empty($id_campania)) {

            $recordsTotalFiltered = count(ReportesDao::reportMO($id_custom,$id_campania));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCop($id_custom, $id_campania, $start, $length));
            print_r(json_encode($mensajes));
            exit();
            //echo json_encode($mensajes);

        }/*else{

            $recordsTotalFiltered = count(ReportesDao::reportMO($id_custom, $result));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportMOCop($id_custom, $result, $start, $length));
            echo json_encode($mensajes);

        }*/

    }


    public function services(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

         <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker1').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker").on("dp.change", function (e) {
                        $('#datetimepicker1').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker1").on("dp.change", function (e) {
                        $('#datetimepicker').data("DateTimePicker").maxDate(e.date);
                });

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });


                var table = $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonService',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

            });

            function actualizarDataTableService(){

                $("#reporte_servicio").dataTable().fnDestroy();
                cambioCampaniaService();
            }

            function cambioCampaniaService(){

                var table = $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataServicesMO',
                                        "dataType":'json',
                                        "data": {id_camp: $("#id_campania option:selected").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            }


        </script>

         <!-- Fin DataTable Reporte Principal Services -->

        <!-- DataTable Reporte Services por campaña y fecha -->

        <script>

        function muestraCalendario(){
            $('#calendario').show();
            $('#shortcode').hide();
        }

        function muestraCalendario2(){
            $('#calendario2').show();
            $('#shortcode').hide();
        }

        function ocultaInfo(){
            $('#calendario').hide();
            $('#calendario2').hide();
            $('#shortcode').show();
        }

        function actualizarDataTableCampaniaFechaServices(){

            $("#reporte_servicio").dataTable().fnDestroy();
            muestraInfoCampFechaServices()
        }


        function muestraInfoCampFechaServices(){

            $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateService',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker1]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

        }

        </script>

        <!-- Fin DataTable Reporte Services por campaña y fecha -->

        <!-- DataTable Reporte Services por fecha -->

        <script>

        function actualizarDataTableFechaServices(){

            $("#reporte_servicio").dataTable().fnDestroy();
            muestraInfoFechaServices()
        }


        function muestraInfoFechaServices(){

            $("#reporte_servicio").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataDateServiceFecha',
                                        "dataType":'json',
                                        "data": {campania: $("#id_campania_1 option:selected").val(),
                                                 fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "entry_time"},
                                { "data": "source"},
                                { "data": "destination" },
                                { "data": "direction"},
                                { "data": "content" },
                                { "data": "status" },
                                { "data": "keyword" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });

        }

        </script>

    <!-- Fin DataTable Reporte Services por fecha -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        $id_custom = MasterDom::getSession('customer_id');
        $row = ReportesDao::getAllServiceMO($id_custom);

        $select = "";
        foreach ($row as $key => $value) {
            $select .= "<option value=".$value['service_id'].">".$value['title']."</option>";
        }

        View::set('select',$select);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("services");
    }

    public function datosJsonService(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_custom = MasterDom::getSession('customer_id');

        $recordsTotalFiltered =ReportesDao::reportService($id);

        if(empty($recordsTotalFiltered)){
            $recordsTotalFiltered = 0;
        }else{
            $recordsTotalFiltered = count($recordsTotalFiltered);
        }

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::reportServiceCop($id, $start, $length));

        echo json_encode($prueba);
    }

    public function reporte_servicio(){

        # Reporte Excel


        if (MasterDom::getData('reporte') == 0){
            $mensajes = ReportesDao::reportService();
            $registro = $this->registroUsuario("Descargo reporte services");
            ReportesDao::registroUsuario($registro);
        }   else {

                $datos = new \stdClass();

                $datos->_id_service = MasterDom::getData('reporte');
                $datos->_id_customer = MasterDom::getSession('customer_id');

                // print_r($datos);

                $mensajes = ReportesDao::reportServiceExcel($datos);
                $registro = $this->registroUsuario("Descargo reporte service {$datos->_id_service}");
                ReportesDao::registroUsuario($registro);
            }
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>".substr($value['destination'], 0, 10)."</td>
                        <td>".substr($value['direction'], 0, 10)."</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_serviceDetalleFechas(){

        # Reporte Excel


       $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);


        $datos = new \stdClass();

        // $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

                // print_r($datos);

                $mensajes = ReportesDao::reportServiceExcelDetalleFechasCount($datos);
                $registro = $this->registroUsuario("Descargo reporte service fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
                ReportesDao::registroUsuario($registro);

        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');


        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>".substr($value['destination'], 0, 10)."</td>
                        <td>".substr($value['direction'], 0, 10)."</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_mtDetalle(){
      // print_r($_POST);
      // exit;


        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker1');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        $datos->_id_campaign = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = ReportesDao::reportMTDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mo detalle {$datos->_id_campaign}");
        ReportesDao::registroUsuario($registro);
        //print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Enviados.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>CARRIER</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['FECHA']}</td>
                        <td>".$value['CARRIER']."</td>
                        <td>".substr($value['DESTINATION'], 0, 10)."</td>
                        <td>{$value['SHORTCODE']}</td>
                        <td>{$value['CONTENT']}</td>
                        <td>{$value['ESTATUSSMS']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


        public function reporte_mtDetalleFechas(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();

        // $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        $mensajes = ReportesDao::reportMTDetalleFechaCount($datos);
        $registro = $this->registroUsuario("Descargo reporte mt fecha_ini:{$fecha_inicio} fecha_fin:{$fecha_fin}");
        ReportesDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Mensajes_Enviados.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>CARRIER</th>
                     <!--<th bgcolor = '#AAB7B8'>DIRECTION</th>-->
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['FECHA']}</td>
                        <td>".$value['CARRIER']."</td>
                        <td>".substr($value['DESTINATION'], 0, 10)."</td>
                        <td>{$value['SHORTCODE']}</td>
                        <td>{$value['CONTENT']}</td>
                        <td>{$value['ESTATUSSMS']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function reporte_serviceDetalle(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker');
        $fin = MasterDom::getData('datetimepicker1');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);


        $datos = new \stdClass();

        $datos->_id_service = MasterDom::getData('campania');
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        // print_r($datos);

        $mensajes = ReportesDao::reportServiceExcelDetalleCount($datos);
        $registro = $this->registroUsuario("Descargo reporte service detalle {$datos}");
        ReportesDao::registroUsuario($registro);
        // print_r($mensajes); exit;
        // $method='creaExcel';
        // $titulo = 'Reporte';
        // $nombre = 'Airmovil';
        // $array = $mensajes;
        // $columna = 7;
        // echo "no entro al metodo descarga\n";
        header("Content-Type: application/
            vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        // header("Content-type: application/vnd.ms-excel");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Servicios_Detalle.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
                //echo "pase las cabeceras\n\n";
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        // header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        // header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>FECHA</th>
                     <th bgcolor = '#AAB7B8'>SOURCE</th>
                     <th bgcolor = '#AAB7B8'>DESTINATION</th>
                     <th bgcolor = '#AAB7B8'>CONTENT</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     <th bgcolor = '#AAB7B8'>KEYWORD</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['entry_time']}</td>
                        <td>".$value['source']."</td>
                        <td>{$value['destination']}</td>
                        <td>{$value['content']}</td>
                        <td>{$value['status']}</td>
                        <td>{$value['keyword']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }


    public function getDataServicesMO(){
        MasterDom::verificaUsuario();

        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_campania = MasterDom::getData('id_camp');
        $id_custom = MasterDom::getSession('customer_id');

        $mensajes = ReportesDao::getDataService($id_campania, $id_custom);

        $recordsTotalFiltered = count(ReportesDao::getDataService($id_campania, $id_custom));
        $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::getDataServiceCop($id_campania, $id_custom, $start, $length));
        echo json_encode($mensajes);

    }


    public function getDataDateMO(){

        # Funcion que actulaiza los campos del reporte MO por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $id = MasterDom::getData('campania');
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_campaign = $id;
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportMOExcelDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::reportMOExcelDetalle($consulta,$start,$length));
            echo json_encode($mensajes);

        }
    }


    public function getDataDateMOFecha(){

        # Funcion que actualiza los campos del reporte MO por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];

            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportMOExcelDetalleFechaCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMOExcelDetalleFecha($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }


    public function getDataDateMT(){

        # Funcion que actualiza los campos del reporte Mt por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];

            $id = MasterDom::getData('campania');
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_campaign = $id;
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportMTDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>ReportesDao::reportMTDetalle($consulta,$start,$length));
            echo json_encode($mensajes);

        }
    }


        public function getDataDateMTFecha(){

        # Funcion que actualiza los campos del reporte Mt por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFecha($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }

####################################### BUSQUEDA POR FECHAS Y PARAMETROS MT ###################################

        public function searchDateReportMTFechas(){

        # Funcion que busca los campos del reporte Mt por fechas
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            $inicio = MasterDom::getData('fecha_ini');

            $fin = MasterDom::getData('fecha_fin');

            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;
            //print_r($consulta);
            $destination = MasterDom::getData('destination');
            $carrier = MasterDom::getData('carrier');
            $source = MasterDom::getData('source');
            $estatus = MasterDom::getData('estatus');

            if (empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Todos vacios
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCount($consulta));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFecha($consulta, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountEstatus($consulta, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaEstatus($consulta, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Source
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountSource($consulta, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaSource($consulta, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Source & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountSourceEstatus($consulta, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaSourceEstatus($consulta, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Carrier
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountCarrier($consulta, $carrier));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaCarrier($consulta, $carrier, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Carrier & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountCarrierEstatus($consulta, $carrier, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaCarrierEstatus($consulta, $carrier, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Carrier & Source
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountCarrierSource($consulta, $carrier, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaCarrierSource($consulta, $carrier, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (empty($destination) && !empty($carrier) && !empty($source) && !empty($estatus)) { # Carrier & Source & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountCarrierSourceEstatus($consulta, $carrier, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaCarrierSourceEstatus($consulta, $carrier, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && empty($source) && empty($estatus)) { # Destination
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestination($consulta, $destination));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestination($consulta, $destination, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationEstatus($consulta, $destination, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationEstatus($consulta, $destination, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Source
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationSource($consulta, $destination, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationSource($consulta, $destination, $source, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && empty($carrier) && !empty($source) && !empty($estatus)) { # Destination & Source & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationSourceEstatus($consulta, $destination, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationSourceEstatus($consulta, $destination, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && empty($source) && empty($estatus)) { # Destination & Carrier
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationCarrier($consulta, $destination, $carrier));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationCarrier($consulta, $destination, $carrier, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && empty($source) && !empty($estatus)) { # Destination & Carrier & Estatus
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationCarrierEstatus($consulta, $destination, $carrier, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationCarrierEstatus($consulta, $destination, $carrier, $estatus, $start, $length));

                echo json_encode($mensajes);
            }
            elseif (!empty($destination) && !empty($carrier) && !empty($source) && empty($estatus)) { # Destination & Carrier & Source
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountDestinationCarrierSource($consulta, $destination, $carrier, $source));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaDestinationCarrierSource($consulta, $destination, $carrier, $source, $start, $length));

                echo json_encode($mensajes);
            }
            else { # Destination & Carrier & Source & Estatus All
                $recordsTotalFiltered = count(ReportesDao::reportMTDetalleFechaCountAllSources($consulta, $destination, $carrier, $source, $estatus));
                $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportMTDetalleFechaAllSources($consulta, $destination, $carrier, $source, $estatus, $start, $length));

                echo json_encode($mensajes);
            }

        }
    }

####################################### FIN BUSQUEDA POR FECHAS Y PARAMETROS MT ###############################


        public function getDataDateService(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            //$id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $id = MasterDom::getData('campania');
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_id_service = $id;
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportServiceExcelDetalleCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportServiceExcelDetalle($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }


        public function getDataDateServiceFecha(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFecha($inicio);
            $fecha_fin = $this->formatoFechaFin($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            $recordsTotalFiltered = count(ReportesDao::reportServiceExcelDetalleFechasCount($consulta));
            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered, "data"=>$mensajes = ReportesDao::reportServiceExcelDetalleFechas($consulta, $start, $length));
            echo json_encode($mensajes);

        }
    }

    public function smspush(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

         <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });

             var table = $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonCampania',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            });
        </script>

        <!-- DataTable Reporte Campanias por fecha -->
        <script>

        function actualizarDataTableFechaCampanias(){

            $("#reporte_campania").dataTable().fnDestroy();
            muestraInfoDetalleCampania()
        }


        function muestraInfoDetalleCampania(){

            $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataCampaniasFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Reporte Campanias por fecha -->

    <script src="/js/magicsuggest-min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script> -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("smspush");
    }


    public function campaniasall(){
       MasterDom::verificaUsuario();

        $extraHeader = <<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <!-- DateTimePicker CSS -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

         <!-- DataTable Reporte Principal Services -->

        <script>
            $(document).ready(function() {

                var anio = (new Date).getFullYear();

                $('#datetimepicker2').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });
                $('#datetimepicker3').datetimepicker({
                        format: 'DD/MM/YYYY',
                        minDate: "01/01/" + anio,
                        //maxDate: moment(),
                        daysOfWeekDisabled: [0, 6]
                });

                $("#datetimepicker2").on("dp.change", function (e) {
                        $('#datetimepicker3').data("DateTimePicker").minDate(e.date);
                });
                $("#datetimepicker3").on("dp.change", function (e) {
                        $('#datetimepicker2').data("DateTimePicker").maxDate(e.date);
                });

             var table = $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/datosJsonCampania',
                                        "dataType":'json'
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing":     "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
            });
        </script>

        <!-- DataTable Reporte Campanias por fecha -->
        <script>

        function actualizarDataTableFechaCampanias(){

            $("#reporte_campania").dataTable().fnDestroy();
            muestraInfoDetalleCampania()
        }


        function muestraInfoDetalleCampania(){

            $("#reporte_campania").DataTable({
                            "processing": true,
                            "serverSide": true,
                            "bLengthChange": false,
                            "searching": false,
                            "ordering": false,
                            "iDisplayLength": 20,
                            "ajax": {
                                        "url": '/Reportes/getDataCampaniasFecha',
                                        "dataType":'json',
                                        "data": {fecha_ini: $("input:text[name=datetimepicker2]").val(),
                                                 fecha_fin: $("input:text[name=datetimepicker3]").val()}
                                    },
                            "columns": [
                                { "data": "campania" },
                                { "data": "created" },
                                { "data": "delivery_date" },
                                { "data": "estatus" }
                            ],
                            "language": {
                                "emptyTable": "No hay datos disponibles",
                                "infoEmpty": "Mostrando 0 a 0 de 0 entradas",
                                "info": "Mostrar _START_ a _END_ de _TOTAL_ entradas",
                                "infoFiltered":   "(Filtrado de _MAX_ total de entradas)",
                                "lengthMenu": "Mostrar _MENU_ entradas",
                                "zeroRecords":  "No se encontraron resultados",
                                "search": "Buscar:",
                                "processing": "Procesando...",
                                "paginate" : {
                                    "next": "Siguiente",
                                    "previous" : "Anterior"
                                }
                            }
                         });
        }

        </script>

    <!-- Fin DataTable Reporte Campanias por fecha -->

    <script src="/js/magicsuggest-min.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <!-- <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script> -->

    <!-- Boton Descargar -->
    <script>
    $(document).ready(function(){

        $("#servicedetalle").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

    <!-- Boton consultar -->
    <script>
    $(document).ready(function(){

        $("#Consultar").validate({
                    rules: {
                        campania: {
                            required: true

                        },
                        datetimepicker: {
                            required: true
                        },
                        datetimepicker1: {
                            required: true
                        }
                    },
                    messages: {
                        campania: {
                            required: "Seleccione una campaña"
                        },
                        datetimepicker: {
                            required: "Seleccione una fecha"
                        },
                        datetimepicker1: {
                            required: "Seleccione una fecha"
                        }
                    }

        });
    });
    </script>

html;

        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("campaniasall");
    }

    public function datosJsonCampania(){
        header("Content-type: application/json; charset=utf-8");

        $start = MasterDom::getData('start');

        $length = MasterDom::getData('length');

        $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

        $id_custom = MasterDom::getSession('customer_id');

        if (empty(ReportesDao::getAllCampaniaByCustomer($id_custom))) {

            $recordsTotalFiltered = 0;
        } else{

            $recordsTotalFiltered = count(ReportesDao::getAllCampaniaByCustomer($id_custom));
        }

        $prueba = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::getAllCampaniaByCustomerCop($id_custom, $start, $length));

        echo json_encode($prueba);
    }


    public function getDataCampaniasFecha(){
        MasterDom::verificaUsuario();

        if (empty($_GET)) {}
        else {

            header("Content-type: application/json; charset=utf-8");

            $start = MasterDom::getData('start');

            $length = MasterDom::getData('length');

            $draw = (MasterDom::getData('draw') == 1) ? 1 : MasterDom::getData('draw');

            // $id    = $_POST['campania'];
            //$inicio= $_POST['fecha_ini'];
            //$fin   = $_POST['fecha_fin'];
            $inicio = MasterDom::getData('fecha_ini');
            $fin = MasterDom::getData('fecha_fin');
            $id_customer = MasterDom::getSession('customer_id');

            $fecha_inicio = $this->formatoFechaReporte($inicio);
            $fecha_fin = $this->formatoFechaFinReporte($fin);

            $consulta = new \stdClass();
            $consulta->_fecha_ini = $fecha_inicio;
            $consulta->_fecha_fin = $fecha_fin;
            $consulta->_id_customer = $id_customer;

            if (empty(ReportesDao::getAllCampaniaByCustomerFechas($consulta))) {
                $recordsTotalFiltered = 0;
            }else {
                $recordsTotalFiltered = count(ReportesDao::getAllCampaniaByCustomerFechas($consulta));
            }

            $mensajes = array("draw"=>$draw, "recordsTotal"=>$recordsTotalFiltered, "recordsFiltered"=>$recordsTotalFiltered,"data"=>ReportesDao::getAllCampaniaByCustomerFechasCop($consulta, $start, $length));
                echo json_encode($mensajes);
        }
    }


        public function reporte_campaniasFecha(){

        # Reporte Excel
        $inicio = MasterDom::getData('datetimepicker2');
        $fin = MasterDom::getData('datetimepicker3');

        $fecha_inicio = $this->formatoFecha($inicio);
        $fecha_fin = $this->formatoFechaFin($fin);

        $datos = new \stdClass();
        $datos->_id_customer = MasterDom::getSession('customer_id');
        $datos->_fecha_ini = $fecha_inicio;
        $datos->_fecha_fin = $fecha_fin;

        if(empty(ReportesDao::getAllCampaniaByCustomerFechas($datos))){
            $mensajes = ReportesDao::getAllCampaniaByCustomer($datos->_id_customer = MasterDom::getSession('customer_id'));
            $registro = $this->registroUsuario("Descargo reporte campanias {$datos->_id_customer}");
            ReportesDao::registroUsuario($registro);
        }else{
            $mensajes = ReportesDao::getAllCampaniaByCustomerFechas($datos);
            $registro = $this->registroUsuario("Descargo reporte campanias detalle {$datos}");
            ReportesDao::registroUsuario($registro);
        }

        //print_r($mensajes);
        //exit();

        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8");
        header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
        header("Content-type:   application/x-msexcel; charset=utf-8");
        header("Content-Disposition: attachment;filename=Campanias_Detalle.xls");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Cache-Control: max-age=0");
        header('Cache-Control: max-age=1');
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        header("Content-Transfer-Encoding: Binary");
        header("Pragma: no-cache");
        header("Expires: 0");

        ob_end_clean();
        ob_start();

        $html = "<table cellspacing='' cellpadding='' border = '1px' >
                     <tr>
                     <th  bgcolor = '#AAB7B8'>CAMPA&Ntilde;A</th>
                     <th bgcolor = '#AAB7B8'>FECHA DE CREACI&Oacute;N</th>
                     <th bgcolor = '#AAB7B8'>FECHA DE ENV&Iacute;O</th>
                     <th bgcolor = '#AAB7B8'>ESTATUS</th>
                     </tr>
                     " ;
        foreach ($mensajes as $key => $value) {
            $html .= "<tr>
                        <td>{$value['campania']}</td>
                        <td>".$value['created']."</td>
                        <td>{$value['delivery_date']}</td>
                        <td>{$value['estatus']}</td>
                    </tr>";
        }

        $html .= "
                </table>";

        // $reportExcel = MasterDom::descargaExcelReport($method,$titulo,$nombre,$array,$columna);
         //echo "\npase el metodo descarga";
        //print_r($reportExcel);
        // print_r($html);
        echo $html;
         // exit;
    }

    public function formatoFecha($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia;//.' '.'00:00:00';
        // return $fecha.' '.'00:00:00';
    }
      public function formatoFechaFin($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia;//.' '.'23:59:59';
        // return $fecha.' '.'00:00:00';
    }

    public function formatoFechaReporte($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia.' '.'00:00:00';
        // return $fecha.' '.'00:00:00';
    }

    public function formatoFechaFinReporte($fecha_){

        list($fecha,$tiempo,$ampm) = explode(" ",$fecha_);

        $fecha_lista = str_replace('/', '-', $fecha);
        list($dia,$mes,$anio) = explode("-",$fecha_lista);

        $hora = '';
        $hora .= $tiempo.' '.$ampm;

        $time = strtotime($hora);
        $cadena = date("H:i", $time);

        return $anio.'-'.$mes.'-'.$dia.' '.'23:59:59';
        // return $fecha.' '.'00:00:00';
    }


    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

    public function json(){
        //phpinfo();
        $hola = array('mensaje' => 'Hola json');
        echo "Hi!";
        echo json_encode($hola);
    }

}
