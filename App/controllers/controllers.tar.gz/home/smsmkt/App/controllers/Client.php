<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Client as ClientDao;
use \App\controllers\Contenedor;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Client {

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader=<<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
        <!-- DataTables JavaScript -->
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {

            var table = $('#muestra-client').DataTable({
                "language": {
                                    "emptyTable": "No hay datos disponibles",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                    "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                    "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                    "lengthMenu": "Mostrar _MENU_ registros",
                                    "zeroRecords":  "No se encontraron resultados",
                                    "search": "Buscar:",
                                    "processing": "Procesando...",
                                    "paginate" : {
                                        "next": "Siguiente",
                                        "previous" : "Anterior"
                                    }
                                }
            });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                    bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                        if (result) 
                            $( "#delete_form" ).submit();
                    });
            });
        } );
        </script>
html;

    $row = ClientDao::getAllClients($id_custom);
    $html = '';
    foreach($row AS $key=>$value){

        $telcel = count(ClientDao::getMsisdnTelcel($value['client_id']));
        $movi = count(ClientDao::getMsisdnMovistar($value['client_id']));
        $att = count(ClientDao::getMsisdnAtt($value['client_id']));
        $proceso = count(ClientDao::getMsisdnProceso($value['client_id']));
        $total = count(ClientDao::getMsisdnBusca($value['client_id']));

        $value['status'] = ($value['status'])? 'Activo' : 'Inactivo';
        $html.= <<<html
        <tr>
            <td><input type="checkbox" name="borrar[]" value="{$value['client_id']}"/></td>
            <td><a class='btn btn-link' href='/client/show/{$value['client_id']}'>{$value['name']}</a></td>
            <td>{$value['status']}</td>
            <td>
                <table class="form-group">
                    <thead>
                        <tr>
                            <th>Telcel</th>
                            <th>Movistar</th>
                            <th>Att</th>
html;
        if (!empty($proceso)) {
        $html .=<<< html
                            <th>Procesando</th>
html;
        }
        $html .=<<<html
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{$telcel}</td>
                            <td>{$movi}</td>
                            <td>{$att}</td>
html;
if (!empty($proceso)) {
$html .=<<< html
                            <td>{$proceso}</td>
html;
}
$html .=<<<html
                            <th>{$total}</th>
                        </tr>
                    </tbody>
                </table>
            </td>
            <td class="text-center">
            <a href="/client/edit/{$value['client_id']}" type="button" class="btn btn-primary btn-circle center-block"><i class="fa fa-pencil-square-o"></i></a>
            <a href="/client/generarExcel/{$value['client_id']}" type="button" class="btn btn-success btn-circle center-block"><i class="fa fa-file-excel-o"></i></a>
            </td>
        </tr>
html;

    }   

    View::set('table',$html);
    View::set('header',$this->_contenedor->header($extraHeader));
    View::set('footer',$this->_contenedor->footer($extraFooter));
  	View::render("client");    
    }


    public function generarExcel($client_id){
        $row = ClientDao::getMsisdnBusca($client_id);
        $mensajes = array();

        foreach ($row as $key => $value) {
            switch($value['carrier_id']){
                case 1: 
                    $value['carrier_id'] = 'Telcel';
                    break;
                case 2:
                    $value['carrier_id'] = 'Movistar';
                    break;
                case 3:
                    $value['carrier_id'] = 'ATT';
                    break;
                default:
                    $value['carrier_id'] = 'Sin Carrier';
            }

            array_push($mensajes, array(0=>$value['msisdn'], 1=> $value['carrier_id']));
        }

        Client::crearExcel($mensajes);

    }

    public static function crearExcel($mensajes){
        $encabezado = array('MSISDN','CARRIER');
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L');
        $title = "Titulo Reporte";
        $name_sheet = "Reporte";
        $objPHPExcel = new \PHPExcel(); 
        $objPHPExcel->getProperties()
        ->setCreator("Cattivo")
        ->setLastModifiedBy("Cattivo")
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription("Reporte de los mensajes")
        ->setKeywords("Excel Office 2007 openxml php")
        ->setCategory("Pruebas de Excel");



        $num_cols = count($encabezado);   
        $fila = 1;

        foreach ($encabezado as $key => $value) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$key].$fila, $value);
        }

        $fila++;

        foreach ($mensajes as $key => $value) {
            for( $i = 0; $i < $num_cols; $i++) {
                $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue($abc[$i].$fila, $value[$i]);
            }
            $fila++;
        }


        $objPHPExcel->getActiveSheet()->setTitle('Reporte');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="pruebaReal.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }

    public function add(){
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');
        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#add").validate({
            rules: {
                nombre: {
                    required: true,
                    maxlength: 50,
                    minlength: 3
                },
                status:{
                    required:true
                }
            },
            messages: {
                nombre: "Este campo es obligatorio",
                status: "Esta campo es obligatorio"
            }
    });
});
</script>
html;
        View::set('customer_id',$id_custom);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("client_add");
    }

    public function add_client(){
        if (MasterDom::getData('nombre') == '')
            return $this->alertas('error general');

        $nombre = MasterDom::getData('nombre');
        $status = MasterDom::getData('status');
        $customer = MasterDom::getData('customer');

        $client = new \stdClass();
        $client->_nombre = $nombre;
        $client->_status = $status;
        $client->_customer_id = $customer;

        $addClient = ClientDao::insert($client);

        if ($addClient == '')
            return $this->alertas('error general');

        $addCustomerclient = ClientDao::insertClientCustomer($client,$addClient);

        if ($addCustomerclient == '')
            return $this->alertas('error general');

        if ($addClient != "" && $addCustomerclient != "") {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Agrego client");
            ClientDao::registroUsuario($registro);
            /***************************************************************/
        }
        //return $this->alertas('success_add'); 
        header("Location:/client/seleccionaCliente/$addClient");
            
    }

    public function edit($id){
        MasterDom::verificaUsuario();
        $id = (int)$id;

        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#edit").validate({
            rules: {
                nombre: {
                    required: true,
                    maxlength: 50,
                    minlength: 3
                },
                status:{
                    required:true,
                    range: [0,1]
                }
            },
            messages: {
                nombre: "Este campo es obligatorio",

                status: "Este campo es obligatorio"
            }
    });
});
</script>
html;

        $row = ClientDao::getById($id);

        View::set('name',$row['name']);
        View::set('status',$row['status']);
        View::set('client_id',$row['client_id']);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("client_edit");
    }

    public function edit_client(){
        MasterDom::verificaUsuario();

        $nombre = MasterDom::getData('nombre');
        $status = MasterDom::getData('status');
        $customer = MasterDom::getData('customer');

        $client = new \stdClass();
        $client->_nombre = $nombre;
        $client->_status = $status;
        $client->_customer_id = $customer;

        $editclient = ClientDao::update($client);

        if ($editclient === FALSE) 
            return $this->alertas('error_general');

        if ($editclient != "") {
            /**************************** Registro *************************/
            $registro = $this->registroUsuario("Edito client");
            ClientDao::registroUsuario($registro);
            /***************************************************************/
        }

        return $this->alertas('success_edit');
        
    }

    public function delete($id){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(ClientDao::delete($id) === false)
                return $this->alertas('error_borrar');

            if ($id != "") {
                /**************************** Registro *************************/
                $registro = $this->registroUsuario("Elimino client {$id}");
                ClientDao::registroUsuario($registro);
                /***************************************************************/
            }

        }

        return $this->alertas('success_delete');
        
    }

    public function show($id){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
<!-- DataTables CSS -->
    <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
<script src="/js/jquery.dataTables.min.js"></script>
<script src="/js/dataTables.bootstrap.min.js"></script>
<script src="/js/bootbox.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
// var table = $('<div id="muestra-client"></div>').DataTable({
//                 "order": [[4, 'desc']]          
//             });

    var table = $('#muestra-msisdn').DataTable();

    $("#checkAll").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });

    $(document).on("click", "#delete", function(e) {
            bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                if (result) 
                    $( "#delete_form" ).submit();
            });
    });
} );
</script>
html;
        $id = (int)$id;

        $row = ClientDao::getMsisdnBusca($id);
        $html = '';
    
        foreach($row AS $key=>$value){
            $carrier = $value['carrier_id'];
            if ($carrier== 1) {
                $carrier = "Telcel";
            }elseif ($carrier == 2) {
                $carrier = "Movistar";
            }elseif ($carrier == 3) {
                $carrier = "Att";
            }elseif ($carrier == -2) {
                $carrier = "Procesando";
            }elseif($carrier ==-1){
                $carrier = "Error";
            }else{
                $carrier = "Nuevo";
            }
        $html.="
            <tr>
                <td><input type='checkbox' name='borrar[]' value='{$value['msisdn_id']}'/></td>
                <td>".$value['msisdn']."</td>
                <td>".$carrier."</td>
                <td class='text-center'><a href='/client/edit_msisdn/{$value['msisdn_id']}' type='button' class='btn btn-primary btn-circle center-block'><i class='fa fa-pencil-square-o'></i></a></td>
            </tr>
";

        }   

        View::set('id_client',$id);
        View::set('table',$html);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("base"); 
    }

    public function add_msisdn($id){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#add").validate({
            rules: {
                msisdn: {
                    required: true,
                    maxlength: 10,
                    minlength: 10
                },
                carrier:{
                    required:true
                }
            },
            messages: {
                msisdn: "Este campo es obligatorio",
                carrier: "Este campo es obligatorio"
            }
    });
});
</script>
html;
        $id = (int)$id;

        $option_carrier ='';
        $carrier = ClientDao::getCarrier();
        foreach ($carrier as $key => $value) {
            $option_carrier .= "<option value='".$value['carrier_id']."'>".$value['name']."</option>";
        }

        View::set('id_client',$id);
        View::set('option_carrier',$option_carrier);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("msisdn_add"); 
    }

    public function msisdn_add(){
        MasterDom::verificaUsuario();

        if(!$_POST)
            return $this->alertas('error_general');

        $msisdn = new \stdClass();
        $msisdn->_msisdn = MasterDom::getData('msisdn');
        $msisdn->_carrier = MasterDom::getData('carrier');
        $msisdn->_client = MasterDom::getData('client');

        $addmsisdn = ClientDao::insert_msisdn($msisdn);

        if($addmsisdn == '')
            return $this->alertas('error_general');

        $add_client_msisdn = ClientDao::insertClientMsisdn($msisdn,$addmsisdn);

        if($add_client_msisdn == '')
            return $this->alertas('error_general');

        return $this->alertas('success_add');
    }

    public function edit_msisdn($id){
        MasterDom::verificaUsuario();

        $extraHeader=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<!-- Jquery Validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {
    $("#edit").validate({
            rules: {
                msisdn: {
                    required: true,
                    maxlength: 10,
                    minlength: 10
                },
                carrier:{
                    required:true
                }
            },
            messages: {
                msisdn: "Este campo es obligatorio",
                carrier: "Este campo es obligatorio"
            }
    });
});
</script>
html;
        $id = (int)$id;
        
        $msisdn = ClientDao::getById_Msisdn($id);
        $msisdn_id_ = $msisdn['msisdn_id'];
        $msisdn_ = substr($msisdn['msisdn'], -10);
        $carrier_id = $msisdn['carrier_id'];

        $option_carrier ='';
        $carrier = ClientDao::getCarrier();
        foreach ($carrier as $key => $value) {
            if ($value['carrier_id'] == $carrier_id)
               $option_carrier .= "<option value='".$value['carrier_id']."' selected>".$value['name']."</option>";
            else
                $option_carrier .= "<option value='".$value['carrier_id']."'>".$value['name']."</option>";
        }
        View::set('msisdn_id',$msisdn_id_);
        View::set('msisdn',$msisdn_);       
        View::set('option_carrier',$option_carrier);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("msisdn_edit"); 
    }

    public function msisdn_edit(){
        // print_r($_POST);
        if(!$_POST)
            return $this->alertas('error_general');

        $msisdn = new \stdClass();
        $msisdn->_msisdn = MasterDom::getData('msisdn');
        $msisdn->_carrier = MasterDom::getData('carrier');
        $msisdn->_msisdn_id = MasterDom::getData('msisdn_id');

        $update_msisdn = ClientDao::update_msisdn($msisdn);

        if ($update_msisdn === FALSE) 
            return $this->alertas('error_general');

        return $this->alertas('success_edit');
    }

    public function delete_msisdn(){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(ClientDao::delete_msisdn($id) === false)
                return $this->alertas('error_borrar');
        }

        return $this->alertas('success_delete');
    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borr&oacute; con exito las bases seleccionadas.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con éxito.';
            $class = 'success';
        }elseif($caso == 'success_process') {
            $mensaje = 'Proceso finalizado correctamente';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/client');
        View::set('class', $class);
        View::set('titulo','client');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    public function seleccionaCliente($id_cliente){

     $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>    
        $(document).ready(function() {
            $('.btn-success').on("click",function() {
                $( "#add" ).submit();
            });
        });
    </script>
html;

    $customer = MasterDom::getSession('customer_id');
    if(empty($customer))
        return MasterDom::alertas('error_general');

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Selecci&oacute;n de Contacto</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                <div class="x_content">
                    <p>Seleccione la opción deseada para definir los Contacto que se utilizaran en la realizaci&oacute;n del env&iacute;o.</p>
                    <div class="ln_solid"></div>
                        <form id="add" action="/client/seleccionaClientePost" enctype="multipart/form-data" method="POST">
                            <div class="form-group">
                                <div class="radio">
                                    <br >
                                    <input type="file" accept=".xls,.xlsx,.txt,.csv" name="file"/>
                                    <p class="help-block">Importar un archivo excel, te recomendamos usar la siguiente plantilla, los formatos validos son .xls, .xlsx</p>
                                    <p class="help-block"><a href='/plantillas/Plantilla.xlsx'><i class="fa fa-file-excel-o"></i> Descarga plantilla</a></p>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                                <input type="hidden" name='id_cliente' value="$id_cliente">
                            <div class="form-group">
                                <div class="col-md-12 col-sm-9 col-xs-12">
                                    <a href="#" class="btn btn-success pull-right">Siguiente</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
html;

    View::set('contenido',$html);
    View::set('footer',$this->_contenedor->footer($extraFooter));
    View::render("base_add");
    }

    public function seleccionaClientePost(){
        $id_cliente = MasterDom::getData('id_cliente');
        $file = $_FILES['file'];
        
        if(empty($file))
            return MasterDom::alertas('error_general');
            
        $filename = $file['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);

        if(strtolower($ext) ==  'xls' || strtolower($ext) == 'xlsx' || strtolower($ext) == 'csv' || strtolower($ext) == 'zip' || strtolower($ext) == 'txt')
            return $this->functionExcel($file, $ext, $id_cliente);
        else
            return MasterDom::alertas('error_general');
    }

    private function functionExcel($file, $ext, $id_cliente){

        $customer = MasterDom::getSession('customer_id');
        if(empty($customer))
            return MasterDom::alertas('error_general');

        $ext = strtolower($ext);
        $archivo = MasterDom::moverDirectorio($file, $customer, 'book');
    
        if($archivo === false)
            return MasterDom::alertas('error_general');

        if($ext ==  'xls' || $ext == 'xlsx'){   

            $excel = MasterDom::procesoExcel('getFilas', $archivo['nombre']);
            $excelArray = json_decode($excel, 1);

            print_r($excelArray);

            if(empty($excelArray))
                //return MasterDom::alertas('error_general');
                return MasterDom::alertas('personal','/client/seleccionaClientePost', 'Error', 'Se cancel&oacute; el proceso, el documento est&aacute; vac&iacute;o.');

            foreach($excelArray AS $key=>$value){
                if($value != '')
                    $array[$key] = $value;
            }
            $file_name = $archivo['nombre'];
        }

        elseif($ext == 'csv'){
            $arch = MasterDom::$_target.$archivo['nombre'];
            $acum = 1;
            if (($fichero = fopen($arch, "r")) !== FALSE) {
                while (($datos = fgetcsv($fichero)) !== FALSE) {
                    if($acum == 1){
                        $array = $datos;
                        print_r($array);
                        break;
                    }
                 $acum += 1;
                }
              fclose($fichero);
              $file_name = $archivo['nombre'];
            }else{
                return MasterDom::alertas('error_general');
            }
        }else{
            //return MasterDom::alertas('error_general');
            return MasterDom::alertas('personal','/client/', 'Error', 'Lo sentimos, ocurri&oacute; un error, el formato del archivo no es v&aacute;lido.');
        }


        //$baseGuardar = (MasterDom::getData('base_guardar') != '') ? MasterDom::getData('base_guardar') : '';
        //$baseNombre = (MasterDom::getData('base_nombre') != '') ? MasterDom::getData('base_nombre') : '';

        $opciones = '';
        foreach($array AS $key=>$value){
            $opciones.=<<<html
                <option value="$key" $selected >$value</option>
html;
        }   

    $operador = '';
        foreach($array AS $key=>$value){
        $select = ($value == 'operador') ? 'selected="selected"' : '';
            $operador.=<<<html
                <option value="$key" $select >$value</option>
html;
        }

    $html=<<<html
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Selecci&oacute;n columna "Numero de Celular"</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla deber&aacute; seleccionar la columna del excel que contiene los N&uacute;meros de Celulares a los cuales se les realizara el env&iacute;o...</p>
                    <div class="ln_solid"></div>
                    <form action="/client/guardaDatos" enctype="multipart/form-data" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione Columna Numero Celular : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_numero">
                                    $opciones
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Seleccione la columna correspondiente al operador de cada celular :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select class="form-control" name="columna_operador">
                                    $operador
                                </select>
                            </div>
                        </div>

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <button type="submit" class="btn btn-success pull-right">Siguiente</button>
                        </div>
                      </div>
                        <input type="hidden" name="ext" value="$ext" />
                        <input type="hidden" name="nombre_archivo" value="{$file_name}" />
                        <input type="hidden" name="customer_id" value="$customer" />
                        <input type='hidden' name='id_cliente' value="$id_cliente" />
                      </form>
                  </div>
                </div>
html;

        View::set('contenido',$html);
        View::render("submit_one_add");
    
    }

    public function guardaDatos(){
        $nombreArchivo = MasterDom::getData('nombre_archivo');
        $id_cliente = MasterDom::getData('id_cliente');
        $msisdnArray = json_decode(MasterDom::procesoExcel('completeArray', $nombreArchivo, true),1);

        $total_registros= count($msisdnArray) -1;
        $numeros_validos = 0;
        $numeros_invalidos = 0;
        $carrier_invalido = 0;
        $nBlackList = 0;

        foreach ($msisdnArray as $key => $value) {

            if($key == 1){
                continue;
            }

            if (preg_match('/TELCEL/i', $value['B'])) {
                $carrier = 1;
                    if ($value['A'] == '' || strlen($value['A']) != 10){
                        $numeros_invalidos ++;
                        continue;
                    } else { 
                        $numeros_validos ++; 
                    }

            } elseif (preg_match('/MOVI/i', $value['B'])) {
                $carrier = 2;
                    if ($value['A'] == '' || strlen($value['A']) != 10){
                        $numeros_invalidos ++;
                        continue;
                    } else { 
                        $numeros_validos ++; 
                    }

            }elseif (preg_match('/AT*/i', $value['B'])) {
                $carrier = 3;
                    if ($value['A'] == '' || strlen($value['A']) != 10){
                        $numeros_invalidos ++;
                        continue;
                    } else { 
                        $numeros_validos ++; 
                    }
            }elseif ($value['B'] == '') {
                $carrier_invalido ++;
                continue;
            } else {
                $carrier_invalido ++;
                continue;
            }

            $msisdn = '52'.$value['A'];

            if ($carrier == 1) 
                $blackList = ClientDao::isBlackListTelcel($msisdn);
            elseif ($carrier == 2)
                $blackList = ClientDao::isBlackListMovi($msisdn);
            elseif ($carrier == 3)
                $blackList = ClientDao::isBlackListATT($msisdn);
            else 
                return $this->alertas('error_general');


            if ($blackList != '') {
                $nBlackList ++;
                continue;
            }

            $addmsisdn = ClientDao::insert_msisdn_excel($value['A'],$carrier);

            if($addmsisdn === false){
                $data = ClientDao::busca_msisdn_carrier_bd($value['A'], $carrier);
                if ($data['msisdn_id'] != '')
                    $addmsisdn = $data['msisdn_id'];
                else
                   $addmsisdn = ClientDao::insert_msisdn_excel($value['A'],$carrier); 
            }

            if($addmsisdn == '')
                continue;

            $add_client_msisdn = ClientDao::insertClientMsisdn_excel($id_cliente,$addmsisdn);

            if($add_client_msisdn == '')
                return $this->alertas('error_general');
        }


        // echo 'Total de registros: '.$total_registros."\n";
        // echo 'Total de Registros validos: '.$numeros_validos."\n";

        $invalidos = $carrier_invalido + $numeros_invalidos;
        //echo 'total de Registros invalidos: '.$invalidos."\n";

        // echo 'numeros en blacklist: '.$nBlackList;
        //return $this->alertas('success_add');

        $html=<<<html
            <form action="/client/mensaje" method="POST">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de la importaci&oacute;n realizada <small>En esta pantalla usted podra ver en detalle los resultados de su importaci&oacute;n.</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripcion</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Total de Contactos :</td>
                          <td>$total_registros</td>
                        </tr>
                        <tr>
                          <td>Contactos correctos :</td>
                          <td>$numeros_validos</td>
                        </tr>
                        <tr>
                          <td>Contactos con operador erroneo :</td>
                          <td>$invalidos</td>
                        </tr>
                        <tr>
                          <td>Contactos en Lista Negra :</td>
                          <td>$nBlackList</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                          <input type="submit" class="btn btn-success pull-right" value="Finalizar Proceso">
                          </div>
                    </div>
                </div>
              </div>
        </form>
html;

        View::set('contenido',$html);
        View::render("detalle_client");
    }

    public function mensaje(){
        
        return $this->alertas('success_process');
    }

    function registroUsuario($accion){

        $id_usuario = $_SESSION['id_user'];
        $nickname = $_SESSION['usuario'];
        $customer = $_SESSION['name_customer'];
        $script = explode("/",$_SERVER["REQUEST_URI"]);
        $ip = $_SERVER['REMOTE_ADDR'];
        $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

        $registro = new \stdClass;
        $registro->_id_usuario = $id_usuario;
        $registro->_nickname = $nickname;
        $registro->_customer = $customer;
        $registro->_script = $script[1];
        $registro->_ip = $ip;
        $registro->_modulo = $modulo;
        $registro->_accion = $accion;
          
        return $registro;

    }

}