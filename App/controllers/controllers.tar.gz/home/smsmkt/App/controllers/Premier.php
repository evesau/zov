<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Dinamicweb as DinamicwebDao;
use \App\controllers\Contenedor;
use \App\controllers\ApiUrl;
require_once '/home/smsmkt/public/Classes/PHPExcel.php';

class Premier {

private $_contenedor;

    function __construct() { 
	$this->_contenedor = new Contenedor;
	View::set('header',$this->_contenedor->header());
	View::set('footer',$this->_contenedor->footer());
    }

    public function index() {
        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader=<<<html
        <!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;

        $extraFooter=<<<html
        <!-- DataTables JavaScript -->
        <script src="/js/jquery.dataTables.min.js"></script>
        <script src="/js/dataTables.bootstrap.min.js"></script>
        <script src="/js/bootbox.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {

            var table = $('#muestraDatos').DataTable({
                "language": {
                                    "emptyTable": "No hay datos disponibles",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                                    "info": "Mostrar _START_ a _END_ de _TOTAL_ registros",
                                    "infoFiltered":   "(Filtrado de _MAX_ total de registros)",
                                    "lengthMenu": "Mostrar _MENU_ registros",
                                    "zeroRecords":  "No se encontraron resultados",
                                    "search": "Buscar:",
                                    "processing": "Procesando...",
                                    "paginate" : {
                                        "next": "Siguiente",
                                        "previous" : "Anterior"
                                    }
                                }
            });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });

            $(document).on("click", "#delete", function(e) {
                    bootbox.confirm("&iquest;Borrar&aacute;s los clientes seleccionados?", function(result) {
                        if (result) 
                            $( "#delete_form" ).submit();
                    });
            });
        } );
        </script>
html;

    

    
    View::set('header',$this->_contenedor->header($extraHeader));
    View::set('footer',$this->_contenedor->footer($extraFooter));
  	View::render("premier");    
    }


}