<?php
//phpinfo();
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\MasterDom;
use \App\models\CampaignBuscaCarrier as CampaignDao;
/*
** Client Wsdl
** Esaú
*/
class ClientSmsServiceWS
{

	public function index()
	{
		echo "Hola ClientSmsServiceWS";
	}


	public function sendSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWs.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$arrayMsisdn = array(	array('msisdn'	=>	'525521984193',	'mensaje'	=> 'sms test airmovil ')/*,	//esau telcel
									array('msisdn' 	=>	'525567049957', 'mensaje'	=> 'sms test airmovil '),	//monitoreo att
									array('msisdn' 	=>	'525551865113', 'mensaje'	=> 'sms test airmovil '),	//cesar movistar
									array('msisdn'	=>	'525510123937',	'mensaje'	=> 'sms test airmovil '),	//att prueba
									array('msisdn'	=>	'525521984193',	'mensaje'	=> 'sms test airmovil '),	//esau telcel
									array('msisdn' 	=>	'525543904792', 'mensaje'	=> 'sms test airmovil '),	//monitoreo att
									array('msisdn' 	=>	'525527633429', 'mensaje'	=> 'sms test airmovil '),	//cesar movistar
									array('msisdn'	=>	'527471406668',	'mensaje'	=> 'sms test airmovil ')*/	//att prueba
							);

			$count = 0;
			foreach ($arrayMsisdn as $key => $value) {
				$count++;
				$msisdn = substr($value['msisdn'] , -12);
				$mensaje = $value['mensaje'].$count;

				$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
				$location = array('location' => $uriServidor);

				$paramssendSms = 	array(
										array(	'headerRequest'		=>	
											array(	'proveedorId'	=> '',
													'proveedor'		=> '',
													'user'			=> 'adminsky',
													'password'		=> '!jW2dc.L',
													'loteId'		=> '',
													'bloques'		=> ''
													),
											'message'	=> 
												array(	'phoneNumber'	=>	"$msisdn",
														'message' 		=>	"$mensaje",
														'loteDetalleId'	=>	''
												)
										)
									);

				//print_r($paramssendSms);
				//usleep(250000);
				$chpw = $clienteSOAP->__soapCall('sendSms', $paramssendSms, $location, $this->generateWSSecurityHeader());
				/*$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
				$var .= $clienteSOAP->__getLastRequest() . "\n";
				$var .= $clienteSOAP->__getLastResponse();*/
				
				print_r($chpw);
				echo "\n <br>";
			}

			
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function statusSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl";
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
			$location = array('location' => $uriServidor);
			$ids = array(13620);
			foreach ($ids as $value) {
				$paramsstatusSms = 	array(
												array(	'headerRequest'		=>	
													array(	'proveedorId'	=> '',
															'proveedor'		=> '',
															'user'			=> 'adminsky',
															'password'		=> '!jW2dc.L',
															'loteId'		=> 1,
															'bloques'		=> 10
														),
													'idMessage'		=> "$value"
												)
											);

				$chpw = $clienteSOAP->__soapCall('statusSms', $paramsstatusSms, $location);
				$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
				$var .= $clienteSOAP->__getLastRequest() . "\n";
				$var .= $clienteSOAP->__getLastResponse();
				/*print $this->_clienteSoap->__getLastRequestHeaders() . "\n";print $this->_clienteSoap->__getLastRequest() . "\n";print $this->_clienteSoap->__getLastResponse();*/
				//echo "--->";
				print_r($chpw);
			}
			
			
			//return $clienteSOAP;
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}


	public function changePasswordSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl";
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
			$location = array('location' => $uriServidor);

			$paramschangePasswordSms = 	array(
											array(	'headerRequest'		=>	
												array(	'proveedorId'	=> '1',
														'proveedor'		=> 'airmovil',
														'user'			=> 'esau',
														'password'		=> 'Exa_1987.',
														'loteId'		=> 1,
														'bloques'		=> 10
													),
												'newPassword'		=> 'Exa_1987.'
											)
										);

			$chpw = $clienteSOAP->__soapCall('changePasswordSms', $paramschangePasswordSms, $location);
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			/*print $this->_clienteSoap->__getLastRequestHeaders() . "\n";print $this->_clienteSoap->__getLastRequest() . "\n";print $this->_clienteSoap->__getLastResponse();*/
			//echo "--->";
			print_r($chpw);
			
			//return $clienteSOAP;
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function incomingSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'user'			=> /*'esau',*/'adminsky',
												'password'		=> /*'Exa_1987.,'*/'!jW2dc.L',
												'loteId'		=> 1,
												'bloques'		=> 10
												),
										'idMessage'	=> '1381',
										'from'		=> '2018-03-01',
										'to'		=> '2018-03-31'
									)
								);

			$chpw = $clienteSOAP->__soapCall('incomingSms', $paramssendSms, $location);
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function balanceSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'user'			=> 'adminsky',
												'password'		=> '!jW2dc.L',
												'loteId'		=> 1,
												'bloques'		=> 10
												)
									)
								);

			$chpw = $clienteSOAP->__soapCall('balanceSms', $paramssendSms, $location);
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function exchangeSms()
	{
		try {
			ini_set("soap.wsdl_cache_enabled","0");
			ini_set('soap.wsdl_cache_ttl', '0');

			$uri = "https://smsmkt.amovil.mx/wsdl/skysms/SmsSkyWs.wsdl";
			
			$clienteSOAP = new \SoapClient($uri, array(	'trace'					=> 1,
														'exceptions' 			=> 1,
														'connection_timeout' 	=> 2000,
														'ssl_method' 			=> SOAP_SSL_METHOD_TLS)
											);

			$uriServidor = "https://smsmkt.amovil.mx/wsdl/smsservicews/SmsServiceWS.php";
			$location = array('location' => $uriServidor);

			$paramssendSms = 	array(
									array(	'headerRequest'		=>	
										array(	'proveedorId'	=> '',
												'proveedor'		=> '',
												'user'			=> 'adminsky',
												'password'		=> '!jW2dc.L',
												'loteId'		=> 1,
												'bloques'		=> 10
												)
									)
								);

			$chpw = $clienteSOAP->__soapCall('exchangeSms', $paramssendSms, $location);
			$var = $clienteSOAP->__getLastRequestHeaders() . "\n";
			$var .= $clienteSOAP->__getLastRequest() . "\n";
			$var .= $clienteSOAP->__getLastResponse();
			
			print_r($chpw);
			
		} catch (\SoapFault $e) {
			echo "Error:\n<br>";
			print_r($e);
		}
	}

	public function generateWSSecurityHeader()
	{
		date_default_timezone_set('UTC');

		$password = 'Exa_1987.';

		$user = 'esau';

		$nonce = substr(md5(uniqid('air_', true)),0,16);
    
    	$nonce64 = base64_encode($nonce);

    	$fecha = date('Y-m-d')."T".date('H:i:s')."Z";

    	$token = $nonce64 . $fecha . utf8_encode($password);
    
    	$token64 = base64_encode(sha1($token,true));

    	$transactionId = 1111;//$this->obtenerTransactionId();

		$xml =<<<xhtml
<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
    <wsse:UsernameToken xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
		<wsse:Username>{$user}</wsse:Username>
        <wsse:Password Type="...#PasswordDigest">{$token64}</wsse:Password>
        <wsse:Nonce>{$nonce64}</wsse:Nonce>
        <wsu:Created>{$fecha}</wsu:Created>
    </wsse:UsernameToken>
</wsse:Security>
xhtml;

/*<!--<tns:RequestSOAPHeader xmlns:tns="http://www.huawei.com/schema/common/v2_1">
    <tns:AppId>0101</tns:AppId>
    <tns:TransId>{$transactionId}</tns:TransId>
    <tns:OA></tns:OA>
    <tns:FA></tns:FA>
</tns:RequestSOAPHeader>-->
*/

		return new \SoapHeader('http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd',
								'Security',
								new \SoapVar($xml, XSD_ANYXML),
								true
							);
	}

}
