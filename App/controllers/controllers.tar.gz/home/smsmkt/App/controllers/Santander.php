<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Santander as SantanderDao;
use \App\controllers\Santander;

class Santander
{

private $_contenedor;

    function __construct() { 
    $this->_contenedor = new Contenedor;
    View::set('header',$this->_contenedor->header());
    View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

       $html=<<<html
              <form id="add" action="/Santander/envioPostExistente" method="POST">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Configuracion del mensaje a enviar</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>En esta pantalla podra confeccionar el mensaje que desea enviar y programar la fecha en que se realizara el env&iacute;o.</p>
                    <div class="ln_solid"></div>
                    <form id="add" action="/Santander/envioPostExistente" method="POST">

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Nombre de la campaña : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
        <input type="text" class="form-control" placeholder="Nombre de Campaña" name="nombre_campania" id="nombre_campania">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">Texto del Mensaje : </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
        <textarea name="mensaje" id="mensaje" class="resizable_textarea form-control" placeholder="En la redacción del mensaje no es válido el uso de la letra “ñ”, símbolos o vocales acentuadas El mensaje debera ser mayor a 5 caracteres y menor de 160 caracteres. ..."></textarea>
                            </div>
                        </div>


      <div class="form-group row">
                            <label for="middle-name" class="control-label col-md-4 col-sm-4 col-xs-12">Fecha Lanzamiento :</label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <div class='input-group date' id='datetimepicker'>
                              <input type='text' class="form-control" name="datetimepicker" id='datetimepicker' />
                              <span class="input-group-addon">
                                  <span class="glyphicon glyphicon-calendar"></span>
                              </span>
            </div>
        <p class="help-block">Si no programadas la fecha se enviara inmediatamente, si la fecha es anterior a la actual de igual manera se enviara automaticamente.<span id="fecha_sistema"></span></p>
          </div>
                        </div>

                        <div class="ln_solid"></div>

                      <div class="form-group">
                        <div class="col-md-12 col-sm-9 col-xs-12">
                          <input type="submit" class="btn btn-success pull-right" value="Siguiente">
                        </div>
                      </div>
                  </div>
                </div>
          </form>
html;

  $extraHeader=<<<html
<!-- DataTables CSS -->
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
html;

        $extraFooter=<<<html
<!-- DataTables JavaScript -->
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
    <script src="/js/bootbox.min.js"></script>
    <script src="/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <script src="/js/validate/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script>    
        $(document).ready(function() {

          $('#datetimepicker').datetimepicker({
                minDate: moment(),
                daysOfWeekDisabled: [0, 6]
          });

      $("#add").validate(
                {
        ignore: "[disabled]",
                    rules: {
                        nombre_campania: {
                            required: true,
                            maxlength: 60,
                            minlength: 3
                        },
                        mensaje: {
                            required: true,
                            maxlength: 160,
                            minlength: 3
                        },
                        datetimepicker: {
                            required: true
                        }
                    },
                    messages: {
                        nombre_campania:{
                            required: "Este campo es obligatorio",
                            maxlength: "El máximo de caracteres son 60",
                            minlength: "El mínimo de caracteres son 3"
                        },
                        mensaje: {
                            required: "Este campo es obligatorio"
                        },
                        datetimepicker: {
                            required: "Este campo es obligatorio"
                        }
                    }
      });

      setInterval(function(){ 
      $.get( "/Santander/getTime", function( data ) {
        $( "#fecha_sistema" ).html( data );
      } );
      }, 1000);
        });
    </script>
html;
     
      View::set('contenido',$html);
      View::set('header',$this->_contenedor->header($extraHeader));
      View::set('footer',$this->_contenedor->footer($extraFooter));
      View::render("santander");
    }

     public function getTime(){
        $fecha = date("Y-m-d H:i:s");
        echo '<b> La fecha del sistema actual es: '.$fecha.'</b>';
        exit;
    }
       public function envioPostExistente(){

        $campaniaId = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        $campaniaSecurity =  substr($campaniaId,rand(1,strlen($campaniaId)),18);
        header("Location: /Santander/ReporteEnvio/$campaniaSecurity");
        exit();
    }

    public function ReporteEnvio(){

        $enviosPush = rand(1,100);
        $mensajesErroneos = rand(1,60);

  $html=<<<html
            <form action="/Santander/Mensaje" method="POST">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reporte de envío </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Descripcion</th>
                          <th>Cantidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Env&iacute;os PUSH :</td>
                          <td>$enviosPush</td>
                        </tr>
                        <tr>
                          <td>Mensajes err&oacute;neos :</td>
                          <td>$mensajesErroneos</td>
                        </tr>
                      </tbody>
                    </table>

                  </div>
      <div class="ln_solid"></div>

                        <div class="form-group">
                          <div class="col-md-12 col-sm-9 col-xs-12">
                          <input type="submit" class="btn btn-success pull-right" value="Enviar Mensajes">
                          </div>
                        </div>

                </div>
              </div>
        </form>
html;
        View::set('contenido',$html);
        
        View::render("santander");
    }

    public function mensaje(){
        
        return $this->alertas('success_add');
    }

    private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Success.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'error_producto')
            $mensaje = 'Ocurrio un error al insertar los productos.';
        else
            $mensaje = 'Ocurrio algo inesperado.';

        View::set('regreso','/menu');
        View::set('class', $class);
        View::set('titulo','Mensajes');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

}