<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\User as UserDao;
use \App\controllers\Contenedor;

class User{

    private $_contenedor;

    function __construct(){
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    public function index(){
        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/custom.min.css" rel="stylesheet">

html;
        $extraFooter=<<<html
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
$(document).ready(function() {

    jQuery.validator.addMethod("pwdVal", function(value, element) {
        return this.optional(element) || /(?=^[^\s]{8,128}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/.test(value);
     });

    $("#profile").validate(
        {
            rules: {
        		passAnterior: {
        		    required: true
        		},
                passNueva: {
                           minlength: 8,
                           pwdVal: true
                        },
                passNueva1: {
                    equalTo: "#passNueva"
                },
                img: {
                    accept: "image/*"
                }

            },

            messages: {
                passAnterior: {
                    required: "Este campo es obligatorio"
                },
        		passNueva: {
            		    minlength: "Minimo 8 caracteres",
            		    pwdVal: "Se requiere minimo un numero y una letra mayuscula"
                },
                passNueva1: {
                    equalTo: 'Este campo debe ser el mismo que el campo anterior'
                },
                img: {                           
                    accept: 'Se necesita un archivo con extensión jpg o png'
                }
            },
            
        }
    );
});

</script> 
html;


        $usuario = MasterDom::getSession('usuario');

        /**************************** Registro *************************/
        /*$registro = $this->registroUsuario();
        print_r($registro);

        $nombre = explode("/", $_SERVER["REQUEST_URI"]);
        print_r($nombre[1]);
        
        //UserDao::registroUsuario($registro);*/
        /***************************************************************/

        View::set('usuario',$usuario);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("userprofile");
    }

    public function updateProfile(){
        $extraHeader=<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/custom.min.css" rel="stylesheet">
html;
        $extraFooter=<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

<script>
    $(document).ready(function() {

        $("#profile").validate(
            {
                rules: {
                    passAnterior{
                        required: true
                    },
                    passNueva1: {
                        equalTo: "#passNueva"
                    },
                    img: {
                        accept: "image/*"
                    }

                },
                messages: {
                    passAnterior: {
                        required: "Este campo es obligatorio"
                    },
                    passNueva1: {
                        equalTo: 'Este campo debe ser el mismo que el campo anterior'
                    },
                    img: {                           
                        accept: 'Se necesita un archivo con extensión jpg o png'
                    }
                },
            }
        );
    });
</script> 
html;

        $passAnterior = md5(MasterDom::getData('passAnterior'));
        $passNueva = MasterDom::getData('passNueva');
        $passNueva1 = MasterDom::getData('passNueva1');
        //$img = MasterDom::getData('img');

        $id_user = MasterDom::getSession('id_user');

        $userlogeado = UserDao::getById($id_user);

        //print_r($userlogeado);

        foreach ($userlogeado as $key => $value) {
            $passAnteriorBase = $value['password'];
        }

        $ruta_servidor='/home/smsmkt/public/img/usr';
        $nombreImagen=$_FILES['img']['name'];
        $rutaTemporal=$_FILES['img']['tmp_name'];
        $nombreImagen = uniqid().$nombreImagen;
        $rutaDestino=$ruta_servidor."/".$nombreImagen;
        move_uploaded_file($rutaTemporal, $rutaDestino);

        if ($passAnteriorBase == $passAnterior) {

            if (empty($passNueva) && empty($passNueva1) && empty($nombreImagen)) {
                //$this->userDatosVacio();
                return $this->alertas('error_general');
            }
             elseif(empty($passNueva) && empty($passNueva1)){
                $datos = new \stdClass();
                $datos->_imgNew = $nombreImagen;
                $datos->_id_user = $id_user;
            
                //UserDao::updateImg($datos);
                if (UserDao::updateImg($datos)) {
                    /**************************** Registro *************************/
                    $registro = $this->registroUsuario("Actualizo imagen");
                    //print_r($registro);
                    UserDao::registroUsuario($registro);
                    /***************************************************************/
                }

            } elseif(empty($nombreImagen))  {
            
                        $datos = new \stdClass();
                        $datos->_passNueva = $passNueva;
                        $datos->_id_user = $id_user;
            
            
                        //UserDao::updatePassword($datos);
                        if (UserDao::updatePassword($datos)) {
                            /**************************** Registro *************************/
                            $registro = $this->registroUsuario("Actualizo password");
                            UserDao::registroUsuario($registro);
                            /***************************************************************/
                        }

            } else  {
            
                $datos = new \stdClass();
                $datos->_passNueva = $passNueva;
                $datos->_imgNew = $nombreImagen;
                $datos->_id_user = $id_user;
    
    
                //UserDao::update($datos);
                if (UserDao::update($datos)) {
                    /**************************** Registro *************************/
                    $registro = $this->registroUsuario("Actualizo todos los campos");
                    UserDao::registroUsuario($registro);
                    /***************************************************************/
                }
            }

            return $this->alertas('success_edit');
            

        } else {

            return MasterDom::alertas('personal','/user', 'Error', 'Lo sentimos, ocurrió un error inesperado.');

        }


        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));


    }

    public function profile(){

        if(($login = isset($_GET['login'])) != ''){
            if ($login=='usrerror') {
                echo "<script>alert('Los datos son incorrectos...');</script>";
            }
        }        
        View::render("user");
    }
/*
    public function userDatosVacio(){

        $extraFooter=<<<html
<script>
    alert('Ingresa una nueva contraseña o actualiza tu imagen');
</script>
html;
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("userprofile");
    }
*/
    
    private function alertas($caso = 'error_general'){
        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'error_producto')
            $mensaje = 'Ocurrio un error al insertar los productos.';
        elseif($caso == 'error_categoria')
            $mensaje = 'Ocurrio un error al insertar las categorias.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito los elementos seleccionados.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
                $mensaje = 'Se modific&oacute; con exito.';
                $class = 'success';
            }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrio algo inesperado.';
        View::set('regreso','/menu');
        View::set('regreso','/menu');
        View::set('class', $class);
        View::set('titulo','Profile');
        View::set('mensaje', $mensaje);
            View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/",$_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }

}
