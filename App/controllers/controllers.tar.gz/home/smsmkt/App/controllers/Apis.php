<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\models\Apis as apisDao;
use \App\controllers\Contenedor;

class Apis {

private $_contenedor;

    function __construct() { 
        $this->_contenedor = new Contenedor;
        View::set('header',$this->_contenedor->header());
        View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {
        echo "Hola apis_web";
    }

    public function add() {
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

        <!--jQuery validate -->
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    usuario: {
                        required: true
                    },
                    password: {
                        required: true
                    },
                    ip: {
                        required: true
                    }
                },
                messages: {
                    usuario: {
                        required: "Ingrese nombre de usuario"
                    },
                    password: {
                        required: "Ingrese password de usuario"
                    },
                    ip: {
                        required: "Ingrese ingrese minimo dos ip's"
                    }
                }
            });
        </script>

html;

        /*$allShortCode = apisDao::getShortCodeAndCarrier();
        $shortcode = '';
        foreach ($allShortCode as $key => $value) {
            $short_code = $value['short_code'];
            $carrier = $value['name'];
            $id_ccsc = $value['carrier_connection_short_code_id'];
            $shortcode .= "<option value=".$id_ccsc.">".$short_code." - ".$carrier."</option>";
        }

        View::set('show_shortcode_carrier',$shortcode);*/
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("apis_add");
    
    }


    public function add_apis(){

        MasterDom::verificaUsuario();
        if (empty($_POST)){ header('location:/apis/add/');}
        else {

        $usuario = MasterDom::getData('usuario');
        $pass = MasterDom::getData('password');
        $ip = htmlentities($_POST['ip']);

        if (preg_match("/\r\n/", $ip)) {
            $newlist = preg_replace("/\r\n/", "|", $ip);
            $newlist = explode("|", $newlist);
        }
        /*print_r($usuario);
        echo "<br>";
        print_r($pass);
        echo "<br>";*/
        //print_r($newlist);
        
        $datos = new \stdClass();
        $datos->_usuario = $usuario;
        $datos->_pass = $pass;
        $datos->_customer = MasterDom::getSession('customer_id');

        //print_r($datos);

        $api_id = apisDao::insert($datos);

        /*Insertamos ips */
        $listip = new \stdClass ();
        foreach ($newlist as $key => $value) {
          $listip->_api_web_id = $api_id;
          $listip->_ip = $value;
          apisDao::insertIp($listip);
        }
        
            if (empty($api_id)){
                header('location:/apis/add');
            } else {
                $registro = $this->registroUsuario("Agrego apis id:{$api_id}");
                apisDao::registroUsuario($registro);
                header('location:/apis/mostrar');
            }
        }
    }

     public function edit(){

         MasterDom::verificaUsuario();

         $extraHeader =<<<html
         <link href="/css/magicsuggest-min.css" rel="stylesheet">
         <link rel="stylesheet" href="/css/validate/screen.css">
html;
         $extraFooter =<<<html
         <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

         <!--jQuery validate -->
         <script src="/js/magicsuggest-min.js"></script>
         <script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    usuario: {
                        required: true
                    },
                    password: {
                        required: true
                    },
                    ip: {
                        required: true
                    }
                },
                messages: {
                    usuario: {
                        required: "Ingrese nombre de usuario"
                    },
                    password: {
                        required: "Ingrese password de usuario"
                    },
                    ip: {
                        required: "Ingrese ingrese minimo dos ip's"
                    }
                }
            });
        </script>
html;

         $api_id = MasterDom::getTituloWeb($_GET);
         //print_r($api_id);
         $id = "";
         foreach ($api_id as $key => $value) {
             $id .= $value;
         }
         $api_id = str_replace('apis/edit/', "", $id);
         //print_r($api_id);
         $data = apisDao::getById($api_id);
         //print_r($data);
         foreach ($data as $key => $value) {
             $api_id = $value['api_web_id'];
             $usuario = $value['user'];
             $password = $value['pwd'];

         }
         

        $ips = apisDao::getIps($api_id);
        //print_r($ips);
        $datosIp = "";
        if (empty($ips)) {
            $datosIp = "";
        }
        else{
            foreach ($ips as $key => $value) {
                $datosIp .= $value['ip']."\r\n";
            }
        }
        //print_r($datosIp);

        View::set('ip',$datosIp);
        View::set('usuarioApi',$usuario);
        View::set('passwordApi',$password);
        View::set('api_id', $api_id);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("apis_edit");
     }


    public function edit_apis(){
        MasterDom::verificaUsuario();
        if (empty($_POST)){ header('location:/apis/mostrar');}
        else {         
            $usuario = MasterDom::getData('usuario');
            $password = MasterDom::getData('password');
            $api_id = MasterDom::getData('api_id');
            $ip = MasterDom::getData('ip');

            /*
            if (preg_match("/\r\n/", $ip)) {
              $newlist = preg_replace("/\r\n/", "|", $ip);
              $newlist = explode("|", $newlist);
            }
            */

            $datos = new \stdClass();
            $datos->_usuario = $usuario;
            $datos->_pass = $password;
            $datos->_api_web_id = $api_id;
            //print_r($datos);
            $upApi = apisDao::update($datos);
            if (!($upApi === FALSE) ) {
            apisDao::deleteIp($api_id);
            /*Insertamos ips */
            $listip = new \stdClass ();
            foreach (explode(',' , $ip) as $key => $value) {
                $listip->_api_web_id = $api_id;
                $listip->_ip = $value;
                apisDao::insertIp($listip);
            }

            $registro = $this->registroUsuario("Actualizo apis id:{$apis_id}");
            apisDao::registroUsuario($registro);
            header('location:/apis/mostrar');
            }
            else {
            self::alertas('error_general');
            }    
        }
    }

    public function delete(){
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

        <!--jQuery validate -->
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    api: {
                        required: true
                    }
                },
                messages: {
                    api: {
                        required: "Elige una opcion"
                    }
                }
            });
        </script>
html;

        /*$id_custom = MasterDom::getSession('customer_id');*/

        $apisOption = '';
        $apis = apisDao::getAll();
        foreach ($apis as $key => $value) {
            $apisOption .= "<option value=".$value['api_web_id'].">".$value['user']."</option>";
        }

        View::set('apisOption',$apisOption);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("apis_delete");
    }

    public function delete_apis(){
        MasterDom::verificaUsuario();
        if (empty($_POST)) header('location:/apis/mostrar');

        $api_id = MasterDom::getData('apis');
        
            if (empty($api_id)) {
                self::alertas('error_borrar');
            } else{
                apisDao::delete($api_id);
                apisDao::deleteIP($api_id);
                $registro = $this->registroUsuario("Actualizo status apis id:{$mail2sms_id}");
                apisDao::registroUsuario($registro);
                //header('location:/apis/mostrar/'); //exito
                self::alertas('success_delete');
            }

    }

    public function mostrar(){
        MasterDom::verificaUsuario();
        //$id_custom = MasterDom::getSession('customer_id');

        $extraHeader =<<<html
        <link href="/css/magicsuggest-min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/validate/screen.css">
        <link href="/css/dataTables.bootstrap.css" rel="stylesheet">
html;
        $extraFooter =<<<html
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
        <!--jQuery validate -->
        <script src="/js/magicsuggest-min.js"></script>
        <script src="/js/validate/jquery.validate.js"></script>
        <script src="/js/jquery.dataTables.min.js"></script>
    <script src="/js/dataTables.bootstrap.min.js"></script>
        <script>
            $(document).ready(function(){

                var oTable = $('#muestra-cupones').DataTable({
                "columnDefs": [{
                    "type": "html",
                    "targets": '_all'}],
                //aaSorting : [[1, 'desc']]
            });
            // Remove accented character from search input as well
            $('#muestra-cupones input[type=search]').keyup( function () {
                var table = $('#example').DataTable();
                table.search(
                    jQuery.fn.DataTable.ext.type.search.html(this.value)
                ).draw();
            });

            $("#checkAll").change(function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            });


                $("input[name='campaign_id[]']").change(function(){
                    var id = $(this).val();
                    cambio_estado(id);
/*************
                    var type = $('#type_'+id).val();
                    var id = $(this).val();

                    $.ajax({
                        url: '/Apis/deleteCampaignId',
                        type: 'POST',
                        data: {campaign_id: id}
                    });

                    if( $(this).prop('checked') ){
                        $.ajax({
                            url: '/Apis/agregarCampaignApis',
                            type: 'POST',
                            data: {campaign_id: id, tipo: type},
                            success: function(response){
                                alert(response);
                                $("#indicador_"+id).append('<span id="mensaje_'+id+'" class="badge badge-pill badge-info">Agregado</span>');
                            }
                        });
                    }else{
                        $("#mensaje_"+id).remove();
                    }
/**************/
                    
                });

                $("select.type_campaign").on("change", function(){
                    var id = $("option:selected",this).attr("cid");
                    cambio_estado(id);
                });


                function cambio_estado(id){
                    var type = $('#type_'+id).val();

                    $.ajax({
                        url: '/Apis/deleteCampaignId',
                        type: 'POST',
                        data: {campaign_id: id}
                    });

                    if( $("#ck_"+id).prop('checked') ){
                        $("#mensaje_"+id).remove();
                        $.ajax({
                            url: '/Apis/agregarCampaignApis',
                            type: 'POST',
                            data: {campaign_id: id, tipo: type},
                            success: function(response){
                                $("#indicador_"+id).append('<span id="mensaje_'+id+'" class="badge badge-pill badge-info">Agregado</span>');
                            }
                        });
                    }else{
                        $("#mensaje_"+id).remove();
                    }
                }

            });
        </script>

html;

        $data_allTable = '';
        $datos = apisDao::getAllByCustomer(MasterDom::getSession('customer_id'));

        foreach ($datos as $key => $value) {
            $id = $value['api_web_id'];

            $data_allTable .= " <tr>
                <!--td><input type='checkbox' name='borrar[]' value='{$value['api_web_id']}'/></td-->
                <td>{$value['user']}</td>
                <td>{$value['pwd']}</td>
                <td>";
            $ips = apisDao::getIps($id);
            foreach ($ips as $key => $value) {
                $data_allTable .= "{$value['ip']}<br>";
            }
            $data_allTable .= "</td>
                                <td class='center'><a href='/apis/edit/".$value['api_web_id']."' type='button' class='btn btn-primary btn-circle center-block'><i class='fa fa-pencil-square-o'></i></a></td>
                                </tr>";
        }

        /* tabla de campañas */
        
        $web_type_id = apisDao::getWebApiType();
        $tablaCampaign = '';
        foreach (apisDao::getCampaignById(MasterDom::getSession('customer_id')) as $key => $value) {
            $checked = '';
            $agregado = '';
            
            foreach (apisDao::getCampaignCarrierShortCodeById(MasterDom::getSession('customer_id')) as $llave => $valor) {
                $type_id = '';
                if($value['campaign_id'] == $valor['campaign_id']){
                    $checked = 'checked';
                    $type_id = $valor['api_web_type_id'];
                    $agregado =<<<html
                    <span id="mensaje_{$value['campaign_id']}" class="badge badge-pill badge-info">Agregado</span>
html;
                    break;
                }
            }

            $sType = "";

            foreach ($web_type_id as $llave => $valor) {
                $selected = ($type_id == $valor['api_web_type_id'])? 'selected' : '';
                $sType .=<<<html
                <option value="{$valor['api_web_type_id']}" {$selected} cid="{$value['campaign_id']}">{$valor['type']}</option>
html;
            }

            $tablaCampaign .=<<<html
             <tr>
                <td id="indicador_{$value['campaign_id']}">
                    <input type="checkbox" name="campaign_id[]" id="ck_{$value['campaign_id']}" campaig_id="{$value['campaign_id']}" value="{$value['campaign_id']}" {$checked}/>
                    {$agregado}
                </td>
                <td>
                    <label>{$value['campaign_id']}</label>
                </td>
                <td>
                    <label class="control-label col-md-8 col-sm-8 col-xs-8" style="text-align: center;color:#000000;" >{$value['name_campaign']}</label>
                </td>
                <td>
html;
                $carriers = apisDao::getCarrierConnectionShortCodeById($value['campaign_id']);
                foreach ($carriers as $llave => $valor) {
                    $tablaCampaign .=<<<html
                    <label>{$valor['name']} : {$valor['carrier_connection_short_code_id']}</label><br>
html;
                }



            $tablaCampaign .=<<<html
                </td>
                <td>
                    {$carriers[0]['short_code']}
                </td>
                <td>
                    <select class="form-control type_campaign" id="type_{$value['campaign_id']}">
                    {$sType}
                    </select>
                </td>
            </tr>
html;
        }

        View::set('table',$data_allTable);
        View::set('tablaCampaign',$tablaCampaign);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("apis_all");
    }

    public function deleteCampaignId(){
        apisDao::deleteCampaignId(MasterDom::getData('campaign_id'));
    }

    public function agregarCampaignApis(){
        $datos = new \stdClass();
        $datos->campaign_id = MasterDom::getData('campaign_id');
        $datos->type = MasterDom::getData('tipo');
        $datos->shortcode = MasterDom::getData('shortcode');
        $ids = array();
        foreach (apisDao::getAll() as $key => $value) {
            $datos->api_web_id =  $value['api_web_id'];
            foreach (apisDao::getCampaignCarrierShortCode(MasterDom::getData('campaign_id')) as $llave => $valor) {
                print_r($valor);
                echo "<br>";
                $datos->campaign_carrier_short_code_id = $valor['campaign_carrier_short_code'];
                $id = apisDao::insertApiWebType($datos);
                array_push($ids,$id);
            }
        }

        foreach ($ids as $key => $value) {
            if($value<=0){
                echo json_encode(array('error'=>-1, 'id' => 'Error'));
                return;
            }
        }
        echo json_encode(array('error'=>0, 'mensaje' => 'Agregada', 'ids' => $ids));
    }


    public function delete_apiList(){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(apisDao::delete($id) === false){
                return $this->alertas('error_borrar');
            }else{
                $registro = $this->registroUsuario("Elimino apis {$id}");
                apisDao::registroUsuario($registro);
            }
        }

        return $this->alertas('success_delete');

        // header('location:/badword/mostrar/'); //exito

    }


     private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con éxito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/apis/mostrar');
        View::set('class', $class);
        View::set('titulo','Apis');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }


}