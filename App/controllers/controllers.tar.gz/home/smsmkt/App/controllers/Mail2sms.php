<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

error_reporting(E_ALL);

use \Core\View;
use \Core\MasterDom;
use \App\models\Mail2sms as mail2smsDao;
use \App\controllers\Contenedor;

class Mail2sms {

private $_contenedor;

    function __construct() { 
    $this->_contenedor = new Contenedor;
    View::set('header',$this->_contenedor->header());
    View::set('footer',$this->_contenedor->footer());
    }

    /**
     * [metodo default para la vista]
     * @return [View render]
     * @see interface
     */
    public function index() {

    MasterDom::verificaUsuario();

    $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

    $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    campania: {
                        required: true
                    },

                    short_code: {
                        required: true
                    },

                    title: {
                        required: true
                    },
                    
                    handler: {
                        required: true
                    },

                    configuration: {
                        required: true
                    }
                }
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#campania").change(function() {
                    var form_data = {
                        campania: $("#campania").val()
                    };
                    $.ajax({
                            type: "POST",
                            url: "/Service/showShortCode",
                            data: form_data,
                            success: function(response)
                            {
                                console.debug(response);
                                $("#short_code").html(response).fadeIn();
                            }
                    });
                });

                $("#handler").change(function(){
                    if( $("#handler").val() == 'url'){
                        console.debug('url');
                        $("#configuration").get(0).placeholder = 'Ingresa la url del servicio';
                        $("#configuration").get(0).type = 'url';
                    }
                    if( $("#handler").val() == 'staticText'){
                        console.debug('staticText');
                        $("#configuration").get(0).placeholder = 'Ingresa el texto';
                        $("#configuration").get(0).type = 'text';
                    }
                });
        
            });
        </script>

html;

     /*$data_allTable = '<tr>';
        $mails = mail2smsDao::getAll();
        foreach ($mails as $key => $value) {
            $data_allTable .=   "<td>".$value['mail2sms_id']."</td>"
                                "<td>".$value['created']."</td>"
                                "<td>".$value['mail']."</td>"
                                "<td>".$value['max_mt_day']."</td>"
                                "<td>".$value['max_mt_month']."</td>";
        }

        $data_allTable .= "</tr>";

    View::set('table',$data_allTable);*/
    View::set('header',$this->_contenedor->header($extraHeader));
    View::set('footer',$this->_contenedor->footer($extraFooter));
    //View::render("mail2sms_all");

    
    }

    public function add() {
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    mail: {
                        required: true
                    },
                    max_dia: {
                        required: true
                    },
                    max_mes: {
                        required: true
                    },
                    'shortcode_carrier[]': {
                        required : true,
                        minlength: 1
                    },
                    detalle: {
                        required: true
                    }
                },
                messages: {
                    mail: {
                        required: "Ingrese un e-mail"
                    },
                    max_dia: {
                        required: "Ingrese un numero de envios m&aacute;ximos por d&iacute;a"
                    },
                    max_mes: {
                        required: "Ingrese un numero de envios m&aacute;ximos por mes"
                    },
                    'shortcode_carrier[]': {
                        required: "Seleccione short code y carrier"
                    },
                    detalle: {
                        required: "Ingrese una descripci&oacute;n"
                    }
                }
            });
        </script>

html;

        $allShortCode = mail2smsDao::getShortCodeAndCarrier();
        $shortcode = '';
        foreach ($allShortCode as $key => $value) {
            $short_code = $value['short_code'];
            $carrier = $value['name'];
            $id_ccsc = $value['carrier_connection_short_code_id'];
            $shortcode .= "<option value=".$id_ccsc.">".$short_code." - ".$carrier."</option>";
        }

        View::set('show_shortcode_carrier',$shortcode);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("mail2sms_add");
    
    }


    public function add_mail2sms(){

        MasterDom::verificaUsuario();

        if (empty($_POST)){ self::alertas('error_general');}
        else {

        $mail = MasterDom::getData('mail');
        //$max_mt_day = MasterDom::getData('max_dia');
        //$max_mt_month = MasterDom::getData('max_mes');
        $detalle = MasterDom::getData('detalle');
        $user_id = MasterDom::getSession('id_user');
        $customer_id = MasterDom::getSession('customer_id');
        $status = MasterDom::getData('status');
            if (!empty($status)) {
                $status = 1;
            } else {
                $status = 0;
            }
        $short_code = MasterDom::getDataAll('shortcode_carrier');
        /*$user = new \stdClass();
        $user->_nickname = $mail;
        $user->_fname = MasterDom::getSession('name_customer');
        $user->_lname = preg_replace("/@(.*)/", "", $mail);
        $user->_img = "user.png";
        $user->_password = MasterDom::generaPassAleatorio();
        $user->_mail = $mail;
        $user->_max_mt_day = $max_mt_day;
        $user->_max_mt_month = $max_mt_month;
        $user->_status = $status;
        print_r($user);*/

        $datos = new \stdClass();
        $datos->_mail = $mail;
        $datos->_status = $status;
        //$datos->_status = $status;
        //$datos->_max_mt_day = $max_mt_day;
        //$datos->_max_mt_month = $max_mt_month;
        $datos->_detalle = $detalle;
        $datos->_user_id = $user_id;
        $datos->_customer_id = $customer_id;
        //$datos->_short_code = $short_code;

        $mailData = mail2smsDao::insert($datos);
        
            if (empty($mailData)){
                //header('location:/mail2sms/add');
                self::alertas('error_general');
            } else {
                /*Insertamos ccsc_id */
                $ccsc = new \stdClass ();
                foreach ($short_code as $key => $value) {
                  $ccsc->_mail2sms_id = $mailData;
                  $ccsc->_ccsc_id = $value;
                  mail2smsDao::insertCCSC($ccsc);    
                }

                $registro = $this->registroUsuario("Agrego mail2sms id:{$mailData}");
                mail2smsDao::registroUsuario($registro);
                //header('location:/mail2sms/mostrar');
                self::alertas('success_add');
            }
        }
    }

     public function edit(){

         MasterDom::verificaUsuario();
//         $id_custom = MasterDom::getSession('customer_id');

         $extraHeader =<<<html
 <link href="/css/magicsuggest-min.css" rel="stylesheet">
 <link rel="stylesheet" href="/css/validate/screen.css">
html;
         $extraFooter =<<<html
 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 <!--jQuery validate -->
 <script src="/js/magicsuggest-min.js"></script>
 <script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    mail: {
                        required: true
                    },
                    max_mail: {
                        required: true
                    },
                    max_dia: {
                        required: true
                    },
                    max_mes: {
                        required: true
                    },
                    'shortcode_carrier[]': {
                        required : true,
                        minlength: 1
                    },
                    detalle: {
                        required: true
                    }
                },
                messages: {
                    mail: {
                        required: "Ingrese un e-mail"
                    },
                    max_mail: {
                        required: "Ingrese un n&uacute;mero de envios m&aacute;ximos por mail"
                    },
                    max_dia: {
                        required: "Ingrese un n&uacute;mero de envios m&aacute;ximos por d&iacute;a"
                    },
                    max_mes: {
                        required: "Ingrese un n&uacute;mero de envios m&aacute;ximos por mes"
                    },
                    'shortcode_carrier[]': {
                        required: "Seleccione short code y carrier"
                    },
                    detalle: {
                        required: "Ingrese una descripci&oacute;n"
                    }
                }
            });
        </script>
html;

         $mail2sms_id = MasterDom::getTituloWeb($_GET);
         //print_r($mail2sms_id);
         $id = "";
         foreach ($mail2sms_id as $key => $value) {
             $id .= $value;
         }
         $mail2sms_id = str_replace('Mail2sms/edit/', "", $id);
         //print_r($mail2sms_id);
         $data = mail2smsDao::getById($mail2sms_id);
         //print_r($data);
         foreach ($data as $key => $value) {
             $mail = $value['mail'];
             $status = $value['status'];
             //$max_mail = $value['max_mt_mail'];
             //$max_dia = $value['max_mt_day'];
             //$max_mes = $value['max_mt_month'];
             $detalle = $value['detalle'];
         }
         if ($status == 1) {
             $checked = "checked";
         }else{
            $checked = "";
         }

        
        $xyre = mail2smsDao::getMCCSC($mail2sms_id);
        

        $allShortCode = mail2smsDao::getShortCodeAndCarrier();
        $shortcode = '';
        foreach ($allShortCode as $key => $value) {
            $short_code = $value['short_code'];
            $carrier = $value['name'];
            $id_ccsc = $value['carrier_connection_short_code_id'];
            if ($xyre ['carrier_connection_short_code_id'] ==$value['carrier_connection_short_code_id']) {
                $shortcode = "<option value=".$id_ccsc." selected>".$short_code." - ".$carrier."</option>";
            }else{
                $shortcode .= "<option value=".$id_ccsc.">".$short_code." - ".$carrier."</option>";
            }

        }

     
        View::set('show_shortcode_carrier',$shortcode);
        View::set('mail',$mail);
        View::set('checked',$checked);
        //View::set('max_mail',$max_mail);
        //View::set('max_dia',$max_dia);
        //View::set('max_mes',$max_mes);
        View::set('detalle',$detalle);
        View::set('id',$mail2sms_id);
        View::set('option',$option);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("mail2sms_edit");
     }


    public function edit_mail2sms(){
         MasterDom::verificaUsuario();
         if (empty($_POST)){ header('location:/Mail2sms/mostrar');}
         else {         
              $mail = MasterDom::getData('mail');
              $status = MasterDom::getData('status');
             // $max_mail = MasterDom::getData('max_mail');
              //$max_dia = MasterDom::getData('max_dia');
              //$max_mes = MasterDom::getData('max_mes');
              $detalle = MasterDom::getData('detalle');
              $mail2sms_id = MasterDom::getData('id');
              $short_code = MasterDom::getDataAll('shortcode_carrier');
     
                 if (!empty($status)) {
                     $status = 1;
                 } else {
                     $status = 0;
                 }
     
              $datos = new \stdClass();
              $datos->_mail = $mail;
              //$datos->_max_mt_mail = $max_mail;
              //$datos->_max_mt_day = $max_dia;
              //$datos->_max_mt_month = $max_mes;
              $datos->_status = $status;
              $datos->_detalle = $detalle;
              $datos->_mail2sms_id = $mail2sms_id;

              /*Se hace la actualización de datos*/
              $actualizar = mail2smsDao::update($datos);

                 if ($actualizar === false) {
                    self::alertas('error_general');
                 }else{

                    /*Borramos ccsc_id relacionadas*/
                    mail2smsDao::deleteCCSC($mail2sms_id);

                    /*Insertamos nuevamente ccsc_id */
                    $ccsc = new \stdClass ();
                    foreach ($short_code as $key => $value) {
                      $ccsc->_mail2sms_id = $mail2sms_id;
                      $ccsc->_ccsc_id = $value;
                      mail2smsDao::insertCCSC($ccsc);    
                    }

                     $registro = $this->registroUsuario("Actualizo mail2sms id:{$mail2sms_id}");
                     mail2smsDao::registroUsuario($registro);
                     //header('location:/mail2sms/mostrar');
                     self::alertas('success_edit');
                 }    
        }
    }

    public function delete(){
        MasterDom::verificaUsuario();

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;

        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

        <script>
            $("#form").validate({
                rules: {
                    mail: {
                        required: true
                    }
                },
                messages: {
                    mail: {
                        required: "Elige una opcion"
                    }
                }
            });
        </script>
html;

        $id_custom = MasterDom::getSession('customer_id');

        $mail2smsOption = '';
        $mail = mail2smsDao::getAll();
        foreach ($mail as $key => $value) {
            $mail2smsOption .= "<option value=".$value['mail2sms_id'].">".$value['mail']."</option>";
        }

        View::set('mail2smsOption',$mail2smsOption);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("mail2sms_delete");
    }

    public function delete_mail2sms(){
        MasterDom::verificaUsuario();
        if (empty($_POST)) header('location:/Mail2sms/mostrar');

        $mail2sms_id = MasterDom::getData('mail');
        
            if (empty($mail2sms_id)) {
                header('location:/Mail2sms/delete');
            } else{
                mail2smsDao::delete($mail2sms_id);
                $registro = $this->registroUsuario("Actualizo status mail2sms id:{$mail2sms_id}");
                mail2smsDao::registroUsuario($registro);
                header('location:/Mail2sms/mostrar/'); //exito
            }

    }

    public function mostrar(){

        MasterDom::verificaUsuario();
        $id_custom = MasterDom::getSession('customer_id');

        $extraHeader =<<<html
<link href="/css/magicsuggest-min.css" rel="stylesheet">
<link rel="stylesheet" href="/css/validate/screen.css">
html;
        $extraFooter =<<<html
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--jQuery validate -->
<script src="/js/magicsuggest-min.js"></script>
<script src="/js/validate/jquery.validate.js"></script>

html;

        $data_allTable = '';
        $mails = mail2smsDao::getAll();
        foreach ($mails as $key => $value) {

            $data_allTable .= " <tr>
                                    <!--td><input type='checkbox' name='borrar[]' value='{$value['mail2sms_id']}'/></td-->
                                    <td>{$value['created']}</td>
                                    <td>{$value['mail']}</td>
                                    ";

            $sc_id = mail2smsDao::getCCSC($value['mail2sms_id']);
            $shortcode = '';
            foreach ($sc_id as $key => $value1) {
                $allShortCode = mail2smsDao::getShortCodeAndCarrierId($value1['carrier_connection_short_code_id']);

                foreach ($allShortCode as $key => $value2) {
                    $short_code = $value2['short_code'];
                    $carrier = $value2['name'];
                    $shortcode .= " | ".$short_code." - ".$carrier." | - ";
                }
            }
            $shortcode = trim($shortcode,"- ");
            
            $data_allTable .="      <td>{$shortcode}</td>
                                    <td>{$value['detalle']}</td>
                                    <td class='center'><a href='/Mail2sms/edit/".$value['mail2sms_id']."' type='button' class='btn btn-primary btn-circle center-block'><i class='fa fa-pencil-square-o'></i></a></td>
                                </tr>";
        }


        View::set('table',$data_allTable);
        View::set('header',$this->_contenedor->header($extraHeader));
        View::set('footer',$this->_contenedor->footer($extraFooter));
        View::render("mail2sms_all");
    }

        public function delete_mail2smsList(){
        if(!$_POST)
            return $this->alertas('error_general');

        $row = MasterDom::getDataAll('borrar');
        if(count($row) < 1 OR empty($row))
            return $this->alertas('error_general');

        foreach($row AS $value){
            $id = (int)$value;
            if($value == '')
                continue;
            if(mail2smsDao::delete($id) === false)
                {return $this->alertas('error_borrar');}
            else
                {$registro = $this->registroUsuario("Elimino mail2sms_id {$id}");
                                mail2smsDao::registroUsuario($registro);}
        }

        return $this->alertas('success_delete');

        // header('location:/badword/mostrar/'); //exito

    }


     private function alertas($caso = 'error_general'){

        $class = 'danger';
        $mensaje = '';
        if($caso == 'success_add'){
            $mensaje = 'Se creo exitosamente.';
            $class = 'success';
        }elseif($caso == 'error_general')
            $mensaje = 'Lo sentimos ocurrio un error.';
        elseif($caso == 'success_delete'){
            $mensaje = 'Borro con exito.';
            $class = 'success';
        }elseif($caso == 'success_edit'){
            $mensaje = 'Se modifo con éxito.';
            $class = 'success';
        }elseif($caso == 'error_borrar')
            $mensaje = 'Lo sentimos ocurrio un error al tratar de borrar el elemento.';
        else
            $mensaje = 'Ocurrió algo inesperado.';

        View::set('regreso','/Mail2sms/mostrar');
        View::set('class', $class);
        View::set('titulo','Mail2sms');
        View::set('mensaje', $mensaje);
        View::render("mensaje");
    }

    function registroUsuario($accion){
      $id_usuario = $_SESSION['id_user'];
      $nickname = $_SESSION['usuario'];
      $customer = $_SESSION['name_customer'];
      $script = explode("/", $_SERVER["REQUEST_URI"]);
      $ip = $_SERVER['REMOTE_ADDR'];
      $modulo = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

      $registro = new \stdClass;
      $registro->_id_usuario = $id_usuario;
      $registro->_nickname = $nickname;
      $registro->_customer = $customer;
      $registro->_script = $script[1];
      $registro->_ip = $ip;
      $registro->_modulo = $modulo;
      $registro->_accion = $accion;
      return $registro;
    }


}