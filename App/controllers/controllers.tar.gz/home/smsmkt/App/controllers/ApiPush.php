<?php
namespace App\controllers;
//defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiPush AS ApiPushDao;
use \App\models\SmsPush AS SmsPushDao;

class ApiPush{

  private $_contenedor;

  function __construct(){

  }

  public function index(){

    View::render("smspush_add");
  }

  public function submitJson(){
    $input = file_get_contents("php://input");
    
    $jsonDecode = json_decode($input, 1);

    $card = $this->isArrayEmpty($jsonDecode['card']);
    $acceso = $this->isArrayEmpty($jsonDecode['acceso']);

    // Validar que los arreglos esten llenos
    $statusArrays = ($acceso != 0 AND $card != 0) ? 1 : 0;

    if($statusArrays == 1)
      echo $this->sendPush($jsonDecode);
    else
      echo json_encode(array("error"=>"Lo sentimos al parecer falta algun parametro"));
  }

  public function subminJsonMulti(){
    $input = file_get_contents("php://input");
    $json = json_decode($input, 1);
    
    $card = $this->isArrayEmpty($json['card']);
  }

  public function SubmitMultiJson(){
    echo "****";
  }

  public function jsonMulti(){
    echo "1";
  }

  public function sendPushNotification($tokenDispositivo){
    print_r($tokenDispositivo);
    exit;
    $registrationIds = array($tokenDispositivo);

    if($dispositivo == "IOS"){
      $msg = array( 
        'title' => "Santander informa", 
        'body' => "Bienvenido IOS Notificaciones", 
        'action' => 1, 
        'vibrate'=> 1, 
        'sound' => 1
      );

      $fields = array( 
        'registration_ids' => $registrationIds, 
        'notification' => $msg, 
        'priority' => "high"
      );

      $headers = array(
        'Authorization: key=AIzaSyD9xIH06QzDD5BKgN44eC49e3igTkNXtXw',
        'Content-Type: application/json'
      );
    }else{
      $msg = array( 
        'message' => "Bienvenido Notificaciones", 
        'title' => 
        "Android informa", 
        'action' => 3, 
        'vibrate'=> 1, 
        'sound' => 1
      );

      $dataJ['data'] = $msg;

      $fields = array(
        'registration_ids' => $registrationIds, 
        'data'  => $dataJ,
        'priority' => "high", 
        "content_available" => true
      );

      $headers = array(
        'Authorization: key=AIzaSyDNyxkuNGU_u2KwzeTwWjqQgwPG01xa39A',
        'Content-Type: application/json'
      );
    }

    $inject = $this->injectCurl( json_encode( $fields ) );
    return $inject;
  }

  public function injectCurl($json){
    //$json = json_encode( $fields );
    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, $json );
    $result = curl_exec($ch );
    curl_close( $ch );

    $resultado = json_decode($result, 1);
    $success = $resultado['success'];

    if($success == 1)
      $val = array("success"=>"add to queue");
    else
      $val = array("error"=>"Lo sentimos ha ocurrido un problema");

    return json_encode($val);
  }

  public function sendPushNotification($divice, $token, $msg){
    if($divice == "ANDROID"){
      $msg = array(
        'title' => 'Mensaje de prueba',
        'body' => "Este es un mensaje de prueba enviado a los usuario de android",
        'action' => 1,
        'vibrate' => 1,
        'sound' =>1
      );

      $fields = array(

      );
    }
  }

  public function sendPush( $jsonDecode ){
    $tipo = $jsonDecode['card']['tipo'];
    $registrationIds = array($jsonDecode['card']['destination']);

    $validacion = $this->validateAccess($jsonDecode['acceso']['token'], $jsonDecode['acceso']['user'], $jsonDecode['acceso']['password']);
    if($validacion == 1){
    
      if($tipo == "IOS"){
        $msg = array( 
          'title' => "Santander informa", 'body' => "Bienvenido IOS Notificaciones", 'action' => 1, 'vibrate'=> 1, 'sound' => 1
        );

        $fields = array( 
          'registration_ids' => $registrationIds, 'notification'  => $msg, 'priority' => "high"
        );

        $headers = array(
          'Authorization: key=AIzaSyD9xIH06QzDD5BKgN44eC49e3igTkNXtXw',
          'Content-Type: application/json'
        );
      }else{
        $msg = array( 
          'message' => "Bienvenido  Notificaciones", 'title' => "Android informa", 'action' => 3, 'vibrate'=> 1, 'sound' => 1
        );

        $dataJ['data'] = $msg;

        $fields = array( 
          'registration_ids' => $registrationIds, 'data'  => $dataJ, 'priority' => "high", "content_available" => true
        );

        $headers = array(
          'Authorization: key=AIzaSyDNyxkuNGU_u2KwzeTwWjqQgwPG01xa39A',
          'Content-Type: application/json'
        );
      }
      $json = json_encode( $fields );
      $ch = curl_init();
      curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
      curl_setopt( $ch,CURLOPT_POST, true );
      curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
      curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
      curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
      curl_setopt( $ch,CURLOPT_POSTFIELDS, $json );
      $result = curl_exec($ch );
      curl_close( $ch );

      $resultado = json_decode($result, 1);
      $success = $resultado['success'];

      if($success == 1)
        $val = array("success"=>"add to queue");
      else
        $val = array("error"=>"Lo sentimos ha ocurrido un problema");
    }else{
      $val = $validacion;
    }

    return json_encode($val);
  }

  // Regresa el estatus en 1, si el array esta lleno
  public function isArrayEmpty($array) {
    if(!empty($array)){
      $statusArray = 0;
      $countKeyArray = count($array);
      $sumValueSuccess = array();

      foreach ($array as $key => $value) {
        if(!empty($key) AND !empty($value))
          array_push($sumValueSuccess, 1);
        else
          array_push($sumValueSuccess, 0);
        
      }

      $status = (array_sum($sumValueSuccess) == $countKeyArray) ? 1 : 0;
    }else{ 
      $status = 0;
    }
    return $status;
  }

  // Regresa 1 si los dos array estan llenos
  public function arraySuccess($arrayCard, $arrayAcceso){
    return ($arrayCard == $arrayAcceso) ? 1 : 0;
  }

  public function validateAccess($token, $user, $password){
    $tokenId = "dhun1n2edc2bui2b3urfiy89ghuiuif3biu8773i2ibuf2b3rbi2y3bhihdua";
    $userId = "airmovil";
    $pwdId = "password123456789password";

    $msg = array();

    if($tokenId != $token)
      array_push($msg, array("error"=>"El token no es valido para realizar el envio del mensaje push."));
    if($userId != $user)
      array_push($msg, array("error"=>"El usuario no es valido para realizar el envio del mensaje push."));
    if($pwdId != $password)
      array_push($msg, array("error"=>"El password no es valido para realizar el envio del mensaje push."));
    
    if(count($msg) > 0)
      return $msg;
    else
      return 1;
    
  }

}

