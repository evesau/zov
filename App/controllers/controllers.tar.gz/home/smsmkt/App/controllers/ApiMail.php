<?php
namespace App\controllers;
defined("APPPATH") OR die("Access denied");

use \Core\View;
use \Core\MasterDom;
use \App\controllers\Contenedor;
use \App\models\ApiMail AS ApiMailDao;
include_once "/home/smsmkt/public/PHPMailer/PHPMailerAutoload.php";

class ApiMail{

    private $_contenedor;

    /*API Doppler Relay*******************************/
    private $_host_doppler_relay = 'http://api.dopplerrelay.com/accounts/';
    private $_api_key_relay='0xaihnrn4pr0jkady17vjyv48kjedg';
    private $_usuario_doppler_relay = '491';
    private $_url_peticion_relay;
    private $_fromEmail = "jorge.manon@airmovil.com";
    private $_fromName = "Jorge";
    private $_subject = "Test Doppler Relay";
    /***********************************************/

    function __construct(){
      $this->_url_peticion = $this->_host_doppler.''.$this->_usuario_doppler;
      $this->_url_peticion_relay = $this->_host_doppler_relay.''.$this->_usuario_doppler_relay; 
    }

    public function enviar($data){
      $url = "$this->_url_peticion_relay/messages?api_key=$this->_api_key_relay";
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
      curl_setopt($ch, CURLOPT_HTTPHEADER,array('Accept: application/json','Content-Type: application/json'));
      $response = json_decode(curl_exec($ch));
      curl_close($ch);
      return $response;
    }

    public function createReportJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_start_date = $input['card']['start_date'];
      $request->_end_date = $input['card']['end_date'];
      $request->_customer = $input['card']['customer'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);
      
      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/
      if( $vacio == 0 && $valido == 0 ){
          $data = array(
            'start_date' => $request->_start_date,
            'end_date' => $request->_end_date,
            'api_key' => $this->_api_key_relay
          );

          $ch = curl_init();
          curl_setopt_array($ch, array(
              CURLOPT_URL => "https://api.dopplerrelay.com/reports/reportrequest",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYmYiOjE1MTU1MjIwNjQsImV4cCI6MTUxODExNDA2NCwiaWF0IjoxNTE1NTIyMDY0LCJpc3MiOiJodHRwOi8vYXBpLmRvcHBsZXJyZWxheS5jb20iLCJzdWIiOjQ5MSwidW5pcXVlX25hbWUiOiJqb3JnZS5tYW5vbkBhaXJtb3ZpbC5jb20iLCJyZWxheV9hY2NvdW50cyI6WyJhaXJtb3ZpbCJdLCJyZWxheV90b2tlbl92ZXJzaW9uIjoiMS4wLjAtYmV0YTUiLCJpbXBlcnNvbmF0ZWRfYnkiOm51bGx9.EdWF9UiRRXH7FIGklYccJhd1s1QrG4K2_m2qpR76GadcK2ToCxreCIp1znZJCPxOzWrTm-qia4O25WDy-VYiHxTcMlk5d1F-iOx3ZUgOJO0FPzP6jy6U8V0p7LT-tceDdwGmAXd_avzcNR8LzfsNzCgjfxawoKR7ZPsj91JTU6FWRTznRFWqgzVBYA-xUccdiFJltncOCfCvNaHt7TZUXXzJ8SLwtgTJGDjtV36fuXYgGp9zXxXtShol5RWmslIL6SrC7Qn8eN0UODxT2KkOM_QYZ7lUR5nQLggeYNfhNQC5L2WYSGkxrw5R72j9xRAwGpKSqXAZ0lt0xV5cC6sd2g","content-type: application/json"
              )
          ));
          $response = json_decode(curl_exec($ch));
          $err = curl_error($ch);
          curl_close($ch);
          if($response->errors[0]->detail != '' || $response->detail != ''){
            if($response->detail != ''){
              echo json_encode(array('Error' => $response->detail));
            }elseif ($response->errors[0]->detail != '') {
              echo json_encode(array('Error' => $response->errors[0]->detail));
            }
          }else{
            $request->_reportId = $response->createdResourceId;
            ApiMailDao::insertReport($request);
            echo json_encode(array('success' => 'success', 'reportId' => $request->_reportId));
          }
      }else{
          $error = MasterDom::alertsService($vacio);
          if($error == ''){
            echo json_encode(MasterDom::alertsService($valido));
          }else{
            echo json_encode($error);
          }
      }
    }

    public function downloadReportJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_reportId = $input['card']['reportId'];
      $request->_customer = $input['card']['customer'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);
      
      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => "http://api.dopplerrelay.com/reports/reportrequests?api_key=$this->_api_key_relay",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "",
          ));
          $response = json_decode(curl_exec($ch));
          $err = curl_error($ch);
          curl_close($ch);
          
          if ($err) {
            echo "Error: ".$err;
          }else{
            if($response->errors[0]->detail != '' || $response->detail != ''){
              if($response->detail != ''){
                echo json_encode(array('Error' => $response->detail));
              }elseif ($response->errors[0]->detail != '') {
                echo json_encode(array('Error' => $response->errors[0]->detail));
              } 
            }else{
              //echo $response;
              foreach ($response->items as $key => $value) {
                if($value->id == $request->_reportId){
                  $url = json_encode(array('success' => 'success', 'file_path' => $value->file_path));
                }
              }

              if($url != ''){
                echo $url;
              }else{
                echo json_encode(array('Error' => 'No se encontro el reporte' ));
              }
            }
          }
        }else{
            $error = MasterDom::alertsService($vacio);
            if($error == ''){
              echo json_encode(MasterDom::alertsService($valido));
            }else{
              echo json_encode($error);
            }
        }
    }

    public function crearToken($fecha, $user, $password){
      $fecha1 = md5($fecha);
      $fecha2 = md5($fecha1);
      $username = md5("$user-$password");
      return md5("$username-$fecha2");
    }

    public function SubmitJson(){

      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_campaign = $input['card']['campaign'];
      $request->_customer = $input['card']['customer'];
      $request->_destination = $input['card']['destination'];
      $request->_plantilla = $input['card']['plantilla']['base64_content'];
      $request->_content_type = $input['card']['attachment']['content_type'];
      $request->_base64_content = $input['card']['attachment']['base64_content'];
      $request->_filename = $input['card']['attachment']['filename'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));


      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);
      
      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
          $data = array(
              "from_name" => $this->_fromName, 
              "from_email" => $this->_fromEmail, 
              "subject" => $this->_subject,
              "text" => "Hola Mundo", 
              "html" => "Hola Mundo",
              "recipients" => array(
                array( 
                   "email" => $request->_destination, 
                   "name" => "", 
                   "type" => "to" 
                 )
              ),
              "attachments" =>array(
                array(
                  "content_type" => $request->_content_type,
                  "base64_content" => $request->_base64_content,
                  "filename" => $request->_filename
                )
              )
            );

            $response= $this->enviar($data);
            //print_r($response);

            if($response->errors[0]->detail != '' || $response->detail != ''){
              if($response->detail != ''){
                echo json_encode(array('Error' => $response->detail));
              }elseif ($response->errors[0]->detail != '') {
                echo json_encode(array('Error' => $response->errors[0]->detail));
              }
              
            }else{
              if($response->createdResourceId != ''){
                $suscriptor = ApiMailDao::getSuscriptorByEmail($request->_destination);
                if(count($suscriptor) > 0){
                  $request->_suscriptor_id = $suscriptor[0]['doppler_suscriptor_id'];
                }else{
                  $suscriptor = new \stdClass();
                  $suscriptor->_email = $request->_destination;
                  $request->_suscriptor_id = ApiMailDao::insertSuscriptor($suscriptor);
                }
                ApiMailDao::insertCampaignSend($request);
                echo json_encode(array('success'=>'add to queue'));
              }
            }

	          
              
        }else{
            $error = MasterDom::alertsService($vacio);
            if($error == ''){
              echo json_encode(MasterDom::alertsService($valido));
            }else{
              echo json_encode($error);
            }
        }        
    }

    public function SubmitMultiJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
        $request = new \stdClass();
        $request->_campaign = $input['card']['campaign'];
        $request->_customer = $input['card']['customer'];
        $request->_destination = $input['card']['destination'];
        $request->_plantilla = $input['card']['plantilla']['base64_content'];
        $request->_content_type = $input['card']['attachment']['content_type'];
        $request->_base64_content = $input['card']['attachment']['base64_content'];
        $request->_filename = $input['card']['attachment']['filename'];
        $request->_token = $input['acceso']['token'];
        $request->_fecha = $input['acceso']['fecha'];
        $request->_user = $input['acceso']['user'];
        $request->_password = $input['acceso']['password'];
        MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));
        $destination = array();

        $request->_fecha = date('Y-m-d H:i:s');
        $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

        $vacio = MasterDom::isArrayEmpty($input);
        $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);

        if( $vacio == 0 && $valido == 0 ){
            foreach ($request->_destination as $key => $value) {

              $suscriptor = ApiMailDao::getSuscriptorByEmail($request->value);
              if(count($suscriptor) > 0){
                $request->_suscriptor_id = $suscriptor[0]['doppler_suscriptor_id'];
              }else{
                $suscriptor = new \stdClass();
                $suscriptor->_email = $value;
                $request->_suscriptor_id = ApiMailDao::insertSuscriptor($suscriptor);
              }
              ApiMailDao::insertCampaignSend($request);
              array_push($destination, array("email" => $value,"name" => "","type" => "to"));
            }

            $data = array(
              "from_name" => $this->_fromName, 
              "from_email" => $this->_fromEmail, 
              "subject" => $this->_subject,
              "text" => html_entity_decode($request->_plantilla), 
              "html" => $request->_plantilla,
              "recipients" => $destination,
              "attachments" =>array(
                array(
                  "content_type" => $request->_content_type,
                  "base64_content" => $request->_base64_content,
                  "filename" => $request->_filename
                )
              )
            );

            $response= $this->enviar($data);

            if($response->errors[0]->detail != '' || $response->detail != ''){
              if($response->detail != ''){
                echo json_encode(array('Error' => $response->detail));
              }elseif ($response->errors[0]->detail != '') {
                echo json_encode(array('Error' => $response->errors[0]->detail));
              }
              
            }else{
              if($response->createdResourceId != ''){
                echo json_encode(array('success'=>'add to queue'));
              }else{
                echo json_encode(array('error'=> $response->errors[0]->detail));
              }
            }
            
        }else{
            $error = MasterDom::alertsService($vacio);
            if($error == ''){
              echo json_encode(MasterDom::alertsService($valido));
            }else{
              echo json_encode($error);
            }
        }  
    }

    public function SubmitListJson(){

      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
        $request = new \stdClass();
        $request->_campaign = $input['card']['campaign'];
        $request->_customer = $input['card']['customer'];
        $request->_list = $input['card']['list'];
        $request->_plantilla = $input['card']['plantilla']['base64_content'];

        $request->_content_type = $input['card']['attachment']['content_type'];
        $request->_base64_content = $input['card']['attachment']['base64_content'];
        $request->_filename = $input['card']['attachment']['filename'];

        $request->_token = $input['acceso']['token'];
        $request->_fecha = $input['acceso']['fecha'];
        $request->_user = $input['acceso']['user'];
        $request->_password = $input['acceso']['password'];
        MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

        $request->_fecha = date('Y-m-d H:i:s');
        $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

        $vacio = MasterDom::isArrayEmpty($input);
        $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);

        if( $vacio == 0 && $valido == 0 ){
            $suscriptores = ApiMailDao::getSuscriptorByListId($request->_list);
            $destination = array();
            foreach ($suscriptores as $key => $value) {
              array_push($destination, array("email" => $value['email'],"name" => $value['nombre'],"type" => "to"));
            }

            $data = array(
              "from_name" => $this->_fromName, 
              "from_email" => $this->_fromEmail, 
              "subject" => $this->_subject,
              "text" => html_entity_decode($request->_plantilla), 
              "html" => $request->_plantilla,
              "recipients" => $destination,
              "attachments" =>array(
                array(
                  "content_type" => $request->_content_type,
                  "base64_content" => $request->_base64_content,
                  "filename" => $request->_filename
                )
              )
            );
            $response= $this->enviar($data);
            if($response->errors[0]->detail != '' || $response->detail != ''){
              if($response->detail != ''){
                echo json_encode(array('Error' => $response->detail));
              }elseif ($response->errors[0]->detail != '') {
                echo json_encode(array('Error' => $response->errors[0]->detail));
              }
              
            }else{
              $request->_createdResourceId = $response->createdResourceId;
              if($request->_createdResourceId != ''){

                ApiMailDao::insertCampaignList($request);
                ApiMailDao::insertCampaignAttachment($request);
                echo json_encode(array('success'=>'add to queue'));
              }else{
                echo json_encode(array('error'=> $response->errors[0]->detail));
              }
            }            
        }else{
            $error = MasterDom::alertsService($vacio);
            if($error != ''){
              echo json_encode($error);
            }else{
              echo json_encode(MasterDom::alertsService($valido));
            }
        }
    }

    public function CreateListJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_customer = $input['card']['customer'];
      $request->_name = $input['card']['name'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
        $id = ApiMailDao::insertList($request);
        echo json_encode(array('success' => 'success', 'id' => $id));
      }else{
          $error = MasterDom::alertsService($vacio);
          if($error == ''){
            echo json_encode(MasterDom::alertsService($valido));
          }else{
            echo json_encode($error);
          }
      }
    }

    public function addListJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_customer = $input['card']['customer'];
      $request->_id = $input['card']['id'];
      $request->_destination = $input['card']['destination'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
          $lista = ApiMailDao::getListById($request->_id);
          if(count($lista) > 0){
            $datos = new \stdClass();
          $datos->_doppler_list_id = $request->_id;
          foreach ($request->_destination as $key => $value) {
            $datos->_email = $value;
            $datos->_doppler_suscriptor_id = ApiMailDao::insertSuscriptor($datos);
            ApiMailDao::addSuscriptorList($datos);
          }
          $count = ApiMailDao::getCountListById($datos->_doppler_list_id);
          echo json_encode(array('success'=>'success', 'count'=>$count['count']));
        }else{
          echo json_encode(MasterDom::alertsService(-6));
        }
      }else{
          $error = MasterDom::alertsService($vacio);
            if($error == ''){
              echo json_encode(MasterDom::alertsService($valido));
            }else{
              echo json_encode($error);
            }
      } 
    }

    public function allListJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_customer = $input['card']['customer'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
          $listas = array();
           foreach(ApiMailDao::getListByCustomer($request->_customer) AS $keyList => $valueList){
              array_push($listas, array('id'=>$valueList['doppler_list_id'], 'name'=>$valueList['nombre'], 'count'=>$valueList['count']));
           }
           echo json_encode(array('listas' => $listas));
         }else{
              $error = MasterDom::alertsService($vacio);
            if($error == ''){
              echo json_encode(MasterDom::alertsService($valido));
            }else{
              echo json_encode($error);
            }
         }
    }
    
    public function listJson(){
      $input = json_decode(file_get_contents("php://input"), 1);
      MasterDom::validateIp($input['acceso']['user']);
      $request = new \stdClass();
      $request->_customer = $input['card']['customer'];
      $request->_id = $input['card']['id'];
      $request->_token = $input['acceso']['token'];
      $request->_fecha = $input['acceso']['fecha'];
      $request->_user = $input['acceso']['user'];
      $request->_password = $input['acceso']['password'];
      MasterDom::validatePermission($request->_user, $request->_customer, MasterDom::getData('url'));
      $destination = array();

      $request->_fecha = date('Y-m-d H:i:s');
      $request->_token = $this->crearToken($request->_fecha, $request->_user, $request->_password);

      /*inicializacion de las variables para pruebas*/
      $vacio = MasterDom::isArrayEmpty($input);
      $valido = MasterDom::validarToken($request->_fecha, $request->_user, $request->_password, $request->_token);
      /**********************************************/

      if( $vacio == 0 && $valido == 0 ){
        foreach (ApiMailDao::getSuscriptors($request) as $key => $value) {
           array_push($destination, $value['email']);
        }

        echo json_encode(array('destination' => $destination));
      }else{
          $error = MasterDom::alertsService($vacio);
          if($error == ''){
            echo json_encode(MasterDom::alertsService($valido));
          }else{
            echo json_encode($error);
          }
      }
    }
}